import { DetectionParams } from '../../models/config.model';
import { WallSegment } from '../../models/wall.model';
import { RedressementDiag } from '../../constants/vanishing-points.const';
import { WallsImportPayload } from '../../models/project.model';
import { SelectionBox } from '../../models/geometry.types';
import { PhotoLayerData } from '../../constants/photo-homography.const';
import { WallMergeReport } from '../../constants/wall-merge.const';
import { PhotoLayerImport } from '../shared/photo-layer-modal/photo-layer-modal.component';
import * as i0 from "@angular/core";
export declare class ScannerComponent {
    initialParams: import("@angular/core").InputSignal<Partial<DetectionParams>>;
    showControls: import("@angular/core").InputSignal<boolean>;
    showTabs: import("@angular/core").InputSignal<boolean>;
    wallsDetected: import("@angular/core").OutputEmitterRef<WallsImportPayload>;
    paramsChanged: import("@angular/core").OutputEmitterRef<DetectionParams>;
    opencvReady: import("@angular/core").OutputEmitterRef<void>;
    private canvasSrcRef;
    private canvasBinRef;
    private canvasResRef;
    private canvasWrapperRef;
    protected readonly isOpenCvReady: import("@angular/core").WritableSignal<boolean>;
    protected readonly isProcessing: import("@angular/core").WritableSignal<boolean>;
    protected readonly activeTab: import("@angular/core").WritableSignal<"src" | "bin" | "res">;
    protected readonly currentMode: import("@angular/core").WritableSignal<"select" | "draw" | "erase" | null>;
    protected readonly wallCount: import("@angular/core").WritableSignal<number>;
    protected readonly params: import("@angular/core").WritableSignal<DetectionParams>;
    protected readonly walls: import("@angular/core").WritableSignal<WallSegment[]>;
    protected readonly selectionBox: import("@angular/core").WritableSignal<SelectionBox>;
    protected readonly hasImage: import("@angular/core").WritableSignal<boolean>;
    protected includeBg: boolean;
    /** Charge utile du redressement/calage, ou `null` tant que l'image n'est pas
     *  passée par l'assistant. C'est la **seule** source d'échelle du scanner. */
    protected readonly photo: import("@angular/core").WritableSignal<PhotoLayerData | null>;
    /** L'assistant « redresser et caler » est-il ouvert ? */
    protected readonly showPhotoWizard: import("@angular/core").WritableSignal<boolean>;
    /**
     * Fichier chargé dans le scanner, transmis tel quel à l'assistant de
     * redressement.
     *
     * Sans lui, l'assistant redemandait « choisissez un fichier » alors que la
     * photo était déjà à l'écran : il fallait retrouver et re-sélectionner la même
     * image pour pouvoir envoyer à l'éditeur. Une étape qui redemande ce qu'on
     * vient de donner passe pour une panne.
     */
    protected readonly fichierSource: import("@angular/core").WritableSignal<File | null>;
    /** Dimensions de l'image sur laquelle la détection a tourné. */
    private readonly tailleAnalysee;
    /** Segments Hough bruts — la seule trace de perspective exploitable. */
    private readonly segmentsBruts;
    /** Résultat de la dernière fusion, affiché sous le bouton. Remis à `null` à
     *  chaque nouvelle détection : un compte-rendu qui survit à ce qu'il décrit
     *  devient un mensonge. */
    protected readonly mergeReport: import("@angular/core").WritableSignal<WallMergeReport | null>;
    /**
     * Distance de raccord, en pixels — réglable, parce qu'elle n'est pas
     * déductible de l'image (cf. `WELD_TOLERANCE_DEFAULT`).
     */
    protected readonly weldTolerance: import("@angular/core").WritableSignal<number>;
    /** Piles d'annulation et de rétablissement des corrections manuelles. */
    private readonly undoStack;
    private readonly redoStack;
    protected readonly canUndo: import("@angular/core").Signal<boolean>;
    protected readonly canRedo: import("@angular/core").Signal<boolean>;
    /**
     * Coins du quadrilatère de référence, en coordonnées normalisées — ou `null`
     * quand le dessin ne permet pas de les déduire.
     *
     * Redressement automatique par **points de fuite** : un plan est fait de deux
     * familles de parallèles perpendiculaires, dont la convergence en perspective
     * suffit à retrouver l'orientation de la feuille. On s'appuie sur le DESSIN,
     * qui est toujours entier dans l'image, et non sur le contour du support —
     * lequel sort du champ dès qu'on cadre serré, ce qui avait fait échouer la
     * détection du plus grand quadrilatère.
     *
     * Normalisées : le scanner analyse une réduction de l'image, l'assistant en
     * prépare une autre, et deux espaces de pixels finiraient par diverger.
     */
    protected readonly coinsAuto: import("@angular/core").Signal<{
        x: number;
        y: number;
    }[] | null>;
    /**
     * Ce que le redressement automatique a vu, motif de refus compris.
     *
     * Séparé de `coinsAuto` parce qu'un `null` ne dit pas **pourquoi**, et que
     * c'est justement la question qu'on se pose devant une photo qui n'est pas
     * redressée. Le motif part en console (voir l'effet du constructeur) : sans
     * lui, il n'y a rien à corriger, ni dans les réglages de détection, ni dans la
     * prise de vue.
     */
    protected readonly diagAuto: import("@angular/core").Signal<RedressementDiag>;
    /**
     * L'utilisateur a-t-il explicitement accepté d'exporter sans échelle ?
     *
     * Case décochée à chaque changement d'image : accepter une fois ne doit pas
     * valoir acceptation pour la photo suivante, sans quoi l'avertissement
     * deviendrait une formalité qu'on coche et qu'on oublie.
     */
    protected readonly acceptUncalibrated: import("@angular/core").WritableSignal<boolean>;
    private readonly opencvSvc;
    private readonly wallDetectionSvc;
    private readonly geometrySvc;
    private readonly photoSvc;
    private readonly destroyRef;
    protected readonly activeWalls: import("@angular/core").Signal<WallSegment[]>;
    /** Ce que le scanner sait de son échelle — y compris qu'il n'en sait rien. */
    protected readonly scale: import("@angular/core").Signal<import("g-plan").ScannerScale>;
    /**
     * Étendue réelle des murs retenus, en mètres.
     *
     * Affichée parce que c'est le seul contrôle de vraisemblance qu'un
     * diagnostiqueur puisse faire d'un coup d'œil avant d'envoyer quoi que ce
     * soit : un séjour qui sort à 40 m de large se voit, un `pixelsPerMeter`
     * faux ne se voit pas.
     */
    protected readonly extent: import("@angular/core").Signal<{
        widthM: number;
        heightM: number;
    } | null>;
    /**
     * L'export est **refusé** sans calage, tant que l'utilisateur n'a pas accepté
     * en connaissance de cause. C'est le critère d'acceptation de la brique C :
     * sans calage, le scanner refuse ou avertit — jamais il n'invente une échelle
     * en silence.
     */
    protected readonly canExport: import("@angular/core").Signal<boolean>;
    /** Image analysée : la photo chargée, ou le **canvas redressé** quand l'image
     *  est passée par l'assistant. Un canvas et une image se dessinent de la même
     *  façon, et la détection ne voit pas la différence. */
    private sourceImage;
    private isDragging;
    private drawingStart;
    /** Dernier message de redressement écrit en console — pour ne pas le répéter
     *  à chaque recalcul, un curseur de réglage se traînant en continu. */
    private dernierDiag;
    constructor();
    setTab(tab: 'src' | 'bin' | 'res'): void;
    /**
     * Chargement direct d'une image, **sans redressement ni calage**.
     *
     * Ce chemin reste ouvert : le scanner sert aussi à dégrossir un tracé qu'on
     * cotera ensuite au mur (brique A). Mais il repart d'une échelle inconnue —
     * `photo` est remis à `null`, donc `scale()` bascule sur le repli et
     * l'avertissement, et l'acceptation antérieure de l'utilisateur est annulée.
     */
    onFileSelected(event: Event): void;
    openPhotoWizard(): void;
    closePhotoWizard(): void;
    /**
     * Reprend la photo redressée et calée par l'assistant, et la substitue à
     * l'image analysée.
     *
     * L'ordre compte : le redressement a lieu **avant** la détection, jamais
     * après. Redresser des segments déjà détectés reviendrait à corriger la
     * perspective sur des traits que la perspective avait déjà fusionnés ou
     * fragmentés — les seuils de la détection (épaisseur de mur, longueur
     * minimale) sont exprimés en pixels et n'ont de sens que sur une image plane.
     *
     * La rotation manuelle reste applicable par-dessus : c'est une isométrie,
     * elle ne change aucune longueur, donc pas l'échelle.
     */
    onPhotoImport(imp: PhotoLayerImport): Promise<void>;
    onParamChange(key: keyof DetectionParams, event: Event): void;
    triggerProcess(): void;
    private process;
    private drawRotated;
    setMode(mode: 'select' | 'draw' | 'erase'): void;
    onCanvasMouseDown(event: MouseEvent): void;
    onCanvasMouseMove(event: MouseEvent): void;
    onCanvasMouseUp(event: MouseEvent): void;
    private getCanvasCoords;
    private finishDraw;
    /**
     * Gomme — **et son contraire** : recliquer sur un mur effacé le rétablit.
     *
     * Le code posait déjà une bascule (`ignored: !w.ignored`), mais elle était
     * **inatteignable** : la recherche du mur le plus proche écartait d'emblée les
     * murs ignorés (`if (w.ignored) return`). Effacer était donc définitif, et il
     * fallait redessiner le mur au crayon — signalé à l'usage.
     *
     * La recherche se fait en deux temps, et l'ordre compte : d'abord parmi les
     * murs **actifs**, et seulement s'il n'y en a aucun sous le curseur, parmi les
     * effacés. Sinon un mur effacé passant sous un mur actif serait rétabli à la
     * place de celui qu'on visait — la gomme deviendrait imprévisible là où le
     * plan est dense, c'est-à-dire aux angles.
     */
    private handleErase;
    /**
     * Mémorise l'état courant **avant** une correction.
     *
     * Appelé par chaque geste qui modifie les murs — gomme, crayon, fusion,
     * nettoyages. Un geste non mémorisé est un geste irréversible, et
     * l'irréversibilité ne se découvre qu'après coup.
     */
    private memoriser;
    protected undo(): void;
    protected redo(): void;
    private appliquerEtat;
    /**
     * `Ctrl/⌘+Z` annule, `Ctrl/⌘+Y` ou `Ctrl/⌘+Maj+Z` rétablit.
     *
     * Écouté sur le document, et non sur le canvas : la correction se fait au
     * pointeur, aucun élément n'a le focus, et exiger un clic préalable pour que
     * le raccourci réponde passerait pour une panne. Neutralisé dès qu'une saisie
     * est en cours — annuler une frappe dans un champ n'est pas annuler un mur.
     */
    protected onKeyDown(event: KeyboardEvent): void;
    /**
     * Fusion propre : aligner, recoller, souder — sur la zone, ou sur tout le plan.
     *
     * Le geste que les outils existants ne couvraient pas. `mergeInSelection`
     * exige une sélection **et** des murs déjà quasi alignés ; celui-ci part de ce
     * que le scanner rend vraiment — des morceaux décalés de quelques pixels, des
     * murs redessinés à la main qui tombent à côté, des croisements qui se ratent.
     *
     * Les tolérances viennent des réglages que l'utilisateur a **déjà posés**
     * (épaisseur de mur, extension) : ce sont exactement les deux distances dont
     * il est question, et un troisième curseur finirait par les contredire.
     *
     * Le rapport est affiché **et** journalisé : une fusion qui déplace un mur de
     * quarante pixels sans le dire retouche le relevé dans le dos de celui qui l'a
     * fait.
     */
    mergeAndAlign(): void;
    /**
     * Tolérances effectives.
     *
     * L'alignement et le recollage restent déduits de l'image (épaisseur de mur,
     * extension) ; **seul le raccord suit le curseur**. Étendre le curseur au
     * recollage reboucherait les passages de porte, qui sont exactement des vides
     * entre deux morceaux alignés — cf. `WELD_TOLERANCE_DEFAULT`.
     */
    private mergeOptions;
    /** Distance de raccord en centimètres réels, ou `null` sans calage. */
    protected readonly weldToleranceCm: import("@angular/core").Signal<number | null>;
    protected onWeldToleranceChange(event: Event): void;
    mergeInSelection(): void;
    cleanIsolatedSegments(): void;
    cleanDanglingSegments(): void;
    private renderFinal;
    private drawConnectionDot;
    private isWallInScope;
    exportWalls(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScannerComponent, "ng-gplan-scanner", never, { "initialParams": { "alias": "initialParams"; "required": false; "isSignal": true; }; "showControls": { "alias": "showControls"; "required": false; "isSignal": true; }; "showTabs": { "alias": "showTabs"; "required": false; "isSignal": true; }; }, { "wallsDetected": "wallsDetected"; "paramsChanged": "paramsChanged"; "opencvReady": "opencvReady"; }, never, never, true, never>;
}
