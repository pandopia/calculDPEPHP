import { AfterViewInit, OnDestroy } from '@angular/core';
import { FloorplanProject } from '../../models/project.model';
import { GeoJsonFeatureCollection, GeoJsonRefus } from '../../services/geojson-export.service';
import { OsmLayer } from '../../constants/map-styles.const';
import * as i0 from "@angular/core";
/** Contenu et position (px, relatifs au conteneur) de l'infobulle ouverte. */
interface Infobulle {
    lngLat: {
        lng: number;
        lat: number;
    };
    x: number;
    y: number;
    /** Libellé métier lisible, repris de la légende du plan. */
    titre: string;
    /** Couleur du trait réellement dessiné, pour la pastille. */
    couleur: string;
    /** Mesure géodésique de l'objet, déjà formatée (`12,4 m`, `36,2 m²`). */
    mesure: string | null;
    lignes: {
        cle: string;
        valeur: string;
    }[];
}
/** Une ligne du récapitulatif des linéaires. */
interface LineaireReseau {
    type: string;
    label: string;
    couleur: string;
    longueurM: number;
    /** Longueur déjà formatée à la française — l'interpolation Angular utilise
     *  la locale par défaut (anglaise) et afficherait « 127.5 » à côté du
     *  « 127,5 » de l'infobulle. */
    longueurTexte: string;
}
/** Un ouvrage posé sur la carte, en pixels écran. */
interface OuvrageRendu {
    id: string;
    dataUrl: string;
    /** Centre de l'emprise, en pixels relatifs au conteneur. */
    x: number;
    y: number;
    /** Dimensions à l'écran de l'emprise, en pixels. */
    largeur: number;
    hauteur: number;
    /** Rotation de l'emprise, en degrés. */
    angle: number;
}
interface NiveauFiltre {
    id: string;
    name: string;
    order: number;
    visible: boolean;
}
/**
 * Vue CARTE — le plan à sa vraie place, sur nos tuiles.
 *
 * Troisième vue à côté de la 2D et de la 3D, et **en lecture seule** comme elle :
 * on regarde, on ne dessine pas. C'est ce choix qui la rend faisable sans
 * toucher au moteur de dessin — une carte vivante *sous* le canvas Fabric
 * imposerait de réécrire le modèle de coordonnées, la navigation, les exports
 * image et toute la suite e2e (cf. `FEATURE-georeferencement-maplibre.md § 4`).
 *
 * Elle ne fait que **consommer** ce que `GeoJsonExportService` produit déjà :
 * géométries WGS84, `bbox`, niveaux, précision et avertissement. Si l'export
 * refuse, la vue affiche le motif au lieu d'une carte — un plan mal ancré
 * affiché sur du satellite serait cru, il n'y a donc aucun mode « forcer ».
 */
export declare class ViewerMapComponent implements AfterViewInit, OnDestroy {
    /** Projet à afficher. Doit être géoréférencé — sinon la vue affiche le motif de refus. */
    readonly project: import("@angular/core").InputSignal<FloorplanProject | null>;
    /** Affiche d'emblée le récapitulatif des linéaires. Alimenté par l'état
     *  « Cotes » de l'éditeur : qui dessine avec les cotes affichées les veut
     *  aussi sur la carte — le redemander à chaque bascule de vue serait du
     *  travail en double. Reste modifiable dans la vue. */
    readonly cotes: import("@angular/core").InputSignal<boolean>;
    /** Émis quand la carte a fini de se charger, ou a échoué. Utile à un hôte qui
     *  veut masquer son propre indicateur de chargement. */
    readonly mapReady: import("@angular/core").OutputEmitterRef<boolean>;
    private readonly mapHost;
    private readonly geojson;
    private readonly projection;
    private readonly config;
    private readonly zone;
    /**
     * Couches proposées.
     *
     * « Vectoriel (alt.) » n'apparaît que s'il diffère réellement du style
     * principal : `config.tileStyle` vaut `styles/osm-bright` par défaut, soit
     * exactement le style de base — les deux entrées pointaient donc la **même
     * URL**, et proposer deux fois la même carte induit en erreur.
     */
    protected readonly couchesDisponibles: {
        id: OsmLayer;
        label: string;
    }[];
    /** Vrai quand le fond courant est vectoriel : la 3D n'a de sens que là. */
    protected readonly fondVectoriel: import("@angular/core").Signal<boolean>;
    /** Le style courant porte-t-il des données de bâtiments ? Renseigné au
     *  chargement du style — sans quoi le bouton n'aurait rien à montrer. */
    protected readonly batimentsDisponibles: import("@angular/core").WritableSignal<boolean>;
    protected readonly vue3D: import("@angular/core").WritableSignal<boolean>;
    /** La 3D est-elle proposable ici et maintenant ? */
    protected readonly peut3D: import("@angular/core").Signal<boolean>;
    /** Satellite par défaut : c'est le fond sur lequel on situe un ouvrage. */
    protected readonly couche: import("@angular/core").WritableSignal<OsmLayer>;
    protected readonly cadastre: import("@angular/core").WritableSignal<boolean>;
    protected readonly erreur: import("@angular/core").WritableSignal<string | null>;
    protected readonly niveaux: import("@angular/core").WritableSignal<NiveauFiltre[]>;
    /** Infobulle de l'objet cliqué. Rendue par CE composant et non par
     *  `maplibregl.Popup` : la feuille de style de MapLibre n'est importée par
     *  aucun hôte, et l'infobulle sortait donc sans mise en forme, en bas de
     *  page, hors de la carte. La nôtre est encapsulée, donc toujours juste. */
    protected readonly infobulle: import("@angular/core").WritableSignal<Infobulle | null>;
    /** Récapitulatif des linéaires, affiché à la demande. */
    protected readonly afficherLineaires: import("@angular/core").WritableSignal<boolean>;
    /** Motifs empêchant l'affichage. Vide = le plan est affichable. */
    protected readonly refus: import("@angular/core").Signal<GeoJsonRefus[]>;
    /** Collection projetée, ou `null` si le plan est refusé. Recalculée à chaque
     *  changement de projet — c'est elle qui alimente la source MapLibre. */
    protected readonly collection: import("@angular/core").Signal<GeoJsonFeatureCollection | null>;
    /**
     * Linéaire développé par type de réseau, en mètres **sol**.
     *
     * Calculé sur la géométrie projetée, par haversine — et non sur la longueur
     * Mercator, qui surestime les distances d'un facteur 1/cos(latitude), soit
     * ~38 % à Toulouse. C'est la mesure que `GEOREF_MESURE_NOTE` recommande à
     * quiconque exploite le GeoJSON ; la vue ne peut pas s'en dispenser
     * elle-même.
     */
    protected readonly lineaires: import("@angular/core").Signal<LineaireReseau[]>;
    protected readonly totalLineaireTexte: import("@angular/core").Signal<string>;
    protected readonly resumePrecision: import("@angular/core").Signal<string>;
    private map;
    private LngLatBounds;
    /** Vrai une fois les sources et couches posées : tout le reste en dépend. */
    private couchesPretes;
    /**
     * Features réellement poussées dans la source, indexées comme leur `id`.
     *
     * Indispensable : `queryRenderedFeatures` rend la géométrie **découpée à la
     * tuile**, pas celle d'origine. Mesurer dessus donnait une longueur qui
     * changeait selon l'endroit cliqué — 185,2 m sur un tronçon pour un tracé de
     * 190,1 m. On remonte donc à la feature source par son identifiant.
     */
    private featuresPoussees;
    /** Ouvrages posés en calque HTML par-dessus la carte. */
    protected readonly ouvrages: import("@angular/core").WritableSignal<OuvrageRendu[]>;
    /** Rasterisation d'un pictogramme par type — `null` = échec mémorisé. */
    private readonly rasters;
    /** URLs d'objets à révoquer : sans cela, chaque ouverture de la vue fuit
     *  une image en mémoire jusqu'au rechargement de la page. */
    private blobsCrees;
    private detruit;
    /** Incohérences de style déjà signalées — inutile de répéter à chaque tuile. */
    private readonly stylesSignales;
    private observateurBandeau;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private initCarte;
    /**
     * Fabrique à la demande les tuiles de motif « numéro de parcelle ».
     *
     * Les numéros visibles ne sont pas connus d'avance ; MapLibre demande chaque
     * image manquante par `styleimagemissing`, on la dessine et on la lui rend.
     * Sans cet écouteur, le `fill-pattern` reste vide — silencieusement.
     */
    private preparerMotifsNumero;
    /**
     * Tient l'attribution au-dessus du bandeau de précision.
     *
     * L'attribution est une **obligation de licence** : la laisser recouverte par
     * notre propre bandeau reviendrait à ne pas l'afficher. Sa hauteur dépend de
     * la longueur du texte et de la largeur de la fenêtre, donc on la **mesure**
     * plutôt que de deviner une constante qui serait fausse un jour sur deux.
     */
    private suivreHauteurBandeau;
    /** Pose la source du plan et ses quatre couches de rendu. */
    private poserCouches;
    /**
     * Pose chaque ouvrage d'assainissement comme **image géoréférencée** sur ses
     * quatre coins, par-dessus son polygone.
     *
     * Un polygone uni dit « il y a quelque chose ici » ; le pictogramme dit
     * *quoi*. Sur une orthophoto, c'est la différence entre une tache colorée et
     * un plan lisible — et c'est le même dessin que sur le plan 2D, donc rien à
     * réapprendre pour l'utilisateur.
     *
     * Le polygone reste dessous : si une image échoue, l'ouvrage ne disparaît pas.
     */
    private poserImagesOuvrages;
    /** Objets du projet groupés par niveau — même lecture que l'exportateur. */
    private niveauxDuProjet;
    /**
     * Recalcule le placement à l'écran de chaque ouvrage.
     *
     * Rendu en HTML par-dessus la carte, et non par une source `image` de
     * MapLibre : celle-ci charge son URL par la couche de requêtes de la
     * bibliothèque, qui n'a jamais peint nos images — sources acceptées, aucune
     * erreur, rien à l'écran. Le calque HTML emprunte le chemin déjà éprouvé par
     * l'infobulle : `map.project()` pour la position, et un simple
     * `rotate`/`scale`, nos emprises étant des rectangles éventuellement pivotés.
     */
    private rafraichirOuvrages;
    /**
     * Rasterise un pictogramme depuis sa **définition**, pas depuis l'objet du
     * plan : la vue carte travaille sur un projet sérialisé, où les primitives
     * Fabric n'existent plus. Tous les ouvrages d'un même type partageant le même
     * dessin, une image par type suffit — d'où le cache.
     */
    private rasterisePictogramme;
    /** Réécrit la source avec les features des niveaux visibles, et recadre. */
    private pousserDonnees;
    /** Recadre sur l'emprise du plan — `bbox` est déjà produite par l'export. */
    private recadrer;
    /** Aligne la liste des niveaux sur le projet, en gardant les cases déjà
     *  décochées par l'utilisateur. */
    private syncNiveaux;
    protected setCouche(id: OsmLayer): void;
    protected toggleCadastre(): void;
    /**
     * Pose le cadastre sous les couches du plan — c'est un fond, pas une donnée.
     *
     * En vectoriel (défaut) : parcelles en contour et bâti en aplat, dans des
     * teintes qui restent lisibles sur une orthophoto sombre. Le trait est net à
     * tous les zooms, là où un raster se pixellise dès qu'on dépasse son niveau
     * natif.
     */
    private poserCadastre;
    protected toggleNiveau(id: string): void;
    protected exporterGeoJson(): void;
    /**
     * Infobulle de l'objet cliqué.
     *
     * Le titre et la couleur viennent de `collectLegendItems`, la **même** source
     * que la légende des exports image : un « PipeEU » brut ne dit rien à qui lit
     * une carte, « Eaux usées » si. Les identifiants techniques sont écartés, et
     * la mesure est calculée en géodésique.
     */
    private montrerInfobulle;
    /**
     * Le style courant déclare-t-il des bâtiments extrudables ?
     *
     * Sans cette vérification, la bascule 3D n'inclinerait qu'un plan vide — et un
     * bouton qui ne fait rien est pire que pas de bouton. Rien ne garantit non
     * plus que le fournisseur de tuiles servira toujours la couche `building`.
     */
    private styleAvecBatiments;
    protected basculer3D(): void;
    /**
     * Applique l'état 3D : inclinaison **et** volumes bâtis, ensemble.
     *
     * Les deux suivent le fond courant. Sur satellite, l'orthophoto porte déjà les
     * toits — des extrusions viendraient s'y superposer en double — et une carte
     * penchée sans rien à montrer laisserait croire à une panne. Le choix de
     * l'utilisateur, lui, reste mémorisé : il retrouve sa 3D en revenant au
     * vectoriel, sans avoir à la réactiver.
     */
    private appliquer3D;
    protected basculerLineaires(): void;
    protected fermerInfobulle(): void;
    /** Recale l'infobulle sur son point géographique après un déplacement. */
    private repositionnerInfobulle;
    /** Position en pixels, relative au conteneur de la carte. */
    private pixels;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewerMapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewerMapComponent, "ng-gplan-viewer-map", never, { "project": { "alias": "project"; "required": false; "isSignal": true; }; "cotes": { "alias": "cotes"; "required": false; "isSignal": true; }; }, { "mapReady": "mapReady"; }, never, never, true, never>;
}
export {};
