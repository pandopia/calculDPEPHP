import { AfterViewInit, OnDestroy } from '@angular/core';
import { HistoryService } from '../../services/history.service';
import { WallsImportPayload, FloorplanProject, ProjectStats, FloorRooms } from '../../models/project.model';
import { EditorMode, InspectorData } from '../../models/floorplan-object.model';
import { PhotoLayerImport } from '../shared/photo-layer-modal/photo-layer-modal.component';
import { ResetPlan } from '../../constants/plan-reset.const';
import { GeoJsonRefus } from '../../services/geojson-export.service';
import { GeoLocation } from '../../models/project.model';
import { ApartmentTemplate } from '../../constants/apartment-templates.const';
import { WorkMode, ToolGroup } from '../../models/floorplan-object.model';
import { PlanSummary } from '../../models/plan-summary.model';
import { PlanOutline } from '../../constants/plan-outline.const';
import * as i0 from "@angular/core";
export declare class PlanEditorComponent implements AfterViewInit, OnDestroy {
    initialWalls: import("@angular/core").InputSignal<WallsImportPayload | null>;
    project: import("@angular/core").InputSignal<FloorplanProject | null>;
    showSidebar: import("@angular/core").InputSignal<boolean>;
    showHeader: import("@angular/core").InputSignal<boolean>;
    canvasHeight: import("@angular/core").InputSignal<number>;
    canvasWidth: import("@angular/core").InputSignal<number>;
    /** Charge automatiquement un fond de carte depuis project.geo au démarrage */
    autoGeoLayer: import("@angular/core").InputSignal<"osm" | "satellite" | null>;
    /** Coordonnées GPS fournies par l'app hôte (mobile / administration) pour
     *  charger automatiquement un fond de carte au démarrage, sans passer par la
     *  modale OSM. `zoom` absent → zoom max (19). `layer` absent → valeur de
     *  `autoGeoLayer` sinon 'satellite'. Prioritaire sur `project.geo`. */
    geoPoint: import("@angular/core").InputSignal<{
        lat: number;
        lng: number;
        zoom?: number;
        layer?: "osm" | "satellite";
        width?: number;
        height?: number;
    } | null>;
    /** Force le mode compact (drawer mobile) même sur grand viewport — utile pour
     *  les conteneurs étroits comme une iframe ou une modal Gordon-PWA. */
    compactMode: import("@angular/core").InputSignal<boolean>;
    /** Mode lecture seule : sélection/zoom/pan possibles, mais aucune création
     *  ni édition d'objet. Utile pour la consultation d'un CRI archivé. */
    readOnly: import("@angular/core").InputSignal<boolean>;
    /** Liste des pièces du CRI à proposer dans l'inspecteur pour lier une pièce
     *  dessinée à une pièce CRI (« cette pièce = Chambre 1 »). */
    criRooms: import("@angular/core").InputSignal<{
        id: string;
        name: string;
    }[]>;
    /** Prélèvements amiante du CRI à positionner. Quand l'outil « Prélèvement » est
     *  actif, chaque clic pose le prochain de la file avec son id/label CRI.
     *  Passer une NOUVELLE référence de tableau pour réinitialiser la file. */
    pendingSamples: import("@angular/core").InputSignal<{
        id: string;
        label: string;
    }[]>;
    projectSaved: import("@angular/core").OutputEmitterRef<FloorplanProject>;
    projectChange: import("@angular/core").OutputEmitterRef<FloorplanProject>;
    statsChanged: import("@angular/core").OutputEmitterRef<ProjectStats>;
    roomsChanged: import("@angular/core").OutputEmitterRef<FloorRooms[]>;
    jpgExported: import("@angular/core").OutputEmitterRef<Blob>;
    pngExported: import("@angular/core").OutputEmitterRef<Blob>;
    svgExported: import("@angular/core").OutputEmitterRef<string>;
    /** Émis une fois le canvas Fabric initialisé — passe l'élément `<canvas>` natif
     *  pour que le parent puisse capturer une vignette à la demande. */
    canvasReady: import("@angular/core").OutputEmitterRef<HTMLCanvasElement>;
    /** Émis à chaque transition de l'état de chargement interne. */
    loadingState: import("@angular/core").OutputEmitterRef<boolean>;
    /** Synthèse structurée du plan, émise (debounce ~500ms) à chaque modification.
     *  Voir aussi la méthode impérative `getPlanSummary()`. */
    summaryChange: import("@angular/core").OutputEmitterRef<PlanSummary>;
    /** Émis quand l'utilisateur lie une pièce dessinée à une pièce CRI. */
    roomLinked: import("@angular/core").OutputEmitterRef<{
        roomId: string;
        criRoomId: string;
        name: string;
    }>;
    /** Émis quand un prélèvement CRI de la file est posé sur le plan. */
    samplePlaced: import("@angular/core").OutputEmitterRef<{
        criSampleId: string;
        label: string;
        position: {
            x: number;
            y: number;
        };
        floorId: string;
    }>;
    private canvasRef;
    /** Conteneur scrollable du canvas — sert à recentrer la vue sur le fond de carte. */
    private canvasAreaRef;
    protected readonly currentMode: import("@angular/core").WritableSignal<EditorMode>;
    protected readonly stats: import("@angular/core").WritableSignal<ProjectStats>;
    protected readonly inspectorData: import("@angular/core").WritableSignal<InspectorData | null>;
    protected readonly showInspector: import("@angular/core").WritableSignal<boolean>;
    protected readonly isLoading: import("@angular/core").WritableSignal<boolean>;
    /**
     * Motif du dernier refus de chargement, affiché à l'utilisateur.
     *
     * Le lot 4 a rendu le lecteur strict : `fromFile` REJETTE désormais dans
     * quantité de cas où il chargeait autrefois un plan à moitié. Sans ce canal,
     * l'échec ne se voyait nulle part — le voile « Chargement… » restait posé
     * indéfiniment et l'éditeur paraissait figé. Un refus motivé est le but du
     * lot ; le taire annulerait ce but.
     */
    protected readonly loadError: import("@angular/core").WritableSignal<string | null>;
    /** Information neutre sur l'échelle — une hypothèse énoncée, pas une erreur. */
    protected readonly scaleNotice: import("@angular/core").WritableSignal<string | null>;
    protected readonly pixelsPerMeter: import("@angular/core").WritableSignal<number>;
    protected readonly showMeasurements: import("@angular/core").WritableSignal<boolean>;
    protected readonly isOsmModalOpen: import("@angular/core").WritableSignal<boolean>;
    protected readonly isPhotoModalOpen: import("@angular/core").WritableSignal<boolean>;
    /** Un calque photo est-il posé sur le niveau courant ? (menu « Fond »). */
    protected readonly hasPhotoLayer: import("@angular/core").WritableSignal<boolean>;
    protected readonly isTemplateModalOpen: import("@angular/core").WritableSignal<boolean>;
    protected readonly calibrationLength: import("@angular/core").WritableSignal<string>;
    protected readonly roomBoxWidthM: import("@angular/core").WritableSignal<string>;
    protected readonly roomBoxHeightM: import("@angular/core").WritableSignal<string>;
    /** Cote relevée au télémètre pour le mur sélectionné (brique A). */
    protected readonly wallDimensionM: import("@angular/core").WritableSignal<string>;
    /**
     * Compte rendu de la dernière cotation — **affiché**, jamais tu.
     *
     * Coter un polygone fermé est un problème surdéterminé : six cotes relevées à
     * la main ne sont jamais exactement compatibles, il reste toujours un écart.
     * Le montrer est la seule façon honnête de livrer la fonction ; le masquer
     * ferait croire à un relevé juste là où le croquis a été arbitré.
     */
    protected readonly dimensionReport: import("@angular/core").WritableSignal<{
        closureCm: number;
        maxResidualCm: number;
        wallCount: number;
        warning: boolean;
    } | null>;
    protected readonly backgroundLocked: import("@angular/core").WritableSignal<boolean>;
    protected readonly bgRotation: import("@angular/core").WritableSignal<number>;
    protected readonly scaleLocked: import("@angular/core").WritableSignal<boolean>;
    protected readonly hasBackdrop: import("@angular/core").WritableSignal<boolean>;
    /**
     * Ancre géographique du plan — l'unique exemplaire vivant, réémis dans chaque
     * projet produit par le composant. Doublé sur `backdrop.data.geo`, qui suit
     * l'image si elle bouge, tandis que celui-ci survit à sa suppression.
     */
    private readonly geoAnchor;
    /**
     * Le plan est-il ancré sur une carte, **de façon exploitable** ? Gèle le
     * curseur d'échelle.
     *
     * La simple présence d'un `geo` ne suffit pas, pour deux raisons distinctes :
     *  - un `geo` fourni par l'app hôte depuis son propre géocodage ne porte que
     *    lat/lng/zoom. Il ne permet aucune projection (`resolveAnchor` renvoie
     *    `null`), donc il ne protège rien — et il gelait pourtant le curseur,
     *    sans même afficher le cadenas qui l'aurait expliqué, puisque
     *    `scaleLocked` reste faux tant qu'aucun fond n'a été posé ;
     *  - une ancre invalide (fond déverrouillé, déplacé, remplacé) ne sert plus à
     *    rien : l'export GeoJSON la refuse. La geler en plus enfermait
     *    l'utilisateur — l'échelle pilote toutes les surfaces affichées, et
     *    aucune action de l'interface ne rendait la main.
     */
    protected readonly isGeoAnchored: import("@angular/core").Signal<boolean>;
    /** Affiche la vue 3D par-dessus le canvas 2D (toggle non destructif). */
    protected readonly show3D: import("@angular/core").WritableSignal<boolean>;
    /** Projet sérialisé passé au viewer 3D — recalculé à chaque entrée en 3D. */
    protected readonly project3D: import("@angular/core").WritableSignal<FloorplanProject | null>;
    /** Vue CARTE (MapLibre, lecture seule) — exclusive de la vue 3D. */
    protected readonly showMap: import("@angular/core").WritableSignal<boolean>;
    protected readonly projectMap: import("@angular/core").WritableSignal<FloorplanProject | null>;
    /** Dernier projet sérialisé, sous forme de signal : c'est lui qui rend
     *  `mapRefus` réactif. `_lastEmittedProject` est un champ ordinaire, lu par
     *  du code impératif ; un `computed` ne pourrait pas en dépendre. */
    private readonly lastProjectSignal;
    /** File des prélèvements CRI restant à poser (pose guidée). Initialisée depuis
     *  l'input `pendingSamples`, consommée tête en premier à chaque pose. */
    protected readonly pendingQueue: import("@angular/core").WritableSignal<{
        id: string;
        label: string;
    }[]>;
    /** Libellés restant à placer — pour le bandeau d'aide. */
    protected readonly remainingSampleLabels: import("@angular/core").Signal<string[]>;
    protected readonly hasAutosave: import("@angular/core").WritableSignal<boolean>;
    protected readonly autosaveTime: import("@angular/core").WritableSignal<string | null>;
    private autosaveInterval;
    private projectChangeTimer;
    protected readonly floors: import("@angular/core").WritableSignal<{
        id: string;
        name: string;
        order: number;
    }[]>;
    protected readonly currentFloorId: import("@angular/core").WritableSignal<string>;
    private floorObjects;
    /** ID du niveau source dont on propose de copier les murs extérieurs. */
    protected readonly copyWallsSourceId: import("@angular/core").WritableSignal<string | null>;
    protected readonly showCopyWallsOffer: import("@angular/core").Signal<boolean>;
    /** Modal d'ajout d'un niveau */
    protected readonly showAddFloorModal: import("@angular/core").WritableSignal<boolean>;
    protected readonly newFloorDirection: import("@angular/core").WritableSignal<"above" | "below">;
    protected readonly newFloorName: import("@angular/core").WritableSignal<string>;
    /** Dropdown "copier depuis" (rétroactif) */
    protected readonly showCopyFromMenu: import("@angular/core").WritableSignal<boolean>;
    /** Modal de confirmation « Réinitialiser le plan ». */
    protected readonly showResetModal: import("@angular/core").WritableSignal<boolean>;
    /** Case « supprimer aussi le fond » de cette modale, remise à faux à chaque
     *  ouverture : un choix destructeur ne se garde pas en mémoire d'une fois sur
     *  l'autre. */
    protected readonly resetIncludeBackground: import("@angular/core").WritableSignal<boolean>;
    /**
     * Ce que la réinitialisation retirerait, recalculé à chaque ouverture de la
     * modale et à chaque coche de la case.
     *
     * `signal` et non `computed` : le canvas n'est pas réactif, il faut le lire au
     * moment où on ouvre. Recalculé aussi quand la case change, pour que la phrase
     * affichée décrive toujours exactement ce que le bouton va faire.
     */
    protected readonly resetPreview: import("@angular/core").WritableSignal<ResetPlan<any> | null>;
    /** Phrase de décompte affichée dans la confirmation. */
    protected readonly resetSummary: import("@angular/core").Signal<string>;
    /** Dropdowns header */
    protected readonly showFondMenu: import("@angular/core").WritableSignal<boolean>;
    protected readonly showFichierMenu: import("@angular/core").WritableSignal<boolean>;
    /** Étages triés du plus bas (SS) au plus haut (Combles) */
    protected readonly sortedFloors: import("@angular/core").Signal<{
        id: string;
        name: string;
        order: number;
    }[]>;
    protected readonly roomsByFloor: import("@angular/core").WritableSignal<{
        floorId: string;
        floorName: string;
        rooms: Array<{
            label: string;
            areaM2: number;
        }>;
        totalArea: number;
    }[]>;
    protected readonly showRoomList: import("@angular/core").WritableSignal<boolean>;
    /** Surface totale cumulée sur tous les niveaux. */
    protected readonly globalAreaM2: import("@angular/core").Signal<number>;
    /** Entrées de linéaire triées par type pour l'affichage. */
    protected readonly pipeEntries: import("@angular/core").Signal<{
        label: string;
        lengthM: number;
    }[]>;
    protected toggleRoomList(): void;
    /** Sélectionne une pièce depuis la liste (les DetectedRoom étant non-sélectionnables
     *  par clic canvas, on ouvre l'inspecteur directement sans passer par setActiveObject). */
    protected selectRoomFromList(floorId: string, label: string, areaM2: number): void;
    private updateRoomList;
    protected readonly currentFloorName: import("@angular/core").Signal<string>;
    /** Ordre calculé selon la direction choisie dans la modal */
    protected readonly newFloorOrder: import("@angular/core").Signal<number>;
    protected readonly toolGroups: ToolGroup[];
    protected readonly ROOM_NAMES: string[];
    /** Version de la librairie (synchronisée depuis package.json au build). */
    protected readonly version = "2.28.0";
    /** État du drawer latéral sur mobile (slide-in). Géré par les media queries CSS,
     *  ce signal pilote uniquement l'overlay/transform sous le breakpoint. */
    protected readonly mobileSidebarOpen: import("@angular/core").WritableSignal<boolean>;
    protected toggleMobileSidebar(): void;
    protected closeMobileSidebar(): void;
    constructor();
    protected readonly workModeDefs: import("g-plan").WorkModeDefinition[];
    protected readonly activeWorkModes: import("@angular/core").WritableSignal<Set<WorkMode>>;
    /** Filtre les groupes/outils selon les modes actifs (union d'outils, sans doublon). */
    protected readonly visibleToolGroups: import("@angular/core").Signal<ToolGroup[]>;
    protected isWorkModeActive(id: WorkMode): boolean;
    protected toggleWorkMode(id: WorkMode): void;
    private loadInitialWorkModes;
    private persistWorkModes;
    /** Si l'outil courant n'est plus dans les modes actifs, retombe en sélection. */
    private resetToolIfHidden;
    private readonly fabricSvc;
    protected readonly historySvc: HistoryService;
    private readonly exportSvc;
    private readonly osmSvc;
    private readonly photoSvc;
    private readonly geometrySvc;
    private readonly analysisSvc;
    private readonly geoJsonSvc;
    protected readonly config: import("g-plan").FloorplanConfig;
    private readonly destroyRef;
    private readonly zone;
    private canvas;
    /** Mur actuellement mis en surbrillance (sélection) — pour restaurer sa couleur. */
    private highlightedWall;
    /** Dernier mur/cloison sélectionné — conservé même après deselection (pour applyCalibration). */
    private calibrationTarget;
    /** Dernier projet émis par CE composant — utilisé pour éviter les rechargements inutiles. */
    private _lastEmittedProject;
    /** Libellé lisible de l'outil actif (résolu depuis TOOL_GROUPS) — utilisé
     *  par le badge contextuel du header pour éviter l'affichage du mode brut
     *  type "ac-regard-eu". */
    protected readonly currentToolLabel: import("@angular/core").Signal<string>;
    /** Vrai dès qu'un outil de tracé polyligne est actif (mur/cloison/pipe).
     *  Décrit l'OUTIL, pas le tracé : sert à masquer le badge de pose, qui n'a
     *  pas de sens pour un outil de tracé. */
    protected readonly isPolylineMode: import("@angular/core").Signal<boolean>;
    /**
     * Vrai quand un tracé est **réellement en cours** — c'est la condition du
     * bouton « Terminer le tracé ».
     *
     * Il s'affichait jusqu'ici dès qu'un outil de tracé était actif, donc **il
     * restait après la fin du tracé** (double-clic, clic droit) : un bouton qui
     * propose de terminer ce qui l'est déjà. Signalé à l'usage.
     *
     * Le commentaire d'origine justifiait ce découplage par la détection de
     * changements : l'état bascule dans un handler Fabric hors zone Angular. Le
     * motif ne tient plus — `isPolylineDrawing` est un **signal**, et un signal lu
     * dans un gabarit notifie Angular par le graphe de dépendances, zone ou pas.
     * C'est d'ailleurs la seule façon fiable dans une application zoneless, mode
     * par défaut des hôtes Angular 21+.
     */
    protected readonly isPolylineActive: import("@angular/core").Signal<boolean>;
    /** Vrai quand un outil de forme d'annotation est actif : la palette de
     *  couleurs ne s'affiche que dans ce cas. */
    protected readonly isAnnotationTool: import("@angular/core").Signal<boolean>;
    /** Palette proposée et couleur active — portées par le service, qui les
     *  applique au moment de créer la forme. */
    protected readonly annotationColors: {
        id: string;
        label: string;
        color: string;
    }[];
    protected readonly annotationColor: import("@angular/core").Signal<string>;
    protected setAnnotationColor(color: string): void;
    /** Vrai s'il y a des pièces détectées (≥ 1). Les compteurs pcs/m² et le badge
     *  de surface n'ont de sens que dans ce cas (un plan SPANC/AC à base de
     *  réseaux n'a aucune pièce → "0 pcs / 0,0 m²" est du bruit). */
    protected readonly hasRooms: import("@angular/core").Signal<boolean>;
    /** Vrai si le panneau latéral droit a quelque chose à afficher : au moins une
     *  pièce détectée OU au moins un linéaire de réseau. Sinon il ne montrerait
     *  que « Aucune pièce détectée » — inutile, on le masque (cf. plan en cours de
     *  tracé sans pièce). */
    protected readonly hasRoomListContent: import("@angular/core").Signal<boolean>;
    /** Le badge de stats du header est masqué quand il n'y a ni pièce ni mur. */
    protected readonly showStatsBadge: import("@angular/core").Signal<boolean>;
    /** Le badge de niveau (RDC…) n'a de sens que s'il y a des pièces ou plusieurs
     *  niveaux à distinguer. Pour un plan réseau SPANC/AC (1 niveau, 0 pièce) il
     *  n'est que du bruit → masqué. (En 3D le badge est de toute façon recouvert
     *  par l'overlay ; c'est le watermark interne du viewer 3D qui prend le relais,
     *  gating identique côté viewer-3d.) */
    protected readonly showFloorBadge: import("@angular/core").Signal<boolean>;
    protected get canUndo(): import("@angular/core").Signal<boolean>;
    protected get canRedo(): import("@angular/core").Signal<boolean>;
    ngAfterViewInit(): void;
    private checkAutosave;
    private scheduleProjectChange;
    /** Synthèse structurée du plan, à la demande (ex : au clic « Valider le plan »).
     *  Synchrone et à jour : `buildProjectWithFloors()` snapshote le niveau courant
     *  et renvoie tous les niveaux. */
    getPlanSummary(): PlanSummary;
    /** Dernière synthèse analysée, alimentée par `scheduleProjectChange`. */
    protected readonly planSummary: import("@angular/core").WritableSignal<PlanSummary | null>;
    /** La description est-elle aussi affichée à l'écran ? (masquée ≠ absente). */
    protected readonly showOutline: import("@angular/core").WritableSignal<boolean>;
    /** `id` de la région décrivant le plan, cible de `aria-describedby`. */
    protected readonly outlineId: string;
    /** Mention légale jointe à la description — la même que les exports JSON. */
    protected readonly surfaceDisclaimer: string;
    /** Étiquette du canvas : de quoi savoir ce qu'on a sous le curseur sans lire
     *  toute la description. Le détail est dans la région liée. */
    protected readonly canvasAriaLabel: import("@angular/core").Signal<string>;
    protected toggleOutline(): void;
    /** Description textuelle du plan, à la demande — pour un rapport hôte ou un
     *  export. Synchrone et à jour, comme `getPlanSummary()` dont elle dérive. */
    getPlanOutline(): PlanOutline;
    /**
     * Sauvegarde périodique du brouillon dans `localStorage`.
     *
     * Le fond de carte y est inclus **depuis qu'il est encodé en WebP** : un fond
     * satellite pesait ~2,6 Mo en PNG, sérialisé **deux fois** par
     * `buildProjectWithFloors` (dans `objects` **et** dans `floors[*].objects`),
     * soit ~5,3 Mo — au-delà du quota `localStorage`. `setItem` levait alors
     * `QuotaExceededError`, la sauvegarde échouait **en silence**, et le brouillon
     * proposé restait celui d'avant la pose du fond : le restaurer effaçait le
     * plan en cours pour un état vide. En WebP le projet complet tombe à ~465 Ko.
     *
     * Les deux replis restent, parce que le quota peut être saturé par ailleurs :
     * on retente **sans l'image du fond** (ce qu'un brouillon doit sauver, c'est le
     * dessin ; le fond se recapture depuis `geo`), puis on **supprime** le
     * brouillon périmé plutôt que d'en proposer un qui détruirait le travail.
     */
    private performAutosave;
    /** Projet destiné au brouillon de repli : identique au projet complet, calques
     *  de fond (fond de carte **et** calque photo) vidés de leur image. Cf.
     *  `performAutosave`. */
    private projetAllege;
    restoreAutosave(): void;
    dismissAutosave(): void;
    openAddFloorModal(): void;
    setAddFloorDirection(dir: 'above' | 'below'): void;
    confirmAddFloor(): void;
    cancelAddFloor(): void;
    /** Nom par défaut selon l'ordre relatif du niveau */
    protected nameForOrder(order: number): string;
    /** Nom d'un niveau par son id */
    protected getFloorName(id: string | null): string;
    /** Ouvre/ferme le menu rétroactif "copier depuis" */
    openCopyFromMenu(): void;
    toggleFondMenu(): void;
    toggleFichierMenu(): void;
    /** Déclenche la proposition de copie depuis un étage donné (rétroactif) */
    copyWallsFromFloor(sourceId: string): void;
    switchFloor(floorId: string): void;
    copyExteriorWalls(): void;
    dismissCopyWallsOffer(): void;
    private updateInspector;
    private setupKeyboardShortcuts;
    setMode(mode: EditorMode): void;
    /** Bascule entre la vue 2D (canvas Fabric) et la vue 3D (Three.js). À chaque
     *  entrée en 3D, on resérialise le projet courant pour refléter les dernières
     *  modifications. Non destructif : le canvas 2D est simplement masqué. */
    toggle3D(): void;
    /** Bascule entre la vue 2D et la vue CARTE (MapLibre, lecture seule). Même
     *  principe que la 3D : le projet est resérialisé à l'ouverture, le canvas
     *  2D est masqué et rien n'est modifié. */
    toggleMap(): void;
    /** Motifs empêchant l'affichage sur la carte, recalculés à chaque émission de
     *  projet (`_lastEmittedProject` suit l'état réel du canvas). */
    protected readonly mapRefus: import("@angular/core").Signal<GeoJsonRefus[]>;
    protected readonly peutAfficherCarte: import("@angular/core").Signal<boolean>;
    /** Infobulle du bouton Carte : le **motif** quand il est désactivé. Un bouton
     *  grisé sans explication laisse croire à une panne. */
    protected readonly mapButtonTitle: import("@angular/core").Signal<string>;
    undo(): void;
    redo(): void;
    /** Termine le tracé en cours et repasse en mode Sélection (l'outil de
     *  dessin est désélectionné — pratique sur tactile pour clôturer nettement). */
    finishPolyline(): void;
    /** Convertit les RoomBox du croquis en murs porteurs et cloisons. */
    generateEnvelope(): void;
    /**
     * Snape les extrémités de tous les murs sur une grille dédupliquée à ±SNAP px.
     * Garantit que deux coordonnées quasi-identiques (ex: 199.7 et 200.0) convergent
     * vers la même valeur — condition nécessaire pour la détection des T-jonctions.
     */
    private normalizeWallCoordinates;
    /** Bascule le mur/cloison sélectionné entre porteur et cloison. */
    toggleSelectedWallType(): void;
    /**
     * 1ère calibration → ajuste le PPM pour que ce mur = realLengthM.
     * Calibrations suivantes → redimensionne CE mur en pixels (PPM inchangé).
     * Dans les deux cas, verrouille la longueur et affiche un indicateur visuel.
     */
    applyCalibration(): void;
    /**
     * Applique au mur sélectionné la longueur relevée au télémètre — brique A.
     *
     * **Ce qui la distingue de la calibration**, avec laquelle elle partage le
     * champ `data.lockedLengthM` : la calibration règle l'**échelle** du plan (le
     * premier mur calibré fixe le nombre de pixels par mètre), la cotation ne
     * touche pas à l'échelle et se contente de conformer le **croquis** aux
     * mesures. C'est le geste du diagnostiqueur qui relève une pièce sans plan :
     * tracer la forme au doigt, puis toucher chaque mur et taper sa cote.
     *
     * **Où se saisit la cote — décision n°4 de `FEATURE-releve-piece-sans-plan.md`,
     * tranchée ici pour l'inspecteur.** La note recommandait la saisie au clic sur
     * la cote affichée. Les cotes sont des `fabric.Text` non sélectionnables
     * posées en 11 px : en faire des cibles cliquables demande d'ajouter un objet
     * évènementiel par-dessus le dessin, qui entrerait en concurrence avec la
     * sélection du mur et avec le clic-pour-déplacer des réseaux. Or sélectionner
     * le mur ouvre déjà l'inspecteur : le nombre de gestes est le même, pour un
     * risque bien moindre. Réversible sans toucher au moteur — seul le déclencheur
     * changerait.
     */
    applyWallDimension(): void;
    /** Définit les dimensions réelles (m) d'une pièce RoomBox et redimensionne en pixels. */
    applyRoomBoxDimensions(): void;
    /**
     * Signale une échelle stockée invraisemblable, au lieu de la subir en silence.
     *
     * Un projet porte son échelle : si elle a été faussée avant l'enregistrement,
     * elle revient telle quelle à chaque ouverture, et tout paraît minuscule sans
     * qu'on sache pourquoi. Le cadrage rend le plan visible ; ce message dit d'où
     * vient l'anomalie et comment en sortir.
     */
    private avertirEchelleInvraisemblable;
    /** Facteur de zoom courant, en pourcentage affichable. */
    protected readonly zoomPercent: import("@angular/core").Signal<number>;
    protected zoomIn(): void;
    protected zoomOut(): void;
    /** Cadre le dessin — la porte de sortie quand le plan a fui hors champ. */
    protected zoomFit(): void;
    /** Dimensions de la zone RÉELLEMENT visible du plan, pour le cadrage. */
    private tailleVue;
    /** Retourne les coordonnées absolues canvas des deux extrémités d'un mur (fabric.Line). */
    private getAbsWallEndpoints;
    /**
     * Solveur de contraintes de layout orthogonal global.
     *
     * Principe :
     *  1. Construire un modèle colonnes (X uniques) / lignes (Y uniques) depuis tous les murs.
     *  2. Chaque mur verrouillé impose une distance fixe entre deux colonnes ou deux lignes.
     *  3. Résoudre les positions 1D en respectant ces contraintes, les spans libres
     *     se compressant/dilatant proportionnellement.
     *  4. Repositionner tous les murs selon les nouvelles positions colonnes/lignes.
     *
     * Avantage vs BFS impératif : toutes les contraintes sont résolues simultanément,
     * sans accumulation d'erreurs entre calibrations successives.
     */
    private applyLayoutConstraints;
    /**
     * Solveur 1D : repositionne N positions ordonnées selon des contraintes de distance.
     *
     * L'ancre est la première position (index 0), fixe.
     * Les contraintes (ci, cj, d) imposent : positions[cj] - positions[ci] = d px.
     * Traitées de gauche à droite : chaque contrainte décale les positions ≥ cj,
     * puis redistribue les positions intermédiaires proportionnellement.
     * Les spans libres s'ajustent naturellement.
     */
    private solve1D;
    /**
     * Mappe une coordonnée de l'ancien espace grille vers le nouveau.
     * Snap exact sur les lignes de grille, interpolation linéaire entre.
     */
    private snapRemap;
    /**
     * Redimensionne les RoomBoxes avec cotes réelles verrouillées selon le PPM courant.
     * Les murs verrouillés sont gérés par applyLayoutConstraints().
     */
    private updateLockedObjects;
    /**
     * Crée les labels visuels "⊛ X.XX m" sur les murs avec longueur verrouillée.
     * Non persistés (recréés à chaque recalculateRooms).
     */
    private refreshLockedLabels;
    /** Met le mur sélectionné en orange vif et sauvegarde sa couleur d'origine. */
    private highlightSelectedWall;
    /** Restaure la couleur d'origine du mur précédemment mis en surbrillance. */
    private restoreHighlightedWall;
    deleteActive(): void;
    /** Ouvre la confirmation, après avoir mesuré ce qu'elle va annoncer. */
    protected openResetModal(): void;
    protected cancelReset(): void;
    /** Bascule « supprimer aussi le fond » — et remesure aussitôt, pour que la
     *  phrase affichée décrive toujours ce que le bouton fera. */
    protected toggleResetBackground(): void;
    private refreshResetPreview;
    /**
     * Vide le niveau courant.
     *
     * `pauseSaving()` / `resumeSaving()` encadrent les suppressions : l'historique
     * les empile en **une seule** commande de groupe, donc un Ctrl+Z restitue le
     * plan entier. C'est le même mécanisme que la génération d'enveloppe.
     *
     * Les autres niveaux ne sont pas touchés : `floorObjects` n'est pas relu ici,
     * et le canvas ne porte que le niveau actif.
     */
    protected confirmReset(): void;
    /** Charge utile déjà importée — comparée par **référence**, la seule identité
     *  dont on dispose : deux envois successifs du même plan sont deux objets
     *  distincts, et doivent tous deux être importés. */
    private importedWallsPayload;
    /**
     * Importe les murs du scanner s'il y en a de nouveaux.
     *
     * Appelée à trois endroits — après le chargement d'un projet, à l'init sans
     * projet, et à chaque changement de `initialWalls` — parce que l'import doit
     * survivre aux trois façons dont l'éditeur peut exister au moment où le
     * scanner émet : créé après lui, créé avant lui, ou déjà chargé d'un projet.
     * La garde de référence rend les trois appels sans danger.
     */
    private importInitialWallsIfAny;
    /**
     * Pose dans le plan les murs détectés par le scanner.
     *
     * ## L'échelle, depuis la 2.13.0
     *
     * Le champ `payload.pixelsPerMeter` existait déjà, mais **rien ne le lisait** :
     * le scanner le remplissait par un ternaire dont les deux branches valaient
     * 50, et l'éditeur l'ignorait. Les murs entraient donc à leurs pixels bruts,
     * mesurés ensuite à l'échelle du plan — un rapport sans aucun fondement.
     *
     * Désormais, quand la charge utile est **calée** (`scaleCalibrated`), les murs
     * sont mis à l'échelle du plan par `scannerImportScale`, exactement comme un
     * calque photo l'est par `photoLayerScale`. **C'est l'apport qui s'adapte au
     * plan, jamais le plan qui se réécrit** : aligner `pixelsPerMeter` sur le
     * scanner redimensionnerait silencieusement les cotes déjà saisies et les
     * objets des autres niveaux, que `canvas.clear()` ne vide pas.
     *
     * Sans calage, le facteur vaut 1 et l'import est annoncé en console : les
     * murs sont là, leurs longueurs ne veulent rien dire, et cela se sait.
     */
    importWallsFromScanner(payload: WallsImportPayload): void;
    /** Identifiant unique (UUID si dispo, sinon fallback). Utilisé pour les ids
     *  stables de pièces (data.roomId). */
    private genId;
    recalculateRooms(): void;
    /** Affiche les identifiants (P1, P2…) des zones à risque sur le plan 2D. */
    private refreshHazardLabels;
    /** Supprime et recrée les labels de pièces nommées sur le canvas (non sélectionnables). */
    private refreshRoomLabels;
    saveProject(): void;
    private buildProjectWithFloors;
    loadProject(event: Event): void;
    /** Applique les modes métier portés par un projet chargé (override localStorage si présents). */
    private applyProjectWorkModes;
    exportJPG(): void;
    exportPNG(): void;
    exportSVG(): void;
    /** Recharge le canvas depuis un projet externe (appelable par le parent au changement d'onglet). */
    reloadFromProject(proj: FloorplanProject): void;
    /**
     * Le curseur d'échelle est **réellement neutralisé** tant qu'une ancre
     * géographique **exploitable** existe (cf. `isGeoAnchored`), au lieu de se
     * contenter d'un cadenas décoratif.
     *
     * Le choix se pose ainsi : soit on laisse modifier `pixelsPerMeter`, et il
     * faut alors invalider l'ancre, soit on gèle le curseur. On gèle, parce que
     * les deux grandeurs ne se valent pas — l'échelle **se recalcule** à tout
     * moment depuis l'ancre (`sceneMetersPerPixel`), alors que l'ancre vient
     * d'une capture qui peut n'être plus reproductible (hors ligne, imagerie
     * mise à jour, opérateur parti du site). Sacrifier l'irremplaçable au
     * réparable sur un glissement de curseur serait un mauvais marché. Le
     * cadenas 🔒 déjà présent devient donc vrai, et le curseur est désactivé
     * côté template pour que le refus soit visible avant d'être subi.
     */
    private canChangeScale;
    onScaleInput(event: Event): void;
    commitScaleChange(event: Event): void;
    toggleMeasurements(): void;
    openOsmModal(): void;
    closeOsmModal(): void;
    openPhotoModal(): void;
    closePhotoModal(): void;
    openTemplateModal(): void;
    closeTemplateModal(): void;
    loadTemplate(tpl: ApartmentTemplate): void;
    onOsmImport(data: {
        dataUrl: string;
        geo: GeoLocation;
        scaleVal: number;
    }): void;
    /** Ancre issue d'une capture faite par la bibliothèque. `valid` est recalculé
     *  à la pose puis à chaque écriture de projet — jamais posé à la main. */
    private anchorFromCapture;
    /**
     * Le `geo` d'un projet rechargé permet-il de **recapturer** son fond ?
     *
     * Le test portait sur `geo.valid`, alors que ce champ est devenu dérivé et
     * sévère : un plan dont le fond a été déverrouillé une fois, ou dont l'ancre
     * n'a jamais été posée par g-plan, ne rechargeait plus jamais sa carte — sans
     * message. Or recapturer ne dégrade rien : la pose enregistrée est conservée
     * (cf. `anchorReposee`) et les doutes déjà établis sont propagés. Ce qu'il
     * faut, ce sont des coordonnées exploitables, rien de plus.
     */
    private geoRecapturable;
    /**
     * Pose de scène enregistrée dans une ancre, si elle en porte une exploitable.
     *
     * Une image recapturée doit être reposée **là où était la précédente**, pas au
     * centre du canvas : `canvasWidth`/`canvasHeight` sont des entrées de l'hôte
     * que le projet ne persiste pas, et qui peuvent avoir changé entre deux
     * sessions — tout le plan se retrouverait alors décalé, en silence.
     */
    private poseEnregistree;
    /**
     * Ancre d'une **recapture** : la pose enregistrée fait foi, la nouvelle
     * capture ne fournit que des pixels.
     *
     * Reconstruire l'ancre depuis la capture — ce que fait `anchorFromCapture` —
     * écrasait `dpr`, `anchorX` et `anchorY`. Un poste non-retina rapportait
     * `dpr: 1` là où la capture d'origine valait 2 : toutes les longueurs du plan
     * doublaient, et aucun garde-fou ne pouvait le voir (`memeVueGeo` ne compare
     * que lat/lng/zoom, `retouchee` restait faux, `valid` repassait à vrai).
     *
     * L'écart de dpr — et, à la marge, celui de zoom effectif écrêté par
     * `maxZoom` — est **absorbé par l'échelle de pose** plutôt qu'ignoré :
     * l'image neuve est posée à `dprEnregistré · 2^(zoomEnregistré − zoomCapturé)
     * / dprCapture`, de sorte qu'un pixel de scène continue de valoir exactement
     * le même nombre de pixels-monde qu'à la pose initiale.
     */
    private anchorReposee;
    /** Charge un fond de carte depuis l'input `geoPoint` (coordonnées fournies par
     *  l'app hôte) si présent et qu'aucun fond n'existe déjà. Zoom max par défaut.
     *  Idempotent — le garde `hasBackdrop` évite le double chargement. */
    private loadGeoBackdropIfNeeded;
    /**
     * Pose une image de fond au centre du canvas.
     *
     * `geo` est l'ancre géographique de la capture, quand il y en a une. Elle est
     * écrite **en même temps que l'image**, sur l'objet Fabric (`data.geo`, donc
     * sérialisée sans rien ajouter à `FABRIC_CUSTOM_PROPS` : `data` y est déjà) et
     * dans le signal du composant, d'où elle repart vers chaque projet émis.
     */
    private applyBackdrop;
    /**
     * Enregistre l'ancre au moment de la pose du fond.
     *
     * `anchorX`/`anchorY` sont écrits explicitement bien que l'image soit posée au
     * centre du canvas : ce centre dépend de `canvasWidth`/`canvasHeight`, qui sont
     * des **inputs de l'hôte non persistés**. Un hôte qui les change entre deux
     * sessions décalerait tout le plan sans le moindre signe.
     */
    private poseAnchor;
    /** Le canvas ou l'un des autres niveaux porte-t-il déjà un objet métier
     *  (hors fond de plan) ? */
    private hasPersistedDrawings;
    /** Le fond de plan vivant du canvas, s'il y en a un. */
    private findBackdrop;
    /**
     * Réévalue l'ancre et la recopie sur le fond vivant.
     *
     * - `'preserve'` (défaut) : un doute déjà posé le reste, et une géométrie qui
     *   ne correspond plus à la pose en crée un.
     * - `'force'` : le fond vient d'être déverrouillé, pivoté ou déplacé. Un
     *   déverrouillage seul ne laisse aucune trace mesurable, il doit donc être
     *   déclaré.
     * - `'replace'` : le fond de carte a été remplacé par une image sans
     *   géoréférencement. Doute **irréversible**, porté par un drapeau distinct
     *   (`fondRemplace`) : posé comme un simple `'force'`, il était effacé au
     *   premier reverrouillage, puisqu'une image locale déposée à la place exacte
     *   de la capture ne laisse aucune trace géométrique à confronter.
     * - `'revalidate'` : le fond vient d'être reverrouillé — on le compare à sa
     *   pose, et un aller-retour sur la case « Verrouiller » sans déplacement
     *   n'invalide donc rien. Sans ce cas, cocher puis décocher condamnerait
     *   définitivement le géoréférencement du plan. Ce mode ne lève que le doute
     *   réversible : il ne touche pas à `fondRemplace`.
     */
    private refreshAnchor;
    /**
     * Reprend l'ancre d'un projet chargé. Appelée sur tous les chemins de
     * chargement : sans elle, le composant réémettrait un projet **sans** `geo` au
     * premier autosave et effacerait le géoréférencement d'un plan qui l'avait.
     */
    private adoptProjectGeo;
    /** Recentre la vue sur le fond de carte / backdrop dès son ajout : viewport
     *  remis à l'identité et zone de canvas scrollée sur le centre (le backdrop
     *  est placé au centre du canvas). */
    private centerViewOnBackdrop;
    /** Mode visualisation : verrouille la motion de tous les objets non-backdrop.
     *  Les objets restent sélectionnables (inspection panneau latéral) mais
     *  immobiles. Backdrop conserve ses propres verrous (syncBackdropState).
     *  Porte/fenêtre conservent leur lock de scaling en sortie de readOnly. */
    private applyReadOnlyToObjects;
    /** Synchronise l'état des calques de fond après chargement d'un projet : le
     *  backdrop est verrouillé (non sélectionnable) par défaut — sinon il se
     *  déplace par mégarde au doigt — et les calques photo sont redressés à
     *  nouveau (`syncPhotoLayers`, appelée d'ici parce que c'est la seule méthode
     *  qui passe sur **tous** les chemins de chargement). */
    private syncBackdropState;
    /**
     * Pose le calque photo redressé rendu par l'assistant.
     *
     * **Le calque s'adapte à l'échelle du plan, jamais l'inverse.** Recaler
     * `pixelsPerMeter` sur la photo réécrirait toutes les longueurs et toutes les
     * surfaces déjà saisies — les cotes relevées au télémètre comprises — alors
     * que l'utilisateur n'a demandé qu'un décalque. Le facteur est donc appliqué à
     * l'image (`photoLayerScale`), et le plan ne bouge pas.
     *
     * Le calque part au fond, sous les dessins et sous le fond de carte s'il y en
     * a un, pour la même raison qu'un fond de carte : c'est un décalque.
     */
    onPhotoImport(imp: PhotoLayerImport): Promise<void>;
    /**
     * Rejoue le redressement des calques photo après un chargement de projet.
     *
     * Ne stocker que la photo d'origine se paie **ici**, en un seul endroit :
     * sans cet appel, le calque reviendrait de biais et étiré sur la taille du
     * rectangle redressé — une image plausible, calée à côté, et rien pour le
     * signaler. Appelée depuis `syncBackdropState`, qui passe sur tous les chemins
     * de chargement (projet, brouillon, changement de niveau).
     */
    private syncPhotoLayers;
    removePhotoLayer(): void;
    removeBackdrop(): void;
    loadBackgroundImage(event: Event): void;
    toggleBackgroundLock(): void;
    /**
     * Applique la rotation du fond depuis le curseur.
     *
     * Le verrouillage est testé explicitement : `lockRotation` ne bloque que la
     * poignée de Fabric, pas une écriture programmatique. Sans ce test, le curseur
     * pivotait un fond « verrouillé » — et détruisait le géoréférencement de tout
     * ce qui avait été dessiné dessus.
     */
    updateBackgroundRotation(event: Event): void;
    showGridOverlay(): void;
    hideGridOverlay(): void;
    onInspectorChange(data: InspectorData): void;
    /**
     * Assigne les lettres A, B, C… à chaque mur d'une pièce, dans le sens horaire
     * en partant de la porte principale (la porte avec isPrimary=true, ou la première).
     * Crée des labels 'RoomWallLabel' sur le canvas et annote les fenêtres (ex : B-F1).
     * Seules les pièces avec au moins une porte sont numérotées.
     */
    private refreshWallLetters;
    /** Vérifie si un point est à moins de `tol` pixels d'une arête du polygone. */
    private rwlNearEdge;
    /** Renvoie l'index de l'arête du polygone la plus proche du point (tolérance 60px). */
    private rwlNearestEdge;
    /** Renvoie les extrémités absolues d'un mur Fabric (même formule que geometry.service). */
    private rwlLineEnds;
    /** Trouve le mur Fabric dont le segment est colinéaire à l'arête (p1, p2). */
    private rwlFindWall;
    /** Distance d'un point à un segment. */
    private rwlDist;
    /** Crée un label de lettre sur le canvas, décalé vers l'intérieur de la pièce. */
    private rwlAddLabel;
    /**
     * Trie les fenêtres d'un mur le long de son axe et leur attribue un label
     * de type "B-F1", "B-F2", etc. stocké dans `window.data.wallLabel`.
     */
    private rwlLabelWindows;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlanEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PlanEditorComponent, "ng-gplan-plan-editor", never, { "initialWalls": { "alias": "initialWalls"; "required": false; "isSignal": true; }; "project": { "alias": "project"; "required": false; "isSignal": true; }; "showSidebar": { "alias": "showSidebar"; "required": false; "isSignal": true; }; "showHeader": { "alias": "showHeader"; "required": false; "isSignal": true; }; "canvasHeight": { "alias": "canvasHeight"; "required": false; "isSignal": true; }; "canvasWidth": { "alias": "canvasWidth"; "required": false; "isSignal": true; }; "autoGeoLayer": { "alias": "autoGeoLayer"; "required": false; "isSignal": true; }; "geoPoint": { "alias": "geoPoint"; "required": false; "isSignal": true; }; "compactMode": { "alias": "compactMode"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; "criRooms": { "alias": "criRooms"; "required": false; "isSignal": true; }; "pendingSamples": { "alias": "pendingSamples"; "required": false; "isSignal": true; }; }, { "projectSaved": "projectSaved"; "projectChange": "projectChange"; "statsChanged": "statsChanged"; "roomsChanged": "roomsChanged"; "jpgExported": "jpgExported"; "pngExported": "pngExported"; "svgExported": "svgExported"; "canvasReady": "canvasReady"; "loadingState": "loadingState"; "summaryChange": "summaryChange"; "roomLinked": "roomLinked"; "samplePlaced": "samplePlaced"; }, never, never, true, never>;
}
