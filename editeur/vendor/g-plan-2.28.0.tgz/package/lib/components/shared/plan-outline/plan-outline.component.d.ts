import { PlanSummary } from '../../../models/plan-summary.model';
import { PlanOutline } from '../../../constants/plan-outline.const';
import * as i0 from "@angular/core";
/**
 * Alternative textuelle du plan — la version du dessin que peut lire une
 * technologie d'assistance.
 *
 * ## Pourquoi le contenu est dans le DOM même quand on ne le voit pas
 *
 * Par défaut le composant est **masqué visuellement mais présent** (technique
 * dite « visually hidden » : 1 px découpé, jamais `display: none` ni
 * `visibility: hidden`, qui retireraient le contenu de l'arbre d'accessibilité
 * en même temps que de l'écran). Le lecteur d'écran lit donc toujours la
 * description, sans qu'on impose un panneau à qui n'en a pas besoin.
 *
 * `visible` bascule le même contenu en panneau lisible à l'œil : c'est utile
 * bien au-delà du handicap — vérifier une surface, relire les cotes d'une pièce
 * sans zoomer, copier la description dans un rapport.
 *
 * ## Pourquoi le composant ne calcule rien
 *
 * Il reçoit un `PlanSummary` — celui que `PlanAnalysisService` produit déjà et
 * que l'éditeur émet par `summaryChange` — et le projette en titres et listes.
 * Aucun second modèle du plan n'existe donc, et la description ne peut pas
 * décrire autre chose que ce que l'analyse a vu. Toute la mise en mots est dans
 * `plan-outline.const.ts`, module pur et testé sans navigateur.
 *
 * ## Structure produite (elle est le sujet, pas un détail)
 *
 * `h2` (titre) → `p` (résumé) → une `section` + `h3` par niveau, puis Réseaux,
 * puis Repérage → `ul`/`li` imbriqués. C'est ce qui permet de **naviguer** de
 * titre en titre au lieu de subir un pavé, et c'est la seule différence qui
 * compte entre une alternative utilisable et une alternative de conformité.
 */
export declare class PlanOutlineComponent {
    /** Synthèse du plan (cf. `summaryChange` / `getPlanSummary()`). `null` → le
     *  composant annonce explicitement un plan vide, jamais rien. */
    summary: import("@angular/core").InputSignal<PlanSummary | null>;
    /** Mention légale sur les surfaces, jointe en fin de description. L'éditeur y
     *  passe `SURFACE_DISCLAIMER` — la même que les exports JSON. */
    notice: import("@angular/core").InputSignal<string | null>;
    /** Afficher la description comme un panneau visible. `false` (défaut) : le
     *  contenu reste lisible par lecteur d'écran, mais invisible à l'écran. */
    visible: import("@angular/core").InputSignal<boolean>;
    /** `id` de la région, pour qu'un `<canvas>` puisse la référencer en
     *  `aria-describedby`. Doit être unique dans la page si l'hôte instancie
     *  plusieurs éditeurs. */
    regionId: import("@angular/core").InputSignal<string>;
    protected readonly outline: import("@angular/core").Signal<PlanOutline>;
    /** Description en texte brut — pour un copier-coller ou un rapport hôte.
     *  Ce n'est **pas** la forme accessible (cf. `planOutlineText`). */
    asText(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlanOutlineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PlanOutlineComponent, "ng-gplan-plan-outline", never, { "summary": { "alias": "summary"; "required": false; "isSignal": true; }; "notice": { "alias": "notice"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "regionId": { "alias": "regionId"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
