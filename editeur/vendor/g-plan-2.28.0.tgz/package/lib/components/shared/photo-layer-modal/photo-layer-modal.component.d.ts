import { Point } from '../../../models/geometry.types';
import { PhotoLayerData, PhotoRectification } from '../../../constants/photo-homography.const';
import { PhotoSource } from '../../../services/photo-layer.service';
import * as i0 from "@angular/core";
/** Étape de l'assistant. Trois gestes, dans l'ordre où on les fait sur le terrain. */
export type PhotoStep = 'file' | 'corners' | 'scale';
/** Ce que la modale rend à l'éditeur : la photo d'origine, et sa charge utile. */
export interface PhotoLayerImport {
    /** Photo **d'origine**, réduite et encodée — la seule image persistée. */
    readonly dataUrl: string;
    readonly photo: PhotoLayerData;
}
/**
 * Assistant du calque photo : charger, poser les quatre coins, caler.
 *
 * ## Pourquoi des poignées à traîner, et non des coins à taper
 *
 * Les quatre coins sont **posés d'avance** aux 10 % de l'image et se déplacent à
 * la traîne. Taper quatre points dans le bon ordre marche à la souris et
 * échoue au doigt : un appui glissé devient un appui déplacé, l'ordre se perd,
 * et l'utilisateur n'a aucun moyen de rattraper le troisième coin sans tout
 * reprendre. Avec quatre poignées, il y a toujours exactement quatre coins,
 * toujours dans un ordre exploitable, et chacun se rattrape seul.
 *
 * ## Pourquoi le calage se fait sur l'aperçu redressé
 *
 * Les deux points de la distance connue se posent sur l'image **déjà
 * redressée**. C'est le seul repère où l'utilisateur voit ce qu'il mesure : sur
 * la photo de biais, un mur qui paraît long est peut-être proche, et le point
 * qu'on croit poser au bout du mur tombe ailleurs. La géométrie, elle, s'en
 * moque — `scaleFromKnownDistance` travaille dans l'image source — mais
 * l'utilisateur non.
 *
 * Le rendu redressé de l'aperçu n'est **jamais** persisté : seul l'original part
 * dans le document, avec la matrice (cf. `PhotoLayerService`).
 */
export declare class PhotoLayerModalComponent {
    /**
     * Titre affiché en tête de l'assistant.
     *
     * Le même assistant sert deux usages depuis la 2.13.0 : poser un calque de
     * décalque, et **caler le scanner** (brique C). Les trois gestes sont
     * identiques, le résultat attendu non — annoncer « Calque photo » à qui vient
     * caler une détection de murs serait mensonger, et c'est le genre de détail
     * qui fait renoncer à réutiliser un composant, donc dupliquer sa géométrie.
     */
    readonly title: import("@angular/core").InputSignal<string>;
    /** Libellé du bouton de validation, pour la même raison que `title`. */
    readonly confirmLabel: import("@angular/core").InputSignal<string>;
    /**
     * Fichier DÉJÀ choisi par l'appelant — l'assistant saute alors l'étape de
     * sélection.
     *
     * Le scanner a déjà la photo sous les yeux quand il propose de la redresser :
     * redemander « choisissez un fichier » obligeait à retrouver et re-sélectionner
     * la même image, alors qu'elle est à l'écran. Une étape qui redemande ce qu'on
     * vient de donner passe pour une panne.
     */
    readonly fichierInitial: import("@angular/core").InputSignal<File | null>;
    /**
     * Coins pré-positionnés, en coordonnées **normalisées** (0 à 1).
     *
     * Normalisées et non en pixels : l'appelant travaille sur sa propre image —
     * le scanner analyse une réduction, l'assistant en prépare une autre — et deux
     * espaces de pixels finiraient par diverger d'un facteur d'échelle silencieux.
     *
     * Fournis par le scanner, qui sait les déduire du dessin par points de fuite.
     * Absents ailleurs : l'éditeur retombe sur un cadre à 10 %, qu'on ajuste.
     */
    readonly coinsInitiaux: import("@angular/core").InputSignal<readonly Point[] | null>;
    readonly import: import("@angular/core").OutputEmitterRef<PhotoLayerImport>;
    readonly close: import("@angular/core").OutputEmitterRef<void>;
    private readonly photoSvc;
    private readonly stageRef;
    protected readonly step: import("@angular/core").WritableSignal<PhotoStep>;
    protected readonly busy: import("@angular/core").WritableSignal<boolean>;
    protected readonly error: import("@angular/core").WritableSignal<string | null>;
    /** Photo réduite et encodée : c'est elle que l'utilisateur voit et annote. */
    protected readonly source: import("@angular/core").WritableSignal<PhotoSource | null>;
    /** Les quatre coins, en pixels de `source`. */
    protected readonly corners: import("@angular/core").WritableSignal<Point[]>;
    /** Redressement courant (recalculé à chaque relâchement de poignée). */
    protected readonly rectification: import("@angular/core").WritableSignal<PhotoRectification | null>;
    /** Aperçu redressé, en `data:` URL — affichage seul, jamais persisté. */
    protected readonly preview: import("@angular/core").WritableSignal<string | null>;
    /** Les deux points de la distance connue, en pixels **redressés**. */
    protected readonly gauge: import("@angular/core").WritableSignal<Point[]>;
    protected readonly knownDistance: import("@angular/core").WritableSignal<number | null>;
    /** Poignée en cours de traîne : index dans `corners` ou `gauge`. */
    private dragging;
    /** Taille affichée de l'image annotée, pour convertir écran ↔ image. */
    protected readonly stageWidth: import("@angular/core").Signal<number>;
    protected readonly stageHeight: import("@angular/core").Signal<number>;
    /** Rayon d'un réticule, proportionnel à l'image affichée. */
    protected readonly handleRadius: import("@angular/core").Signal<number>;
    /**
     * Réticule d'une poignée : quatre traits d'approche laissant un **vide
     * central**.
     *
     * Les poignées étaient des disques pleins (`fill: #fff`) — donc elles
     * masquaient précisément le point qu'on cherche à viser, et poser un coin de
     * document se faisait à l'aveugle. Or c'est la justesse de ces quatre points
     * qui décide de tout le redressement.
     *
     * Le vide central n'est pas une marge décorative : il fait exactement la
     * moitié du rayon, assez pour laisser voir l'angle du document sous le
     * curseur, assez peu pour que le centre reste évident à l'œil.
     */
    protected reticlePath(p: Point): string;
    /** Polygone SVG des quatre coins. */
    protected readonly quadPoints: import("@angular/core").Signal<string>;
    /** Rapport d'aspect recouvré, tel qu'on l'annonce à l'utilisateur. */
    protected readonly aspectLabel: import("@angular/core").Signal<string>;
    /** Échelle obtenue : pixels redressés par mètre. */
    protected readonly pixelsPerMeter: import("@angular/core").Signal<number | null>;
    /**
     * Dimensions réelles du **document**, une fois calé — marge de tracé exclue.
     *
     * C'est le seul contrôle de vraisemblance qu'on puisse faire d'un coup d'œil
     * (« ce plan fait bien 12 × 9 m »). Y inclure la marge le fausserait de 24 %,
     * et personne ne saurait d'où vient l'écart.
     */
    protected readonly sizeLabel: import("@angular/core").Signal<string | null>;
    protected readonly canRectify: import("@angular/core").Signal<boolean>;
    protected readonly canImport: import("@angular/core").Signal<boolean>;
    constructor();
    onFile(event: Event): Promise<void>;
    private chargerFichier;
    onPointerDown(event: PointerEvent): void;
    onPointerMove(event: PointerEvent): void;
    onPointerUp(): void;
    rectify(): Promise<void>;
    backToCorners(): void;
    /** Repart de zéro — le fichier compris. */
    reset(): void;
    confirm(): void;
    onClose(): void;
    /** Coordonnées image d'un évènement pointeur, quel que soit le zoom d'affichage. */
    private toImage;
    static ɵfac: i0.ɵɵFactoryDeclaration<PhotoLayerModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PhotoLayerModalComponent, "ng-gplan-photo-layer-modal", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; "isSignal": true; }; "fichierInitial": { "alias": "fichierInitial"; "required": false; "isSignal": true; }; "coinsInitiaux": { "alias": "coinsInitiaux"; "required": false; "isSignal": true; }; }, { "import": "import"; "close": "close"; }, never, never, true, never>;
}
