/** Libellés courts des canalisations par `myType` Fabric. */
export declare const PIPE_LABELS: Record<string, string>;
/**
 * Couleur de tracé de chaque réseau — **source unique**.
 *
 * Ces neuf couleurs étaient recopiées à cinq endroits (tracé Fabric, cotes,
 * vue 3D, légende d'export, pastilles de la barre d'outils). Les rassembler
 * ici n'est pas de l'esthétique : sur un plan, la couleur d'une polyligne est
 * la **seule** chose qui dise si c'est de l'eau potable ou du gaz. Deux
 * nuanciers pour un même sens, et personne ne sait lequel fait foi.
 *
 * **Contraste (2.15.0).** Chaque valeur atteint au moins **3:1** sur le fond
 * blanc du canvas (WCAG 2.1 §1.4.11), ce que `pipe-labels.const.spec.ts`
 * vérifie. Quatre couleurs ont dû changer, mesures à l'appui :
 *
 * | Réseau | Avant | Contraste | Après | Contraste |
 * |---|---|---|---|---|
 * | EP    | `#22d3ee` | 1,81:1 | `#0e7490` | 5,36:1 |
 * | Élec  | `#eab308` | 1,92:1 | `#b91c1c` | 6,47:1 |
 * | Gaz   | `#f59e0b` | 2,15:1 | `#d97706` | 3,19:1 |
 * | Fibre | `#06b6d4` | 2,43:1 | `#15803d` | 5,02:1 |
 *
 * Élec et Fibre changent de teinte, et c'est volontaire : aucun jaune ni aucun
 * cyan clair n'atteint 3:1 sur blanc sans virer au brun — ils deviendraient
 * alors indiscernables de EM (`#a16207`) et de EV (`#78350f`). Les nouvelles
 * teintes suivent la convention française des grillages avertisseurs
 * (NF P 98-332) : **rouge** pour l'électricité, **vert** pour les télécoms. Le
 * gaz reste ambré, au minimum de darkening nécessaire pour passer le seuil.
 *
 * **Les plans existants ne sont pas retouchés** : la couleur est sérialisée
 * dans chaque objet Fabric (`stroke`), et la légende d'export la dérive de
 * l'objet réellement dessiné (`dominantColor`). Un plan ancien reste donc
 * cohérent avec sa propre légende ; seuls les tracés faits à partir de la
 * 2.15.0 prennent les nouvelles couleurs. Réécrire les anciens serait modifier
 * le document de l'utilisateur sans qu'il l'ait demandé.
 */
export declare const PIPE_COLORS: Record<string, string>;
/**
 * Mode d'outil → `myType` du tracé produit.
 *
 * Correspondance **explicite** : `pipe-aep` donne `PipeAEP` mais `pipe-vent`
 * donne `PipeVent`, l'un étant un sigle et l'autre un mot. Aucune règle de
 * casse ne couvre les deux, et l'écrire à la main à chaque usage a déjà produit
 * deux pastilles annonçant une couleur que l'outil ne trace pas.
 */
export declare const PIPE_MODE_TO_TYPE: Record<string, string>;
/** Ordre d'affichage des linéaires de réseaux. */
export declare const PIPE_ORDER: string[];
