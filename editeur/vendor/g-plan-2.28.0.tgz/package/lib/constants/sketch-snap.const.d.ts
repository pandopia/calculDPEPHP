/**
 * Magnétisme de croquis — angle contraint, alignement, fermeture de boucle.
 *
 * **Pourquoi ce module existe.** Le magnétisme de g-plan était exclusivement
 * *positionnel* : on accrochait un point à un nœud, à un mur, ou à la grille. Rien
 * ne contraignait la **direction** d'un segment. Or c'est la direction qui décide
 * si un croquis a l'air d'un plan : un rectangle tracé au doigt sort avec des
 * angles à 87° et 93°, et aucune grille ne le redresse — le pas de 20 px ne dit
 * rien de l'angle entre deux points qui tombent tous deux dessus.
 *
 * Le pendant du même problème est la **fermeture** : le dernier mur d'une pièce
 * ne retombe jamais exactement sur le premier point. Fermer en déplaçant le seul
 * dernier sommet détruirait l'angle du dernier segment — celui-là même qu'on
 * venait de contraindre. La répartition de Bowditch, empruntée au cheminement
 * topographique, étale l'erreur sur tous les sommets au prorata du chemin
 * parcouru : la boucle se ferme **exactement** et chaque angle ne bouge qu'un peu.
 *
 * Comme `plan-commands.const.ts`, ce fichier ne contient **que des fonctions
 * pures** — ni Fabric, ni DOM, ni canvas. `FabricCanvasService` se contente de
 * lui fournir un contexte et d'appliquer le résultat.
 */
import { Point } from '../models/geometry.types';
export type { Point };
/** Pas angulaire, en degrés. 15° couvre les angles d'un logement : les 90° des
 *  pièces, les 45° des pans coupés, les 30/60° des combles. */
export declare const PAS_ANGULAIRE = 15;
/**
 * Demi-largeur de la zone d'attraction, en degrés.
 *
 * Volontairement **inférieure au demi-pas** (7,5°) : sinon toute direction
 * tomberait dans une zone et le tracé libre deviendrait impossible. À 4°, il
 * reste entre deux multiples une plage où le trait suit le doigt.
 */
export declare const TOLERANCE_ANGLE = 4;
/**
 * Attraction sur les multiples de 90°, doublée.
 *
 * L'équerre est ce qu'on cherche neuf fois sur dix dans un logement, et c'est
 * aussi là que l'erreur du doigt est la plus visible : un mur à 3° de
 * l'horizontale se voit immédiatement, un pan coupé à 48° au lieu de 45° ne se
 * voit pas.
 */
export declare const TOLERANCE_ORTHO: number;
/** Tolérance applicable au multiple `deg` : doublée sur les multiples de 90°. */
export declare function tolerancePour(deg: number): number;
/**
 * Contraint la direction `origine → pt` au multiple de `pas` le plus proche,
 * ou rend `null` si aucun multiple n'est assez près.
 *
 * Le point rendu est la **projection orthogonale** sur la demi-droite
 * contrainte, pas le point à distance égale : il reste ainsi le plus proche
 * possible du curseur, donc le tracé ne « saute » pas sous le doigt. La perte de
 * longueur est négligeable — 0,5 % au bord de la zone d'attraction à 8°.
 */
export declare function contraindreAngle(origine: Point, pt: Point, pas?: number): Point | null;
/** Tolérance d'alignement, en pixels. */
export declare const TOLERANCE_ALIGNEMENT = 8;
/**
 * Aligne `pt` sur l'abscisse et/ou l'ordonnée d'un point de référence.
 *
 * Sert à ce que deux murs parallèles séparés par une pièce entière tombent
 * malgré tout dans le même axe — ce qu'aucune contrainte d'angle ne peut faire,
 * puisqu'elle ne connaît que le segment courant. Les deux axes sont traités
 * indépendamment : un coin peut s'aligner verticalement sur un point et
 * horizontalement sur un autre.
 */
export declare function aligner(pt: Point, references: readonly Point[], tolerance?: number): Point | null;
export type TypeAccroche = 'noeud' | 'milieu' | 'segment' | 'angle' | 'alignement' | 'grille' | 'libre';
export interface Accroche extends Point {
    readonly type: TypeAccroche;
}
export interface ContexteAccroche {
    /** Nœuds et extrémités de murs — l'accroche la plus forte. */
    readonly noeuds: readonly Point[];
    /** Milieux de murs. */
    readonly milieux: readonly Point[];
    /** Murs et cloisons, pour les raccords en T. */
    readonly segments: readonly {
        p1: Point;
        p2: Point;
    }[];
    /** Dernier sommet posé, origine de la contrainte angulaire. `null` au premier
     *  point d'un tracé : il n'y a pas encore de direction à contraindre. */
    readonly origine: Point | null;
    /** Pas de grille, dernier recours. */
    readonly pas: number;
    readonly distNoeud: number;
    readonly distMur: number;
    /** Coupe tout magnétisme (touche Maj enfoncée). */
    readonly libre?: boolean;
}
/**
 * Point retenu pour un tracé de croquis, par ordre de priorité décroissante :
 *
 *  1. **nœud existant** — la topologie prime : deux murs qui se rejoignent
 *     doivent partager exactement le même point, sinon la détection de pièces
 *     ne voit pas le cycle ;
 *  2. **milieu de mur**, puis **projection sur un mur** — raccords en T ;
 *  3. **angle contraint** — l'apport de ce lot ;
 *  4. **alignement** sur l'existant ;
 *  5. **grille**.
 *
 * L'ordre n'est pas arbitraire : les accroches positionnelles passent avant
 * l'angulaire parce qu'un croquis dont les murs ne se touchent pas ne produit
 * aucune pièce, alors qu'un croquis d'équerre à 2° près reste lisible.
 */
export declare function accrocherCroquis(pt: Point, ctx: ContexteAccroche): Accroche;
/** Distance sous laquelle un retour près du point de départ vaut fermeture. */
export declare const RAYON_FERMETURE_M = 0.5;
/** Au-delà de ce rapport erreur/périmètre, la fermeture reste appliquée mais
 *  signalée : le croquis est trop faux pour que la répartition soit anodine. */
export declare const SEUIL_ALERTE_FERMETURE = 0.08;
export declare function rayonFermeturePx(pixelsPerMeter: number): number;
export interface Fermeture {
    /** Sommets corrigés — le dernier est **exactement** le premier. */
    readonly sommets: readonly Point[];
    /** Écart de fermeture avant correction, en pixels. */
    readonly erreurPx: number;
    readonly perimetrePx: number;
    /** Erreur rapportée au périmètre. Au-delà de `SEUIL_ALERTE_FERMETURE`,
     *  l'appelant avertit — sans bloquer. */
    readonly ratio: number;
}
/**
 * Répartition de Bowditch (règle de la boussole).
 *
 * `sommets` décrit un cheminement dont le dernier point *devrait* coïncider avec
 * le premier. Chaque sommet est décalé de l'erreur de fermeture au prorata du
 * chemin parcouru depuis le départ : le premier ne bouge pas, le dernier
 * encaisse la totalité et retombe exactement sur le premier.
 *
 * C'est ce qui permet de fermer **sans détruire les angles** : concentrer la
 * correction sur le dernier sommet ferait pivoter le dernier segment de tout
 * l'écart, alors que le réparti la fait pivoter d'une fraction. Un cheminement
 * dont on vient de contraindre chaque angle à 15° près reste d'équerre après
 * correction.
 *
 * Rend `null` si le tracé n'a pas de quoi former une boucle, ou s'il est de
 * longueur nulle.
 */
export declare function repartirBowditch(sommets: readonly Point[]): Fermeture | null;
