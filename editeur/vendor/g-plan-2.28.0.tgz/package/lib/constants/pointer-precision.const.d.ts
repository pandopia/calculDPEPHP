/**
 * Précision de visée du pointeur — le « trou de la tablette ».
 *
 * Le responsive de l'éditeur connaissait deux mondes : le téléphone
 * (`max-width: 768px` → mise en page compacte, cibles à 44 px) et le bureau
 * (pointeur fin, tout va bien). Une tablette n'est ni l'un ni l'autre : une
 * Galaxy Tab S10 Lite expose **960 px CSS de large** en paysage — au-dessus du
 * seuil compact, donc mise en page bureau — avec un **pointeur grossier**,
 * doigt ou stylet. Elle héritait donc des cibles pensées pour la souris.
 *
 * Le symptôme rapporté est exactement celui-là : « la résolution rendait
 * compliqué certaines actions comme la sélection de mur ». Un mur est une
 * `fabric.Line` : sa boîte de visée fait la largeur du trait, soit **4 px**.
 * Viser 4 px à la souris est banal, au stylet c'est un jeu d'adresse, et au
 * doigt (contact ≈ 8 mm, soit ~40 px CSS) c'est hors de portée.
 *
 * Ce module ne décide rien tout seul : il **répond une précision**, que le
 * service Fabric applique. Trois leviers, tous en pixels **écran** (Fabric
 * divise `padding` par le zoom, la tolérance est mesurée après transformation
 * du viewport) — la visée ne se dégrade donc pas quand on zoome.
 *
 * Aucun de ces réglages n'entre dans le document : `padding` ne figure pas dans
 * la liste sérialisée par `toObject()` de Fabric (vérifié dans
 * `fabric/dist/index.js`, il n'est ni destructuré ni repris par `pick`), et la
 * tolérance vit sur le canvas, pas sur les objets. Un plan dessiné sur tablette
 * et un plan dessiné au bureau restent **le même fichier**.
 */
import { FloorplanObjectType } from '../models/floorplan-object.model';
/** Réglages de visée déduits du type de pointeur. */
export interface PointerPrecision {
    /** `true` si le pointeur principal est grossier (doigt, stylet). */
    coarse: boolean;
    /**
     * Marge de visée ajoutée autour des objets fins, en pixels écran.
     * Devient le `padding` Fabric, qui élargit la zone de sélection sans rien
     * changer au dessin ni au document.
     */
    hitPaddingPx: number;
    /**
     * Tolérance du test « par pixel » (`targetFindTolerance` de Fabric), utilisée
     * par les objets en `perPixelTargetFind` — les polylignes de réseau, dont la
     * boîte englobante couvre parfois un quart du plan pour un trait de 3 px.
     */
    targetFindTolerance: number;
    /** Facteur appliqué au rayon des poignées de nœuds (murs et réseaux). */
    handleScale: number;
    /** Facteur appliqué au pas de grille du magnétisme. */
    gridScale: number;
}
/** Souris, trackpad, stylet de précision : rien à corriger. */
export declare const PRECISION_FINE: PointerPrecision;
/**
 * Doigt ou stylet.
 *
 * `hitPaddingPx: 7` porte la cible d'un mur de 4 px à **18 px** de large
 * (4 + 2 × 7) — au-dessus du seuil de 16 px sous lequel la visée au stylet
 * devient un jeu d'adresse, et en deçà du contact d'un doigt (~40 px), qu'on ne
 * cherche pas à couvrir : à ce point-là, deux murs voisins deviendraient
 * indiscernables et le remède serait pire que le mal.
 *
 * `handleScale: 1.4` porte une poignée de nœud de 5 à 7 unités (10 → 14 px de
 * diamètre), une jonction de 7 à ~10. Elles restent compensées du zoom.
 *
 * `gridScale: 1.5` reprend à l'identique le facteur tactile qui vivait en dur
 * dans `effectiveGrid` — il est ici pour qu'un seul endroit décrive « ce qui
 * change au doigt ».
 */
export declare const PRECISION_COARSE: PointerPrecision;
/** Précision correspondant au type de pointeur. */
export declare function pointerPrecision(coarse: boolean): PointerPrecision;
/**
 * Lit le type de pointeur principal.
 *
 * `pointer: coarse` et non une largeur d'écran : c'est la seule requête qui
 * parle de la **façon de viser**, et c'est elle qui distingue la tablette du
 * portable de même largeur. Elle décrit le pointeur *principal* — un stylet sur
 * tablette y répond `coarse`, ce qui est le bon verdict ici : sa pointe est
 * fine, mais la main qui la tient tremble à l'échelle du pixel.
 *
 * Fenêtre absente (SSR, test Node) ou `matchMedia` non implémenté (jsdom
 * ancien) : on répond `false`. Un faux négatif ne dégrade rien — c'est le
 * comportement historique.
 */
export declare function coarsePointer(win?: {
    matchMedia?: (q: string) => {
        matches: boolean;
    };
} | null): boolean;
/**
 * Types dont la cible de visée est **plus fine que le doigt**, et qui reçoivent
 * donc la marge de visée.
 *
 * Fermée volontairement, et pas « tout sauf les fonds » : élargir la cible d'un
 * objet déjà large ne gagne rien et coûte un vol de clic. Une `RoomBox` de 3 m
 * de côté n'a aucun besoin d'aide, mais si elle recevait 7 px de marge, ces
 * 7 px passeraient **au-dessus** du mur qui la borde dans l'ordre de recherche
 * de Fabric (du dessus vers le dessous) : viser le mur donnerait la pièce.
 *
 * - murs et cloisons : trait de 3 à 8 px ;
 * - réseaux : trait de 3 px, en polyligne ou en ligne des plans d'avant 2.1 ;
 * - portes et fenêtres : rectangles étroits posés sur le mur ;
 * - cotes : trait fin + texte, qu'on saisit pour corriger une mesure.
 */
export declare const FINE_TARGET_TYPES: readonly FloorplanObjectType[];
/** `true` si `myType` désigne un objet à cible fine (cf. `FINE_TARGET_TYPES`). */
export declare function isFineTarget(myType: unknown): boolean;
