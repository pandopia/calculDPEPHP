/**
 * Extraction géométrique unifiée — coordonnées de scène d'un objet de plan.
 *
 * Un seul jeu de fonctions, partagé par tout ce qui a besoin de savoir *où* se
 * trouve un objet : détection de pièces, analyse, vue 3D, export GeoJSON. La
 * règle est celle de `pipe-geometry.const.ts`, dont ce fichier généralise
 * l'approche : ne lire que des propriétés présentes **aussi bien sur un objet
 * Fabric vivant que sur sa forme sérialisée** (`toObject`). C'est indispensable
 * — l'analyseur, la vue 3D et l'exportateur géographique travaillent sur des
 * projets stockés, sans canvas.
 *
 * ## Biais du demi-trait, assumé
 *
 * `absLineEnds` reprend **à l'identique** la formule historique de
 * `GeometryService.getAbsoluteLineEnds` : `left − min(x1, x2)`, alors que Fabric
 * pose `left = min(x1, x2) − strokeWidth / 2`. Les extrémités ressortent donc
 * décalées d'un demi-trait — 2,5 px pour un `Mur`, 1,5 px pour une `Cloison`,
 * soit ~13 cm au sol sur un fond de carte.
 *
 * Ce biais n'est **pas** corrigé, et ce n'est pas un oubli : les polygones
 * `DetectedRoom` sont construits sur ces mêmes extrémités (`recalculateRooms`),
 * comme les surfaces qui en découlent. Le corriger ici seulement rendrait la
 * géométrie incohérente avec elle-même — les murs ne borderaient plus les
 * pièces qu'ils délimitent. Soit on corrige partout en rejouant les specs de
 * détection, soit on assume partout : c'est la seconde branche qui est retenue,
 * et le décalage est **annoncé** dans la précision de l'export géographique.
 *
 * ## Ce qui n'est volontairement pas pris en compte
 *
 * `absPolylinePoints` ignore `angle` et `scaleX/scaleY` de l'objet, exactement
 * comme le faisait `pipeAbsPoints` avant cette factorisation : un tracé n'est
 * jamais pivoté ni redimensionné par l'éditeur, seulement déplacé et réécrit
 * sommet par sommet. Un objet pivoté à la main par un hôte ressortirait faux.
 */
import { Point } from '../models/geometry.types';
/**
 * Extrémités absolues d'une ligne à deux points (`Mur`, `Cloison`, et les
 * réseaux des plans antérieurs à 2.1).
 *
 * `x1/y1/x2/y2` sont les coordonnées de construction ; après un glissement
 * Fabric natif, `left ≠ min(x1, x2)` et c'est cet écart qui porte le
 * déplacement. Renvoie `null` si l'objet n'est pas une ligne.
 *
 * **L'origine est prise en compte** (depuis la 2.23.2), et ce n'était pas un
 * détail. La formule supposait `originX/originY: 'left'/'top'` — ce que la
 * bibliothèque impose bien par défaut (`FabricObject.ownDefaults`, cf. CLAUDE.md)
 * — mais l'import du scanner posait ses murs en `'center'`. Les extrémités
 * ressortaient alors décalées d'une **demi-longueur de mur**, avec deux
 * conséquences visibles et une invisible : les poignées de nœuds flottaient à
 * côté du plan, **aucune pièce n'était détectée** — les murs ne partageaient plus
 * aucun nœud, donc le graphe n'avait plus un seul cycle — et les longueurs
 * calculées étaient justes par accident, la formule conservant l'écart p2 − p1.
 * Le plan *paraissait* correct : c'est le motif de panne que ce dépôt traque.
 *
 * Définition **unique** de cette formule dans la bibliothèque : `GeometryService`,
 * `PlanAnalysisService` et `pipeAbsPoints` s'y ramènent tous.
 */
export declare function absLineEnds(obj: any): {
    p1: Point;
    p2: Point;
} | null;
/**
 * Distance d'un point à un segment, projection bornée aux extrémités.
 *
 * Écrite ici parce que trois appelants la refaisaient — `GeometryService`, le
 * scanner et le service Fabric — et qu'une définition dupliquée finit toujours
 * par diverger sur le cas dégénéré (segment de longueur nulle), qui rend ici la
 * distance au point lui-même plutôt qu'un `NaN`.
 */
export declare function distancePointSegment(p: Point, a: Point, b: Point): number;
/**
 * Sommets absolus d'un objet à liste de points (`Polyline`, `Polygon`).
 *
 * Fabric stocke les points dans le repère local et positionne l'objet par sa
 * boîte englobante **rendue**, laquelle inclut la moitié du trait de chaque
 * côté : d'où le `+ strokeWidth / 2`. Sans lui les sommets ressortent décalés
 * d'un demi-trait — invisible à l'œil, suffisant pour faire dériver un calage.
 */
export declare function absPolylinePoints(obj: any): Point[];
/**
 * Sommets absolus d'un tracé linéaire, quel que soit son format : polyligne
 * (mur ou réseau depuis 2.1) ou ligne à deux points (plans antérieurs).
 * Liste vide si l'objet ne porte aucune géométrie linéaire.
 */
export declare function absTracePoints(obj: any): Point[];
/**
 * Les quatre coins absolus d'un objet rectangulaire (`RoomBox`, `HazardZone`,
 * `Stair`…), dans l'ordre horaire à l'écran, rotation et mise à l'échelle
 * comprises. Liste vide si l'objet n'a pas de dimensions exploitables.
 *
 * Le trait n'est pas retranché : le reste de la bibliothèque lit ces objets de
 * la même façon (`generateEnvelope`, `snapForRoomSketch`), et l'écart d'un
 * demi-trait — 1 px au plus — vaut ~10 cm au sol. Même arbitrage que le biais
 * du demi-trait des murs : cohérent partout plutôt que juste à un seul endroit.
 */
export declare function absRectCorners(obj: any): Point[];
/**
 * Contour absolu d'un objet surfacique : ses sommets s'il en porte
 * (`DetectedRoom`), sinon les quatre coins de son rectangle. Le contour n'est
 * **pas** refermé — c'est à l'appelant de le faire selon son format.
 */
export declare function absRingPoints(obj: any): Point[];
/**
 * Centre absolu d'un objet ponctuel (pictogramme, équipement, prélèvement,
 * porte, fenêtre…). Presque tous sont posés en `originX/originY: 'center'` :
 * le centre est alors `left`/`top` lui-même. Le calcul reste général pour
 * couvrir les objets ancrés au coin (`HazardZone` d'un plan ancien, par ex.).
 *
 * Renvoie `null` si l'objet n'a aucune position exploitable.
 */
export declare function absCenter(obj: any): Point | null;
/**
 * Enveloppe convexe d'un nuage de points (parcours monotone d'Andrew).
 *
 * **Pourquoi elle existe.** La vue 3D posait sa dalle et sa pelouse sur une boîte
 * englobante **alignée sur les axes** (min/max en X et Z). C'est juste pour un
 * bâtiment d'équerre, et faux dès qu'il est tracé de biais — ce qui est le cas
 * ordinaire d'un croquis posé sur une orthophoto, où l'on suit l'orientation
 * réelle du bâti. Sur une pièce tournée de 20°, la boîte déborde de plusieurs
 * mètres sur les quatre côtés : la dalle sortait franchement du dessin.
 *
 * L'enveloppe convexe suit l'orientation, elle. Elle comble le renfoncement d'un
 * bâtiment en L — une dalle légèrement plus grande que l'emprise reste physique,
 * là où une boîte non orientée est visiblement fausse.
 *
 * Rend les sommets dans le sens **trigonométrique**, sans doublon. Moins de trois
 * points distincts : rend l'entrée telle quelle, il n'y a pas d'enveloppe.
 */
export declare function convexHull(points: readonly Point[]): Point[];
/**
 * Dilate un polygone convexe de `marge`, en poussant chaque sommet le long de sa
 * bissectrice depuis le centroïde.
 *
 * Suffisant ici : une dalle déborde des murs de quelques dizaines de centimètres,
 * et sur un polygone convexe cette approximation ne peut pas se replier sur
 * elle-même. Elle n'est pas un offset exact — inutile de l'utiliser pour autre
 * chose.
 */
export declare function dilaterConvexe(poly: readonly Point[], marge: number): Point[];
