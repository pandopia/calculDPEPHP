/**
 * Contraste des couleurs — mesure, pas intention.
 *
 * **Pourquoi ce module existe.** Un plan est d'abord un dessin de traits, et la
 * couleur d'un trait est souvent la **seule** information qu'il porte : une
 * polyligne cyan est un réseau d'eaux pluviales, la même en jaune est
 * l'électricité. Si ce trait ne se détache pas du fond, l'information n'est pas
 * dégradée — elle est absente. C'est l'objet du critère WCAG 2.1 **1.4.11
 * (Non-text Contrast)** : tout élément graphique porteur d'information doit
 * atteindre **3:1** avec ce qui l'entoure.
 *
 * La mesure a été faite avant d'écrire quoi que ce soit, et quatre des neuf
 * couleurs de canalisation échouaient franchement sur le fond blanc du canvas :
 * EP `#22d3ee` à **1,81:1**, Élec `#eab308` à **1,92:1**, Gaz `#f59e0b` à
 * **2,15:1**, Fibre `#06b6d4` à **2,43:1**. Les cinq autres passaient. Les
 * valeurs corrigées vivent dans `pipe-labels.const.ts` (`PIPE_COLORS`), et
 * `pipe-labels.const.spec.ts` les vérifie avec les fonctions d'ici — de sorte
 * qu'une couleur ajoutée demain ne puisse pas retomber sous le seuil sans que
 * la suite ne le dise.
 *
 * Module **pur** : ni Fabric, ni DOM, ni canvas. La formule de luminance est
 * celle de WCAG 2.x, appliquée en sRGB, sans gestion de profil colorimétrique —
 * c'est exactement ce que la norme demande.
 */
/** Composantes d'une couleur, 0-255, alpha 0-1. */
export interface Rgba {
    r: number;
    g: number;
    b: number;
    a: number;
}
/** Fond du canvas de l'éditeur — la référence de tout trait dessiné.
 *  Posé par `FabricCanvasService.init()` (`canvas.backgroundColor = '#ffffff'`). */
export declare const PLAN_BACKGROUND = "#ffffff";
/** Seuil WCAG 2.1 §1.4.11 pour un élément graphique porteur d'information. */
export declare const MIN_GRAPHIC_CONTRAST = 3;
/**
 * Analyse une couleur CSS : `#rgb`, `#rrggbb`, `rgb()`, `rgba()`.
 *
 * Les couleurs **nommées** (`red`, `transparent`) rendent `null` plutôt qu'une
 * valeur inventée : sans DOM on ne peut pas les résoudre, et rendre du noir par
 * défaut ferait passer pour « très contrasté » une couleur qu'on n'a pas su
 * lire. Un `null` se voit ; un noir supposé, non.
 */
export declare function parseCssColor(color: unknown): Rgba | null;
/** Luminance relative WCAG (0 = noir, 1 = blanc). Rend `null` si la couleur
 *  n'est pas lisible — l'appelant décide quoi en faire. */
export declare function relativeLuminance(color: string): number | null;
/**
 * Rapport de contraste entre deux couleurs, de 1 (identiques) à 21
 * (noir sur blanc). Rend `null` si l'une des deux n'est pas lisible.
 *
 * L'alpha n'est **pas** pris en compte : composer une couleur semi-transparente
 * sur son fond demanderait de connaître tout l'empilement, et une valeur
 * approchée serait pire qu'une absence de valeur sur un critère normatif.
 */
export declare function contrastRatio(a: string, b: string): number | null;
/**
 * Le trait `color` se détache-t-il assez du fond `background` ?
 *
 * Une couleur illisible rend `false` : sur un critère d'accessibilité, ce qu'on
 * ne sait pas mesurer ne doit pas être déclaré conforme.
 */
export declare function meetsGraphicContrast(color: string, background?: string, min?: number): boolean;
