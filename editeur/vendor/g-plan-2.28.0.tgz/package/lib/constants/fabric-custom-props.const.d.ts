/**
 * Déclare les propriétés métier auprès de TypeScript, en plus de les déclarer
 * auprès du runtime Fabric (voir `registerFabricCustomProperties` plus bas).
 * Les deux sont nécessaires et distincts : sans cette augmentation, tout
 * `new Line({ …, myType: 'Mur' })` échoue à la compilation depuis la v6, qui
 * type strictement les objets littéraux de configuration.
 *
 * `myType` est typé `string` et non `FloorplanObjectType` à dessein : certains
 * marqueurs internes n'appartiennent pas au domaine métier ('GhostFloor', posé
 * par `showGhostFloor`). Cela reste cohérent avec le typage volontairement
 * souple du canvas, documenté dans CLAUDE.md.
 */
declare module 'fabric' {
    interface FabricObjectProps {
        myType?: string;
        data?: any;
        roomName?: string;
        isPrimary?: boolean;
    }
    interface FabricObject {
        myType?: string;
        data?: any;
        roomName?: string;
        isPrimary?: boolean;
    }
}
/**
 * Propriétés métier portées par les objets Fabric et qui DOIVENT survivre à un
 * cycle sérialisation → rechargement :
 *  - `myType`    : discriminant `FloorplanObjectType` ('Mur', 'PipeAEP', …)
 *  - `data`      : charge utile par objet (material, wallId, hazardType, …)
 *  - `roomName`  : nom de pièce saisi par l'utilisateur
 *  - `isPrimary` : marqueur de pièce principale
 *
 * En Fabric v5, on les passait à chaque appel : `canvas.toJSON([...])`.
 * **Depuis la v6, `toJSON()` n'accepte plus d'arguments** : les propriétés
 * supplémentaires se déclarent une fois pour toutes sur `FabricObject`. Sans
 * cette déclaration, elles sont perdues **silencieusement** — le plan se
 * recharge sans erreur mais vide de tout sens métier.
 *
 * L'enregistrement se fait ici, dans la librairie, et non dans le bootstrap de
 * l'application hôte : faire dépendre l'intégrité des données d'une ligne que
 * l'intégrateur doit penser à écrire n'est pas tenable.
 */
export declare const FABRIC_CUSTOM_PROPS: readonly ["myType", "data", "roomName", "isPrimary"];
/**
 * Déclare les propriétés métier auprès de Fabric. Idempotent, et appelé par
 * tous les services qui sérialisent ou rechargent un canvas — plutôt qu'en
 * effet de bord d'import, que le `sideEffects: false` du paquet autoriserait un
 * bundler à supprimer.
 */
export declare function registerFabricCustomProperties(): void;
