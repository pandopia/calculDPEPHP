/**
 * Calque photo — redressement par homographie 4 points et calage à l'échelle.
 *
 * **Pourquoi ce module existe.** `grep -riE "perspective|homograph|warp"` ne
 * trouvait *aucun* redressement dans la bibliothèque : une photo prise de biais
 * restait de biais, et rien ne donnait l'échelle — le scanner OpenCV renvoyait
 * un `pixelsPerMeter` de 50 arbitraire, par un ternaire dont les deux branches
 * valaient 50 (`FEATURE-releve-piece-sans-plan.md § 1`). Une photo de plan
 * papier était donc un fond de décalque **faux dans les deux dimensions**.
 *
 * Le redressement d'un quadrilatère photographié est un problème résolu — c'est
 * exactement ce que fait toute application de numérisation de document. Il tient
 * en un système 8×8 et une élimination de Gauss : **zéro WASM, zéro dépendance
 * ajoutée**, contre les 8 Mo d'OpenCV.js chargés d'un CDN externe (donc
 * indisponibles dans un vide sanitaire, ce qui est précisément le terrain).
 *
 * ## Les trois décisions qui structurent le module
 *
 * **1. On stocke l'image d'origine et la matrice, jamais les pixels déformés.**
 * C'est plus léger (une seule image persistée au lieu de deux) et c'est
 * réversible : les quatre coins restent modifiables après coup, et un plan
 * enregistré peut être re-redressé sans avoir perdu la photo d'origine. Les
 * pixels redressés sont regénérés à l'affichage par le pont
 * (`PhotoLayerService`), jamais sérialisés. Le poids est un enjeu mesuré, pas
 * théorique : un fond de carte PNG a déjà fait sauter le quota `localStorage`
 * (5 290 Ko) et cassé la restauration du brouillon.
 *
 * **2. Le rapport d'aspect est *recouvré*, pas supposé.** Prendre le rectangle
 * de destination « à la taille moyenne des côtés » revient à supposer que la
 * photo était fronto-parallèle : sur une prise de vue à 30°, un axe est étiré de
 * 15 à 20 % par rapport à l'autre. Comme le calage se fait ensuite par **une
 * seule** distance connue, cette erreur d'aspect se reporte intégralement sur
 * tous les murs mesurés dans l'autre direction — et le critère des 5 % tombe.
 * On recouvre donc focale *et* rapport d'aspect à partir des quatre coins, par
 * les points de fuite (méthode de Zhang & He), avec repli documenté sur la
 * moyenne des côtés quand la configuration ne porte plus d'information de
 * perspective exploitable (§ `quadAspectRatio`).
 *
 * **3. Une seule distance connue suffit à caler l'image.** Le diagnostiqueur
 * mesure un mur au télémètre laser — l'outil est déjà dans sa poche et
 * obligatoire pour le mesurage Carrez/Boutin — saisit la valeur une fois, et
 * toute l'image est à l'échelle. Pas de Bluetooth, pas de WebXR, pas de
 * permission, hors ligne, sur tous les téléphones (cf. § 2 de la note : tout ce
 * qui tire une mesure du matériel est Android-seul dans une PWA).
 *
 * Comme `plan-graph.const.ts`, `sketch-snap.const.ts` et
 * `wall-dimension.const.ts`, ce fichier ne contient **que des fonctions pures**
 * — ni Fabric, ni DOM, ni canvas, donc testable sans navigateur. Le pont vers
 * les pixels et vers Fabric vit dans `PhotoLayerService`, et nulle part ailleurs.
 */
import { Point } from '../models/geometry.types';
/**
 * Matrice 3×3 homogène, **en ligne-major** : `[a,b,c, d,e,f, g,h,i]` pour
 * ```
 *   | a b c |
 *   | d e f |
 *   | g h i |
 * ```
 * Elle est définie **à un facteur près** (coordonnées homogènes) : deux
 * matrices proportionnelles décrivent la même transformation. Ne jamais
 * comparer deux homographies terme à terme — comparer l'image de quelques
 * points.
 */
export type Homography = readonly [
    number,
    number,
    number,
    number,
    number,
    number,
    number,
    number,
    number
];
/** Comment le rapport d'aspect du rectangle redressé a été obtenu. */
export type AspectMethod = 'vanishing-points' | 'mean-sides';
/** Côté maximal de la photo persistée, en pixels. Réglage éprouvé en 2.5.0 sur
 *  le fond de carte : au-delà, le gain visuel est nul sur un fond de décalque et
 *  le poids explose. */
export declare const MAX_PHOTO_SIZE_PX = 2048;
/** Qualité WebP de la photo persistée. Même arbitrage que le fond de carte :
 *  l'encodage est **natif** (`canvas.toDataURL`), donc rien à télécharger et un
 *  fonctionnement hors ligne inchangé. */
export declare const PHOTO_WEBP_QUALITY = 0.8;
/**
 * Plafond de poids de la photo persistée, en octets de `data:` URL.
 *
 * Ce n'est pas une précaution de principe : un fond de carte PNG a porté un
 * projet à 5 290 Ko, `localStorage.setItem` levait `QuotaExceededError`,
 * l'autosave échouait **en silence** et le brouillon proposé au démarrage
 * datait d'avant la pose du fond — le restaurer vidait le plan en cours.
 */
export declare const MAX_PHOTO_BYTES = 1500000;
/**
 * Au-delà de ce rapport `focale / diagonale du quadrilatère`, la perspective
 * recouvrée n'est plus qu'un artefact numérique : le quadrilatère est presque un
 * parallélogramme, les points de fuite partent à l'infini et une variation d'un
 * pixel sur un coin fait varier la focale d'un ordre de grandeur. On bascule
 * alors sur le repli « moyenne des côtés », qui ne prétend rien recouvrer.
 * Valeur très permissive : une photo réelle, même peu inclinée, reste bien en
 * deçà (typiquement 0,5 à 2).
 */
export declare const FOCAL_TRUST_RATIO = 20;
/**
 * Marge laissée **autour** du document dans l'image redressée, en part de sa
 * taille.
 *
 * **Sans elle, le redressement se retourne contre l'utilisateur.** Les quatre
 * coins épousent le document — le contour du dessin quand ils sont déduits des
 * points de fuite, le bord de la feuille quand ils sont posés à la main. Envoyer
 * ces coins sur le rectangle plein place les murs de l'enveloppe **exactement
 * sur la frontière** de l'image redressée : on ne peut plus ni les saisir, ni
 * les prolonger, ni tracer le contour du bâtiment, qui est pourtant le premier
 * geste du relevé.
 *
 * La marge est prise **à la destination**, et non en dilatant le quadrilatère
 * détecté, pour deux raisons :
 *  1. elle vaut alors pour **tous** les chemins — coins automatiques ou posés au
 *     doigt — et pas seulement pour le redressement par points de fuite ;
 *  2. dilater le quadrilatère déforme la figure (`dilaterConvexe` pousse les
 *     sommets à distance constante, ce n'est pas une homothétie), or c'est sa
 *     forme qui porte la perspective, donc le rapport d'aspect et la focale
 *     recouvrés. On paierait la marge en justesse.
 *
 * Ce que la marge contient : la photo elle-même, tout simplement — le pourtour
 * du dessin sur la feuille. Au-delà de la photo, `warp` laisse **transparent**.
 *
 * 12 % de chaque côté laissent de quoi tracer une enveloppe sans diluer le
 * dessin dans du vide.
 */
export declare const MARGE_REDRESSEMENT = 0.12;
/** Résultat du redressement d'un quadrilatère. */
export interface PhotoRectification {
    /** Coins **réordonnés** dans l'image source : haut-gauche, haut-droit,
     *  bas-droit, bas-gauche. */
    readonly corners: readonly Point[];
    /** Largeur **totale** de l'image redressée, marge comprise, en pixels. */
    readonly width: number;
    /** Hauteur **totale** de l'image redressée, marge comprise, en pixels. */
    readonly height: number;
    /** Largeur du **document** seul, sans la marge. */
    readonly contentWidth: number;
    /** Hauteur du **document** seul, sans la marge. */
    readonly contentHeight: number;
    /** Abscisse du coin haut-gauche du document dans l'image redressée. */
    readonly offsetX: number;
    /** Ordonnée du coin haut-gauche du document dans l'image redressée. */
    readonly offsetY: number;
    /** Homographie **source → redressé**. */
    readonly matrix: Homography;
    /** Homographie **redressé → source** : c'est elle que parcourt le rendu, qui
     *  travaille par image inverse pour ne laisser aucun trou. */
    readonly inverse: Homography;
    /** Rapport largeur/hauteur retenu pour le rectangle. */
    readonly ratio: number;
    /** Focale recouvrée en pixels, ou `null` si l'aspect vient du repli. */
    readonly focalPx: number | null;
    readonly method: AspectMethod;
}
/** Options de `rectifyQuad`. La taille de l'image est **exigée** : le point
 *  principal (centre optique) s'en déduit, et le supposer ailleurs fausserait la
 *  focale donc le rapport d'aspect. */
export interface RectifyOptions {
    readonly imageWidth: number;
    readonly imageHeight: number;
    /** Côté maximal de l'image redressée, **marge comprise**. Défaut
     *  `MAX_PHOTO_SIZE_PX`. */
    readonly maxSize?: number;
    /** Marge laissée autour du document, en part de sa taille. Défaut
     *  `MARGE_REDRESSEMENT`. Passer `0` colle le document aux bords — à ne faire
     *  que si personne ne doit dessiner par-dessus. */
    readonly margin?: number;
}
/**
 * Charge utile persistée sur l'objet Fabric du calque (`data.photo`).
 *
 * Tout y est **petit** : quelques dizaines d'octets. La seule donnée lourde est
 * l'image d'origine, portée une fois par le `src` de l'objet Fabric — et pas une
 * deuxième fois ici, ce que garde un test.
 */
export interface PhotoLayerData {
    /** Homographie source → redressé, 9 nombres en ligne-major. */
    readonly homography: readonly number[];
    /** Les quatre coins posés par l'utilisateur, dans l'image **persistée**
     *  (c'est-à-dire après redimensionnement à `MAX_PHOTO_SIZE_PX`). */
    readonly corners: readonly Point[];
    /** Taille du rectangle redressé, en pixels. */
    readonly width: number;
    readonly height: number;
    /** Taille de l'image persistée, en pixels — sans elle on ne peut pas vérifier
     *  que l'homographie décrit bien l'image rechargée. */
    readonly sourceWidth: number;
    readonly sourceHeight: number;
    readonly ratio: number;
    readonly method: AspectMethod;
    readonly focalPx: number | null;
    /** Distance réelle saisie par l'utilisateur, en mètres. */
    readonly knownDistanceM: number | null;
    /** Les deux points, en coordonnées **redressées**, entre lesquels la distance
     *  a été relevée. Conservés pour pouvoir recaler sans tout reprendre. */
    readonly knownPoints?: readonly Point[];
    /** Pixels **redressés** par mètre. `null` tant que rien n'a été calé. */
    readonly pixelsPerMeter: number | null;
}
/**
 * Homographie envoyant les quatre points `src` sur les quatre points `dst`.
 *
 * Chaque correspondance donne deux équations linéaires ; quatre correspondances
 * donnent le système 8×8 résolu ci-dessus. Le neuvième coefficient est fixé à 1
 * dans l'espace **normalisé** (cf. `normalization`), puis la matrice est
 * ramenée dans les coordonnées d'origine par `T_dst⁻¹ · H' · T_src`.
 *
 * Rend `null` si l'un des jeux est dégénéré — trois points alignés, deux points
 * confondus — parce qu'alors aucune homographie n'existe et qu'une matrice
 * approchée serait pire qu'un refus : elle produirait un calque plausible et
 * faux.
 */
export declare function solveHomography(src: readonly Point[], dst: readonly Point[]): Homography | null;
/**
 * Image d'un point par une homographie.
 *
 * Rend `null` quand le point tombe sur la **droite de fuite** (`w = 0`) : son
 * image est à l'infini. Ce n'est pas un cas d'école — c'est l'horizon de la
 * photo, et il traverse l'image dès qu'on photographie un sol de biais. Rendre
 * un `Infinity` silencieux ferait ensuite dessiner un mur à des coordonnées
 * absurdes.
 */
export declare function applyHomography(h: Homography | null | undefined, p: Point): Point | null;
/**
 * Inverse d'une homographie, par la comatrice (`adj(H) / det(H)`).
 *
 * L'inverse sert au rendu : on parcourt le rectangle redressé et on va chercher
 * le pixel source correspondant. Parcourir dans l'autre sens laisserait des
 * trous là où l'image est étirée.
 */
export declare function invertHomography(h: Homography | null | undefined): Homography | null;
/**
 * Réordonne quatre coins posés dans n'importe quel ordre en
 * **haut-gauche, haut-droit, bas-droit, bas-gauche**.
 *
 * Méthode : tri angulaire autour du centre de gravité (qui donne l'ordre
 * cyclique du quadrilatère, donc élimine un ordre en « Z »), orientation forcée
 * dans le sens horaire à l'écran, puis rotation de la liste pour partir du coin
 * de plus petite somme `x + y`.
 *
 * **Hypothèse assumée** : le document photographié est *à peu près* debout dans
 * le cadre. Sur une photo tournée de 45°, « haut-gauche » n'a plus de sens et le
 * choix devient arbitraire — sans conséquence sur le redressement lui-même, qui
 * reste correct, mais le rectangle sortira couché. C'est le compromis de toutes
 * les applications de numérisation de document.
 *
 * Rend `null` si le quadrilatère est dégénéré : trois points alignés, deux
 * points confondus, ou contour croisé.
 */
export declare function orderQuadCorners(quad: readonly Point[]): Point[] | null;
/** Rapport d'aspect recouvré, et ce qui a permis de le recouvrer. */
export interface AspectResult {
    /** Largeur / hauteur du rectangle réel. */
    readonly ratio: number;
    /** Focale en pixels, ou `null` si l'aspect vient du repli. */
    readonly focalPx: number | null;
    readonly method: AspectMethod;
}
/**
 * Recouvre le rapport largeur/hauteur du **rectangle réel** photographié, et
 * avec lui la focale, à partir des seuls quatre coins.
 *
 * ## La méthode, en clair
 *
 * L'homographie qui envoie le carré unité sur les quatre coins vaut
 * `s·K·[w·r₁, h·r₂, t]` : sa première colonne est `s·w·K·r₁`, sa deuxième
 * `s·h·K·r₂`, où `r₁` et `r₂` sont **unitaires et orthogonaux** (ce sont deux
 * colonnes d'une rotation). Deux conséquences immédiates :
 *
 *  - l'orthogonalité `(K⁻¹c₁)·(K⁻¹c₂) = 0` donne la focale, seule inconnue de
 *    `K = diag(f, f, 1)` une fois le point principal posé au centre de l'image ;
 *  - le rapport `‖K⁻¹c₁‖ / ‖K⁻¹c₂‖` vaut alors exactement `w/h`, le facteur
 *    d'échelle inconnu `s` se simplifiant.
 *
 * Les deux colonnes s'obtiennent des quatre coins en résolvant
 * `−λ₁m₁ + λ₂m₂ + λ₃m₃ = m₄` (les coins étant homogènes, chacun connu à un
 * facteur près) : un système 3×3, résolu par le même Gauss que le 8×8.
 *
 * ## Quand la méthode ne dit rien, et ce qu'on fait alors
 *
 * Si le quadrilatère est un parallélogramme — photo fronto-parallèle, ou objet
 * loin devant un téléobjectif — les points de fuite partent à l'infini, `f²`
 * sort négatif ou astronomique, et la perspective ne porte plus aucune
 * information. On bascule alors sur la **moyenne des côtés opposés**, qui
 * suppose la vue fronto-parallèle : c'est faux en général, mais dans ce cas
 * précis c'est justement vrai, et surtout `method` le dit à l'appelant au lieu
 * de le taire.
 */
export declare function quadAspectRatio(quad: readonly Point[], principal: Point): AspectResult | null;
/**
 * Taille rabattue sous un côté maximal, en conservant le rapport d'aspect.
 * Ne grandit jamais : réduire une photo est légitime, l'agrandir n'apporterait
 * que du poids.
 */
export declare function fitWithin(width: number, height: number, max: number): {
    width: number;
    height: number;
    scale: number;
} | null;
/**
 * Redresse un quadrilatère photographié en rectangle debout.
 *
 * La **taille** du rectangle de destination est choisie pour conserver l'aire
 * apparente du quadrilatère (moyenne géométrique des côtés moyens), répartie
 * selon le rapport d'aspect recouvré : agrandir n'inventerait pas de détail, et
 * réduire jetterait de la résolution là où la photo en avait.
 *
 * Le document n'est **pas** collé aux bords : il est posé au centre d'une image
 * plus grande de `margin` de chaque côté (cf. `MARGE_REDRESSEMENT`), sans quoi
 * les murs de l'enveloppe tomberaient sur la frontière même de l'image. La marge
 * est une **translation**, pas un changement d'échelle : `pixelsPerMeter`, les
 * longueurs et les surfaces sont rigoureusement les mêmes avec ou sans elle.
 *
 * `maxSize` borne l'image **totale**, marge comprise : c'est elle qu'un canvas
 * devra porter.
 *
 * Rend `null` sur un quadrilatère dégénéré.
 */
export declare function rectifyQuad(quad: readonly Point[], opts: RectifyOptions): PhotoRectification | null;
/**
 * Échelle du calque à partir d'**une seule** distance connue.
 *
 * `a` et `b` sont deux points de l'image **source** (ceux que l'utilisateur a
 * désignés sur sa photo) ; ils sont d'abord redressés, puis leur écartement
 * rapporté à la longueur relevée au télémètre. C'est ce qui rend la brique
 * utilisable hors ligne et sur tous les téléphones : rien d'autre à mesurer.
 *
 * Rend des **pixels redressés par mètre**, ou `null` si la mesure est
 * inexploitable (points confondus, distance nulle ou négative, point sur la
 * droite de fuite).
 */
export declare function scaleFromKnownDistance(matrix: Homography | null | undefined, a: Point, b: Point, knownM: number): number | null;
/** Le calage : deux points de l'image **source** et la distance réelle qui les
 *  sépare, relevée au télémètre. */
export interface PhotoCalibration {
    readonly a: Point;
    readonly b: Point;
    /** Distance réelle entre `a` et `b`, en mètres. */
    readonly knownM: number;
}
/**
 * Assemble la charge utile persistée du calque.
 *
 * Les deux points de calage y sont enregistrés en coordonnées **redressées** et
 * non dans l'image source : c'est le repère dans lequel ils gardent un sens si
 * les coins sont repris plus tard, et celui dans lequel `pixelsPerMeter` est
 * exprimé. On ne stocke jamais de pixels déformés, mais on stocke bien la
 * mesure dans le repère où elle vaut.
 *
 * Un calage absent ou inexploitable n'est **pas** une erreur : le calque reste
 * posable comme simple décalque, à l'échelle courante du plan, et
 * `pixelsPerMeter` vaut alors `null` — ce que l'interface dit à l'utilisateur.
 */
export declare function photoLayerData(rect: PhotoRectification | null | undefined, sourceWidth: number, sourceHeight: number, calibration?: PhotoCalibration | null): PhotoLayerData | null;
/**
 * Facteur d'échelle à appliquer au calque pour qu'un mètre du calque mesure un
 * mètre du plan.
 *
 * **C'est le calque qui s'adapte au plan, jamais l'inverse.** Changer le
 * `pixelsPerMeter` du plan pour l'aligner sur la photo réécrirait toutes les
 * longueurs et toutes les surfaces déjà saisies — y compris les cotes relevées
 * au télémètre de la brique A — sans que l'utilisateur ait rien demandé d'autre
 * que de poser un décalque.
 *
 * Rend `null` si le calque n'est pas calé : il est alors posé à l'échelle 1,
 * comme n'importe quelle image de fond.
 */
export declare function photoLayerScale(photo: PhotoLayerData | null | undefined, planPixelsPerMeter: number): number | null;
/**
 * Relit une homographie venue d'un document JSON.
 *
 * Un plan est un **contrat public** relu par Gordon-PWA : la matrice qui en
 * revient peut être tronquée, remplie de `null` ou avoir été retapée à la main.
 * On la refuse alors, plutôt que de redresser une photo avec du `NaN` — ce qui
 * donnerait un calque vide sans le moindre message.
 */
export declare function toHomography(raw: unknown): Homography | null;
