/**
 * Redressement automatique par **points de fuite**.
 *
 * **Pourquoi cette approche.** On a d'abord essayé de détecter la feuille — le
 * plus grand quadrilatère de l'image — puis de la redresser. Mesuré sur une
 * photo réelle : aucun quadrilatère. On cadre serré pour que le plan remplisse
 * l'image, le contour du support sort donc du champ, et `approxPolyDP` ne rend
 * jamais quatre côtés. Cette voie est un cul-de-sac dès que la photo est bien
 * cadrée, c'est-à-dire toujours.
 *
 * Les points de fuite, eux, n'ont pas besoin de voir la feuille : ils se lisent
 * sur **le dessin lui-même**. Un plan est fait de deux familles de parallèles
 * perpendiculaires ; en perspective, chacune converge vers un point de fuite. Les
 * deux points suffisent à retrouver l'orientation du plan de la feuille — c'est
 * ce que fait déjà `rectifyQuad` quand on lui donne quatre coins connus pour
 * former un rectangle. On lui fabrique donc ce rectangle : deux traits extrêmes
 * de chaque famille, et leurs quatre intersections.
 *
 * Module **pur** : aucune dépendance à OpenCV, à Fabric ni au DOM.
 */
import { Point } from '../models/geometry.types';
export interface Segment {
    readonly x1: number;
    readonly y1: number;
    readonly x2: number;
    readonly y2: number;
}
/**
 * Écart angulaire maximal, en degrés, entre un segment et la direction moyenne
 * de sa famille.
 *
 * Assez large pour absorber la perspective — c'est justement elle qui fait
 * diverger les parallèles — et assez étroit pour ne pas mélanger les deux
 * familles. Une photo prise à plus de 40° d'inclinaison n'est de toute façon plus
 * exploitable.
 */
export declare const ECART_FAMILLE_DEG = 30;
/**
 * Nombre minimal de traits par famille.
 *
 * Deux suffiraient à définir un point de fuite, mais deux traits d'un croquis à
 * main levée se coupent n'importe où : le point obtenu serait du bruit. À partir
 * de quatre, la convergence est une propriété du dessin et non un accident.
 */
export declare const TRAITS_MIN_FAMILLE = 4;
/**
 * Quantile auquel on prend les traits « extrêmes » de chaque famille.
 *
 * Pas le minimum et le maximum : un seul artefact résiduel — un pli du papier,
 * une ombre — suffirait alors à tirer tout le quadrilatère jusqu'au bord de
 * l'image, et l'aspect recouvré avec lui. Mesuré sur une photo réelle : les
 * extrêmes absolus plaçaient deux coins à 5 px du cadre, très au-delà du dessin.
 *
 * À 10 %, la base reste large — c'est elle qui donne la précision — tout en
 * ignorant le trait aberrant isolé.
 */
export declare const QUANTILE_EXTREME = 0.1;
/**
 * Marge ajoutée autour du quadrilatère détecté, en part de sa demi-diagonale
 * moyenne.
 *
 * @deprecated Plus appliquée par défaut depuis la 2.21.0, et à ne réactiver
 * qu'en connaissance de cause. La marge dont l'utilisateur a besoin — de quoi
 * tracer l'enveloppe autour du dessin — est désormais prise **à la destination**
 * du redressement (`MARGE_REDRESSEMENT`, dans `photo-homography.const.ts`).
 *
 * Deux raisons de l'avoir déplacée :
 *  1. **elle ne survivait pas.** Le quadrilatère dilaté sortait du cadre dès que
 *     la photo était cadrée serré — c'est-à-dire toujours, puisqu'on cadre pour
 *     que le plan remplisse l'image — et `reduireDansCadre` le ramenait en le
 *     réduisant en bloc, annulant exactement ce que la dilatation venait
 *     d'ajouter. La marge était donc nulle **précisément dans le cas courant**,
 *     ce qui est le motif de panne muette que ce dépôt traque ;
 *  2. **elle se payait en justesse.** `dilaterConvexe` pousse les sommets à
 *     distance constante depuis le centroïde : ce n'est pas une homothétie, donc
 *     la forme du quadrilatère change, donc le rapport d'aspect et la focale que
 *     `rectifyQuad` en déduit changent aussi. On dégradait le redressement pour
 *     obtenir une marge qui, de toute façon, disparaissait.
 */
export declare const MARGE_CADRAGE = 0.12;
/** Écart angulaire entre deux directions non orientées, dans [0, 90]. */
export declare function ecartAngulaire(a: number, b: number): number;
export interface Familles {
    readonly horizontaux: Segment[];
    readonly verticaux: Segment[];
    /** Directions moyennes retenues, en degrés. */
    readonly angleH: number;
    readonly angleV: number;
}
/**
 * Sépare les segments en deux familles perpendiculaires.
 *
 * On ne suppose pas que les familles sont à 0° et 90° : une photo tenue de
 * travers les décale toutes deux. On prend la direction dominante — celle qui
 * rassemble le plus de longueur cumulée — puis sa perpendiculaire.
 *
 * Pondérer par la LONGUEUR et non par le nombre est délibéré : un croquis
 * contient beaucoup de petits traits (flèches de porte, hachures) et peu de longs
 * murs, or ce sont les murs qui portent l'orientation.
 */
export declare function separerFamilles(segments: readonly Segment[]): Familles | null;
/** Intersection de deux droites homogènes ; `null` si elles sont parallèles. */
export declare function intersection(a: [number, number, number], b: [number, number, number]): Point | null;
/**
 * Quadrilatère de référence : les deux traits extrêmes de chaque famille et
 * leurs quatre intersections.
 *
 * Ce quadrilatère est, dans le monde réel, un **rectangle** — puisque ses côtés
 * appartiennent à deux familles perpendiculaires du plan. C'est exactement
 * l'hypothèse dont `rectifyQuad` a besoin, et c'est par elle qu'il recouvre la
 * focale et le rapport d'aspect. On prend les traits extrêmes plutôt que
 * quelconques : plus la base est large, moins l'erreur de tracé pèse sur la
 * direction retrouvée.
 *
 * Rend `null` si une famille est trop pauvre ou si les intersections dégénèrent.
 */
export declare function quadrilatereDeReference(segments: readonly Segment[], marge?: number): Point[] | null;
/**
 * Ce que le redressement automatique a vu — **y compris quand il ne voit rien**.
 *
 * `quadrilatereDeReference` rend `null` dans cinq situations distinctes, et un
 * `null` ne dit laquelle. Or c'est exactement la question qu'on se pose devant
 * une photo qui n'est pas redressée : est-ce que la détection n'a pas trouvé
 * assez de traits ? qu'une seule famille ? des droites presque concourantes ?
 * Sans la réponse, il n'y a rien à corriger — ni côté réglages de détection,
 * ni côté prise de vue.
 *
 * Même parti que `parsePlanDocument` et `scannerScale` : le refus est une
 * **valeur de retour** portant un motif rédigé en français, pas un `null` muet
 * ni une exception qu'un `catch {}` avalerait.
 */
export interface RedressementDiag {
    /** Le quadrilatère, ou `null` si le dessin ne permet pas de le déduire. */
    readonly quad: Point[] | null;
    /** Motif du refus, rédigé — `null` quand `quad` est là. */
    readonly raison: string | null;
    /** Nombre de segments soumis. */
    readonly nbSegments: number;
    /** Traits retenus dans chaque famille. */
    readonly nbHorizontaux: number;
    readonly nbVerticaux: number;
    /** Directions moyennes des deux familles, en degrés — `null` si l'histogramme
     *  n'a rien donné. Elles disent l'inclinaison de la photo. */
    readonly angleH: number | null;
    readonly angleV: number | null;
}
/** Diagnostic complet, dont `quadrilatereDeReference` n'est que la façade. */
export declare function diagnostiquerRedressement(segments: readonly Segment[], marge?: number): RedressementDiag;
/**
 * Ramène un polygone dans un cadre en le **réduisant en bloc** autour de son
 * centre.
 *
 * Rabattre chaque sommet séparément déforme la figure — or c'est sa forme qui
 * porte la perspective, donc le rapport d'aspect et la focale qu'on en déduit :
 * on obtiendrait un redressement plausible et faux. Une réduction homothétique
 * conserve la forme, et ne coûte qu'un peu de marge.
 *
 * Rend le polygone inchangé s'il tient déjà.
 */
export declare function reduireDansCadre(poly: readonly Point[], largeur: number, hauteur: number): Point[];
