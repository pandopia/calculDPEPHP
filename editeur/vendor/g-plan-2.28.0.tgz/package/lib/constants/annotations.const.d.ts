/**
 * Formes d'annotation — rectangle, cercle, flèche.
 *
 * Destinées au même usage que l'annotation d'une photo : entourer, cerner,
 * désigner. Elles ne portent aucune sémantique métier (ce ne sont ni des
 * pièces, ni des zones à risque) et n'entrent donc dans aucun calcul de
 * surface, de linéaire ou de synthèse. Un seul `myType` — `'Annotation'` — les
 * regroupe ; la forme et la couleur voulues vivent dans `data`.
 */
import { EditorMode } from '../models/floorplan-object.model';
/** Forme d'une annotation, telle que persistée dans `data.shape`. */
export type AnnotationShape = 'rect' | 'circle' | 'arrow';
/** `myType` porté par toutes les formes d'annotation. */
export declare const ANNOTATION_TYPE = "Annotation";
/** Palette proposée dans la barre d'outils. La première entrée est la couleur
 *  active par défaut. Le jaune en est volontairement absent : illisible sur le
 *  fond blanc d'un plan comme sur une capture satellite claire. */
export declare const ANNOTATION_COLORS: {
    id: string;
    label: string;
    color: string;
}[];
/** Couleur active au démarrage de l'éditeur. */
export declare const ANNOTATION_DEFAULT_COLOR: string;
/** Épaisseur de trait des annotations (px scène). */
export declare const ANNOTATION_STROKE_WIDTH = 3;
/** Taille minimale (px) d'une annotation. En deçà, le geste est un clic et non
 *  un tracé : rien n'est créé, plutôt que de semer des formes microscopiques
 *  invisibles mais bien présentes dans le plan. */
export declare const ANNOTATION_MIN_PX = 12;
/** Longueur de la pointe d'une flèche (px). */
export declare const ANNOTATION_ARROW_HEAD_PX = 16;
/** Correspondance mode d'édition → forme dessinée. */
export declare const ANNOTATION_MODES: Record<string, AnnotationShape>;
/** Vrai si ce mode dessine une forme d'annotation. */
export declare function isAnnotationMode(mode: EditorMode | string): boolean;
/** Libellé lisible d'une forme — utilisé par la légende des exports image. */
export declare const ANNOTATION_LABELS: Record<AnnotationShape, string>;
