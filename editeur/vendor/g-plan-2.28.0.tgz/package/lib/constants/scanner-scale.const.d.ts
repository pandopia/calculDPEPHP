/**
 * Échelle du scanner OpenCV — d'où elle vient, et ce qu'on dit quand elle
 * n'existe pas.
 *
 * **Pourquoi ce module existe.** `scanner.component.ts` remplissait le
 * `pixelsPerMeter` de son export ainsi :
 *
 * ```ts
 * pixelsPerMeter: this.params().clusterDistance > 0 ? 50 : 50
 * ```
 *
 * Un ternaire dont les **deux** branches valent 50. Le scanner n'avait aucune
 * notion d'échelle : il en simulait le calcul. Quelle que soit la photo, le plan
 * sortait à 50 px/m arbitraires, donc **toutes les surfaces étaient fausses** —
 * et fausses *en silence*, ce qui est le motif de panne que ce dépôt traque
 * (`FEATURE-releve-piece-sans-plan.md § 1`). Pire encore : l'éditeur ne lisait
 * même pas ce champ, si bien que la valeur inventée n'allait nulle part.
 *
 * Ce module est le maillon manquant. Il ne calcule pas l'échelle — c'est le
 * travail de `photo-homography.const.ts`, la couche pure de la **brique B** —
 * il **dit d'où elle vient**, et il oblige l'appelant à traiter le cas où elle
 * ne vient de nulle part.
 *
 * ## Les trois décisions qui structurent le module
 *
 * **1. L'absence de calage est une valeur de retour, pas une exception.**
 * `scannerScale(null)` rend un objet complet, avec `calibrated: false` et un
 * `warning` rédigé. Lever une erreur aurait obligé chaque appelant à un
 * `try/catch` et, en pratique, à l'avaler ; rendre `null` aurait fait
 * réapparaître un `?? 50` quelque part. Ici le repli est **nommé**
 * (`SCANNER_FALLBACK_PIXELS_PER_METER`) et le fait qu'il soit un repli voyage
 * avec lui, jusque dans la charge utile remise à l'éditeur
 * (`WallsImportPayload.scaleCalibrated`).
 *
 * **2. Le scanner s'adapte à l'échelle du plan, jamais l'inverse.** C'est la
 * même décision que pour le calque photo (`photoLayerScale`), et pour la même
 * raison : réécrire le `pixelsPerMeter` du plan réécrirait silencieusement
 * toutes les longueurs et surfaces déjà saisies — les cotes relevées au
 * télémètre de la brique A comprises, et les objets des **autres niveaux**, que
 * l'import du scanner ne vide pas. `scannerImportScale` rend donc un facteur à
 * appliquer aux murs détectés, symétrique de `photoLayerScale`.
 *
 * **3. Une échelle non calée ne se propage pas.** `scannerImportScale` rend
 * `null` dès que le calage manque : sans repère réel, la seule conduite honnête
 * est de poser les murs tels quels et de le dire, pas de les redimensionner
 * d'un facteur tiré d'un 50 inventé.
 *
 * Comme `plan-graph.const.ts`, `sketch-snap.const.ts`, `wall-dimension.const.ts`
 * et `photo-homography.const.ts`, ce fichier ne contient **que des fonctions
 * pures** — ni Fabric, ni DOM, ni canvas, ni OpenCV. Le pont vers les pixels
 * vit dans `ScannerComponent` et `PhotoLayerService`.
 */
import { PhotoLayerData } from './photo-homography.const';
/**
 * Échelle de repli, en pixels par mètre, quand rien n'a été calé.
 *
 * C'est la valeur historique du ternaire mort, **nommée** au lieu d'être écrite
 * deux fois dans une condition. Elle ne prétend rien : elle donne un plan
 * dessinable dont les cotes ne veulent rien dire, ce que `calibrated: false` et
 * `warning` annoncent partout où la valeur circule.
 */
export declare const SCANNER_FALLBACK_PIXELS_PER_METER = 50;
/** D'où vient l'échelle rendue par `scannerScale`. */
export type ScannerScaleSource = 
/** Calage réel : photo redressée puis calée sur une distance relevée. */
'photo-calibration'
/** Aucun calage : l'échelle est le repli arbitraire. */
 | 'uncalibrated';
/**
 * Ce que le scanner sait de son échelle — y compris quand il n'en sait rien.
 *
 * `warning` est rédigé **en français** parce qu'il est affiché tel quel à
 * l'utilisateur : le seul moyen d'être sûr que le message existe est qu'il soit
 * porté par la donnée, et non reconstruit dans chaque gabarit.
 */
export interface ScannerScale {
    /** Pixels de l'image analysée par mètre réel. Toujours > 0 : c'est le repli
     *  quand rien n'a été calé, `calibrated` disant alors ce qu'il vaut. */
    readonly pixelsPerMeter: number;
    /** `true` seulement si l'échelle vient d'une distance réellement relevée. */
    readonly calibrated: boolean;
    readonly source: ScannerScaleSource;
    /** Distance saisie au télémètre, en mètres, quand il y en a une. Sert à
     *  afficher *sur quoi* le calage repose — une échelle dont on ne peut pas
     *  citer la mesure d'origine ne se vérifie pas. */
    readonly knownDistanceM: number | null;
    /** Message à afficher, en français, ou `null` si l'échelle est réelle. */
    readonly warning: string | null;
}
/**
 * Aucune photo redressée : le scanner travaille sur l'image brute.
 *
 * Le message dit **les deux** manques, parce qu'ils sont indissociables : sans
 * redressement, une photo prise de biais reste de biais et aucune échelle
 * unique ne peut lui convenir.
 */
export declare const SCANNER_NO_PHOTO_WARNING: string;
/**
 * Photo redressée, mais calage absent ou inexploitable (points de mesure
 * confondus, distance nulle). Le redressement seul corrige la perspective et ne
 * donne toujours pas le mètre.
 */
export declare const SCANNER_NOT_SCALED_WARNING: string;
/**
 * Échelle du scanner déduite de la charge utile du redressement photo.
 *
 * Rend **toujours** un objet exploitable : c'est ce qui permet au gabarit
 * d'afficher l'état de l'échelle sans le reconstruire, et à l'export de dire la
 * vérité sur ce qu'il transporte.
 *
 * `photo` est la charge utile produite par la brique B
 * (`photoLayerData`) — la même que celle persistée sur un calque, à ceci près
 * qu'ici elle sert à mesurer, pas à décalquer.
 */
export declare function scannerScale(photo: PhotoLayerData | null | undefined): ScannerScale;
/** Ce que `scannerImportScale` a besoin de savoir d'une charge utile de murs —
 *  volontairement structurel, pour rester indépendant de `WallsImportPayload`
 *  et donc du modèle de projet. */
export interface ScannerImportScaleInput {
    readonly pixelsPerMeter?: number;
    readonly scaleCalibrated?: boolean;
}
/**
 * Facteur à appliquer aux murs détectés pour qu'ils entrent dans un plan
 * d'échelle `planPixelsPerMeter` **à leur longueur réelle**.
 *
 * Symétrique exact de `photoLayerScale`, et pour la même raison : c'est
 * l'apport qui s'adapte au plan, jamais le plan qui se réécrit. Aligner le
 * `pixelsPerMeter` du plan sur celui du scanner redimensionnerait
 * silencieusement tout ce qui existe déjà — les cotes de la brique A, les
 * pièces validées, et les objets des autres niveaux, que l'import du scanner ne
 * vide pas.
 *
 * Rend `null` quand le facteur ne veut rien dire : pas de calage, échelle
 * absente ou absurde. L'appelant pose alors les murs tels quels (facteur 1) et
 * **le dit** — c'est mieux qu'un redimensionnement fondé sur un 50 inventé.
 */
export declare function scannerImportScale(payload: ScannerImportScaleInput | null | undefined, planPixelsPerMeter: number): number | null;
/** Segment mesurable : les quatre coordonnées d'un `WallSegment`, sans le
 *  reste — pour que ce module ne dépende pas du modèle de mur. */
export interface MeasurableSegment {
    readonly x1: number;
    readonly y1: number;
    readonly x2: number;
    readonly y2: number;
}
/**
 * Longueur réelle d'un segment détecté, en mètres.
 *
 * Rend `null` plutôt qu'un `NaN` silencieux quand l'échelle ou les coordonnées
 * sont inexploitables : une longueur affichée doit toujours pouvoir être crue,
 * ou ne pas être affichée du tout.
 */
export declare function wallLengthM(wall: MeasurableSegment | null | undefined, pixelsPerMeter: number): number | null;
/**
 * Étendue réelle d'un lot de murs, en mètres — le contrôle de vraisemblance
 * qu'un utilisateur fait d'un coup d'œil (« ce plan fait bien 12 m de large »).
 *
 * C'est le seul moyen simple de **voir** que l'échelle est juste avant
 * d'envoyer quoi que ce soit à l'éditeur. Rend `null` sur un lot vide ou une
 * échelle inexploitable.
 */
export declare function wallsExtentM(walls: readonly MeasurableSegment[] | null | undefined, pixelsPerMeter: number): {
    widthM: number;
    heightM: number;
} | null;
