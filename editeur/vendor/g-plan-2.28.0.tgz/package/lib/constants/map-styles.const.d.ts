/**
 * Feuilles de style MapLibre — définition unique pour toute la bibliothèque.
 *
 * Elles vivaient dans les méthodes privées d'`OsmService`, qui ne sert qu'à la
 * capture d'un fond de plan. La vue carte (`<ng-gplan-viewer-map>`) a besoin des
 * mêmes styles sans rien avoir à capturer : les extraire évite d'en tenir deux
 * jeux, qui divergeraient à la première correction.
 */
import { FloorplanConfig } from '../models/config.model';
/** Couches cartographiques proposées. */
export type OsmLayer = 'osm' | 'satellite' | 'cadastre' | 'custom';
/**
 * URL par défaut des tuiles satellite (serveur PMTiles maison).
 *
 * Surchargeable par `config.satelliteTilesUrl` : jusqu'à la 2.3.0 cette adresse
 * était **gravée dans la bibliothèque**, si bien qu'une application hôte
 * recevait ce serveur qu'elle le veuille ou non, sans pouvoir pointer un miroir
 * ni distinguer recette de production — là où le fond vectoriel, lui, passe
 * depuis toujours par `config.tileServerUrl`.
 */
export declare const DEFAULT_SATELLITE_TILES_URL = "https://tiles.g-ordon.io/v1/imagery/{z}/{x}/{y}.webp";
/**
 * Mention de source de l'imagerie servie par `DEFAULT_SATELLITE_TILES_URL` :
 * **BD ORTHO® de l'IGN** sur la France, **NASA** ailleurs.
 *
 * Les deux permettent l'usage commercial — Licence Ouverte 2.0 pour la première
 * (usage commercial autorisé, **paternité due**), domaine public pour la
 * seconde (crédit demandé, non exigible). D'où une mention par défaut, là où il
 * n'y en avait aucune.
 *
 * Elle ne vaut QUE pour ces tuiles-là : un hôte qui change
 * `satelliteTilesUrl` sans déclarer `satelliteAttribution` sert autre chose sous
 * une mention qui ne le décrit plus — c'est ce cas, et lui seul, qui est
 * signalé en console.
 */
export declare const DEFAULT_SATELLITE_ATTRIBUTION = "Imagerie \u00A9 IGN \u2014 BD ORTHO\u00AE (Licence Ouverte 2.0) \u00B7 NASA (domaine public)";
/**
 * Contraintes de projection imposées à **toute** carte créée par la
 * bibliothèque.
 *
 * Une capture inclinée ou pivotée n'est pas géoréférençable du tout, et rien ne
 * le détecte a posteriori : l'image paraît normale. `renderWorldCopies: false`
 * évite en prime qu'un pan au-delà de l'antiméridien renvoie une longitude hors
 * [-180, 180].
 *
 * Note : `projection` n'est pas (encore) une option du constructeur MapLibre 5 —
 * elle est ignorée sans erreur. Le verrouillage effectif est fait par
 * `enforceMercator()`, qui la réapplique après chaque chargement de style.
 */
export declare const PROJECTION_LOCK: {
    bearing: number;
    pitch: number;
    projection: {
        type: string;
    };
    renderWorldCopies: boolean;
};
/**
 * Cadastre IGN — service **externe**, contrairement aux deux autres couches.
 *
 * `STYLE=PCI%20vecteur` et non `bdparcellaire` : ce dernier n'existe pas sur la
 * Géoplateforme, qui répondait `HTTP 400 — Style bdparcellaire unknown` à
 * **chaque** tuile. MapLibre n'en dit rien : une tuile raster en échec ne se
 * peint pas, sans erreur d'application — la case « Cadastre » se cochait donc
 * sans que rien n'apparaisse jamais.
 *
 * Surchargeable par `config.cadastreTilesUrl`, pour pointer un service maison
 * (cf. le microservice `g-ordon-cadastre`) plutôt que de dépendre de la
 * disponibilité de l'IGN.
 */
export declare const DEFAULT_CADASTRE_TILES_URL: string;
/** @deprecated Utiliser `cadastreTiles(config)`, qui honore la configuration. */
export declare const CADASTRE_TILES: string[];
/**
 * Tuiles **vectorielles** du Plan Cadastral Informatisé (TMS Géoplateforme).
 *
 * Préférées au raster : le trait reste net à tous les zooms, la couleur se règle
 * pour rester lisible sur une orthophoto sombre, et surtout les parcelles
 * deviennent **interrogeables** — un raster ne peut que se superposer.
 * Couches disponibles : `parcelle`, `batiment`, `section`, `commune`,
 * `localisant`, `borne_limite_propriete`… (millésime dans les métadonnées).
 */
export declare const DEFAULT_CADASTRE_VECTOR_URL = "https://data.geopf.fr/tms/1.0.0/PCI/{z}/{x}/{y}.pbf";
/**
 * Fontes vectorielles, indispensables dès qu'un style porte du **texte**.
 *
 * Le style satellite est un raster construit à la main : il n'avait aucune clé
 * `glyphs`, et un calque `symbol` y serait resté **muet** — pas d'erreur, pas de
 * texte. Les fontes de la Géoplateforme conviennent et sont servies sans clé.
 */
export declare const DEFAULT_GLYPHS_URL = "https://data.geopf.fr/annexes/ressources/vectorTiles/fonts/{fontstack}/{range}.pbf";
/** Pile de fontes disponible sur ce serveur de glyphes. */
export declare const CADASTRE_TEXT_FONT: string[];
/** Gabarit(s) d'URL des tuiles cadastre, configuration de l'hôte comprise. */
export declare function cadastreTiles(config?: FloorplanConfig | null): string[];
/**
 * Mention de source du cadastre.
 *
 * **Ce n'est pas décoratif.** Le Plan Cadastral Informatisé est diffusé sous
 * Licence Ouverte 2.0 (Etalab), qui autorise l'usage commercial mais impose la
 * **paternité** : citer la source et la date de dernière mise à jour. Une
 * application qui affiche ces tuiles sans mention n'est pas conforme.
 *
 * Remplacée par `config.cadastreAttribution` si l'hôte sert le cadastre depuis
 * sa propre infrastructure — la mention doit alors décrire *sa* source.
 */
export declare const DEFAULT_CADASTRE_ATTRIBUTION = "Cadastre \u00A9 DGFiP \u2014 G\u00E9oplateforme / IGN \u2014 Licence Ouverte 2.0";
/**
 * Source de la couche cadastre, mention comprise.
 *
 * **Vectorielle par défaut.** Le raster reste accessible pour un hôte qui sert
 * ses propres tuiles images : déclarer `cadastreTilesUrl` bascule dans ce mode,
 * puisqu'un gabarit d'image ne peut pas être lu comme du vecteur.
 */
export declare function cadastreSource(config?: FloorplanConfig | null): any;
/**
 * Couches à poser pour afficher le cadastre — **définition unique**.
 *
 * **Pourquoi cette fonction existe.** Deux endroits posaient le cadastre : la
 * vue carte, qui gère le cas vectoriel, et la capture de fond de plan
 * (`OsmService`), qui ajoutait une couche `type: 'raster'`… sur une source
 * **vectorielle**, puisque c'est le défaut depuis que le PCI est lu en `.pbf`.
 * MapLibre refuse cet attelage : la couche n'est jamais peinte, et le refus
 * part dans `map.on('error')` — que la capture n'écoutait pas. La case
 * « Cadastre » se cochait donc **sans que rien n'apparaisse**, exactement comme
 * au temps du `STYLE=bdparcellaire` inexistant. Signalé à l'usage.
 *
 * Le type des couches suit donc désormais le type de la source, en un seul
 * endroit. Le motif de numéro répété (`fill-pattern`) n'en fait **pas** partie :
 * il exige de fabriquer les images à la demande (`styleimagemissing`), ce que
 * seule la vue carte sait faire ; une capture n'en a pas l'usage.
 *
 * `prefixe` distingue les identifiants des deux appelants — deux cartes
 * différentes, jamais dans le même document, mais des identifiants distincts
 * évitent qu'un futur partage de code ne les confonde.
 */
export declare function cadastreOverlayLayers(config: FloorplanConfig | null | undefined, source: string, prefixe?: string): any[];
/** Vrai si la source cadastre résolue est vectorielle (donc stylable et
 *  interrogeable) plutôt qu'une simple image superposée. */
export declare function cadastreEstVectoriel(config?: FloorplanConfig | null): boolean;
/** Repli utilisé quand l'hôte n'a pas de tileserver : tuiles OSM publiques. */
export declare const FALLBACK_OSM_STYLE: any;
/** Style vectoriel principal du tileserver, ou repli OSM. */
export declare function baseStyle(config: FloorplanConfig): string | object;
/** Style vectoriel alternatif (`config.tileStyle`), ou repli OSM. */
export declare function customStyle(config: FloorplanConfig): string | object;
/**
 * Style satellite raster.
 *
 * `maxzoom: 19` est le zoom **natif estimé** des tuiles (analyse d'entropie par
 * zone : z18 en rural type Hossegor, z19-20 en grande ville). En le déclarant,
 * MapLibre suréchantillonne côté client au-delà — meilleure qualité que le
 * suréchantillonnage serveur. L'échelle géographique reste juste quel que soit
 * le zoom visuel : le zoom caméra *est* l'échelle réelle.
 */
export declare function satelliteStyle(config: FloorplanConfig): any;
/** Style d'une couche donnée. `'cadastre'` est un **overlay** et n'a pas de
 *  style propre : il se pose par-dessus le fond courant. */
export declare function layerStyle(layer: OsmLayer, config: FloorplanConfig): string | object;
/**
 * Réapplique la projection Mercator après chaque chargement de style.
 *
 * Les styles peuvent pointer une feuille **fournie par l'hôte**, qui a le droit
 * de déclarer `projection: { type: 'globe' }` en MapLibre 5. Cette valeur est
 * appliquée au chargement du style et écraserait l'option du constructeur :
 * l'option explicite doit gagner, donc on repasse derrière.
 */
export declare function enforceMercator(map: any): void;
/**
 * Résout la classe `Map` quelle que soit la forme de distribution de
 * maplibre-gl :
 * - ESM natif → `mod.Map`
 * - UMD/CJS empaqueté comme ESM par certains bundlers → `mod.default.Map`
 *   (le package.json upstream déclare `"type": "module"` alors que le main est
 *   un UMD sans export nommé, ce qui peut rendre `mod.Map` indéfini dans
 *   certains contextes esbuild/webpack et planter avec « r is not a
 *   constructor »).
 *
 * L'import reste **dynamique** : maplibre-gl pèse ~1 Mo, et une application qui
 * n'ouvre jamais de carte ne doit pas le télécharger.
 *
 * ## Le worker de la v6, et pourquoi cette fonction prend une URL
 *
 * La v6 est livrée en **trois** modules — `maplibre-gl.mjs`,
 * `maplibre-gl-shared.mjs` et `maplibre-gl-worker.mjs` — et déduit l'URL de son
 * worker **à l'exécution**, de `import.meta.url`. Une fois la librairie
 * empaquetée dans l'application, cette URL désigne le **chunk de
 * l'application** : MapLibre cherche alors un `maplibre-gl-worker.mjs` que le
 * build n'émet pas, et le worker ne démarre jamais.
 *
 * Or c'est lui qui décode les tuiles **vectorielles** — le raster, lui, est
 * décodé sur le fil principal. Le symptôme est donc dissymétrique et muet : le
 * fond satellite s'affiche, le fond vectoriel et le cadastre restent **blancs**,
 * et la console de la page ne dit rien, l'échec ayant lieu dans un worker
 * mort-né. Mesuré et documenté dans `FEATURE-compatibilite-maplibre-5-6.md`.
 *
 * D'où `maplibreWorkerUrl` : l'application hôte sert les deux fichiers et donne
 * l'URL du worker. En v5, `setWorkerUrl` n'existe pas et le réglage est ignoré —
 * c'est ce qui permet à une seule version de g-plan de viser les deux majeures.
 */
export declare function loadMapLibre(workerUrl?: string | null): Promise<{
    Map: any;
    Popup: any;
    LngLatBounds: any;
}>;
/**
 * Ce que `applyMaplibreWorkerUrl` a fait — rendu plutôt que tu, pour être
 * éprouvable sans dépendre de la version réellement installée.
 */
export type MaplibreWorkerStatus = 
/** La distribution n'expose pas `setWorkerUrl` : v5, worker embarqué. */
'not-needed'
/** URL posée : les tuiles vectorielles seront décodées. */
 | 'applied'
/** v6 sans URL : les fonds vectoriels resteront blancs. */
 | 'missing';
/**
 * Pose l'URL du worker si la version installée en a besoin, et **rend ce qui
 * s'est passé**.
 *
 * Fonction séparée, exportée et testée : c'est elle qui décide si les fonds
 * vectoriels s'afficheront, et son oubli ne se voit nulle part à l'exécution.
 */
export declare function applyMaplibreWorkerUrl(racine: any, workerUrl?: string | null): MaplibreWorkerStatus;
/**
 * Ce qu'il faut dire à l'hôte qui a oublié le réglage — les deux gestes, pas
 * seulement le constat.
 */
export declare const MAPLIBRE_WORKER_WARNING: string;
