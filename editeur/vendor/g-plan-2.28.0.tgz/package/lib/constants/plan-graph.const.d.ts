/**
 * Graphe de nœuds partagés — la topologie du croquis, **en plus** des objets Fabric.
 *
 * **Pourquoi ce module existe.** Les murs sont des `fabric.Line` autonomes : leurs
 * extrémités sont des coordonnées *recopiées*, sans lien entre elles. Deux murs
 * qui se rejoignent à un angle ne le savent pas — ils se trouvent simplement au
 * même endroit. D'où le défaut mesuré (`FEATURE-refonte-moteur-croquis.md § 1.2`) :
 * déplacer un angle n'entraîne pas les deux murs, il faut les rattraper un par
 * un, et chaque code qui a besoin de la topologie la refabrique par tolérance de
 * distance — `refreshNodeHandles` à 5 px, `onNodeMoving` à 10 px,
 * `snapLineEndpoints` à 20 px, `GeometryService.buildGraph` à ~15 px. Quatre
 * reconstructions, quatre seuils, aucune identité.
 *
 * Ce module tient cette identité une fois pour toutes : un **nœud** porte un
 * identifiant, une **arête** (un mur) désigne deux nœuds, une **boucle** (une
 * pièce validée) désigne une suite de nœuds. Déplacer un nœud déplace de fait
 * tout ce qui s'y rattache, sans re-détection.
 *
 * **Cohabitation, pas remplacement.** Le graphe ne remplace ni les objets Fabric
 * ni le document sérialisé : `FloorplanProject.objects` reste le contrat public
 * lu par l'application hôte, et **rien n'y est ajouté** — l'identité vit en
 * mémoire, comme celle de l'historique depuis la 2.8.0. Un plan enregistré avant
 * ou après ce lot est strictement le même fichier ; le graphe se reconstruit de
 * la géométrie au chargement (`syncGraph`).
 *
 * `findMinimalCycles` (`GeometryService`) est **conservé en assistance** : il
 * propose des boucles, que l'éditeur matérialise ensuite ici.
 *
 * Comme `plan-commands.const.ts` et `sketch-snap.const.ts`, ce fichier ne
 * contient **que des fonctions pures** — ni Fabric, ni DOM, ni canvas. Le pont
 * vers le canvas vit dans `WallGraphService`, et lui seul : deux états qui
 * divergent est le risque principal du chantier, et il ne peut diverger que là
 * où il est écrit.
 */
import { Point } from '../models/geometry.types';
/**
 * Distance sous laquelle deux extrémités de murs sont **le même nœud**, en pixels.
 *
 * 10 px reprend délibérément la tolérance de `onNodeMoving` : le graphe doit
 * capturer exactement ce que l'ancien code capturait, ni plus ni moins, sinon on
 * corrige un défaut en en introduisant un autre. La valeur doit rester
 * supérieure au biais du demi-trait (2,5 px pour un `Mur`, cf.
 * `plan-geometry.const.ts`) — deux murs recollés par `snapLineEndpoints` ne
 * coïncident pas exactement — et nettement inférieure aux 20 px d'accroche, sans
 * quoi deux angles que l'utilisateur a voulus distincts fusionneraient.
 */
export declare const NODE_MERGE_PX = 10;
/** Sommet partagé du croquis. Sa position fait foi pour tous les murs qui s'y
 *  rattachent. */
export interface PlanNode {
    readonly id: string;
    readonly x: number;
    readonly y: number;
}
/** Un mur, vu comme une arête entre deux nœuds. `id` est celui que le pont
 *  attribue à l'objet Fabric — le graphe ne connaît pas Fabric. */
export interface PlanEdge {
    readonly id: string;
    readonly from: string;
    readonly to: string;
}
/** Pièce **validée** : une suite de nœuds, pas une suite de coordonnées. C'est
 *  toute la différence — elle survit au déplacement des murs sans être
 *  redétectée. */
export interface PlanLoop {
    readonly id: string;
    readonly nodes: readonly string[];
}
/**
 * État complet du graphe. Immuable : chaque opération rend un nouveau graphe,
 * ce qui rend les tests lisibles et interdit les mutations à distance.
 *
 * `seq` est le compteur d'identifiants. Il vit dans le graphe plutôt que dans un
 * module : deux graphes indépendants (deux étages) ne doivent pas se marcher
 * dessus, et des identifiants déterministes (`n1`, `n2`…) rendent les tests
 * lisibles là où un UUID ne dit rien.
 */
export interface PlanGraph {
    readonly nodes: ReadonlyMap<string, PlanNode>;
    readonly edges: ReadonlyMap<string, PlanEdge>;
    readonly loops: ReadonlyMap<string, PlanLoop>;
    readonly seq: number;
}
/** Géométrie d'un mur telle que le pont la relève sur le canvas. */
export interface EdgeGeometry {
    readonly id: string;
    readonly p1: Point;
    readonly p2: Point;
}
export declare function emptyGraph(): PlanGraph;
/**
 * Reconstruit le graphe depuis la géométrie des murs, **en conservant les
 * identités** du graphe précédent.
 *
 * C'est le point d'entrée de la resynchronisation : chargement d'un projet,
 * ajout ou suppression d'un mur, annulation. Les extrémités sont regroupées en
 * amas (tout ce qui tient dans `tolerance`), puis chaque amas reprend
 * l'identifiant du nœud précédent le plus proche encore libre.
 *
 * **Pourquoi conserver les identités plutôt que tout renuméroter** : les boucles
 * (pièces validées) désignent des nœuds. Renuméroter à chaque ajout de mur les
 * invaliderait toutes, et la pièce validée disparaîtrait au premier trait — soit
 * exactement le défaut qu'on corrige.
 *
 * La position retenue pour un amas est celle de **la première extrémité
 * rencontrée**, pas la moyenne : moyenner déplacerait les murs à chaque
 * resynchronisation, sans que l'utilisateur n'ait rien demandé. Le recollage se
 * fait quand le nœud bouge (`moveNode`), pas quand on le relit.
 */
export declare function syncGraph(previous: PlanGraph, geometries: readonly EdgeGeometry[], tolerance?: number): PlanGraph;
/** Nœud le plus proche de `pt` dans la tolérance, ou `null`. */
export declare function nodeAt(graph: PlanGraph, pt: Point, tolerance?: number): PlanNode | null;
/** Arêtes (murs) qui touchent ce nœud. Une arête dont les deux extrémités
 *  tombent sur le même nœud n'est rendue **qu'une fois** : c'est une liste de
 *  murs à mettre à jour, pas un décompte de connexions. */
export declare function edgesAtNode(graph: PlanGraph, nodeId: string): PlanEdge[];
/** Nombre d'**extrémités** de murs arrivant sur ce nœud — un mur replié sur
 *  lui-même en compte deux. C'est ce décompte qui distingue un angle simple
 *  (2) d'une jonction (3 et plus), et la poignée change de taille en
 *  conséquence. */
export declare function nodeDegree(graph: PlanGraph, nodeId: string): number;
/**
 * Suite de murs enchaînés bout à bout — le contour d'une pièce quand elle est
 * fermée, sinon le tronçon délimité par les jonctions.
 *
 * `edges[i]` relie `nodes[i]` à `nodes[i + 1]`. Pour une chaîne **fermée** le
 * premier nœud n'est pas répété à la fin : il y a autant d'arêtes que de nœuds.
 * Pour une chaîne ouverte, il y a un nœud de plus que d'arêtes. C'est exactement
 * la convention qu'attend `solveWallDimensions`.
 */
export interface NodeChain {
    readonly nodes: readonly string[];
    readonly edges: readonly string[];
    readonly closed: boolean;
}
/**
 * Remonte la chaîne de murs à laquelle appartient `edgeId`.
 *
 * **Pourquoi s'arrêter aux jonctions.** La marche ne traverse que les nœuds de
 * degré 2 — un angle simple, où deux murs se suivent sans ambiguïté. Sur un
 * nœud de degré 3 ou plus (une cloison qui vient buter sur un mur), il n'y a pas
 * de « suivant » : continuer voudrait dire choisir, et un choix arbitraire ferait
 * suivre à la cotation un chemin que l'utilisateur ne voit pas. On s'arrête, la
 * chaîne est ouverte, et le mur coté prend sa longueur sans prétendre refermer
 * quoi que ce soit.
 *
 * Rend `null` si l'arête est inconnue.
 */
export declare function edgeChain(graph: PlanGraph, edgeId: string): NodeChain | null;
/** Géométrie courante d'une arête, lue **depuis les nœuds** : c'est le graphe
 *  qui fait foi, pas la copie que l'objet Fabric porte encore. */
export declare function edgeGeometry(graph: PlanGraph, edgeId: string): {
    p1: Point;
    p2: Point;
} | null;
/** Déplace un nœud. Tout ce qui le référence — murs, pièces validées — suit,
 *  puisque rien n'en détient de copie. */
export declare function moveNode(graph: PlanGraph, nodeId: string, pt: Point): PlanGraph;
/**
 * Fusionne deux nœuds : `dropId` disparaît, tout ce qui le désignait désigne
 * désormais `keepId`.
 *
 * Les arêtes devenues dégénérées (leurs deux extrémités sur le même nœud) sont
 * **conservées** : c'est au pont de décider s'il supprime le mur correspondant.
 * Les faire disparaître ici laisserait un objet Fabric sans arête, donc un mur
 * que plus aucun déplacement n'entraînerait — une divergence silencieuse.
 */
export declare function mergeNodes(graph: PlanGraph, keepId: string, dropId: string): PlanGraph;
/**
 * Matérialise une pièce : mémorise la boucle formée par ces nœuds.
 *
 * Rend `{ graph, id: null }` si la boucle est inexploitable (moins de trois
 * nœuds distincts, ou un nœud inconnu) — une pièce fausse vaut moins que pas de
 * pièce du tout.
 */
export declare function addLoop(graph: PlanGraph, nodeIds: readonly string[]): {
    graph: PlanGraph;
    id: string | null;
};
/**
 * Traduit un contour en suite de nœuds — le pont entre la boucle *proposée* par
 * `findMinimalCycles` (des coordonnées) et la pièce *validée* (des identités).
 *
 * Rend `null` dès qu'un sommet ne tombe sur aucun nœud : mieux vaut refuser la
 * validation que lier une pièce à moitié, ce qui la ferait dériver au premier
 * déplacement.
 */
export declare function loopFromPoints(graph: PlanGraph, points: readonly Point[], tolerance?: number): string[] | null;
/** Sommets courants d'une pièce validée, recalculés depuis les nœuds. Liste
 *  vide si la boucle n'existe plus. */
export declare function loopPoints(graph: PlanGraph, loopId: string): Point[];
/** Retire une pièce validée (la pièce redevient une simple proposition). */
export declare function removeLoop(graph: PlanGraph, loopId: string): PlanGraph;
