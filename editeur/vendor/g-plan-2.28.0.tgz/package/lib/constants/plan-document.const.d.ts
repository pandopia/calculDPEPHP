/**
 * Lecture d'un document de plan — vérification, migration, refus motivé.
 *
 * **Pourquoi ce module existe.** Jusqu'à la 2.14.0, toute la gestion de version
 * d'un projet tenait en ceci (`export.service.ts`) :
 *
 * ```ts
 * if (project.version !== '5.3.0') {
 *   console.warn(`[G-Plan] Version de projet ${project.version} différente…`);
 * }
 * ```
 *
 * Un avertissement en console, puis le document était chargé quand même. Pas de
 * migration, pas de refus, pas de valeur de retour à examiner. Conséquences,
 * dans l'ordre de gravité :
 *
 * 1. **le premier changement de schéma aurait corrompu des plans en silence** —
 *    Fabric ignore les objets qu'il ne comprend pas, l'analyse métier ignore les
 *    champs qu'elle ne trouve pas, et le plan se serait rechargé « intact » mais
 *    amputé, exactement comme la perte des propriétés custom que
 *    `fabric-custom-props.const.ts` documente ;
 * 2. un document **tronqué** (écriture interrompue, transfert coupé, brouillon
 *    partiel) passait la porte : `!project.version || !Array.isArray(objects)`
 *    ne regardait que deux champs de la racine. Un `floors[2]` sans `objects`,
 *    un objet sans `type`, un `pixelsPerMeter` à zéro — tout passait, et le plan
 *    se chargeait **à moitié** ;
 * 3. rien ne disait **où** était la violation, donc rien n'était réparable.
 *
 * `parsePlanDocument` remplace les trois : il rend un `Result`, et l'erreur
 * porte le **chemin JSON** de la première violation (`floors[2].objects[7].type`).
 *
 * ## Les quatre décisions qui structurent le module
 *
 * **1. Gardes écrites à la main, pas de validateur runtime.** Le schéma est
 * fermé et petit ; embarquer un validateur générique coûterait plusieurs dizaines
 * de kilo-octets à une bibliothèque qui compte son budget, pour un gain nul en
 * expressivité. Le prix à payer est que ce fichier doit être **relu** quand
 * `FloorplanProject` change — c'est le seul endroit, et il est nommé dans
 * `docs/API.md`.
 *
 * **2. Un refus est une valeur de retour, pas une exception.** Même choix que
 * `scanner-scale.const.ts` : une exception se rattrape en `catch {}` et se perd,
 * un `Result` oblige l'appelant à regarder. Le motif est **rédigé en français**
 * et voyage avec l'erreur, pour qu'il n'ait pas à être reconstruit dans chaque
 * gabarit.
 *
 * **3. Le document courant n'est jamais réécrit.** Quand la version est déjà
 * `PLAN_DOCUMENT_VERSION`, `parsePlanDocument` rend **l'objet reçu lui-même**,
 * sans copie ni normalisation : c'est le critère d'acceptation du lot (« un plan
 * 5.3.0 se charge inchangé »), et c'est aussi la seule façon de ne pas dupliquer
 * en mémoire un plan qui porte un fond de carte en base64. Normaliser « au
 * passage » (compléter `floors`, arrondir `pixelsPerMeter`…) serait une écriture
 * silencieuse dans le fichier de l'utilisateur.
 *
 * **4. Une migration par saut de version, composables.** Chaque étape ne connaît
 * que son propre saut ; `migratePlanDocument` les enchaîne jusqu'à la version
 * courante. Ajouter un format futur, c'est ajouter **une** fonction à
 * `PLAN_MIGRATIONS`, sans toucher aux autres ni aux gardes.
 *
 * Comme `plan-graph.const.ts`, `sketch-snap.const.ts`, `wall-dimension.const.ts`
 * et `scanner-scale.const.ts`, ce fichier ne contient **que des fonctions
 * pures** — ni Fabric, ni DOM, ni canvas, ni `localStorage`. Le pont vers les
 * fichiers et le stockage vit dans `ExportService.fromFile` et
 * `PlanEditorComponent.restoreAutosave`.
 */
import { FloorplanProject } from '../models/project.model';
/**
 * Succès ou échec, explicite. Volontairement minimal : ce n'est pas une
 * bibliothèque de programmation fonctionnelle, juste le type de retour qui
 * empêche d'ignorer un refus. `ok` est le discriminant — `if (!r.ok) …` suffit,
 * et TypeScript restreint alors `r` à sa branche.
 */
export type Result<T, E> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly error: E;
};
/** Succès. */
export declare function ok<T>(value: T): Result<T, never>;
/** Échec. */
export declare function err<E>(error: E): Result<never, E>;
/** Nature du refus. Fermé à dessein : chaque code correspond à une conduite
 *  différente côté appelant (réparer le fichier, migrer, prévenir l'hôte). */
export type PlanParseErrorCode = 
/** Le texte fourni n'est pas du JSON — cas le plus courant d'un fichier tronqué. */
'invalid-json'
/** La racine du document n'est pas un objet JSON. */
 | 'not-an-object'
/** Un champ obligatoire manque. */
 | 'missing-field'
/** Un champ existe mais n'a pas le type attendu (ou une valeur hors domaine). */
 | 'wrong-type'
/** Version inconnue, et aucune migration ne mène à la version courante. */
 | 'unsupported-version'
/** Une migration a levé, rendu autre chose qu'un objet, ou bouclé. */
 | 'migration-failed';
/**
 * Motif d'un refus, avec l'endroit exact.
 *
 * `message` est **en français** et affichable tel quel : le seul moyen d'être
 * sûr qu'un motif existe est qu'il soit porté par la donnée.
 */
export interface PlanParseError {
    readonly code: PlanParseErrorCode;
    /**
     * Chemin JSON de la **première** violation, sans préfixe : `pixelsPerMeter`,
     * `floors[2].objects[7].type`, `geo.lat`. Chaîne **vide** pour la racine du
     * document.
     *
     * Première, et pas toutes : la lecture s'arrête au premier manquement. Rendre
     * la liste complète supposerait de continuer à interpréter un document dont on
     * vient d'établir qu'il ne respecte pas le format — et produirait surtout des
     * violations en cascade dérivées de la première.
     */
    readonly path: string;
    readonly message: string;
    /** Ce qui était attendu, en français (« un tableau », « un nombre > 0 »). */
    readonly expected?: string;
    /** Ce qui a été trouvé, **résumé**. Jamais la valeur brute : un `Backdrop`
     *  porte son image en base64, et l'écrire dans un message noierait la console
     *  sous deux mégaoctets. */
    readonly received?: string;
}
/** Motif prêt à afficher ou à journaliser : le message, et où il s'applique. */
export declare function planParseErrorMessage(error: PlanParseError): string;
/**
 * Version du format de document écrite par cette bibliothèque.
 *
 * Elle est **fixe depuis l'origine du dépôt** — d'où une chaîne de migrations
 * encore vide (cf. `PLAN_MIGRATIONS`). Le moteur est là **avant** le premier
 * saut, précisément parce qu'après il serait trop tard : le format aurait déjà
 * changé sans que rien ne l'annonce.
 *
 * Elle doit rester **synchronisée** avec le littéral de `FloorplanProject.version`
 * (`models/project.model.ts`) et avec ce qu'écrit `ExportService.toProject` — le
 * type littéral fait échouer la compilation si les trois divergent.
 */
export declare const PLAN_DOCUMENT_VERSION: FloorplanProject['version'];
/** Document en cours de lecture : un objet JSON, rien de plus. Volontairement
 *  non typé `FloorplanProject` — tant que les gardes n'ont pas tourné, ce n'en
 *  est pas un, et le prétendre serait le mensonge que ce module corrige. */
export type PlanRecord = Record<string, unknown>;
/**
 * Un **saut de version**, et un seul.
 *
 * Découper ainsi n'est pas cosmétique : une fonction qui traiterait « toutes les
 * versions antérieures » redeviendrait, au troisième format, une pile de `if`
 * dont plus personne ne saurait dire dans quel ordre ils s'appliquent.
 */
export interface PlanMigration {
    /** Version d'entrée, telle qu'écrite dans le document. */
    readonly from: string;
    /** Version de sortie. `migratePlanDocument` la **repose** lui-même sur le
     *  document rendu — voir le piège documenté là-bas. */
    readonly to: string;
    /** Ce que fait l'étape, en français. Affiché dans le motif si elle échoue :
     *  « la migration a échoué » sans dire laquelle n'est pas un motif. */
    readonly describe: string;
    /** Transformation **pure** : ne pas muter `doc`, rendre un nouvel objet. */
    migrate(doc: PlanRecord): PlanRecord;
}
/**
 * Chaîne de migrations, de la plus ancienne à la plus récente.
 *
 * **Vide aujourd'hui, et c'est exact** : `5.3.0` est le seul format que g-plan
 * ait jamais écrit (vérifié sur l'historique complet du dépôt). Une entrée
 * inventée pour « avoir un exemple » serait pire que rien — elle transformerait
 * des documents qui n'existent pas, et personne ne saurait plus lesquels sont
 * réels.
 *
 * **Pour ajouter un format** : bumper le littéral de `FloorplanProject.version`
 * et `PLAN_DOCUMENT_VERSION`, puis pousser ici une entrée
 * `{ from: '5.3.0', to: '<nouvelle>', describe: '…', migrate }`. Les gardes de
 * `parsePlanDocument` décrivent alors le **nouveau** format : elles s'appliquent
 * après la chaîne, jamais avant.
 */
export declare const PLAN_MIGRATIONS: readonly PlanMigration[];
/**
 * Amène un document à `PLAN_DOCUMENT_VERSION` en composant les sauts.
 *
 * Rend le document **inchangé, par référence**, quand il est déjà à la version
 * courante — cf. décision n°3 en tête de fichier.
 *
 * `migrations` est paramétrable pour que la composition soit testable sans
 * attendre qu'un vrai saut existe ; en usage réel, on ne passe rien.
 */
export declare function migratePlanDocument(doc: PlanRecord, migrations?: readonly PlanMigration[]): Result<PlanRecord, PlanParseError>;
/**
 * Lit un document de plan **déjà désérialisé**.
 *
 * Trois temps, dans cet ordre : racine, migration, gardes. L'ordre compte — les
 * gardes décrivent le format **courant**, elles n'ont donc rien à dire d'un
 * document qui n'y a pas encore été amené.
 *
 * En cas de succès sur un document déjà à la version courante, la valeur rendue
 * **est** l'objet reçu (même référence, aucune normalisation).
 */
export declare function parsePlanDocument(raw: unknown, migrations?: readonly PlanMigration[]): Result<FloorplanProject, PlanParseError>;
/**
 * Lit un document de plan depuis son **texte** JSON.
 *
 * C'est la porte d'entrée des sources non fiables : fichier importé, brouillon
 * `localStorage`, charge utile d'une app hôte. Un JSON tronqué s'arrête ici,
 * avec le motif — et non trois écrans plus loin, sur un plan à moitié dessiné.
 */
export declare function parsePlanDocumentText(text: string, migrations?: readonly PlanMigration[]): Result<FloorplanProject, PlanParseError>;
