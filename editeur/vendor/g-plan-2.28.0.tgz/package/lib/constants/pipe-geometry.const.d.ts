/**
 * Géométrie des réseaux — lecture unifiée des deux formats de tracé.
 *
 * Depuis g-plan 2.1.0, un tracé de réseau est **une seule polyligne**
 * (`fabric.Polyline`) portant tous ses sommets, là où les versions antérieures
 * produisaient une suite de `fabric.Line` indépendantes. Les plans enregistrés
 * avant cette version contiennent donc encore des lignes à deux points, et
 * doivent rester lisibles : c'est le rôle de `pipeAbsPoints`, qui rend les
 * sommets **absolus** quel que soit le format rencontré.
 *
 * Ces fonctions travaillent aussi bien sur un objet Fabric vivant que sur sa
 * forme sérialisée (`toJSON`) : elles ne lisent que des propriétés présentes
 * dans les deux cas. C'est indispensable — `PlanAnalysisService` et la vue 3D
 * n'ont jamais de canvas sous la main.
 */
/** Vrai si ce `myType` désigne un tracé de réseau (et non une cote `PipeMeasurement`). */
export declare function isPipeType(myType: unknown): boolean;
/**
 * Sommets absolus d'un objet réseau, en coordonnées scène.
 *
 * Polyligne (format courant) comme ligne à deux points (plans antérieurs à
 * 2.1) : la lecture est celle de `absTracePoints`, l'extracteur commun à tous
 * les objets de plan (cf. `plan-geometry.const.ts`, qui documente le demi-trait
 * de la boîte englobante et le biais historique assumé des lignes). Ce nom est
 * conservé parce qu'il dit *quel* objet on lit, et parce qu'il est exporté par
 * l'API publique depuis 2.1.
 */
export declare function pipeAbsPoints(obj: any): {
    x: number;
    y: number;
}[];
/** Longueur développée (px) d'un tracé de réseau — somme de tous ses segments. */
export declare function pipeLengthPx(obj: any): number;
/** Segments d'un tracé, sous forme de couples de sommets consécutifs. */
export declare function pipeSegments(obj: any): {
    p1: {
        x: number;
        y: number;
    };
    p2: {
        x: number;
        y: number;
    };
}[];
/** Point situé au milieu du **développé** du tracé — là où poser sa cote. */
export declare function pipeMidpoint(obj: any): {
    x: number;
    y: number;
} | null;
