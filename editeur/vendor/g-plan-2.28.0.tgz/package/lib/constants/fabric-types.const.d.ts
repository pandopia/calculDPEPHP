import { FloorplanObjectType, ToolGroup } from '../models/floorplan-object.model';
/** Types d'objets Fabric.js persistés lors de la sauvegarde */
export declare const FABRIC_SAVED_TYPES: FloorplanObjectType[];
/**
 * **Calques de fond** : images posées sous le dessin, inertes, sans aucune
 * information métier — le fond de carte (`Backdrop`) et, depuis la 2.12.0, le
 * calque photo redressé (`PhotoLayer`).
 *
 * Ils partagent un comportement en une douzaine d'endroits : non déplaçables au
 * doigt, ignorés par le panoramique « clic sur le vide », comptés à part dans
 * l'empilement des réseaux, exclus des « dessins existants », vidés de leur
 * image dans le brouillon de repli. Ces endroits testaient `=== 'Backdrop'` en
 * dur ; le second type de calque en aurait oublié la moitié, et chaque oubli
 * aurait été un défaut discret et différent. D'où cette liste unique.
 *
 * `GhostFloor` n'y figure pas : c'est un calque de fond, mais **non persisté**,
 * et les sites qui le concernent le nomment déjà à côté.
 */
export declare const BACKGROUND_LAYER_TYPES: readonly string[];
/** `true` si `myType` désigne un calque de fond (cf. `BACKGROUND_LAYER_TYPES`). */
export declare function isBackgroundLayer(myType: string | undefined | null): boolean;
/** Groupes d'outils de la barre d'outils de l'éditeur */
export declare const TOOL_GROUPS: ToolGroup[];
