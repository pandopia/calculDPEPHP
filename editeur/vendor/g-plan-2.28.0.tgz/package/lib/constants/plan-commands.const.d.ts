/**
 * Commandes réversibles — la couche pure de l'historique.
 *
 * **Pourquoi ce module existe.** Jusqu'à la 2.7.0, `HistoryService` empilait
 * jusqu'à cinquante **sérialisations JSON complètes du plan** dans un
 * `string[]`. Un projet avec fond de carte pèse ~465 Ko : l'historique atteignait
 * donc des dizaines de mégaoctets en mémoire, et c'est la même recopie intégrale
 * qui faisait dépasser le quota `localStorage` de l'autosave — le brouillon
 * proposé au démarrage datait alors d'avant la pose du fond, et le restaurer
 * vidait le plan en cours (cf. `FEATURE-refonte-moteur-croquis.md § 1.1`).
 *
 * Une commande ne décrit que **ce qui change** : quelques dizaines d'octets pour
 * un déplacement, contre 465 Ko pour un instantané.
 *
 * Ce fichier ne contient **que des données et des fonctions pures** — aucune
 * dépendance à Fabric ni au DOM, donc testable sans navigateur. Le pont vers le
 * canvas vit dans `HistoryService`, et lui seul : deux états qui divergent est
 * le risque principal de ce chantier.
 */
/** Propriétés dont une modification doit être historisée.
 *
 *  Liste **fermée** à dessein : sérialiser l'objet entier ferait revenir le
 *  problème qu'on corrige — un `Backdrop` porte son image en base64, soit
 *  ~2,6 Mo qu'un simple déplacement recopierait. */
export declare const PROPS_SUIVIES: readonly string[];
/**
 * Propriétés **intrinsèques**, à réappliquer AVANT les propriétés de position.
 *
 * Pour une `fabric.Line`, écrire `x1..y2` **recalcule** `left`/`top` : les poser
 * dans le même `set()` que la position faisait gagner la géométrie, et la
 * position rétablie était aussitôt écrasée. Symptôme observé : l'annulation
 * fonctionnait (les deux jeux de valeurs concordaient) mais le rétablissement
 * ne bougeait pas.
 */
export declare const PROPS_INTRINSEQUES: ReadonlySet<string>;
/** Sépare un état en deux passes d'application, dans l'ordre à respecter. */
export declare function passesApplication(etat: EtatObjet): [EtatObjet, EtatObjet];
/** Instantané partiel d'un objet, restreint à `PROPS_SUIVIES`. */
export type EtatObjet = Record<string, unknown>;
/**
 * Types **jamais** historisés.
 *
 * Deux familles, pour deux raisons distinctes :
 *  - les objets **transitoires** (poignées de nœud, étage fantôme, aperçus de
 *    tracé) n'existent que le temps d'un geste ;
 *  - les objets **dérivés** (cotes, étiquettes, pièces détectées) sont
 *    régénérés par `recalculateRooms` après chaque annulation. Les historiser
 *    noierait la pile sous du bruit et les ferait réapparaître en double.
 */
export declare const TYPES_NON_HISTORISES: ReadonlySet<string>;
/** Vrai si l'objet mérite une entrée d'historique. */
export declare function estHistorisable(obj: {
    myType?: string;
} | null | undefined): boolean;
export interface CommandeAjout {
    readonly type: 'ajout';
    readonly id: string;
    /** Sérialisation complète — nécessaire pour recréer l'objet à la redite. */
    readonly objet: Record<string, unknown>;
    /** Rang dans la pile d'affichage, pour restaurer l'ordre exact. */
    readonly index: number;
}
export interface CommandeSuppression {
    readonly type: 'suppression';
    readonly id: string;
    readonly objet: Record<string, unknown>;
    readonly index: number;
}
export interface CommandeModification {
    readonly type: 'modification';
    readonly id: string;
    readonly avant: EtatObjet;
    readonly apres: EtatObjet;
    /** Horodatage — sert à la fenêtre de fusion des gestes continus. */
    readonly a: number;
}
/** Plusieurs commandes annulées d'un seul geste (génération d'enveloppe, pose
 *  d'un modèle de logement…). */
export interface CommandeGroupe {
    readonly type: 'groupe';
    readonly commandes: readonly PlanCommand[];
}
export type PlanCommand = CommandeAjout | CommandeSuppression | CommandeModification | CommandeGroupe;
/** Fenêtre de fusion des modifications consécutives sur un même objet (ms).
 *  Sans elle, un glisser produirait une entrée par frame et l'annulation
 *  reculerait pixel par pixel. */
export declare const FENETRE_FUSION_MS = 400;
/**
 * Commande inverse — c'est elle qui rend l'annulation exacte plutôt
 * qu'approchée.
 */
export declare function inverser(c: PlanCommand): PlanCommand;
/**
 * Fusionne deux commandes consécutives, ou rend `null` si elles ne se fusionnent
 * pas. Seules les modifications d'un **même objet** dans la fenêtre de temps
 * fusionnent : l'état de départ est celui de la première, l'arrivée celui de la
 * seconde.
 */
export declare function fusionner(a: PlanCommand, b: PlanCommand): PlanCommand | null;
/** Poids approximatif d'une commande, en octets. Sert à mesurer — c'est le
 *  critère d'acceptation du lot — et à borner la pile. */
export declare function poidsCommande(c: PlanCommand): number;
/** Extrait l'état suivi d'un objet Fabric (ou de sa forme sérialisée). */
export declare function etatObjet(obj: any): EtatObjet;
/** Vrai si deux états suivis diffèrent. */
export declare function etatsDifferent(a: EtatObjet, b: EtatObjet): boolean;
