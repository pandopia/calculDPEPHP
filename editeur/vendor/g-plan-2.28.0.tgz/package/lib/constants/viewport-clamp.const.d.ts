/**
 * Ramener un panneau flottant dans la fenêtre.
 *
 * Les menus déroulants de l'éditeur (« Fond », « Fichier », « Copier depuis »)
 * sont des `position: absolute` ancrés sous leur bouton. Tant que le bouton est
 * loin des bords, le panneau tient ; collé au bord droit, il sort de l'écran.
 * Sur un poste de travail, le bandeau a de la place et personne ne le voyait.
 * Sur tablette (960 px CSS en paysage), le menu « Fond » — 240 px de large,
 * ancré à ~130 px du bord — sortait de **moitié**, et l'entrée « Supprimer le
 * fond », en bas à droite, devenait inatteignable.
 *
 * Le CSS seul n'y répond pas : un `right: 0` déplace le problème vers la gauche
 * dès que le bouton se retrouve au milieu (le bandeau se replie sur plusieurs
 * lignes), et aucune propriété ne borne un élément absolu sur la **fenêtre**.
 * Il faut mesurer. D'où cette fonction pure — le calcul, sans le DOM — et la
 * directive `KeepInViewportDirective` qui l'applique.
 */
/** Marge minimale conservée entre le panneau et le bord de la fenêtre. */
export declare const VIEWPORT_MARGIN_PX = 8;
/** Ce que la directive mesure du panneau et de la fenêtre. */
export interface ClampInput {
    /** Bord gauche du panneau, en coordonnées fenêtre (`getBoundingClientRect`). */
    left: number;
    /** Bord droit du panneau, en coordonnées fenêtre. */
    right: number;
    /** Largeur de la fenêtre (`innerWidth` / `clientWidth`). */
    viewportWidth: number;
    /** Marge à conserver de chaque côté. */
    margin?: number;
}
/**
 * Décalage horizontal à appliquer au panneau, en pixels.
 *
 * Positif : le panneau glisse vers la droite (il sortait à gauche). Négatif :
 * vers la gauche (il sortait à droite). Zéro : il tient, on ne touche à rien.
 *
 * Le débordement à **droite** est corrigé en premier, puis le résultat est
 * revérifié à gauche : un panneau plus large que la fenêtre déborde des deux
 * côtés, et on préfère alors montrer son début — c'est là que sont le titre et
 * les premières entrées. Le décalage est mesuré à partir de la position
 * courante, jamais accumulé : rappeler la fonction sur un panneau déjà corrigé
 * rend 0, ce qui rend l'application idempotente.
 */
export declare function clampShiftX(input: ClampInput): number;
