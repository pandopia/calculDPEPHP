/**
 * Réglages de détection dérivés de l'image — la couche pure du scanner.
 *
 * **Pourquoi ce module existe.** Les réglages du scanner étaient des pixels
 * absolus : un bloc de seuillage de 3, une longueur minimale de 40 px. Or une
 * photo de plan fait 1 000 px sur un téléphone d'entrée de gamme et 4 000 sur un
 * autre : les mêmes chiffres n'y décrivent pas la même chose. Un bloc de 3 ne
 * voit que la texture du crayon, jamais le trait.
 *
 * Tout se déduit donc de la taille de l'image. Comme ailleurs dans la
 * bibliothèque, la décision est ici, **pure et testable sans navigateur** ; le
 * pont OpenCV se contente de l'appliquer.
 */
/** Réglages effectifs, en pixels de l'image analysée. */
export interface ReglagesDetection {
    /** `blockSize` du seuillage adaptatif — impair, jamais inférieur à 3. */
    readonly blocSeuil: number;
    /** Longueur du noyau d'ouverture horizontal. */
    readonly noyauH: number;
    /** Longueur du noyau d'ouverture vertical. */
    readonly noyauV: number;
    /** Longueur minimale d'un segment retenu par Hough. */
    readonly longueurMin: number;
    /** Écart maximal toléré pour relier deux morceaux d'un même trait. */
    readonly ecartMax: number;
    /** Épaisseur de la bande de bord dans laquelle un trait est tenu pour le
     *  cadre de la photo et non pour un mur. */
    readonly bandeBord: number;
}
/**
 * Un bloc de seuillage doit couvrir plusieurs fois l'épaisseur d'un trait de
 * crayon pour distinguer le trait du papier. 3 % du grand côté place la fenêtre
 * autour de 40 px sur une photo de 1 400 — l'ordre de grandeur d'un trait, pas
 * de son grain.
 */
export declare const PART_BLOC_SEUIL = 0.03;
/**
 * Longueur des noyaux d'ouverture morphologique, en part du côté correspondant.
 *
 * C'est le réglage qui **sépare un mur d'une écriture**. Un trait de cloison
 * court sur une fraction notable de la feuille ; les lettres de « SÉJOUR » ou
 * les chiffres d'une cote n'ont de course longue dans aucune des deux
 * directions, et disparaissent donc entièrement de l'ouverture. Mesuré sur une
 * photo réelle de croquis : l'écriture manuscrite ne survit pas, le plan entier
 * ressort.
 */
export declare const PART_NOYAU: number;
/** Longueur minimale d'un mur, en part de la hauteur. En deçà, c'est un détail
 *  de dessin (flèche de porte, hachure) plutôt qu'une cloison. */
export declare const PART_LONGUEUR_MIN = 0.04;
/** Bande de bord, en part du petit côté. Le bord d'un cahier, l'arête d'une
 *  table ou l'ombre du photographe longent le cadre — jamais un mur du plan,
 *  qu'on cadre toujours avec un peu d'air autour. */
export declare const PART_BANDE_BORD = 0.02;
/**
 * Envergure au-delà de laquelle un trait est tenu pour un bord de support et non
 * pour un mur, en part de la dimension de l'image dans sa direction.
 *
 * C'est le critère qui attrape ce que la bande de bord laisse passer : le bord
 * d'un cahier court parfois à cinquante pixels du cadre — hors bande — mais il
 * traverse **toute** la photo. Or on cadre toujours un plan avec un peu d'air
 * autour ; un mur qui occuperait 90 % du champ dans sa direction n'existe pas en
 * pratique.
 *
 * Le filtre s'applique aux segments BRUTS, avant l'extension vers les
 * intersections : celle-ci allonge les traits jusqu'aux coins et effacerait la
 * distinction.
 */
export declare const PART_ENVERGURE_MAX = 0.9;
/**
 * Vrai si un segment traverse la photo de part en part — donc s'il s'agit du
 * support et non du plan.
 */
export declare function estBordDeSupport(s: {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
}, largeur: number, hauteur: number): boolean;
/** Déduit les réglages effectifs de la taille de l'image. */
export declare function reglagesPour(largeur: number, hauteur: number): ReglagesDetection;
/**
 * Vrai si un segment longe le **cadre de la photo** plutôt que le plan.
 *
 * Deux conditions réunies, et non une seule : le segment doit se tenir tout
 * entier dans la bande de bord, **et** courir parallèlement à ce bord. Un mur
 * qui frôle le bord en le traversant n'est pas un cadre ; le bord d'un cahier,
 * lui, longe l'image sur toute sa course.
 */
export declare function estCadre(s: {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
}, largeur: number, hauteur: number, bande: number): boolean;
