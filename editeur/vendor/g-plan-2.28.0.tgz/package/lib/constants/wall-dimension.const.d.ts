/**
 * Cotes saisies au mur — résolution au moindre écart, puis fermeture.
 *
 * **Pourquoi ce module existe.** Le diagnostiqueur qui relève une pièce sans
 * plan a déjà son télémètre laser dans la poche. Il ne demande pas que le
 * téléphone mesure à sa place : il veut **saisir ce qu'il vient de lire**, et
 * que le croquis s'y conforme. Or jusqu'ici la saisie de dimensions n'existait
 * que pour un `RoomBox` — un rectangle, largeur et hauteur. Dès qu'une pièce a
 * un placard ou un pan coupé, elle ne servait plus à rien, et **aucun mur d'un
 * tracé ne pouvait recevoir sa longueur**
 * (cf. `FEATURE-releve-piece-sans-plan.md § 4.1`).
 *
 * ## Le point qui décide de tout : le problème est surdéterminé
 *
 * Contraindre des longueurs dans un polygone fermé n'a **pas** de solution
 * exacte en général. Six cotes relevées à la main sur une pièce en L ne sont
 * jamais compatibles au millimètre : le tour horizontal ne retombe pas sur la
 * somme des tronçons, ni le tour vertical. Une implémentation qui prétendrait
 * satisfaire les six exactement devrait fausser la géométrie ailleurs — angle
 * tordu, mur voisin déplacé — **en silence**. C'est le motif de panne muette que
 * ce projet traque depuis le 31/07.
 *
 * La réponse retenue est celle du géomètre qui ferme un cheminement :
 *
 *  1. **moindre écart pondéré** — les murs cotés sont tenus fort, les non cotés
 *     absorbent le reste ; la fermeture est imposée comme contrainte dure, ce
 *     qui se résout en forme close (deux multiplicateurs de Lagrange) ;
 *  2. **fermeture de Bowditch** (`repartirBowditch`, lot 3) — le résidu, qu'il
 *     vienne du calcul flottant, d'un système singulier ou d'un écrêtage, est
 *     réparti au prorata du chemin parcouru plutôt que jeté sur le dernier mur ;
 *  3. **l'écart résiduel est rendu, mur par mur** (`residualM`). Ce n'est pas un
 *     échec à masquer, c'est la donnée que l'utilisateur doit voir : elle lui
 *     dit laquelle de ses six lectures est douteuse.
 *
 * ## Ce que ce module ne fait pas, volontairement
 *
 * Il **ne redresse pas les angles**. Re-contraindre les directions ici ferait
 * pivoter des murs que l'utilisateur n'a pas désignés — il a touché *un* mur
 * pour lui donner *une* longueur — et un plan importé, dont les traits sont à 3°
 * de l'horizontale parce que la photo était de biais, serait silencieusement mis
 * d'équerre. Redresser est le travail du lot 3, au moment du tracé.
 *
 * ## Mais les directions ne sont pas garanties intactes — et c'est mesuré
 *
 * Tant que le relevé est **compatible**, les directions sortent inchangées :
 * seules les longueurs bougent, et c'est le cas courant. Dès qu'il ne l'est pas,
 * les garder toutes est arithmétiquement impossible. Sur une pièce fermée, deux
 * murs opposés sont liés : demander `ab = 1 m` quand `cd = 3,80 m` lui fait face
 * impose au troisième côté une longueur **négative**. On l'écrête à
 * `MIN_WALL_PX`, et dès lors le cheminement ne retombe plus sur son point de
 * départ : refermer le polygone fait forcément tourner au moins un mur.
 *
 * C'est là que `repartirBowditch` gagne sa place, et le gain est **mesuré** sur
 * ce cas précis :
 *
 * | | pire rotation | pire écart de cote |
 * |---|---|---|
 * | sans Bowditch | **54°**, tout entiers sur le dernier mur | 3 cm |
 * | avec Bowditch | **17°**, partagés entre deux murs | 1,21 m |
 *
 * Sans lui les longueurs restent justes et **un** mur part à 54° — le croquis
 * est détruit à un endroit. Avec lui la déformation est étalée et la forme reste
 * plausible, au prix de cotes qui s'écartent. C'est le bon arbitrage pour un
 * croquis : on préfère une figure lisible et un écart annoncé à une figure
 * cassée et des chiffres exacts.
 *
 * Ce qui ne doit **jamais** céder, c'est de le dire. D'où `maxRotationDeg`,
 * rendu au même titre que `residualM` : la déformation est une donnée affichée,
 * pas un effet de bord tu. Au-delà de `ROTATION_ALERTE_DEG`, `warning` passe à
 * `true`.
 *
 * Conséquence assumée : sur un relevé compatible, la surface obtenue est celle
 * du produit des cotes **à l'obliquité près du croquis** — exacte sur un tracé
 * d'équerre, basse de ~0,3 % sur un tracé à 2° de travers.
 *
 * Comme `plan-commands.const.ts`, `sketch-snap.const.ts` et
 * `plan-graph.const.ts`, ce fichier ne contient **que des fonctions pures** — ni
 * Fabric, ni DOM, ni canvas. Le pont vers le canvas vit dans `WallGraphService`
 * (topologie) et `FabricCanvasService` (écriture), et nulle part ailleurs.
 */
import { Point } from '../models/geometry.types';
/**
 * Poids d'un mur **coté**. Cent fois celui d'un mur libre : à cette raideur, un
 * mur coté encaisse 1 % de ce qu'encaisse un mur libre voisin, ce qui revient en
 * pratique à le tenir tout en gardant le système soluble. Une contrainte dure
 * rendrait la pièce insoluble dès deux cotes contradictoires — décision n°2 de
 * `FEATURE-releve-piece-sans-plan.md`.
 */
export declare const MEASURED_WEIGHT = 100;
/** Poids d'un mur **non coté** : c'est lui qui absorbe l'incompatibilité. */
export declare const FREE_WEIGHT = 1;
/**
 * Longueur minimale d'un mur après résolution, en pixels.
 *
 * Le moindre écart n'interdit pas mathématiquement une longueur négative : trois
 * cotes franchement fausses peuvent demander à un mur de se retourner. Un mur
 * retourné casserait l'ordre des sommets et donc la détection de pièce ; on
 * l'écrête, et l'écart correspondant ressort dans `residualM` au lieu de se
 * perdre.
 */
export declare const MIN_WALL_PX = 1;
/** Cote demandée sur un mur du cheminement. `targetM` à `null` = non coté. */
export interface WallDimensionInput {
    readonly id: string;
    /** Longueur relevée au télémètre, en mètres. */
    readonly targetM: number | null;
}
/**
 * Cheminement à résoudre : les sommets tels qu'ils sont dessinés, et une cote
 * (ou pas) par segment.
 *
 * Pour une boucle (`closed: true`), le premier sommet n'est **pas** répété à la
 * fin — il y a autant de segments que de sommets. Pour un cheminement ouvert, il
 * y a un sommet de plus que de segments.
 */
export interface DimensionChain {
    readonly points: readonly Point[];
    readonly walls: readonly WallDimensionInput[];
    readonly closed: boolean;
    readonly pixelsPerMeter: number;
}
/** Ce qu'un mur a effectivement obtenu, et de combien il s'écarte de sa cote. */
export interface WallDimensionResult {
    readonly id: string;
    /** Cote saisie, en mètres ; `null` si le mur n'était pas coté. */
    readonly targetM: number | null;
    /** Longueur obtenue après résolution et fermeture, en mètres. */
    readonly lengthM: number;
    /** `lengthM − targetM`, en mètres. `null` si le mur n'était pas coté.
     *  **C'est la donnée à afficher** : elle dit ce que le croquis n'a pas pu
     *  honorer, et sur quel mur. */
    readonly residualM: number | null;
}
/**
 * Rotation, en degrés, au-delà de laquelle la déformation devient visible et
 * doit être signalée. Un demi-degré sur un mur de 4 m, c'est 3,5 cm au bout :
 * invisible. Deux degrés, c'est 14 cm — ça se voit, et ça doit se dire.
 */
export declare const ROTATION_ALERTE_DEG = 1;
export interface DimensionSolution {
    /** Sommets corrigés, dans l'ordre et en même nombre qu'à l'entrée. */
    readonly points: readonly Point[];
    readonly walls: readonly WallDimensionResult[];
    /**
     * Écart de fermeture **des cotes telles que saisies**, en pixels : de combien
     * le cheminement raterait son point de départ si l'on posait chaque longueur
     * demandée sans rien corriger. C'est la mesure de l'incompatibilité du relevé,
     * pas celle du résultat — le résultat, lui, ferme exactement.
     */
    readonly closureErrorPx: number;
    /** Cet écart rapporté au périmètre. */
    readonly closureRatio: number;
    /** Pire écart constaté sur un mur coté, en mètres. */
    readonly maxResidualM: number;
    /**
     * Pire rotation subie par un mur, en degrés — **zéro sur un relevé
     * compatible**.
     *
     * Le module ne redresse jamais un angle, mais refermer une boucle que les
     * cotes rendent impossible déplace des sommets, donc fait tourner des murs. Le
     * taire reviendrait à déformer le croquis en silence ; on le rend, comme on
     * rend `residualM`.
     */
    readonly maxRotationDeg: number;
    /** `closureRatio` au-delà de `SEUIL_ALERTE_FERMETURE` (8 %) : la répartition
     *  déplace visiblement les murs, l'appelant avertit — sans bloquer. */
    readonly warning: boolean;
}
/**
 * Résout un cheminement coté.
 *
 * ## La résolution, en clair
 *
 * Les directions `u_i` des segments sont **fixées** par le croquis ; seules les
 * longueurs `t_i` sont inconnues. On cherche
 *
 * ```
 *   min  Σ w_i (t_i − L_i)²      sous contrainte   Σ t_i u_i = 0   (boucle fermée)
 * ```
 *
 * où `L_i` est la cote demandée (ou la longueur actuelle si le mur n'est pas
 * coté) et `w_i` son poids. Le lagrangien donne `t = L + W⁻¹Aᵀλ`, la contrainte
 * `λ = −M⁻¹E` avec `E = Σ L_i u_i` (l'écart de fermeture des cotes) et
 * `M = Σ u_iu_iᵀ / w_i`, une matrice **2×2** qu'on inverse à la main. Soit, par
 * mur : `t_i = L_i + (u_i·λ) / w_i`.
 *
 * Trois choses tombent de cette forme, et c'est pourquoi elle a été retenue
 * plutôt qu'une relaxation itérative :
 *  - la correction d'un mur est **inversement proportionnelle à son poids** —
 *    « les cotés sont tenus, les libres absorbent » n'est pas une intention,
 *    c'est le résultat ;
 *  - elle est **déterministe et sans réglage** : pas de nombre d'itérations, pas
 *    de critère de convergence, donc pas de comportement qui change avec la
 *    taille de la pièce ;
 *  - elle est **exacte**, donc testable au millimètre.
 *
 * Le premier sommet est l'**ancre** : il ne bouge pas, le cheminement se
 * reconstruit à partir de lui. Il fallait bien en fixer un — sans quoi la
 * solution est définie à une translation près — et le premier est le seul choix
 * que l'appelant contrôle sans rien deviner.
 *
 * Rend `null` si le cheminement est inexploitable (échelle absente, nombre de
 * murs incohérent avec le nombre de sommets).
 */
export declare function solveWallDimensions(chain: DimensionChain): DimensionSolution | null;
