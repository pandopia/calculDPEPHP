/**
 * Réinitialisation du dessin — décider quoi effacer, et l'annoncer.
 *
 * Vider un plan est le seul geste de l'éditeur qui détruit **tout** d'un coup.
 * Une commande pareille ne se contente pas d'un « Êtes-vous sûr ? » : cette
 * question n'informe de rien, et on y répond « oui » par réflexe. Ce module
 * répond donc à la seule question utile — **qu'est-ce qui va disparaître, au
 * juste** — sous la forme d'un décompte et d'une phrase française prête à
 * afficher.
 *
 * Couche pure : ni Fabric, ni DOM, ni canvas. Elle travaille sur n'importe quel
 * objet portant un `myType`, donc aussi bien sur les objets vivants du canvas
 * que sur leur forme sérialisée.
 *
 * Deux règles de périmètre, toutes deux délibérées :
 *
 *  - **les calques de fond ne partent pas par défaut.** Un fond de carte a
 *    coûté une capture réseau, un calage, parfois un géoréférencement ; le
 *    reprendre parce qu'on recommence son croquis serait une punition. Il part
 *    si on le demande explicitement (`includeBackground`) ;
 *  - **les objets dérivés ne sont pas comptés.** Cotes, étiquettes, pièces
 *    détectées et poignées sont régénérés depuis la géométrie : les annoncer
 *    gonflerait le décompte d'objets que l'utilisateur n'a jamais posés.
 */
/** Ce que l'utilisateur a posé lui-même, par famille. */
export interface ResetCounts {
    walls: number;
    pipes: number;
    rooms: number;
    openings: number;
    equipment: number;
    annotations: number;
    /** Tout le reste (escaliers, flèche du nord, étiquettes de repérage…). */
    others: number;
    /** Total des familles ci-dessus — ce qui sera réellement effacé. */
    total: number;
    /** Calques de fond présents (fond de carte, calque photo). */
    backgroundLayers: number;
}
/** Portée demandée pour la remise à zéro. */
export interface ResetScope {
    /** Effacer aussi les calques de fond. Faux par défaut. */
    includeBackground?: boolean;
}
/** Résultat : ce qui part, ce qui reste, et de quoi le dire. */
export interface ResetPlan<T> {
    /** Objets à retirer du canvas. */
    removed: T[];
    /** Objets conservés — fonds gardés et objets dérivés, qui se régénèrent. */
    kept: T[];
    counts: ResetCounts;
    /**
     * `true` s'il n'y a rien à effacer. L'appelant s'en sert pour désactiver la
     * commande **avec un motif**, plutôt que d'ouvrir une confirmation qui ne
     * confirmerait rien.
     */
    empty: boolean;
}
/**
 * Établit ce que la réinitialisation retirerait.
 *
 * Ne modifie rien : elle **décrit**. C'est ce qui permet de l'appeler pour
 * peupler la confirmation, puis de la rappeler pour exécuter, sans que les deux
 * puissent diverger.
 */
export declare function planReset<T extends {
    myType?: unknown;
}>(objects: readonly T[] | null | undefined, scope?: ResetScope): ResetPlan<T>;
/**
 * Phrase de décompte — « 12 murs, 2 pièces et 3 tracés de réseau ».
 *
 * Chaîne vide si rien n'est compté : l'appelant écrit alors sa propre phrase
 * plutôt que d'afficher « 0 objet », qui se lit comme une erreur.
 */
export declare function resetSummaryText(counts: ResetCounts): string;
