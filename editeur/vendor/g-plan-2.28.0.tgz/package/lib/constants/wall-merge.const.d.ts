/**
 * Fusion propre des murs détectés — aligner, recoller, souder.
 *
 * **Pourquoi ce module existe.** Ce que rend le scanner n'est pas un plan mais
 * une collection de traits : un mur photographié sort en deux ou trois morceaux
 * décalés de quelques pixels, un mur redessiné à la main tombe à côté de celui
 * qu'il prolonge, et deux murs qui devraient se croiser se ratent. À l'écran, le
 * résultat *ressemble* à un plan — ce sont les pastilles rouges (extrémités
 * libres) qui trahissent que rien ne se touche.
 *
 * Les outils qui existaient ne couvraient pas ce geste :
 *  - `mergeCollinearSegments` fusionne **une sélection**, à la main, zone par
 *    zone, et exige que les murs soient déjà quasi alignés (10 px en dur) ;
 *  - `extendToIntersections` ne regarde que **le premier** mur perpendiculaire
 *    trouvé et exige que le croisement tombe déjà **dans** son étendue — donc il
 *    ne referme pas un mur qui s'arrête trop tôt, qui est le cas courant ;
 *  - `snapCorners` ne traite que les **coins**, jamais les T ni les croix.
 *
 * `mergeWalls` fait le geste complet, sur tout le plan ou sur une zone, en
 * quatre passes dont l'ordre est le fond du sujet.
 *
 * ## Les quatre passes, et pourquoi cet ordre
 *
 * 1. **Aligner.** Les murs parallèles distants de moins de `alignTolerance` sont
 *    le même mur : ils sont ramenés sur un axe commun. Sans cette passe d'abord,
 *    les trois suivantes travailleraient sur des coordonnées qui se ratent de
 *    trois pixels et ne recolleraient rien.
 * 2. **Recoller.** Sur cet axe, les morceaux qui se chevauchent ou ne sont
 *    séparés que de `gapTolerance` deviennent **un seul mur**.
 * 3. **Souder.** Une extrémité restée libre à moins de `weldTolerance` d'un mur
 *    perpendiculaire est posée exactement sur le croisement — et le mur
 *    perpendiculaire est **prolongé** s'il s'arrêtait juste avant. C'est cette
 *    réciprocité qui referme un mur inachevé, ce qu'`extendToIntersections` ne
 *    savait pas faire.
 * 4. **Recoller à nouveau.** La soudure peut rendre jointifs deux murs qui ne
 *    l'étaient pas ; sans cette seconde passe, `mergeWalls` ne serait pas
 *    **idempotent** — relancer la fusion continuerait de changer le plan, et on
 *    ne saurait jamais quand c'est fini. Un test le garde.
 *
 * ## Trois décisions
 *
 * **1. L'axe commun est la moyenne pondérée par la LONGUEUR, et le groupe est
 * ancré sur le mur le plus long.** Un mur de façade porte la vérité du plan ; un
 * moignon de vingt pixels, rien du tout. À moyenne simple, le moignon tirerait
 * la façade à lui. L'ancrage sur le plus long évite en outre l'**effet de
 * chaîne** : en agrégeant de proche en proche, dix murs décalés chacun de trois
 * pixels finiraient dans le même groupe, et le dernier serait déplacé de trente.
 * Chaque membre est donc à moins de `alignTolerance` **de l'ancre**, jamais de
 * son voisin.
 *
 * **2. Le rapport dit ce qui a bougé, et de combien.** `maxShiftPx` est le plus
 * grand déplacement appliqué. Une fusion qui déplace un mur de quarante pixels
 * sans le dire, c'est un plan retouché dans le dos de celui qui l'a relevé : les
 * tolérances viennent des réglages qu'il a lui-même posés, et le résultat lui est
 * rendu chiffré. Même parti que `solveWallDimensions`, qui rend son résidu.
 *
 * **3. Les murs ignorés ne sont pas touchés — et ils témoignent.** Ils ont été
 * effacés à la gomme : les faire reparaître fusionnés serait défaire un geste
 * explicite. Ils traversent donc le module inchangés. Mais ils ne sont pas pour
 * autant sans effet : là où l'un d'eux se trouve, l'utilisateur a dit qu'il n'y
 * avait **pas** de mur, et le recollage refuse de franchir ce vide-là. Sans
 * cette règle, effacer un morceau puis relancer la fusion le faisait reparaître
 * — pire, réuni à ses voisins en un seul mur plus long, qu'on ne pouvait plus
 * effacer sans effacer aussi ce qui l'entourait.
 *
 * Module **pur** : ni Fabric, ni DOM, ni canvas, ni Angular — comme
 * `plan-graph.const.ts`, `sketch-snap.const.ts` ou `wall-dimension.const.ts`. Le
 * pont vers l'interface vit dans `ScannerComponent`.
 */
import { WallSegment, WallOrientation } from '../models/wall.model';
/**
 * Distance sous laquelle une extrémité est tenue pour **posée** sur un mur.
 *
 * Deux pixels : de quoi absorber un arrondi, pas de quoi confondre « ce bout
 * touche ce mur » avec « ce bout en est proche ». La question décide si la
 * soudure a le droit d'agir, et une valeur large la désactiverait partout.
 */
export declare const JONCTION_PX = 2;
export interface WallMergeOptions {
    /** Deux murs parallèles plus proches que cela sont **le même mur** (px). */
    readonly alignTolerance: number;
    /** Écart maximal entre deux morceaux colinéaires pour les recoller (px). */
    readonly gapTolerance: number;
    /** Distance sous laquelle une extrémité libre est soudée à un mur
     *  perpendiculaire, et ce mur prolongé jusqu'au croisement (px). */
    readonly weldTolerance: number;
}
/**
 * Réglages déduits de ceux que l'utilisateur a **déjà posés** dans le scanner.
 *
 * Aucun curseur supplémentaire, et ce n'est pas de l'économie : « épaisseur de
 * mur » et « extension » **sont** les deux distances dont il est question ici.
 * Deux traits distants de moins d'une épaisseur de mur sont les deux bords du
 * même mur ; l'extension est déjà la distance jusqu'à laquelle on accepte de
 * tirer un trait pour rejoindre un croisement. Un troisième réglage nommé
 * autrement dirait la même chose et finirait par le contredire.
 */
export declare function wallMergeOptions(params?: {
    clusterDistance?: number;
    extensionDistance?: number;
} | null): WallMergeOptions;
/** Repli, quand aucun réglage n'est disponible. Ordres de grandeur d'une photo
 *  de plan A4 réduite à ~1000 px : un mur y fait 20 à 50 px d'épaisseur. */
export declare const DEFAULT_WALL_MERGE_OPTIONS: WallMergeOptions;
/** Ce que la fusion a fait — rendu à l'appelant, jamais tu. */
export interface WallMergeReport {
    /** Murs actifs avant fusion. */
    readonly before: number;
    /** Murs actifs après fusion. */
    readonly after: number;
    /** Murs ramenés sur l'axe commun de leur groupe. */
    readonly aligned: number;
    /** Extrémités posées sur un croisement (soudures et prolongements). */
    readonly welded: number;
    /** Plus grand déplacement appliqué à un mur, en pixels. */
    readonly maxShiftPx: number;
}
export interface WallMergeResult {
    readonly walls: WallSegment[];
    readonly report: WallMergeReport;
}
/**
 * Aligne, recolle et soude les murs actifs.
 *
 * `scope` restreint l'opération : un mur n'est traité que si `scope` le retient.
 * Les murs écartés — comme les murs ignorés — traversent le module **inchangés**,
 * et ne participent à aucun calcul : fusionner une zone ne doit pas déplacer ce
 * qui est en dehors.
 *
 * L'opération est **idempotente** : la relancer sur son propre résultat ne
 * change plus rien (test dédié). Sans cette propriété, on ne saurait jamais si
 * le plan est stabilisé ou si un clic de plus le déformerait encore.
 */
export declare function mergeWalls(walls: readonly WallSegment[], options?: Partial<WallMergeOptions> | null, scope?: ((w: WallSegment) => boolean) | null): WallMergeResult;
/**
 * Positions des croisements le long d'un mur, dans son propre axe.
 *
 * Ni ses extrémités, ni les murs qui le frôlent : uniquement les endroits où un
 * mur perpendiculaire le **traverse** ou vient buter dessus.
 */
export declare function junctionsAlong(wall: WallSegment, others: readonly WallSegment[], tol?: number): number[];
/**
 * Découpe un mur à ses croisements.
 *
 * **Pourquoi c'est nécessaire.** Après une fusion, un mur de façade est **un
 * seul objet** de bout en bout : la gomme, qui efface un objet, l'efface donc
 * en entier. Retirer un tronçon devenait impossible — signalé à l'usage :
 * « cela me crée un mur en trop, je ne peux pas le supprimer avec la gomme ».
 * Découper d'abord, effacer ensuite, rend à la gomme la granularité que la
 * fusion lui avait retirée, sans renoncer à la fusion.
 *
 * Rend `[wall]` inchangé s'il n'y a aucun croisement intérieur.
 */
export declare function splitAtJunctions(wall: WallSegment, others: readonly WallSegment[], nextId: () => string, tol?: number): WallSegment[];
/** Orientation d'un segment quelconque, à l'aune de sa plus grande étendue.
 *  Utile aux appelants qui construisent un mur avant de le fusionner. */
export declare function orientationOf(s: {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
}): WallOrientation;
