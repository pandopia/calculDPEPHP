/**
 * Alternative textuelle du plan — ce qu'un lecteur d'écran peut lire.
 *
 * **Pourquoi ce module existe.** Un `<canvas>` est un rectangle de pixels : pour
 * une technologie d'assistance, il ne contient rien. Tout ce que g-plan produit
 * — pièces, surfaces, ouvertures, linéaires de réseau, prélèvements — est donc
 * strictement invisible à qui n'a pas la vue, ce qui est rédhibitoire en marché
 * public (RGAA 4.1 / WCAG 2.1 §1.1.1 : tout contenu non textuel doit avoir un
 * équivalent textuel qui remplit la **même fonction**).
 *
 * **Ce module ne recalcule rien.** `PlanAnalysisService` produit déjà la
 * synthèse complète (`PlanSummary`) à chaque modification du plan, et l'éditeur
 * l'émet déjà par `summaryChange`. L'alternative textuelle en est une **vue**,
 * pas un second modèle : c'est la condition pour qu'elle ne puisse pas dériver
 * du dessin. Le jour où l'analyseur compte une pièce de plus, le texte la dit,
 * sans qu'une seule ligne d'ici ne bouge.
 *
 * **Ce que ce module rend, et pourquoi ce n'est pas une chaîne.** Il rend une
 * arborescence (titres → sections → entrées → détails), pas un pavé de texte.
 * Un pavé se lit d'un bout à l'autre ou pas du tout ; une structure se
 * **parcourt** — le lecteur d'écran saute de titre en titre, entre dans la
 * liste qui l'intéresse, en ressort. C'est la différence entre « accessible »
 * et « conforme sur le papier ». `planOutlineText()` existe quand même, pour
 * l'export et pour les tests, mais ce n'est pas la forme de référence.
 *
 * Module **pur** : ni Angular, ni DOM, ni Fabric. Le composant
 * `<ng-gplan-plan-outline>` se contente de projeter cette arborescence en
 * titres et listes HTML.
 */
import { PlanSummary } from '../models/plan-summary.model';
/** Une ligne de liste : un fait principal, et ses précisions. */
export interface PlanOutlineEntry {
    /** Clé de suivi stable pour `@for (… track …)`. */
    readonly key: string;
    /** Le fait principal, seul contenu qu'on est sûr d'entendre : « Séjour — 24,5 m² ». */
    readonly text: string;
    /** Précisions, énoncées comme sous-liste. Jamais indispensables à la compréhension. */
    readonly details: readonly string[];
}
/** Une section, rendue en titre de niveau 3 suivi d'une liste. */
export interface PlanOutlineSection {
    /** Identifiant stable (ancre, clé de suivi) : `floor-rdc`, `network`, `hazards`. */
    readonly id: string;
    readonly heading: string;
    /** Phrase de synthèse lue avant la liste. `null` s'il n'y a rien à résumer. */
    readonly summary: string | null;
    readonly entries: readonly PlanOutlineEntry[];
    /** Phrase affichée quand la section est vide. Une section vide **muette**
     *  laisse croire à une panne de lecture ; on dit « aucune pièce relevée ». */
    readonly empty: string | null;
}
/** L'alternative textuelle complète. */
export interface PlanOutline {
    readonly title: string;
    /** Résumé d'ouverture — ce qu'on veut entendre en premier, en une phrase. */
    readonly intro: string;
    readonly sections: readonly PlanOutlineSection[];
    /** Mention légale sur les surfaces, fournie par l'appelant (`SURFACE_DISCLAIMER`).
     *  Non recopiée ici : un texte juridique dupliqué finit par diverger. */
    readonly notice: string | null;
    /** Vrai quand le plan ne contient encore rien de relevé. */
    readonly isEmpty: boolean;
}
/** Options de construction. */
export interface PlanOutlineOptions {
    /** Mention légale à joindre (typiquement `SURFACE_DISCLAIMER`). */
    readonly notice?: string | null;
}
export declare const PLAN_OUTLINE_TITLE = "Description textuelle du plan";
/**
 * Nombre à la française, virgule décimale.
 *
 * Écrit à la main plutôt que par `Intl`/`DecimalPipe` : ce module est pur, et
 * `toLocaleString` dépend de la locale du navigateur — un plan lu en `en-US`
 * annoncerait « 24.5 » là où l'affichage montre « 24,5 ». Un écart entre ce
 * qu'on voit et ce qu'on entend est exactement ce que l'alternative doit éviter.
 */
export declare function frNumber(value: number, decimals?: number): string;
/** Surface : « 24,5 m² ». Une décimale, comme la liste des pièces à l'écran. */
export declare function formatArea(m2: number): string;
/** Longueur : « 4,2 m ». Une décimale — l'analyseur n'en garantit pas plus sur
 *  les murs (`round1`), et afficher « 4,20 m » promettrait le centimètre. */
export declare function formatLength(m: number): string;
/**
 * Construit l'alternative textuelle à partir de la synthèse du plan.
 *
 * `summary` peut être `null` (plan pas encore analysé) : on rend alors une
 * structure valide qui **dit** qu'elle est vide. Rendre `null` obligerait
 * chaque appelant à gérer l'absence, et le premier qui l'oublierait afficherait
 * un `<section>` sans contenu — soit, pour un lecteur d'écran, un plan qui n'a
 * pas d'alternative du tout.
 */
export declare function buildPlanOutline(summary: PlanSummary | null | undefined, options?: PlanOutlineOptions): PlanOutline;
/**
 * Rendu texte brut de l'arborescence — pour un copier-coller, un export, ou un
 * test. **Ce n'est pas la forme accessible** : un lecteur d'écran a besoin de
 * titres et de listes réels, pas de tirets dans un paragraphe. Voir
 * `<ng-gplan-plan-outline>`.
 */
export declare function planOutlineText(outline: PlanOutline): string;
