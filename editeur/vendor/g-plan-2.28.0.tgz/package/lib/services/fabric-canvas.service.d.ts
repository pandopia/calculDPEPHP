import { EditorMode } from '../models/floorplan-object.model';
import { FloorplanProject } from '../models/project.model';
import { Point } from '../models/geometry.types';
import { DimensionSolution } from '../constants/wall-dimension.const';
import { PointerPrecision } from '../constants/pointer-precision.const';
import * as i0 from "@angular/core";
export declare class FabricCanvasService {
    /** Configuration de l'hôte — seul `defaultGridSize` y est lu aujourd'hui. */
    private readonly config;
    /** Sert uniquement à grouper les mutations multi-objets (fermeture de boucle)
     *  en un seul pas d'annulation. Aucun cycle : l'historique ignore ce service. */
    private readonly history;
    /** Graphe de nœuds partagés (lot 2). Il vient **en plus** des objets Fabric :
     *  rien n'est ajouté au document sérialisé, l'identité vit en mémoire. */
    private readonly wallGraph;
    private canvas;
    private readonly _isPolylineDrawing;
    private activePolylineLines;
    private lastPoint;
    private previewLine;
    private readonly _currentMode;
    /** Tracé de réseau en cours. Contrairement aux murs — un objet Fabric par
     *  segment, car chaque mur porte ses propres matériau, ouvertures et lettre —
     *  un réseau est UNE polyligne unique, alimentée sommet par sommet. */
    private activePipePoints;
    private activePipeObject;
    /** Premier sommet du tracé mur/cloison en cours — sert à proposer la fermeture
     *  de la boucle quand on y revient. `null` hors tracé. */
    private polylineStart;
    /** Aperçu du magnétisme (cote + repère de fermeture), retiré à chaque frame. */
    private previewHints;
    /** Nature de la dernière accroche calculée — pilote la couleur de l'aperçu. */
    private lastSnapType;
    /** Couleur active de la palette d'annotation, partagée par les trois formes. */
    private readonly _annotationColor;
    readonly annotationColor: import("@angular/core").Signal<string>;
    readonly annotationColors: {
        id: string;
        label: string;
        color: string;
    }[];
    setAnnotationColor(color: string): void;
    /**
     * Bornes du zoom.
     *
     * En bas, 10 % : au-delà, un plan de logement tient dans quelques pixels et on
     * ne peut plus rien viser. En haut, 800 % : de quoi placer une ouverture au
     * centimètre sur un croquis à 50 px/m.
     */
    private readonly ZOOM_MIN;
    private readonly ZOOM_MAX;
    private readonly _zoom;
    /**
     * Vrai dès que l'utilisateur a lui-même réglé la vue (molette, boutons, pan).
     *
     * Les cadrages AUTOMATIQUES s'y soumettent : un fond de carte arrive de façon
     * asynchrone, parfois plusieurs secondes après l'ouverture, et recadrer à ce
     * moment-là déplace le plan sous le doigt de quelqu'un qui a déjà commencé à
     * travailler — le point qu'il visait n'est plus où il le vise. Le bouton
     * « Ajuster », lui, cadre toujours : c'est une demande explicite.
     */
    private vueReglee;
    /**
     * Un cadrage automatique a déjà eu lieu pour ce document.
     *
     * Le drapeau `vueReglee` ne suffisait pas : un rechargement de projet le remet
     * à zéro, si bien qu'une capture satellite arrivant ensuite recadrait à
     * nouveau — et faisait manquer l'appui suivant. Deux tests e2e de tracé
     * échouaient en alternance, celui dont les clics tombaient au mauvais moment.
     *
     * Le cadrage automatique est donc **unique par document** : la première nappe
     * de contenu cadre, les arrivées tardives ne bougent plus rien. Le bouton
     * « Ajuster » reste disponible pour tout le reste.
     */
    private dejaCadre;
    /** Facteur de zoom courant — 1 = 100 %. Lu par la barre d'outils. */
    readonly zoom: import("@angular/core").Signal<number>;
    private isDragging;
    private lastPosX;
    private lastPosY;
    private isDrawingRect;
    private rectStart;
    private previewRect;
    private activeNodes;
    private readonly WALL_CONN_SNAP;
    /** Callback déclenché après chaque ajout/modification — utilisé pour recalculateRooms. */
    onWallsChanged?: () => void;
    /** Prochain prélèvement CRI à poser au clic (pose guidée). null = pose libre (P{n+1}). */
    private _nextSample;
    setNextSample(s: {
        id: string;
        label: string;
    } | null): void;
    /** Callback déclenché quand un prélèvement de la file guidée vient d'être posé. */
    onSamplePlaced?: (e: {
        criSampleId: string;
        label: string;
        position: {
            x: number;
            y: number;
        };
    }) => void;
    readonly isPolylineDrawing: import("@angular/core").Signal<boolean>;
    readonly currentMode: import("@angular/core").Signal<EditorMode>;
    /**
     * Réglages de visée déduits du type de pointeur, relus à chaque `init()`.
     *
     * Relire à l'init et pas une fois pour toutes : un même onglet peut passer du
     * pointeur fin au grossier (tablette détachable, écran tactile branché) et
     * l'éditeur est réinstancié à chaque ouverture. Le coût est une requête
     * `matchMedia` par ouverture.
     */
    private precision;
    /** Précision de visée en vigueur — lue par l'éditeur pour ses propres cibles. */
    pointerPrecision(): PointerPrecision;
    /**
     * Élargit la zone de visée d'un objet fin (mur, réseau, ouverture, cote).
     *
     * `padding` est un réglage d'INTERACTION : Fabric l'ajoute à la zone de
     * sélection (`_pointIsInObjectSelectionArea`, divisé par le zoom donc constant
     * à l'écran) et ne le sérialise pas. Rien n'entre dans le document.
     *
     * Branché sur `object:added`, seul point par où passent à la fois la création
     * à la souris et le peuplement par `loadFromJSON` — un seul écrivain, et pas
     * de passe de rattrapage à oublier après chaque chargement.
     */
    private applyHitPadding;
    init(canvas: any): void;
    setMode(mode: EditorMode): void;
    /**
     * En mode sélection : tous les objets sont sélectionnables/évènementiels.
     * Dans les autres modes : seuls les WallNodes restent évènementiels (drag de nœud possible),
     * le reste est verrouillé pour ne pas interférer avec le dessin.
     * En lecture seule : aucun objet n'est sélectionnable — masque le cadre de
     * sélection et les poignées qui laissaient croire à une modification possible.
     */
    private applyModeSelectability;
    private _readOnly;
    /** Active/désactive le mode lecture seule au niveau du service Fabric.
     *  À jour dès l'appel — re-applique la sélectabilité de tous les objets. */
    setReadOnly(ro: boolean): void;
    isReadOnly(): boolean;
    /**
     * Resynchronise le graphe de nœuds partagés sur le canvas.
     *
     * Le graphe est reconstruit depuis la **géométrie** — il ne lit aucun champ du
     * document, et n'en écrit aucun : un plan enregistré avant ou après le lot 2
     * est strictement le même fichier. Les pièces portant un `roomId` sont liées
     * au passage, ce qui leur permet de suivre les murs sans redétection.
     */
    private syncWallGraph;
    /**
     * Recrée les poignées de nœuds sur les extrémités de murs/cloisons.
     * Appelé après chaque ajout/modification de mur.
     *
     * **Depuis la 2.10.0, ces poignées sont la représentation visible du graphe** :
     * chaque cercle porte l'identifiant du nœud qu'il montre (`_nodeId`), et c'est
     * cet identifiant — pas une tolérance de distance relue à chaque frame — qui
     * décide des murs entraînés quand on le tire. Le regroupement des extrémités
     * en nœuds se fait donc une seule fois, dans le module pur, au lieu d'être
     * refait ici à 5 px puis ailleurs à 8, 10 et 20 px.
     */
    refreshNodeHandles(): void;
    private onNodeMoving;
    /**
     * Reporte sur les pièces validées le déplacement de leurs nœuds.
     *
     * C'est le second volet du lot 2 : une pièce **matérialisée** n'est plus
     * redétectée à chaque frappe, elle se relit du graphe. L'ancien mécanisme —
     * `findMinimalCycles`, puis restauration des métadonnées par proximité de
     * centroïde à 25 px — perdait le nom, le lien CRI et les notes d'une pièce dès
     * qu'un mur bougeait assez pour déplacer son centre de plus de 25 px.
     *
     * L'**aire** n'est volontairement pas recalculée ici : elle demande
     * `pixelsPerMeter`, que ce service ne connaît pas, et elle est de toute façon
     * rétablie au relâchement par `recalculateRooms`. Mieux vaut une aire d'une
     * frame de retard qu'une échelle devinée.
     */
    private updateBoundRooms;
    /**
     * Repose les poignées de sommet des tracés de réseau.
     *
     * Elles n'existent QUE dans l'outil « Nœuds », à la différence des nœuds de
     * murs qui restent affichés en permanence : un plan VRD compte facilement
     * cent sommets, et les montrer tout le temps masquerait le tracé qu'elles
     * servent justement à corriger.
     *
     * Le type 'PipeNode' est absent de `FABRIC_SAVED_TYPES` : ces poignées ne
     * sont jamais enregistrées, elles se recalculent depuis la géométrie.
     */
    refreshPipeNodes(): void;
    /** Déplacement d'un sommet de réseau : on réécrit la géométrie du tracé
     *  entier, le sommet visé prenant la position de la poignée. */
    private onPipeNodeMoving;
    /**
     * Réécrit les sommets d'un tracé de réseau, en coordonnées absolues.
     *
     * Deux formats coexistent et sont tous deux modifiables :
     *  - polyligne (2.1+) : Fabric recalcule lui-même boîte et `pathOffset` via
     *    `setBoundingBox(true)`, seule façon fiable de rester cohérent avec le
     *    rendu après une modification de `points` ;
     *  - ligne à deux points (plans antérieurs) : mise à jour directe des
     *    extrémités, comme le fait `onNodeMoving` pour les murs. On ne la
     *    convertit PAS en polyligne — réécrire un plan existant à la volée, hors
     *    de toute action explicite de l'utilisateur, n'est pas souhaitable.
     */
    private setPipePoints;
    /**
     * Enregistre les positions initiales et les connexions d'un mur/cloison
     * AVANT tout déplacement (appelé depuis mouse:down pour avoir les bonnes coords).
     *
     * Deux types de connexions détectées :
     *  - endpoint-to-endpoint : extrémité d'un autre mur coïncide avec P1 ou P2
     *  - endpoint-to-body : extrémité d'une cloison posée sur le CORPS du mur (milieu)
     */
    private initWallMoveState;
    /**
     * Déplacement d'un mur/cloison en temps réel avec maintien des connexions.
     * L'état (_moveInit) doit être initialisé dans mouse:down pour des positions correctes.
     */
    private onWallMoving;
    /**
     * Molette (et pincement du pavé tactile) : zoom **centré sur le curseur**.
     *
     * Centrer sur le curseur plutôt que sur le canvas est ce qui rend le zoom
     * utilisable sans repanoter après chaque cran : le point qu'on regarde reste
     * sous le doigt.
     *
     * Le point d'ancrage est calculé depuis `getBoundingClientRect()`, comme
     * `getCanvasPointer`, et non par les utilitaires de Fabric — pour la même
     * raison qu'ailleurs dans ce service : ils se trompent dans un conteneur
     * défilable.
     */
    private onWheel;
    /** Applique un zoom en gardant fixe un point donné en coordonnées écran. */
    private zoomAtScreenPoint;
    /**
     * Milieu de la zone RÉELLEMENT visible, en coordonnées écran du canvas.
     *
     * Le canvas mesure 1600 × 1200 par défaut — une entrée de l'hôte, sans rapport
     * avec la place disponible. `.ngf-editor__canvas-area` le centre tant qu'il
     * tient (`justify-content: safe center`) et l'aligne au début dès qu'il
     * déborde : la fenêtre visible est donc [0, min(vue, canvas)] sur chaque axe,
     * et son milieu n'est le milieu du canvas que sur écran large.
     *
     * Sans `vue`, on retombe sur le milieu du canvas : c'est le comportement
     * historique, valable partout où le canvas tient dans la fenêtre.
     */
    private centreVue;
    /**
     * Zoom d'un cran, centré sur le milieu de la vue.
     *
     * Le milieu était celui du canvas, pas celui de la vue : sur une tablette
     * (960 px visibles pour un canvas de 1600), le point fixe du zoom tombait hors
     * écran et le dessin fuyait à chaque appui sur « + ».
     */
    zoomBy(facteur: number, vue?: {
        width: number;
        height: number;
    }): void;
    /** Revient à 100 % sans toucher au déplacement de la vue. */
    resetZoom(vue?: {
        width: number;
        height: number;
    }): void;
    /**
     * Cadre le dessin dans la vue.
     *
     * C'est la porte de sortie quand le plan a fui hors champ — après une
     * calibration malheureuse, un import, ou un pan trop généreux. Sans elle, un
     * plan devenu minuscule ou lointain n'est plus récupérable autrement qu'en
     * rechargeant, ce qui perd le travail en cours.
     */
    /**
     * Cadrage automatique — respecte le réglage de vue de l'utilisateur.
     *
     * À appeler depuis les chemins qui ne sont PAS une demande explicite : pose
     * d'un fond, arrivée d'une capture. Sans cette distinction, une capture
     * satellite arrivant en cours de tracé recadrait tout et faisait manquer le
     * point suivant.
     */
    zoomToFitAuto(margePx?: number, vue?: {
        width: number;
        height: number;
    }): void;
    /** Oublie le réglage de vue — à l'ouverture d'un document, la vue repart neuve. */
    resetViewState(): void;
    zoomToFit(margePx?: number, vue?: {
        width: number;
        height: number;
    }): void;
    /**
     * Calcule les coordonnées canvas à partir d'un MouseEvent en utilisant
     * getBoundingClientRect() directement, évitant le bug de scroll traversal
     * de canvas.getScenePoint() (ex-getPointer en v5) dans les conteneurs scrollables.
     */
    /** Coordonnées écran d'un événement souris OU tactile (les TouchEvent
     *  n'exposent pas clientX/Y à la racine). */
    private eventClient;
    private getCanvasPointer;
    /**
     * Pas de grille effectif — élargi de moitié sur tactile pour viser plus
     * facilement au doigt.
     *
     * Le pas venait d'un littéral 20 : `config.defaultGridSize` existait mais
     * n'était lu nulle part, si bien qu'un hôte ne pouvait pas affiner le
     * magnétisme. C'est le pas de grille qui plafonne la précision d'un plan
     * dessiné sur fond de carte — 20 px valent 1 à 3 m au sol selon le zoom et le
     * dpr de la capture. Le défaut reste 20 (30 en tactile) : le comportement est
     * inchangé, l'hôte a désormais le levier, et l'export GeoJSON annonce le pas
     * réellement appliqué.
     */
    private get effectiveGrid();
    private snapToGrid;
    /**
     * Rassemble ce que le canvas sait offrir au magnétisme de croquis.
     *
     * Les nœuds ne viennent **pas** que des poignées `WallNode` : celles-ci sont
     * recréées au fil du tracé et absentes dans d'autres modes, si bien qu'un
     * magnétisme qui n'aurait qu'elles pour référence serait intermittent sans
     * raison visible. On lit donc directement les extrémités des murs, et les
     * poignées ne font que s'y ajouter.
     */
    private contexteAccroche;
    /**
     * Point retenu pour un appui ou un survol en tracé de mur/cloison.
     *
     * La décision elle-même est dans `accrocherCroquis` (pure, testée sans
     * navigateur) ; il ne reste ici que la lecture du canvas et la mémorisation du
     * type d'accroche, qui sert à colorer l'aperçu.
     */
    private snapPolylinePoint;
    /**
     * Point retenu pour un tracé de croquis, fermeture comprise.
     *
     * Un point de **fermeture** est traité à part, et c'est le cœur du sujet :
     * l'accroche au nœud de départ aurait raison de lui bien avant (20 px contre
     * 25), le poserait exactement sur le premier sommet — et il n'y aurait plus
     * d'écart à répartir. Le dernier segment garderait alors l'angle de travers
     * qu'il avait, celui-là même qu'on cherche à corriger. On ne retient donc que
     * la contrainte angulaire, et on laisse Bowditch fermer la boucle.
     *
     * Utilisée à l'identique par l'appui et par l'aperçu : deux calculs distincts
     * finiraient par diverger, et le trait ne tomberait pas où l'aperçu l'annonce.
     */
    private pointCroquis;
    private clearPreviewHints;
    /** Vrai si revenir ici clôturerait la boucle du tracé en cours. */
    private peutFermer;
    /**
     * Rayon de fermeture, en unités de scène, avec un **plancher à l'écran**.
     *
     * 50 cm est la bonne mesure dans le monde réel, mais elle se traduit à l'écran
     * par un rayon qui rétrécit avec le zoom : à 40 %, refermer une boucle
     * demanderait de viser à moins d'un pixel. Le geste devient impossible alors
     * que rien, dans le plan, n'a changé.
     *
     * On garde donc le plus grand des deux : la mesure métier, et
     * `FERMETURE_MIN_ECRAN_PX` ramenés en unités de scène. Zoomer davantage ne rend
     * pas la fermeture plus permissive dans le monde réel — le maximum joue dans
     * l'autre sens.
     */
    private rayonFermetureEffectif;
    /**
     * Cote vivante et repère de fermeture pendant le tracé.
     *
     * Sans ce retour, le magnétisme angulaire est invisible : le trait paraît
     * simplement suivre le doigt, et rien ne dit à l'utilisateur qu'il vient
     * d'obtenir un angle droit exact plutôt qu'un 89° convaincant.
     */
    private drawPreviewHints;
    private onMouseDown;
    private onMouseMove;
    private onMouseUp;
    private handlePolylineClick;
    /**
     * Ferme le tracé courant en répartissant l'écart de fermeture (Bowditch).
     *
     * Le cheminement est relu **depuis les objets Fabric** plutôt que depuis un
     * tableau tenu en parallèle : c'est le canvas qui fait foi, et les extrémités
     * ont pu bouger entre-temps (accrochage sur un mur existant, fusion de nœuds).
     */
    private fermerBoucle;
    /**
     * Impose à un mur la longueur relevée au télémètre, et fait suivre le croquis.
     *
     * C'est le pont de la brique A (`FEATURE-releve-piece-sans-plan.md § 4.1`) :
     * toute la décision — qui bouge, de combien — est prise par
     * `solveWallDimensions`, module **pur** et testé sans navigateur. Ici on ne
     * fait que trois choses, et rien d'autre :
     *  1. relire la chaîne de murs depuis le graphe (lot 2) ;
     *  2. lui passer les cotes déjà posées sur les murs voisins (`lockedLengthM`),
     *     pour qu'une cote saisie hier soit tenue en même temps que celle de
     *     maintenant ;
     *  3. réécrire les extrémités que le graphe désigne — par `setWallEnds`, le
     *     seul écrivain, qui pose `left`/`top` dans le **même** `set()` que
     *     `x1..y2` (sans quoi Fabric les recalcule et le mur glisse d'un
     *     demi-trait à chaque passage : dette connue de `snapLineEndpoints`).
     *
     * La cote est mémorisée dans `data.lockedLengthM`, le champ que la calibration
     * utilise déjà — un mur n'a qu'une longueur imposée, et deux champs pour la
     * même chose finiraient par se contredire. Elle est donc persistée et
     * réaffichée par l'étiquette « ⊛ x.xx m ».
     *
     * Rend la solution — écart de fermeture, écart résiduel par mur — pour que
     * l'appelant l'**affiche**. C'est une donnée, pas un échec : sur un relevé
     * surdéterminé, il y a toujours un résidu, et le masquer serait exactement la
     * panne muette qu'on cherche à éviter. Rend `null` si rien n'a pu être fait.
     */
    applyWallDimension(wall: any, lengthM: number, pixelsPerMeter: number): DimensionSolution | null;
    /** Repose les extrémités d'un mur et remet à jour ses caches et ouvertures. */
    private setWallEnds;
    /**
     * Crée un mur porteur (fabric.Line) avec un wallId unique pour le cascade delete.
     * Utilise des coords relatives au centre pour être compatible avec calcLinePoints().
     */
    private createWallLine;
    /**
     * Crée une cloison (non porteur) — trait plus fin et tirets.
     */
    private createCloisonLine;
    /**
     * Crée la polyligne d'un tracé de réseau.
     *
     * `hasControls: false` est délibéré : un réseau se remodèle sommet par sommet
     * (outil « Nœuds »), jamais à la poignée. Une mise à l'échelle ou une rotation
     * fausserait silencieusement les linéaires — `scaleX`/`angle` n'entrent dans
     * aucun des calculs de longueur, ni ici ni dans `PlanAnalysisService`.
     *
     * `perPixelTargetFind` évite l'autre travers de la polyligne : sa boîte
     * englobante peut couvrir un quart du plan alors que le trait, lui, est fin.
     * Sans cela, cliquer « à côté » du réseau le sélectionnerait quand même.
     */
    private createPipePolyline;
    /** Reporte `activePipePoints` sur la polyligne du tracé courant (créée au
     *  deuxième sommet, étendue ensuite). */
    private extendActivePipe;
    /**
     * Rend tous les dessins existants inertes le temps d'un tracé.
     *
     * Sans cela, un appui qui retombe sur un objet déjà dessiné est capté par
     * Fabric : cadre de sélection, poignées de redimensionnement, et tracé perdu.
     * C'est surtout visible au doigt, où la zone de contact est bien plus large
     * qu'un curseur. La restauration repasse par `applyModeSelectability`, qui
     * seul connaît les règles par mode (croquis, réseau, lecture seule…).
     */
    private setObjectsInertDuringTrace;
    finishPolyline(): void;
    /** Double-clic : termine le tracé en cours. Pour les murs, le 2ᵉ clic du
     *  double-clic a pu créer un segment quasi nul (le curseur n'a pas bougé) —
     *  on le retire avant de clôturer pour ne pas laisser de point parasite. Un
     *  réseau n'en souffre pas : le sommet en doublon est écarté en amont par le
     *  seuil `SEGMENT_MIN_PX`. */
    private onDoubleClick;
    /** Longueur (px) d'un segment fabric.Line, indépendante du recentrage. */
    private lineLength;
    /** Vrai si le mode courant est un tracé de réseau (canalisation). */
    private isPipeMode;
    /** Vrai si l'objet peut être déplacé au clic pendant un tracé réseau. */
    private isUserMovable;
    /** Renvoie un objet réseau au fond, juste au-dessus du fond de carte et des
     *  étages fantômes (qui doivent rester tout en bas). */
    private sendNetworkToBack;
    /** Reclasse tous les traits de réseau sous les autres dessins (appelé au
     *  chargement d'un projet pour garantir l'ordre même sur les plans anciens). */
    private restackNetworksBelow;
    /**
     * Construit une forme d'annotation entre deux points de glisser.
     *
     * Sert à la fois à l'aperçu (pendant le glisser) et à l'objet définitif : une
     * seule géométrie pour les deux, sans quoi la forme obtenue au relâché finit
     * par différer de celle qu'on voyait — l'écart typique de ce genre de code.
     * L'aperçu s'en distingue par le pointillé et l'absence de `myType` : il ne
     * doit être ni sélectionnable, ni sérialisé, ni compté nulle part.
     *
     * Renvoie `null` si le geste est trop court pour valoir une forme.
     */
    private createAnnotation;
    private createStairObject;
    private createHazardZone;
    private createRoomBox;
    /**
     * Snap d'un point sur les bords (X et Y) des RoomBox existantes.
     * Utilise la grille (20px) comme fallback si aucune boîte n'est assez proche.
     */
    private snapForRoomSketch;
    /**
     * Génère l'enveloppe de l'appartement à partir des RoomBox présentes sur le canvas.
     * - Les segments partagés par ≥ 2 pièces → Cloison
     * - Les segments extérieurs (1 seule pièce) → Mur porteur
     * Supprime ensuite tous les RoomBox.
     */
    generateEnvelope(): void;
    /**
     * Mur ou cloison sous un point, à la tolérance du doigt.
     *
     * Fabric ne retient un objet que si le clic tombe sur son trait — cinq pixels
     * de large, trois pour une cloison. Au doigt, sur tablette, viser cela relève
     * du hasard : d'où cette recherche par distance, en repli de `o.target`.
     */
    wallAt(pt: Point, tolerance?: number): any | null;
    /**
     * Bascule un mur porteur en cloison ou vice-versa.
     */
    toggleWallType(obj: any): void;
    private handleDoorWindow;
    private handleClickEquipment;
    private handleNorthArrow;
    private handleClickSymbol;
    private handleClickSpancPictogram;
    private handleClickAcPictogram;
    private handleClickPrelevement;
    /** Distance from point p to segment (a, b) */
    private ptSegDist;
    /**
     * Contraint une porte/fenêtre à glisser sur son mur parent pendant le drag.
     * Si le mur n'est pas trouvé, on laisse libre.
     */
    private constrainOpeningToWall;
    /**
     * Remet toutes les portes/fenêtres d'un mur sur sa nouvelle géométrie
     * (appelé pendant le drag d'un nœud).
     */
    private updateOpeningsOnWall;
    /** Projette le centre d'une ouverture sur le segment [p1,p2] et met à jour angle. */
    private projectOpeningOntoWall;
    /**
     * Après déplacement d'un mur, recolle ses extrémités aux extrémités voisines
     * des autres murs (tolérance 20px) et aligne sur la grille sinon.
     * Retourne true si un snap a eu lieu.
     */
    private snapLineEndpoints;
    private findNearestWallSnap;
    /** Calcul robuste sans passer par getCenterPoint() ni calcLinePoints().
     *  Délègue à l'extracteur commun (`plan-geometry.const.ts`) — c'était la
     *  troisième copie de la même formule. */
    private getAbsoluteLineEnds;
    cascadeDeleteOpenings(deletedWallIds: string[]): void;
    /** Affiche les objets d'un étage précédent en très atténué (8% opacité). */
    showGhostFloor(rawObjects: any[]): void;
    /** Supprime tous les objets fantôme du canvas. */
    clearGhostFloor(): void;
    /**
     * Copie les murs extérieurs (Mur) d'un étage sur le canvas courant.
     * Utilisé pour repartir des murs de l'étage inférieur sur un nouvel étage.
     */
    copyObjectsFromFloor(rawObjects: any[]): void;
    loadFromProject(project: FloorplanProject): Promise<void>;
    destroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FabricCanvasService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FabricCanvasService>;
}
