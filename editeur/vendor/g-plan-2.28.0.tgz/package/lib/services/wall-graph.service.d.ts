import { Point } from '../models/geometry.types';
import { PlanGraph, PlanNode } from '../constants/plan-graph.const';
import * as i0 from "@angular/core";
/** Extrémités à réécrire sur un mur. Le service **ne touche pas** à Fabric : il
 *  dit ce qu'il faut poser, `FabricCanvasService.setWallEnds` le pose. */
export interface WallEndsUpdate {
    readonly wall: any;
    readonly x1: number;
    readonly y1: number;
    readonly x2: number;
    readonly y2: number;
}
/** Pièce validée telle que le pont la relève sur le canvas. `key` est
 *  l'identifiant métier stable de la pièce (`data.roomId`). */
export interface RoomBinding {
    readonly key: string;
    readonly points: readonly Point[];
}
/**
 * Suite de murs enchaînés bout à bout, telle que la cotation la consomme.
 *
 * `walls[i]` relie `points[i]` à `points[i + 1]`. Fermée, la chaîne a autant de
 * murs que de sommets ; ouverte, un sommet de plus — la convention de
 * `solveWallDimensions`, à qui ces champs sont passés tels quels.
 */
export interface WallChain {
    readonly walls: readonly any[];
    readonly nodeIds: readonly string[];
    readonly points: readonly Point[];
    readonly closed: boolean;
}
/** Nouvelle géométrie d'une pièce validée après déplacement des murs. */
export interface RoomUpdate {
    readonly key: string;
    readonly points: readonly Point[];
    readonly centroid: Point;
}
/**
 * Pont entre le graphe de nœuds partagés et les objets Fabric — lot 2.
 *
 * **Ce qu'il apporte.** Jusqu'ici, deux murs qui se rejoignent à un angle ne le
 * savaient pas : chacun portait sa propre copie du point, et tout code ayant
 * besoin de la topologie la refabriquait par tolérance de distance. Déplacer
 * l'angle n'entraînait donc pas les deux murs — il fallait les rattraper un par
 * un. Ici l'angle est un **nœud**, les murs le **désignent**, et le déplacer les
 * déplace tous les deux par construction.
 *
 * **Le partage des rôles, qui est tout l'intérêt du découpage :**
 *  - `plan-graph.const.ts` tient la topologie — fonctions pures, aucune
 *    dépendance à Fabric, testables sans navigateur ;
 *  - ce service tient l'**identité** (quel objet Fabric est quelle arête) et
 *    **lit** la géométrie du canvas ;
 *  - `FabricCanvasService` est le **seul** à écrire dans Fabric.
 *
 * Deux états qui divergent est le risque principal du chantier : il ne peut
 * diverger que là où il est écrit, et il n'est écrit qu'à un endroit.
 *
 * **Rien n'est ajouté au document.** L'identité des arêtes vit dans une
 * `WeakMap` indexée par l'objet Fabric — comme celle de l'historique depuis la
 * 2.8.0. Un plan enregistré est strictement le même fichier qu'avant ce lot, et
 * le graphe se reconstruit de la géométrie au chargement. Pas de champ nouveau,
 * pas de majeure, pas de migration côté hôte.
 */
export declare class WallGraphService {
    /** Pour le centroïde des pièces : **la même** fonction que celle qui écrit
     *  `_cx`/`_cy` dans `recalculateRooms`, sinon la pièce déplacée ne serait plus
     *  reconnue par la restauration des métadonnées de l'éditeur. */
    private readonly geometry;
    private graph;
    /**
     * Identité des arêtes, tenue **en mémoire**.
     *
     * Indexée par l'objet Fabric et non par `data.wallId` : un mur importé,
     * dupliqué ou issu d'un plan ancien peut n'avoir aucun `wallId`, et deux murs
     * copiés d'un étage à l'autre partagent le leur. La `WeakMap` ne ment jamais
     * sur l'identité, et libère l'entrée quand l'objet disparaît.
     */
    private readonly edgeIdByWall;
    /** Sens inverse, reconstruit à chaque `sync` : seuls les murs **présents sur
     *  le canvas** y figurent, donc on n'écrit jamais dans un objet supprimé. */
    private wallByEdgeId;
    private edgeCounter;
    /** Pièces validées : identifiant métier → boucle du graphe. */
    private loopByRoom;
    /**
     * Relit la géométrie des murs et remet le graphe en phase, **en conservant les
     * identités** des nœuds encore reconnaissables.
     *
     * Appelée depuis `refreshNodeHandles`, qui est déjà le point de passage obligé
     * après tout changement de mur (tracé, déplacement, suppression, annulation,
     * chargement de projet). Un seul point d'entrée, donc pas de chemin par lequel
     * le graphe pourrait rester en retard sur le canvas.
     */
    sync(walls: readonly any[], rooms?: readonly RoomBinding[]): void;
    /** Lecture seule du graphe — diagnostic et tests. */
    snapshot(): PlanGraph;
    /** Vide tout (changement d'étage, nouveau projet). */
    reset(): void;
    /** Tous les nœuds, pour poser les poignées. */
    nodes(): PlanNode[];
    /** Nombre d'extrémités de murs arrivant sur ce nœud (2 = angle simple,
     *  3 et plus = jonction). */
    degree(nodeId: string): number;
    nodeIdAt(pt: Point, tolerance?: number): string | null;
    /** Murs qui partagent ce nœud. */
    wallsAtNode(nodeId: string): any[];
    /**
     * Déplace un angle. Rend les extrémités à réécrire pour **tous** les murs qui
     * s'y rejoignent — c'est le critère d'acceptation du lot, et il tient en une
     * ligne parce que le nœud est partagé au lieu d'être recopié.
     */
    moveNode(nodeId: string, pt: Point): WallEndsUpdate[];
    /**
     * Reporte le glissement d'un mur entier sur ses deux nœuds : les murs voisins
     * suivent leurs extrémités.
     *
     * Le mur déplacé est **exclu** du résultat : pendant un glisser, Fabric tient
     * déjà sa position, et la lui réécrire la ferait sauter d'une frame à l'autre.
     */
    moveWall(wall: any, p1: Point, p2: Point): WallEndsUpdate[];
    /**
     * Fusionne deux angles en un seul (l'utilisateur a lâché un nœud sur un
     * autre). Les murs des deux côtés se rattachent au nœud conservé.
     */
    mergeNodes(keepId: string, dropId: string): WallEndsUpdate[];
    /**
     * Chaîne de murs à laquelle appartient `wall` : le contour de la pièce s'il
     * est fermé, sinon le tronçon délimité par les jonctions.
     *
     * C'est ce que la cotation a besoin de connaître, et c'est le graphe qui le
     * sait — pas une nouvelle reconstruction par tolérance de distance. Rend
     * `null` si le mur n'est pas dans le graphe (jamais synchronisé, ou géométrie
     * inexploitable) ou si l'un des murs de la chaîne a disparu du canvas.
     */
    chainAt(wall: any): WallChain | null;
    /**
     * Repose les nœuds d'un cheminement coté et rend les extrémités à réécrire.
     *
     * Les murs **voisins** de la chaîne sont inclus dans le résultat : une cloison
     * qui bute sur un mur allongé doit suivre son point d'attache, sinon la
     * cotation décolle le croquis là où on ne regardait pas.
     */
    applyChain(nodeIds: readonly string[], points: readonly Point[]): WallEndsUpdate[];
    private updatesFor;
    private edgeIdOf;
    /**
     * Lie chaque pièce à une **boucle de nœuds**. C'est ce qui la fait survivre au
     * déplacement d'un mur : ses sommets ne sont plus des coordonnées figées mais
     * des références, et le contour se relit du graphe sans repasser par la
     * détection de cycles.
     *
     * La liaison est refaite à chaque `sync` plutôt que conservée : l'éditeur
     * détruit et recrée les `DetectedRoom` à chaque recalcul, et une boucle gardée
     * en l'état finirait par désigner une pièce qui n'existe plus.
     *
     * **Limite assumée** : une pièce dont un sommet n'est pas une extrémité de mur
     * — le cas d'un raccord en T, où `findMinimalCycles` place un sommet au milieu
     * du mur traversé — n'est pas liée du tout. La lier à moitié la ferait dériver
     * au premier déplacement, ce qui est pire que ne pas la suivre : elle reste
     * alors gérée comme avant, par recalcul au relâchement.
     */
    private bindRooms;
    /** Pièces validées dont le contour a bougé avec les murs. */
    roomUpdates(): RoomUpdate[];
    /** Contour courant d'une pièce validée, ou `null` si elle n'est pas liée. */
    roomPoints(key: string): Point[] | null;
    /** Identifiants des pièces effectivement liées au graphe. */
    boundRooms(): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<WallGraphService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WallGraphService>;
}
