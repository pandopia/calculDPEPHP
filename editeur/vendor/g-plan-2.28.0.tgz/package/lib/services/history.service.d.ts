import * as i0 from "@angular/core";
/**
 * Historique d'édition — **commandes réversibles**, plus instantanés.
 *
 * Jusqu'à la 2.7.0 ce service empilait des sérialisations JSON complètes du
 * plan (`private history: string[]`). Un projet avec fond de carte pèse ~465 Ko :
 * cinquante entrées faisaient donc des dizaines de mégaoctets, et c'est la même
 * recopie intégrale qui saturait le quota `localStorage` de l'autosave, cassant
 * la restauration du brouillon. Une commande ne décrit que ce qui change.
 *
 * **Cohabitation assumée** : Fabric reste la source de vérité du *rendu*, et le
 * document sérialisé reste le contrat public lu par l'application hôte. Ce
 * service n'introduit pas un second modèle — il enregistre les mutations que
 * Fabric annonce, et sait les rejouer à l'envers. Le pont vers le canvas est
 * **entièrement contenu ici** : deux états qui divergent serait le pire des
 * résultats, et il ne peut diverger que là où il est écrit.
 *
 * L'identité des objets vit en mémoire (`WeakMap`), pas dans le document : rien
 * n'est ajouté au format sérialisé, donc aucune rupture pour les hôtes.
 */
export declare class HistoryService {
    private canvas;
    /** Pile de commandes et position courante (-1 = rien à annuler). */
    private pile;
    private index;
    /** Vrai pendant l'application d'une commande : les événements Fabric qu'elle
     *  déclenche ne doivent pas être ré-enregistrés. */
    private enRejeu;
    /** Groupe en cours de constitution (entre `pauseSaving` et `resumeSaving`). */
    private groupe;
    private readonly idParObjet;
    private readonly objetParId;
    private readonly etatConnu;
    /** Dernier rang d'affichage connu. `object:removed` étant émis **après** le
     *  retrait, `indexOf` y renvoie -1 : sans ce suivi, un objet rétabli
     *  remonterait au sommet de la pile d'affichage. */
    private readonly zConnu;
    private compteurId;
    private readonly _index;
    private readonly _taille;
    readonly canUndo: import("@angular/core").Signal<boolean>;
    readonly canRedo: import("@angular/core").Signal<boolean>;
    constructor();
    init(canvas: any): void;
    /**
     * Ouvre un **regroupement** : tout ce qui suit jusqu'à `resumeSaving()` sera
     * annulé d'un seul geste.
     *
     * Le nom vient de l'ancienne implémentation, où il s'agissait de suspendre les
     * instantanés. Le besoin réel des appelants était déjà celui-ci : générer
     * l'enveloppe d'un croquis produit une vingtaine de murs, et personne ne veut
     * les annuler un par un.
     */
    pauseSaving(): void;
    /** Referme le regroupement et l'empile comme une seule commande. */
    resumeSaving(): void;
    /**
     * Enregistre les modifications que **Fabric n'annonce pas**.
     *
     * `object:modified` n'est émis que pour les manipulations à la souris : une
     * mutation programmatique (`obj.set({...})` depuis l'inspecteur, normalisation
     * de coordonnées, application d'un modèle) passe sous le radar. Les appelants
     * historiques compensaient déjà par un `save()` explicite ; la méthode garde
     * ce rôle, en comparant chaque objet à son dernier état connu.
     */
    save(): void;
    undo(): Promise<void>;
    redo(): Promise<void>;
    /** Poids total de l'historique, en octets. Exposé pour être **mesuré** :
     *  c'est le critère d'acceptation de ce chantier, pas une intuition. */
    poidsHistorique(): number;
    private surAjout;
    private surSuppression;
    private surModification;
    private recevable;
    private enregistrerObjet;
    /** Sérialisation d'un objet, propriétés métier comprises (cf.
     *  `registerFabricCustomProperties`). */
    private serialiser;
    private enregistrer;
    private empiler;
    private publier;
    private appliquer;
    private appliquerUne;
    static ɵfac: i0.ɵɵFactoryDeclaration<HistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HistoryService>;
}
