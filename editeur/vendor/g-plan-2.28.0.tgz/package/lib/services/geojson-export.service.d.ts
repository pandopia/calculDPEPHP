import { FloorplanProject } from '../models/project.model';
import { FloorplanObjectType } from '../models/floorplan-object.model';
import * as i0 from "@angular/core";
/**
 * Avertissement légal accompagnant **tout** GeoJSON produit par g-plan.
 *
 * Même statut que `SURFACE_DISCLAIMER` pour les surfaces : il n'est pas
 * optionnel. Un GeoJSON de réseaux enterrés a l'apparence d'un plan de
 * récolement — coordonnées, précision affichée à sept décimales, superposition
 * exacte sur une carte — alors qu'il rapporte l'estimation d'un opérateur sur
 * un fond de carte lui-même faux de plusieurs mètres. Sans ce texte, l'écart
 * sera imputé à g-plan, et pire, quelqu'un creusera en s'y fiant.
 */
export declare const GEOREF_DISCLAIMER: string;
/**
 * Note de mesure — à lire avant de calculer une longueur ou une surface sur ce
 * GeoJSON. Les valeurs affichées par g-plan sont des mètres **sol** ; mesurer
 * les géométries directement en Web Mercator gonfle les surfaces de 1/cos²φ.
 */
export declare const GEOREF_MESURE_NOTE: string;
/** Couple `[longitude, latitude]` — ordre RFC 7946, jamais l'inverse. */
export type GeoJsonPosition = [number, number];
export interface GeoJsonPointGeometry {
    type: 'Point';
    coordinates: GeoJsonPosition;
}
export interface GeoJsonLineStringGeometry {
    type: 'LineString';
    coordinates: GeoJsonPosition[];
}
/** Polygone sans trou : un seul anneau, fermé et orienté main droite. */
export interface GeoJsonPolygonGeometry {
    type: 'Polygon';
    coordinates: GeoJsonPosition[][];
}
export type GeoJsonGeometry = GeoJsonPointGeometry | GeoJsonLineStringGeometry | GeoJsonPolygonGeometry;
/** Nature géométrique retenue pour un `myType`. `null` = objet exclu de l'export. */
export type GeoJsonGeometryKind = 'Point' | 'LineString' | 'Polygon';
export interface GeoJsonFeature {
    type: 'Feature';
    /** Identifiant métier stable quand l'objet en porte un (`wallId`, `roomId`…). */
    id?: string;
    geometry: GeoJsonGeometry;
    properties: Record<string, unknown>;
}
/** Ancre effectivement utilisée pour projeter le plan, reportée telle quelle. */
export interface GeoJsonAncre {
    lat: number;
    lng: number;
    /** Zoom **effectif** de la capture (`maxZoom: 19` écrête le zoom demandé). */
    zoom: number;
    /** Ratio pixels image / pixels CSS mesuré à la capture. */
    dpr: number;
    /** Rotation du fond de carte sur la scène, en degrés (0 attendu). */
    angle: number;
    /** Couche capturée, si elle a été persistée. */
    couche?: string;
    /** Horodatage ISO 8601 de la capture, s'il a été persisté. */
    capturedAt?: string;
    /** Niveau porteur du fond de carte. */
    floorId?: string;
    /** Porteur qui a fait foi : `project.geo` ou le `data` du fond. */
    source: 'project' | 'backdrop';
}
/** Précision **annoncée** — mesurée sur l'ancre, jamais corrigée. */
export interface GeoJsonPrecision {
    /** Mètres sol par pixel de scène (résolution du repère de dessin). */
    metresParPixel: number;
    /** Pas du magnétisme de grille, en pixels (`config.defaultGridSize`). */
    pasGrillePx: number;
    /** Quantification du tracé au sol, en mètres — la vraie limite de finesse. */
    pasGrilleM: number;
    /** Fourchette de précision absolue annoncée, en mètres. */
    absolueM: [number, number];
    /** Ordre de grandeur de la précision relative, en mètres. */
    relativeM: number;
    /** Biais systématique des extrémités de murs (demi-trait assumé), en mètres. */
    biaisDemiTraitM: number;
    /** Facteur de surestimation des surfaces si elles sont mesurées en EPSG:3857. */
    facteurSurfaceMercator: number;
    /** Phrase à afficher telle quelle à l'utilisateur. */
    resume: string;
    /** Note de mesure (`GEOREF_MESURE_NOTE`). */
    mesure: string;
}
/**
 * `FeatureCollection` RFC 7946, augmentée de trois membres étrangers :
 * `ancre`, `precision` et `avertissement`. Pas de membre `crs` — la RFC impose
 * WGS84 et interdit d'en déclarer un autre.
 */
export interface GeoJsonFeatureCollection {
    type: 'FeatureCollection';
    /** `[ouest, sud, est, nord]`, absente si la collection est vide. */
    bbox?: [number, number, number, number];
    features: GeoJsonFeature[];
    ancre: GeoJsonAncre;
    precision: GeoJsonPrecision;
    avertissement: string;
    genereLe: string;
    gplanVersion: string;
}
export type GeoJsonRefusCode = 'ancre-absente' | 'ancre-retouchee' | 'ancre-divergente' | 'dpr-inconnu' | 'dessins-anterieurs' | 'echelle-anisotrope';
export interface GeoJsonRefus {
    code: GeoJsonRefusCode;
    /** Message en français, destiné à être affiché tel quel : il dit ce qui
     *  cloche **et** ce qu'il faut faire pour y remédier. */
    message: string;
}
/** Erreur levée par `toFeatureCollection` quand le plan n'est pas exportable. */
export declare class GeoJsonExportError extends Error {
    readonly motifs: GeoJsonRefus[];
    constructor(motifs: GeoJsonRefus[]);
}
/**
 * Nature géométrique de chaque type d'objet, ou `null` s'il est **exclu**.
 *
 * Le `Record<FloorplanObjectType, …>` est le garde-fou : ajouter un type à
 * l'union sans le classer ici casse la compilation, plutôt que de le faire
 * disparaître en silence de tous les exports. Le second garde-fou est dans la
 * spec, qui confronte cette table à `FABRIC_SAVED_TYPES`.
 *
 * Sont exclus les objets **dérivés** (étiquettes et cotes régénérées à chaque
 * recalcul : elles répéteraient une information déjà portée par leur objet
 * source) et les objets **non métier** (le fond de carte, qui est l'ancre
 * elle-même ; les annotations, formes de commentaire sans sémantique — un
 * rond rouge « à vérifier » n'a pas de position terrain à revendiquer).
 */
export declare const GEOJSON_GEOMETRY_BY_TYPE: Record<FloorplanObjectType, GeoJsonGeometryKind | null>;
/**
 * Produit un GeoJSON WGS84 (RFC 7946) à partir d'un projet **sérialisé**.
 *
 * L'entrée est un `FloorplanProject` stocké, pas un canvas vivant : l'hôte doit
 * pouvoir exporter un plan qu'il a en base sans jamais ouvrir l'éditeur. Toute
 * la géométrie est donc lue par l'extracteur commun (`plan-geometry.const.ts`)
 * et projetée par `GeoProjectionService`, l'un et l'autre purs.
 *
 * Le service **refuse** plus volontiers qu'il n'exporte : un GeoJSON faux est
 * plus dangereux qu'un export manquant, parce qu'il est indiscernable d'un bon.
 * Voir `motifsDeRefus`.
 */
export declare class GeoJsonExportService {
    private readonly projection;
    private readonly config;
    /**
     * Ce qui empêche l'export, ou liste vide si le plan est exportable.
     *
     * À appeler pour griser un bouton ou expliquer un refus : `toFeatureCollection`
     * lève exactement sur ces motifs.
     */
    motifsDeRefus(project: FloorplanProject | null | undefined): GeoJsonRefus[];
    /** `true` si `toFeatureCollection` produira un résultat plutôt qu'une erreur. */
    peutExporter(project: FloorplanProject | null | undefined): boolean;
    /**
     * Convertit un projet sérialisé en `FeatureCollection` WGS84.
     *
     * @throws {GeoJsonExportError} si le plan n'est pas géoréférençable ou si son
     * ancre est douteuse — les motifs y sont portés en clair (`motifs`).
     */
    toFeatureCollection(project: FloorplanProject | null | undefined): GeoJsonFeatureCollection;
    /** Le même GeoJSON, sérialisé. */
    toJson(project: FloorplanProject | null | undefined, indentation?: number): string;
    /** Déclenche le téléchargement du GeoJSON (extension `.geojson` par convention). */
    downloadGeoJson(project: FloorplanProject | null | undefined, filename?: string): void;
    /**
     * Niveaux à parcourir. `project.objects` porte une **copie** du niveau
     * courant quand `floors` existe (cf. `buildProjectWithFloors`) : le lire en
     * plus dupliquerait toutes ses features. On ne s'y rabat donc que si aucun
     * niveau n'est déclaré, avec le même niveau implicite que l'analyseur.
     */
    private niveaux;
    private feature;
    private geometrie;
    /**
     * Anneau extérieur conforme RFC 7946 : fermé (dernière position identique à
     * la première) et orienté **main droite**, c'est-à-dire dans le sens
     * trigonométrique en (lng, lat).
     *
     * L'orientation est calculée après projection, pas dans le repère scène : la
     * scène a son axe Y vers le bas, un fond pivoté ou une capture dans
     * l'hémisphère sud inverseraient le raisonnement. Une aire signée nulle
     * (contour dégénéré, aplati) fait rejeter l'objet.
     */
    private anneau;
    /** Aire signée (formule des lacets) en degrés² — le signe seul nous intéresse. */
    private aireSignee;
    /**
     * Supprime les positions consécutives devenues identiques après arrondi (deux
     * sommets distants de moins d'un centimètre).
     *
     * `retirerFermeture` n'est demandé que pour les anneaux, qui sont refermés
     * ensuite : sur un tracé linéaire, un dernier point égal au premier est une
     * boucle légitime — un réseau qui revient à son départ — et l'écraser
     * ouvrirait le tracé.
     */
    private deduplique;
    /** Point de scène → position `[lng, lat]` arrondie à 7 décimales. */
    private position;
    /**
     * Propriétés de la feature : le niveau (les étages se superposent sur une
     * carte 2D — sans `floorId`/`floorOrder`, l'hôte ne peut ni filtrer ni
     * empiler), le type d'objet, et les données métier de `data`.
     *
     * Les champs de travail (préfixés `_`, comme les centroïdes de rendu) et les
     * champs d'état d'éditeur (`geo`, `locked`) sont écartés : ils n'ont pas de
     * sens hors de g-plan et l'ancre est déjà portée par la collection.
     */
    private proprietes;
    private identifiant;
    private ancreExportee;
    /**
     * Précision **annoncée**. Rien n'est corrigé ici : on mesure ce que vaut
     * réellement un pixel de dessin sur cette ancre, on rappelle le pas de grille
     * qui quantifie le tracé, et on redit la fourchette honnête (±2 à 5 m en
     * absolu). La finesse apparente des sept décimales ne doit tromper personne.
     */
    private precision;
    private bbox;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeoJsonExportService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeoJsonExportService>;
}
