import { FloorplanProject, GeoLocation, GeoAnchorParams } from '../models/project.model';
import { Point } from '../models/geometry.types';
import * as i0 from "@angular/core";
/** Couple longitude/latitude WGS84, dans l'ordre MapLibre (lng d'abord). */
export interface LngLat {
    lng: number;
    lat: number;
}
/**
 * Côté du monde entier en pixels au zoom 0. MapLibre rend sur une grille de
 * tuiles de 512 px : au zoom z, le monde fait `512 · 2^z` pixels et **un pixel
 * CSS de carte vaut exactement un pixel-monde**. C'est cette grille — et non le
 * mètre — qui définit la projection : l'aller-retour y est une bijection exacte.
 */
export declare const MERCATOR_TILE_SIZE = 512;
/**
 * Latitude au-delà de laquelle Web Mercator n'est plus défini (le monde y
 * devient un carré). Au-delà, `tan φ` diverge : on borne plutôt que de laisser
 * remonter un Infinity qui contaminerait silencieusement toute la scène.
 */
export declare const MERCATOR_MAX_LATITUDE = 85.0511287798066;
/**
 * Résolution nominale du Mercator sphérique, en mètres au sol par pixel-monde
 * (donc par pixel CSS de carte).
 *
 * `40 075 016,686 / 512 ≈ 78 271,515` — la circonférence équatoriale divisée par
 * la taille de tuile. Le facteur `cos(φ)` est déjà dedans : le résultat est un
 * mètre **sol**, pas un mètre EPSG:3857.
 *
 * Précision réelle : c'est la résolution du Mercator **sphérique** appliquée à
 * une latitude **géodésique** WGS84, soit ~0,2 % d'écart à nos latitudes, avec
 * une anisotropie E-O / N-S de ~0,3 %. Négligeable devant le pas de grille de
 * l'éditeur (1 à 3 m au sol), mais à ne pas prétendre corriger sans le mesurer.
 *
 * Cette formule était dupliquée à l'identique dans `osm.service.ts` et dans la
 * modale OSM ; elle vit ici désormais, pour qu'une correction s'applique partout.
 */
export declare function metersPerPixel(lat: number, zoom: number): number;
/** Côté du monde en pixels-monde au zoom donné. */
export declare function mercatorWorldSize(zoom: number): number;
/**
 * WGS84 → pixels-monde Web Mercator au zoom donné.
 *
 * `X = (lng + 180) / 360 · 512 · 2^z`
 * `Y = (1 − ln(tan φ + sec φ) / π) / 2 · 512 · 2^z`
 */
export declare function lngLatToWorld(lngLat: LngLat, zoom: number): Point;
/** Pixels-monde Web Mercator → WGS84. Réciproque exacte de `lngLatToWorld`. */
export declare function worldToLngLat(pt: Point, zoom: number): LngLat;
/**
 * Les champs de capture persistés (`GeoAnchorParams`) vivent avec le modèle de
 * projet, pas ici : ils décrivent une **donnée enregistrée**, et c'est ce qui
 * est écrit dans le JSON qui fait contrat. Ce service les consomme de façon
 * défensive — un projet antérieur à la persistance de l'ancre n'en porte aucun,
 * et l'ancre reste alors exploitable, avec un dpr supposé
 * (voir `GeoAnchor.dprSuppose`).
 */
/**
 * Tout ce qui permet de passer du repère scène (pixels du canvas Fabric) aux
 * coordonnées WGS84, et retour.
 *
 * Une ancre décrit **une image de capture posée sur la scène** : son centre
 * `centerX`/`centerY` correspond à `lat`/`lng`, et un pixel scène vaut
 * `1 / (dpr · scale)` pixel-monde au zoom `zoom`.
 */
export interface GeoAnchor {
    /** Latitude du centre de l'image de capture. */
    lat: number;
    /** Longitude du centre de l'image de capture. */
    lng: number;
    /** Zoom **effectif** de la capture (celui de `map.getZoom()`, pas le demandé). */
    zoom: number;
    /** Ratio pixels image / pixels-monde. 1 pixel image = 1/dpr pixel-monde. */
    dpr: number;
    /** Centre de l'image dans le repère scène — `resolveAnchor` y normalise
     *  `left`/`top` quels que soient `originX`/`originY`. */
    centerX: number;
    /** Ordonnée du centre de l'image dans le repère scène. */
    centerY: number;
    /** Rotation du fond, en degrés, convention Fabric (positif = horaire à l'écran). */
    angle: number;
    /** Échelle horizontale appliquée à l'image sur la scène. */
    scaleX: number;
    /** Échelle verticale appliquée à l'image sur la scène. */
    scaleY: number;
    /** Largeur naturelle de l'image, si connue (diagnostic et emprise). */
    imageW?: number;
    /** Hauteur naturelle de l'image, si connue. */
    imageH?: number;
    /** Horodatage de la capture, s'il a été persisté. Sert à détecter un fond posé
     *  **après** que le plan a été dessiné — cas où le GeoJSON serait parfaitement
     *  formé et complètement faux. */
    capturedAt?: string;
    /** Couche capturée, si elle a été persistée. */
    layer?: string;
    /** Niveau porteur du Backdrop (`undefined` s'il a été trouvé dans
     *  `project.objects`, qui n'est rattaché à aucun niveau nommé). */
    floorId?: string;
    /** D'où viennent `lat`/`lng`/`zoom` : `project.geo` fait foi quand il est
     *  exploitable, sinon on retombe sur le `data` du Backdrop. */
    source: 'project' | 'backdrop';
    /** `true` si `project.geo` et le `data` du Backdrop décrivent des vues
     *  différentes — signe que le fond a été remplacé sans que `geo` suive (ou
     *  l'inverse). L'ancre reste celle de `project.geo`. */
    divergence: boolean;
    /** `true` si le Backdrop a été déplacé, pivoté ou redimensionné depuis sa
     *  pose (comparaison avec les champs de scène enregistrés dans son `data`),
     *  ou si l'éditeur l'a marqué `retouchee` — un déverrouillage du fond suffit,
     *  et il ne laisse aucune trace géométrique. Reste `false` quand la pose n'a
     *  pas été enregistrée **et** que rien n'a été marqué : non détectable. */
    retouche: boolean;
    /** `true` si des objets métier existaient déjà quand le fond a été posé : le
     *  plan n'a pas été tracé sur cette carte. L'ancre est géométriquement
     *  correcte et le géoréférencement des dessins n'en est pas moins faux —
     *  c'est à l'exportateur de refuser ou d'annoncer. */
    dessinsAnterieurs: boolean;
    /** `true` si aucun dpr n'a été persisté et qu'il a été **supposé** à 1. Une
     *  capture faite sur écran retina vaut alors deux fois la résolution admise :
     *  toutes les distances seraient fausses d'un facteur 2, en silence. */
    dprSuppose: boolean;
}
/**
 * Conversion repère scène ↔ WGS84 pour un plan dessiné sur fond de carte.
 *
 * **Pur et sans état** : ne touche ni au canvas Fabric, ni à MapLibre, ni au
 * DOM. Il ne consomme que des données sérialisées, ce qui le rend utilisable
 * côté hôte sur un projet stocké, et testable sans navigateur.
 *
 * Le modèle de projection passe volontairement par les **pixels-monde**, pas par
 * `pixelsPerMeter` : ce dernier est arrondi à 0,1 à l'écriture du projet et
 * embarque déjà le facteur `cos(φ)`. Les pixels-monde, eux, sont la grille de
 * tuiles elle-même — l'inverse Mercator y est exact.
 */
export declare class GeoProjectionService {
    /**
     * Retrouve l'ancre géographique d'un projet **sérialisé**, ou `null` si le
     * plan n'est pas géoréférençable.
     *
     * Deux porteurs, complémentaires :
     *  - le **Backdrop** donne la géométrie de scène vivante (`left`/`top`/
     *    `angle`/`scaleX`/`scaleY`), donc absorbe gratuitement un déplacement du
     *    fond ;
     *  - **`project.geo`** survit à la suppression du fond et au dépouillement du
     *    base64 par l'hôte, et **fait foi** en cas de divergence.
     *
     * Le Backdrop est cherché dans `project.floors[*].objects` **et** dans
     * `project.objects` : il n'appartient à la liste d'objets que d'**un seul**
     * niveau, et `project.objects` ne porte que le niveau courant.
     */
    resolveAnchor(project: FloorplanProject | null | undefined): GeoAnchor | null;
    /**
     * Point du repère scène (pixels canvas) → WGS84.
     *
     * Chaîne : scène → repère image (annulation de `left`/`top`, de `angle` puis
     * de `scaleX`/`scaleY`) → pixels-monde (division par `dpr`, l'image de fond
     * étant posée sans mise à l'échelle supplémentaire) → inverse Mercator.
     */
    sceneToLngLat(pt: Point, anchor: GeoAnchor): LngLat;
    /** WGS84 → point du repère scène. Réciproque exacte de `sceneToLngLat`. */
    lngLatToScene(lngLat: LngLat, anchor: GeoAnchor): Point;
    /**
     * Résolution nominale de la carte, en mètres au sol par pixel-monde.
     * Voir la fonction module du même nom pour les réserves de précision.
     */
    metersPerPixel(lat: number, zoom: number): number;
    /**
     * Résolution d'un pixel **de scène**, en mètres au sol — la précision
     * réellement annonçable pour un plan tracé sur cette ancre. Un pixel scène
     * vaut `1 / (dpr · scaleX)` pixel-monde.
     */
    sceneMetersPerPixel(anchor: GeoAnchor): number;
    /**
     * Cherche le Backdrop dans les niveaux (du plus bas au plus haut, comme la
     * vue 3D) puis, à défaut, dans `project.objects`. Les niveaux d'abord parce
     * qu'eux seuls donnent un `floorId` exploitable par l'exportateur.
     */
    private findBackdrop;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeoProjectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeoProjectionService>;
}
/**
 * Ce `geo` porte-t-il au moins un champ d'ancrage **écrit par g-plan** ?
 *
 * Sert à distinguer une ancre que la bibliothèque a posée d'un `geo` fourni par
 * l'app hôte depuis son propre géocodage, qui ne porte que `lat`/`lng`/`zoom`.
 * La distinction est nécessaire à l'écriture du projet : dériver le `valid`
 * d'un geo entrant reviendrait à le passer systématiquement à `false` (il n'a
 * ni pose enregistrée, ni fond à confronter), donc à **dégrader une donnée de
 * l'hôte** que g-plan ne réémettait même pas auparavant.
 */
export declare function porteAncreGPlan(geo: Partial<GeoLocation> | null | undefined): boolean;
/**
 * Le fond **vivant** a-t-il quitté la pose enregistrée dans l'ancre ?
 *
 * Comparaison géométrique pure — elle ne dit rien d'un fond simplement
 * déverrouillé, ni d'un fond remplacé par une image locale posée au même
 * endroit. Ces deux cas-là sont portés par le drapeau `retouchee`, que
 * l'éditeur écrit au moment où ils se produisent.
 */
export declare function backdropDeplace(backdrop: unknown | null | undefined, pose: GeoAnchorParams | null | undefined): boolean;
/**
 * Deux porteurs décrivent-ils la **même vue** (mêmes lat/lng/zoom) ?
 *
 * Sert à distinguer une **recapture** de la même carte — qui conserve les
 * doutes déjà établis sur l'ancre — d'un **changement de lieu**, qui repart de
 * zéro et rend caducs les dessins existants.
 */
export declare function memeVueGeo(a: Partial<GeoLocation> | null | undefined, b: Partial<GeoLocation> | null | undefined): boolean;
/**
 * Calcule le `valid` de `GeoLocation` — enfin **dérivé**, alors qu'il était
 * écrit en dur à `true` depuis l'origine et ne garantissait donc rien.
 *
 * Une ancre n'est déclarée exploitable que si, cumulativement :
 *  1. elle porte des lat/lng/zoom finis ;
 *  2. sa position de scène est connue — fond vivant, ou `anchorX`/`anchorY`
 *     persistés (le centre du canvas ne peut pas servir de repli, il dépend
 *     d'entrées de l'hôte que le projet ne persiste pas) ;
 *  3. le fond n'a pas été retouché — ni marqué comme tel, ni géométriquement
 *     déplacé depuis sa pose — ni **remplacé** par une image sans
 *     géoréférencement (`fondRemplace`, doute qu'aucun reverrouillage ne lève,
 *     faute de trace mesurable à confronter) ;
 *  4. la mise à l'échelle reste **isotrope** (`scaleX === scaleY`) : un fond
 *     étiré ne se projette plus par une similitude, et l'écart croît avec la
 *     distance à l'ancre sans jamais être visible sur l'image ;
 *  5. le fond n'est pas cisaillé (`skewX`/`skewY` nuls), même raison.
 *
 * `dessinsAnterieurs` n'entre **pas** dans le calcul : l'ancre y est
 * géométriquement juste, ce sont les dessins qui ne lui appartiennent pas.
 * Confondre les deux ferait disparaître le fond de carte au rechargement d'un
 * plan pourtant correctement ancré. Le drapeau est propagé tel quel, à charge
 * pour l'exportateur d'en tenir compte.
 */
export declare function computeGeoValidity(geo: GeoLocation | null | undefined, backdrop?: unknown | null): boolean;
/**
 * Renvoie une copie de l'ancre dont le `valid` a été recalculé. C'est le seul
 * point d'écriture de ce champ : partout ailleurs il est propagé, jamais posé.
 */
export declare function withGeoValidity(geo: GeoLocation, backdrop?: unknown | null): GeoLocation;
