import { FloorplanProject } from '../models/project.model';
import { PlanSummary } from '../models/plan-summary.model';
import * as i0 from "@angular/core";
/**
 * Analyseur pur : produit une synthèse structurée (`PlanSummary`) à partir d'un
 * `FloorplanProject` sérialisé. Ne dépend PAS d'un canvas Fabric vivant — toutes
 * les associations (pièce↔murs↔ouvertures) sont reconstruites depuis les champs
 * `data` persistés (wallLetters, parentWallId…). Couvre donc tous les niveaux.
 */
export declare class PlanAnalysisService {
    analyze(project: FloorplanProject, opts?: {
        criRooms?: {
            id: string;
            name: string;
        }[];
    }): PlanSummary;
    /** Endpoints absolus d'une ligne Fabric (mur ou pipe) — gère l'offset de drag.
     *  Délègue à l'extracteur commun (`plan-geometry.const.ts`) : cette formule
     *  était recopiée ici, dans `GeometryService` et dans `FabricCanvasService`. */
    private absEnds;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlanAnalysisService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlanAnalysisService>;
}
