import { Homography, PhotoLayerData } from '../constants/photo-homography.const';
import * as i0 from "@angular/core";
/** `myType` de l'objet Fabric portant un calque photo. */
export declare const PHOTO_LAYER_TYPE = "PhotoLayer";
/** La photo prête à être travaillée : réduite, encodée, décodée une fois. */
export interface PhotoSource {
    /** Image **persistée** : WebP, ≤ `MAX_PHOTO_SIZE_PX` de côté, sous plafond. */
    readonly dataUrl: string;
    readonly width: number;
    readonly height: number;
    /** Élément décodé correspondant à `dataUrl` — c'est sur **celui-là** que
     *  l'utilisateur pose ses coins, donc celui auquel l'homographie se rapporte. */
    readonly image: HTMLImageElement;
}
/**
 * Pont du calque photo vers les pixels et vers Fabric.
 *
 * Toute la géométrie vit dans `constants/photo-homography.const.ts`, module
 * **pur** et testé sans navigateur. Ce service ne fait que ce qui exige un
 * canvas ou un objet Fabric : décoder un fichier, réduire, encoder, appliquer le
 * redressement pixel par pixel, et poser le résultat sur un `FabricImage`.
 *
 * ## Ce qui est persisté, et ce qui ne l'est pas
 *
 * Le calque est un `FabricImage` dont :
 *  - `_originalElement` reste la **photo d'origine** — c'est elle que
 *    `getSrc()` rend, donc c'est elle, et elle seule, que `toObject()` écrit
 *    dans le document ;
 *  - `_element` est un canvas **redressé**, regénéré à chaque chargement, jamais
 *    sérialisé.
 *
 * C'est exactement le mécanisme des filtres Fabric (`applyFilters` remplace
 * `_element` et laisse `_originalElement` intact) : on ne détourne rien, on
 * l'applique. La conséquence pratique est le point d'attention n°1 de la
 * brique B : **l'image n'est stockée qu'une fois**. Stocker aussi les pixels
 * redressés doublerait le poids d'un plan — et un fond de carte a déjà, à lui
 * seul, fait sauter le quota `localStorage` et cassé la restauration du
 * brouillon. Un test le garde (`photo-layer.service.spec.ts`).
 *
 * Corollaire : le redressement doit être **rejoué** après chaque
 * `loadFromJSON`, sans quoi le calque se réafficherait de biais, étiré sur la
 * taille du rectangle. C'est le rôle de `rehydrate`, appelée sur tous les
 * chemins de chargement de l'éditeur.
 */
export declare class PhotoLayerService {
    constructor();
    /**
     * Lit un fichier photo, le réduit à `MAX_PHOTO_SIZE_PX` et l'encode en WebP
     * sous le plafond de poids.
     *
     * La réduction a lieu **avant** que l'utilisateur ne pose les quatre coins :
     * l'homographie se rapporte alors directement à l'image persistée, et il n'y a
     * aucun facteur d'échelle à retenir quelque part — donc aucun à oublier. Le
     * rapport d'aspect recouvré est invariant par redimensionnement (vérifié en
     * unitaire), donc rien n'est perdu à réduire d'abord.
     *
     * Lève une erreur explicite plutôt que de rendre une photo hors plafond :
     * poser un calque trop lourd ferait échouer l'autosave plus tard, ailleurs, et
     * sans lien visible avec la photo — le motif de panne muette que ce projet
     * traque.
     */
    prepareSource(file: File): Promise<PhotoSource>;
    /**
     * Redresse une source dans un canvas, par **image inverse**.
     *
     * On parcourt le rectangle de destination et on va chercher, pour chaque
     * pixel, son antécédent dans la photo. Parcourir dans l'autre sens laisserait
     * des trous partout où la perspective étire l'image — c'est la raison d'être
     * de `invertHomography`.
     *
     * L'échantillonnage est **bilinéaire** : au plus proche voisin, les traits
     * fins d'un plan papier se hachent en escalier et deviennent illisibles, ce
     * qui ruine le seul usage du calque.
     *
     * Ce qui tombe hors de la photo reste **transparent**, et non noir : le calque
     * se superpose au plan, un fond opaque masquerait le dessin.
     */
    warp(source: CanvasImageSource, sourceWidth: number, sourceHeight: number, matrix: Homography, width: number, height: number): HTMLCanvasElement | null;
    /**
     * Redresse une photo **persistée** (sa `data:` URL et sa charge utile) et rend
     * le canvas redressé, sans passer par Fabric.
     *
     * Le calque photo n'en a pas besoin — il redresse en place l'élément déjà
     * décodé par Fabric (`applyRectification`). Cette variante existe pour le
     * **scanner** (brique C), qui doit détecter ses traits sur l'image redressée
     * et n'a aucun objet Fabric à sa disposition : il travaille sur des
     * `<canvas>` bruts. Sans elle, le scanner aurait dû réécrire le décodage et
     * l'appel à `warp`, c'est-à-dire un second chemin vers la même géométrie —
     * exactement ce que la règle du pont unique interdit.
     *
     * Rend `null` sans lever si la charge utile est inexploitable : l'appelant
     * garde alors son image d'origine, non redressée, et doit le dire.
     */
    rectifiedCanvas(dataUrl: string, photo: PhotoLayerData | null | undefined): Promise<HTMLCanvasElement | null>;
    /**
     * Pose les pixels redressés sur un `FabricImage` **sans toucher à sa source**.
     *
     * `_originalElement` n'est pas modifié : c'est ce qui garantit que la
     * sérialisation continue d'écrire la photo d'origine, et elle seule.
     *
     * Rend `false` — sans lever — si la charge utile est inexploitable : une
     * homographie tronquée par un hôte ou retapée à la main ne doit pas empêcher
     * le reste du plan de s'afficher.
     */
    applyRectification(img: any, photo: PhotoLayerData | null | undefined): boolean;
    /**
     * Construit l'objet Fabric du calque à partir de la photo d'origine et de sa
     * charge utile.
     *
     * Le calque est posé **inerte** (`selectable`/`evented` à `false`, verrous de
     * mouvement) comme le fond de carte : sur tablette, un décalque qui se déplace
     * au doigt pendant qu'on trace est pire que pas de décalque du tout — et son
     * calage serait alors faux sans que rien ne le dise.
     */
    createLayer(dataUrl: string, photo: PhotoLayerData, pose: {
        left: number;
        top: number;
        scale?: number;
        opacity?: number;
    }): Promise<any | null>;
    /**
     * Rejoue le redressement de tous les calques d'un canvas après chargement.
     *
     * Sans cet appel, le calque revient **de biais** et étiré sur les dimensions
     * du rectangle redressé : une image plausible, calée à côté, et rien pour le
     * signaler. C'est le prix de ne stocker que l'original — et il se paie ici, en
     * un seul endroit.
     *
     * Rend le nombre de calques effectivement redressés.
     */
    rehydrate(canvas: any): number;
    /** Lecture d'un fichier en `data:` URL. */
    private readAsDataUrl;
    /** Décodage d'une `data:` URL en élément image. */
    private decode;
    static ɵfac: i0.ɵɵFactoryDeclaration<PhotoLayerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PhotoLayerService>;
}
