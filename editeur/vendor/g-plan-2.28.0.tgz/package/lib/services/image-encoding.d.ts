/**
 * Encodage et redimensionnement des images de calque — **un seul** encodeur
 * pour toute la bibliothèque.
 *
 * **Pourquoi ce fichier existe.** Le poids des images n'est pas un souci
 * théorique dans ce projet : un fond de carte PNG a porté un projet à
 * **5 290 Ko** (2 714 Ko de base64, sérialisés deux fois — dans `objects` *et*
 * dans `floors[*].objects`), `localStorage.setItem` levait
 * `QuotaExceededError`, l'autosave échouait **en silence**, et le brouillon
 * proposé au démarrage datait d'avant la pose du fond : le restaurer vidait le
 * plan en cours. Le passage en WebP a ramené le projet à 465 Ko.
 *
 * Cette leçon vaut pour **toute** image posée sur le plan, pas seulement pour le
 * fond de carte. Le calque photo (2.12.0) réutilise donc le même encodeur au
 * lieu d'en écrire un second, qui aurait dérivé à la première correction.
 *
 * **Placement.** Ces fonctions touchent au `canvas`, donc elles ne peuvent pas
 * vivre dans `constants/`, réservé aux modules purs (ni Fabric, ni DOM, ni
 * canvas). Elles n'ont pas d'état non plus, donc pas de `@Injectable` : ce sont
 * des fonctions libres, importées par `OsmService` et `PhotoLayerService`.
 */
/** Qualité WebP par défaut d'une capture cartographique. 0,85 sur de l'imagerie
 *  aérienne reste indiscernable à l'œil tout en divisant le poids par un ordre
 *  de grandeur — et c'est un fond de calque, pas une pièce du dossier. */
export declare const DEFAULT_WEBP_QUALITY = 0.85;
/**
 * Encode un canvas en **WebP** plutôt qu'en PNG.
 *
 * L'encodage est **natif** (`canvas.toDataURL`) : pas de codec WASM à charger,
 * donc rien à télécharger et un fonctionnement hors ligne inchangé.
 *
 * Repli : un navigateur sans encodeur WebP renvoie silencieusement un PNG. On le
 * détecte au préfixe et on le **signale**, plutôt que de laisser croire à un
 * gain qui n'a pas eu lieu.
 */
export declare function encodeWebp(canvas: HTMLCanvasElement, quality?: number, defaut?: number): string;
/** Poids d'une `data:` URL, en octets de la chaîne telle qu'elle sera
 *  sérialisée — c'est ce poids-là, et non celui des pixels décodés, qui compte
 *  pour `localStorage`. */
export declare function dataUrlBytes(dataUrl: string): number;
/**
 * Encode sous un plafond de poids, en dégradant **d'abord la qualité, puis la
 * taille**.
 *
 * L'ordre n'est pas indifférent : sur un fond de décalque, perdre du détail de
 * compression ne gêne pas le tracé, alors que perdre des pixels rend les traits
 * du plan papier illisibles. On ne descend donc en résolution qu'après avoir
 * épuisé la qualité.
 *
 * Rend `null` si même la dernière tentative dépasse le plafond — à l'appelant de
 * le dire à l'utilisateur, plutôt que de poser une image qui fera échouer
 * l'enregistrement plus tard, ailleurs, sans rapport visible avec la photo.
 */
export declare function encodeUnderCap(canvas: HTMLCanvasElement, quality: number, maxBytes: number): {
    dataUrl: string;
    width: number;
    height: number;
} | null;
/**
 * Dessine une source (image ou canvas) dans un canvas de la taille demandée.
 * `imageSmoothingQuality: 'high'` n'est pas décoratif : la réduction par défaut
 * de `drawImage` crénelle franchement les traits fins d'un plan papier.
 */
export declare function drawScaled(source: CanvasImageSource, width: number, height: number): HTMLCanvasElement;
