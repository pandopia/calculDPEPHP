import { WallSegment, RawSegment } from '../models/wall.model';
import { ProjectStats } from '../models/project.model';
import { Point, SelectionBox, Graph } from '../models/geometry.types';
import * as i0 from "@angular/core";
export declare class GeometryService {
    performClustering(segments: RawSegment[], clusterDist: number): WallSegment[];
    extendToIntersections(walls: WallSegment[], extDist: number): WallSegment[];
    snapCorners(walls: WallSegment[], snapDist: number): WallSegment[];
    fragmentWalls(walls: WallSegment[]): WallSegment[];
    getConnectivity(x: number, y: number, walls: WallSegment[], scopeBox?: SelectionBox): number;
    mergeCollinearSegments(walls: WallSegment[], indices: number[]): WallSegment[];
    buildGraph(segments: Array<{
        x1: number;
        y1: number;
        x2: number;
        y2: number;
    }>, snapPx?: number): Graph;
    findMinimalCycles(graph: Graph): Point[][];
    getSignedArea(points: Point[]): number;
    getCentroid(points: Point[]): Point;
    /**
     * Test point-dans-polygone (ray casting).
     * Utilisé pour détecter les cycles imbriqués (ex : placard dans une chambre).
     */
    isPointInPolygon(point: Point, polygon: Point[]): boolean;
    distanceToSegment(p: Point, v: Point, w: Point): number;
    recalculateRooms(canvas: any, pixelsPerMeter: number, showMeasurements: boolean): {
        stats: ProjectStats;
    };
    /**
     * Extrémités absolues d'un mur ou d'une cloison. Délègue à `absLineEnds`, la
     * définition unique de cette formule (cf. `plan-geometry.const.ts`) : les
     * pièces détectées ici, l'analyseur et l'export géographique doivent lire la
     * même géométrie, biais du demi-trait compris.
     *
     * Publique parce que l'exportateur GeoJSON s'appuie dessus pour ne pas
     * réécrire une seconde vérité géométrique.
     */
    /**
     * Pose les cotes des réseaux et renvoie leurs linéaires par type.
     *
     * Extrait de `recalculateRooms` parce qu'il y était placé **après** la sortie
     * anticipée sur l'absence de mur : un plan purement réseau — AEP, EU, SPANC,
     * AC, VRD, soit cinq des six modes métier — n'avait donc ni cote ni linéaire,
     * sans que rien ne le signale. Les réseaux n'ont rien à voir avec les murs,
     * ce calcul n'a pas à en dépendre.
     *
     * La cote porte le linéaire **développé** du tracé et se pose au milieu de ce
     * développé — le milieu du segment n'a plus de sens depuis qu'un réseau est
     * une polyligne à plusieurs sommets.
     */
    private renderPipeMeasurements;
    getAbsoluteLineEnds(line: any): {
        p1: Point;
        p2: Point;
    };
    /**
     * Pour chaque extrémité de segment qui se trouve à moins de `snapDist` px de l'intérieur
     * d'un autre segment, déplace cette extrémité sur la surface du mur (snap exact).
     * Garantit des T-jonctions précises avant la fragmentation, même si les murs sont légèrement
     * désalignés (tracé manuel, croquis).
     */
    private snapEndpointsToWalls;
    private splitIntersectingFabricLines;
    private lineIntersect;
    /**
     * Vérifie qu'un point est à l'intérieur d'un segment (hors extrémités).
     * Utilise la distance perpendiculaire normalisée par la longueur du segment
     * pour être robuste sur les murs diagonaux (contrairement à un EPS absolu).
     */
    private pointOnSegment;
    private generateStablePastelColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeometryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeometryService>;
}
