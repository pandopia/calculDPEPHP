import { FloorplanConfig } from '../models/config.model';
import { GeoLocation } from '../models/project.model';
import { OsmLayer } from '../constants/map-styles.const';
import * as i0 from "@angular/core";
export type { OsmLayer };
export interface GeocodeResult {
    lat: number;
    lng: number;
    label: string;
}
/**
 * Tout ce qu'une capture cartographique doit livrer pour être exploitable —
 * l'image, mais aussi les paramètres qui l'ont produite.
 *
 * `scaleVal` seul ne suffit pas : ce n'est pas une grandeur physique, il
 * embarque le dpr de la machine qui a capturé. Deux opérateurs sur deux postes
 * obtiennent deux `pixelsPerMeter` pour le même terrain. Sans `dpr`, `zoom`
 * effectif et taille réelle de l'image, on ne peut ni rejouer, ni vérifier, ni
 * géoréférencer la capture après coup.
 */
export interface OsmCapture {
    /** Image PNG en base64 (`data:image/png;base64,...`). */
    dataUrl: string;
    /** Pixels image par mètre au sol — c'est le `pixelsPerMeter` du plan. */
    scaleVal: number;
    /** Latitude réellement centrée au moment de la lecture du canvas. */
    lat: number;
    /** Longitude réellement centrée au moment de la lecture du canvas. */
    lng: number;
    /** Zoom **effectif** (`map.getZoom()`), pas le zoom demandé : `maxZoom: 19`
     *  écrête une demande supérieure, et une résolution fausse d'un facteur 2
     *  passerait autrement inaperçue. */
    zoom: number;
    /** Largeur de l'image en pixels réels (`canvas.width`). */
    imageW: number;
    /** Hauteur de l'image en pixels réels (`canvas.height`). */
    imageH: number;
    /** Largeur du conteneur en pixels CSS. */
    cssW: number;
    /** Hauteur du conteneur en pixels CSS. */
    cssH: number;
    /** Ratio réellement appliqué au rendu (`imageW / cssW`), qui peut différer de
     *  `window.devicePixelRatio` si WebGL a borné la taille du canvas. */
    dpr: number;
    /** Couche capturée. */
    layer: OsmLayer;
    /** Horodatage ISO 8601 de la capture (sert à détecter un fond posé après coup). */
    capturedAt: string;
}
export declare class OsmService {
    /** Configuration de la librairie — sert de repli pour l'URL du worker
     *  maplibre quand aucune configuration n'a encore été reçue. */
    private readonly config;
    private map;
    /** Couche actuellement affichée par `initMap`/`setLayer` — reportée dans `OsmCapture`. */
    private currentLayer;
    /** Dernière configuration reçue : `captureCurrentView()` n'en prend pas en
     *  paramètre mais doit encoder le fond avec la qualité voulue par l'hôte. */
    private currentConfig;
    /**
     * Classe `Map` de maplibre-gl, chargée dynamiquement (cf. `loadMapLibre`).
     *
     * L'URL du worker est lue sur la configuration **reçue au dernier appel**
     * plutôt que sur le jeton injecté : `initMap` la fournit toujours, et une
     * capture n'a jamais lieu avant elle. Le repli sur le jeton couvre le cas où
     * la classe serait demandée en dehors de ce chemin.
     */
    private loadMapClass;
    initMap(container: HTMLElement, config: FloorplanConfig): void;
    /** cf. `enforceMercator` de `map-styles.const` — une seule définition. */
    private enforceMercator;
    /**
     * Bascule la couche affichée :
     * - 'osm'       → style vecteur du tileserver (ou raster OSM en fallback)
     * - 'satellite' → imagerie satellite raster
     * - 'cadastre'  → ajoute le cadastre en overlay par-dessus le fond courant
     * - 'custom'    → style alternatif du tileserver (config.tileStyle)
     */
    setLayer(type: OsmLayer, config: FloorplanConfig): void;
    /** Géocode une adresse via Nominatim et retourne les résultats. */
    geocode(query: string): Promise<GeocodeResult[]>;
    /** Déplace la carte vers les coordonnées données, zoom minimum 18. */
    flyTo(lat: number, lng: number, zoom?: number): void;
    getCenter(): {
        lat: number;
        lng: number;
        zoom: number;
    } | null;
    /** Résolution en mètres/px CSS à la position courante (formule MapLibre 512px). */
    getMetersPerPixel(): number | null;
    /**
     * Capture la vue courante de la carte affichée (modale OSM).
     *
     * Le centre et le zoom sont lus **dans le même bloc synchrone** que
     * `toDataURL()` : lire `getCenter()` séparément après la capture laisse une
     * fenêtre pendant laquelle une inertie de pan déplace la carte, et l'ancre
     * décrit alors une autre vue que l'image — décalage silencieux et
     * indétectable a posteriori. On attend en plus l'immobilisation de la carte
     * quand un mouvement est en cours ; cette attente est un confort (netteté),
     * son échec n'est donc pas fatal.
     */
    captureCurrentView(timeoutMs?: number): Promise<OsmCapture>;
    destroy(): void;
    /**
     * Capture une vue cartographique en offscreen à la position `geo` donnée.
     * Crée un div temporaire hors-écran, initialise une carte MapLibre, attend le chargement
     * des tuiles (idle), capture le canvas et retourne l'image **et ses paramètres**.
     *
     * L'attente est bornée par `timeoutMs` : hors ligne, `style.load` puis `idle`
     * ne se résolvaient jamais et le spinner de l'appelant restait actif
     * indéfiniment. La carte temporaire et son conteneur sont libérés dans tous
     * les cas, échec compris.
     */
    captureAt(geo: GeoLocation, layer: 'osm' | 'satellite', config: FloorplanConfig, width?: number, height?: number, timeoutMs?: number): Promise<OsmCapture>;
    /**
     * Lit l'image et **tous** les paramètres qui la décrivent, en une seule passe
     * synchrone pour que l'ancre et les pixels décrivent la même vue.
     */
    private readCapture;
    /**
     * Attend un événement MapLibre avec un délai maximal.
     * Sans garde, `once('style.load')` ne se résout jamais hors ligne.
     */
    private waitForEvent;
    private getBaseStyle;
    private getCustomStyle;
    private getSatelliteStyle;
    /**
     * Ajoute le cadastre par-dessus le fond courant.
     *
     * Les couches viennent de `cadastreOverlayLayers`, **définition unique**
     * partagée avec la vue carte. Elles étaient écrites ici en dur, et en
     * `type: 'raster'` — sur une source devenue **vectorielle** : MapLibre refuse
     * l'attelage, la couche n'est jamais peinte, et le refus part dans
     * `map.on('error')`, que ce service n'écoutait pas. Cocher « Cadastre » ne
     * faisait donc rien du tout.
     */
    private addCadastreOverlay;
    private removeCadastreOverlay;
    static ɵfac: i0.ɵɵFactoryDeclaration<OsmService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OsmService>;
}
