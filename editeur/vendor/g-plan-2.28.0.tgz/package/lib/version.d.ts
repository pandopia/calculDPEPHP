export declare const GPLAN_VERSION = "2.28.0";
