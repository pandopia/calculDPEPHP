import { AfterViewInit, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Maintient un panneau flottant à l'intérieur de la fenêtre.
 *
 * À poser sur un élément positionné en `absolute` (les menus déroulants de
 * l'éditeur) : à l'affichage, la directive mesure sa position réelle et le
 * ramène horizontalement dans l'écran si besoin, par un `translateX`.
 *
 * Elle ne s'applique qu'à l'horizontale, seule dimension où le problème se pose
 * ici : les panneaux descendent sous un bandeau haut, jamais sous un bandeau
 * bas. Le motif du débordement vertical, s'il apparaît, sera un autre travail —
 * il demande de retourner le panneau au-dessus de son bouton, pas de le glisser.
 *
 * ```html
 * <div class="ngf-dropdown-panel" ngGplanKeepInViewport>…</div>
 * ```
 *
 * Le calcul est dans `constants/viewport-clamp.const.ts` (`clampShiftX`), donc
 * testable sans navigateur ; ici il n'y a que la mesure et l'écriture.
 */
export declare class KeepInViewportDirective implements AfterViewInit, OnDestroy {
    private readonly host;
    private readonly zone;
    private readonly destroyRef;
    private onResize?;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private detacher;
    /**
     * Mesure et corrige.
     *
     * Le décalage est remis à zéro AVANT de mesurer : sans cela, la mesure
     * porterait sur la position déjà corrigée et les décalages s'additionneraient
     * à chaque redimensionnement, jusqu'à sortir le panneau de l'autre côté.
     *
     * On écrit la propriété `translate` et non `transform` : les panneaux ouvrent
     * sur une animation (`@keyframes dropDown`) qui, elle, anime `transform`. Une
     * animation l'emporte sur le style en ligne pendant sa durée — le panneau
     * serait donc apparu à la mauvaise place pendant 120 ms avant de sauter à la
     * bonne. `translate` est une propriété distincte, qui se compose avec
     * `transform` au lieu de le remplacer.
     */
    private recadrer;
    static ɵfac: i0.ɵɵFactoryDeclaration<KeepInViewportDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<KeepInViewportDirective, "[ngGplanKeepInViewport]", never, {}, {}, never, never, true, never>;
}
