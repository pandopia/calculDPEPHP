export interface FloorplanConfig {
    /** URL CDN d'OpenCV.js */
    opencvUrl: string;
    /** Pixels par mètre (échelle initiale) */
    pixelsPerMeter: number;
    /** URL du serveur de tuiles (TileServer GL) */
    tileServerUrl: string;
    /** Nom du style de tuile */
    tileStyle: string;
    /** Gabarit d'URL des tuiles satellite (`{z}/{x}/{y}`).
     *  Facultatif : à défaut, le serveur maison `DEFAULT_SATELLITE_TILES_URL`.
     *  Le déclarer permet de pointer un miroir, ou de distinguer recette et
     *  production — ce que l'URL en dur des versions antérieures interdisait. */
    satelliteTilesUrl?: string;
    /** Taille de la grille (snap) en px */
    defaultGridSize: number;
    /** Distance de snap pour les nœuds en px */
    defaultSnapDistance: number;
    /** Largeur (px CSS) de la capture cartographique servant de fond de plan.
     *  Taille réelle de l'image = cette valeur × devicePixelRatio. Plus grand =
     *  plus d'emprise géographique capturée autour du point (à zoom constant),
     *  mais image plus lourde (embarquée en base64 dans le projet). */
    backdropCaptureWidth?: number;
    /** Hauteur (px CSS) de la capture cartographique servant de fond de plan. */
    backdropCaptureHeight?: number;
    /** Qualité WebP du fond de carte capturé (0 à 1, défaut 0,85).
     *
     *  Le fond voyage en base64 dans **chaque** projet émis, chaque instantané
     *  d'historique et chaque brouillon : un PNG de 2560 × 1920 pèse ~2,6 Mo, le
     *  même fond en WebP quelques centaines de kilo-octets. Monter la qualité
     *  n'a d'intérêt que si le fond sert de référence de tracé fin — au prix du
     *  poids partout ailleurs. */
    backdropImageQuality?: number;
    /** Gabarit d'URL des tuiles cadastre (`{z}/{x}/{y}`, ou WMTS `{TILEMATRIX}`…).
     *  À défaut, la Géoplateforme IGN — service **externe**, dont la
     *  disponibilité ne dépend pas de nous. Le déclarer permet de servir le
     *  cadastre depuis une infrastructure maison. */
    cadastreTilesUrl?: string;
    /** Mention de source du cadastre. À défaut, celle de la Géoplateforme IGN.
     *  **Obligatoire au titre de la Licence Ouverte 2.0**, qui autorise l'usage
     *  commercial mais impose de citer la source. À adapter si le cadastre est
     *  servi depuis une autre infrastructure. */
    cadastreAttribution?: string;
    /** Gabarit d'URL des tuiles **vectorielles** du cadastre (`{z}/{x}/{y}.pbf`).
     *  À défaut, le TMS de la Géoplateforme. Ignoré si `cadastreTilesUrl` est
     *  déclaré : un gabarit d'image ne se lit pas comme du vecteur. */
    cadastreVectorUrl?: string;
    /** Gabarit d'URL des fontes vectorielles (`{fontstack}/{range}.pbf`).
     *  Nécessaire à tout calque de texte — sans lui, les étiquettes restent
     *  invisibles, sans erreur. À défaut, celles de la Géoplateforme. */
    glyphsUrl?: string;
    /** Mention de source de l'imagerie satellite. **Aucune valeur par défaut** :
     *  la provenance dépend du contrat de l'application hôte avec son
     *  fournisseur, et g-plan ne peut pas l'inventer. Son absence est signalée
     *  en console — la plupart des fournisseurs l'exigent. */
    satelliteAttribution?: string;
    /**
     * URL du worker de maplibre-gl, **exigée par la v6 et ignorée par la v5**.
     *
     * La v6 est livrée en trois modules et déduit l'URL de son worker de
     * `import.meta.url` — laquelle, une fois la librairie empaquetée, désigne le
     * chunk de l'application. MapLibre cherche alors un fichier que le build
     * n'émet pas, le worker ne démarre pas, et **les tuiles vectorielles ne sont
     * jamais décodées** : fond vectoriel et cadastre restent blancs, sans une
     * seule erreur, tandis que le satellite s'affiche normalement.
     *
     * L'application hôte sert donc `maplibre-gl-worker.mjs` **et**
     * `maplibre-gl-shared.mjs` côte à côte (le premier importe le second
     * relativement à sa propre URL) et déclare ici l'URL du premier. Sans ce
     * réglage sous une v6, g-plan écrit un avertissement portant les deux gestes.
     */
    maplibreWorkerUrl?: string;
    /** Valeurs par défaut des paramètres de détection */
    detection?: Partial<DetectionParams>;
}
export interface DetectionParams {
    /** Seuil adaptatif (blockSize, impair, 3–99) */
    threshold: number;
    /** Longueur minimale d'un segment (px) */
    minLineLength: number;
    /** Gap maximal pour relier segments (px) */
    maxLineGap: number;
    /** Distance de clustering (épaisseur mur) (px) */
    clusterDistance: number;
    /** Extension vers intersections (px) */
    extensionDistance: number;
    /** Rotation de l'image source (degrés, -10 à +10) */
    rotation: number;
}
