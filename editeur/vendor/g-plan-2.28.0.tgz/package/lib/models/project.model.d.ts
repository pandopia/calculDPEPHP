import { WallSegment } from './wall.model';
import { WorkMode } from './floorplan-object.model';
/** D'où vient l'ancre géographique d'un plan. */
export type GeoAnchorSource = 
/** Capture faite par l'utilisateur dans la modale « Importer depuis la carte ». */
'osm-modal'
/** Capture faite depuis les coordonnées fournies par l'app hôte (input `geoPoint`). */
 | 'host-geopoint'
/** Recapture automatique à partir du `geo` déjà porté par le projet rechargé. */
 | 'project-geo';
/**
 * Paramètres d'ancrage persistés avec un plan géoréférencé — tout ce qu'il faut
 * pour reconstruire la transformation repère scène ↔ WGS84 **après** un
 * rechargement, sans dépendre d'entrées non persistées de l'app hôte.
 *
 * Tous les champs sont facultatifs : un projet enregistré avant l'introduction
 * de l'ancre n'en porte aucun, et doit continuer à se charger. L'ancre est
 * portée **deux fois** — par `project.geo` et par `backdrop.data.geo` — parce
 * que les deux porteurs ont des durées de vie différentes : le `data` du fond
 * absorbe gratuitement un déplacement de l'image, `project.geo` survit à la
 * suppression du fond et au dépouillement du base64 par l'hôte.
 */
export interface GeoAnchorParams {
    /** Ratio pixels image / pixels CSS **mesuré** à la capture (`OsmCapture.dpr`).
     *  Sans lui, une capture retina est fausse d'un facteur 2, en silence. */
    dpr?: number;
    /** Largeur de l'image de capture, en pixels réels. */
    captureWidth?: number;
    /** Hauteur de l'image de capture, en pixels réels. */
    captureHeight?: number;
    /** Horodatage ISO 8601 de la capture. Seul moyen de détecter un fond posé
     *  **après** que le plan a été dessiné — cas où le géoréférencement est
     *  parfaitement formé et entièrement faux. */
    capturedAt?: string;
    /** Couche capturée ('osm', 'satellite', 'cadastre'…). */
    layer?: string;
    /** Abscisse scène du **centre** de l'image au moment de la pose. Explicite,
     *  parce que la pose au centre du canvas dépend de `canvasWidth`/`canvasHeight`,
     *  qui sont des entrées de l'hôte que le projet ne persiste pas. */
    anchorX?: number;
    /** Ordonnée scène du centre de l'image au moment de la pose. */
    anchorY?: number;
    /** Rotation du fond au moment de la pose, en degrés (convention Fabric). */
    angle?: number;
    /** Échelle horizontale du fond au moment de la pose. */
    scaleX?: number;
    /** Échelle verticale du fond au moment de la pose. */
    scaleY?: number;
    /** Cap de la carte à la capture. Toujours 0 : les cartes créées par g-plan
     *  sont verrouillées au nord (cf. `PROJECTION_LOCK`). Persisté quand même,
     *  pour qu'une capture d'origine inconnue puisse être reconnue comme telle. */
    bearing?: number;
    /** Origine de l'ancre. */
    source?: GeoAnchorSource;
    /** `true` dès que le fond a été déverrouillé, pivoté ou déplacé depuis sa
     *  pose : la correspondance image ↔ terrain n'est plus garantie.
     *
     *  Doute **réversible** : reverrouiller un fond qui n'a pas bougé le lève,
     *  sans quoi un simple aller-retour sur la case à cocher condamnerait le
     *  géoréférencement. Pour ce qui ne se rattrape pas, voir `fondRemplace`. */
    retouchee?: boolean;
    /** `true` quand le fond de carte a été **remplacé** par une image sans
     *  géoréférencement (import d'un scan local).
     *
     *  Doute **irréversible**, et c'est tout l'intérêt de le distinguer de
     *  `retouchee` : une image locale posée exactement à la place de la capture
     *  ne laisse **aucune** trace géométrique, si bien qu'un reverrouillage
     *  « reconfrontait le fond à sa pose », ne trouvait rien, et effaçait le
     *  doute. Ce drapeau, lui, ne se relit pas. */
    fondRemplace?: boolean;
    /** `true` si des objets métier existaient **déjà** quand le fond a été posé.
     *  Ces dessins n'ont pas été tracés sur cette carte : leurs coordonnées
     *  seraient parfaitement formées et entièrement fausses. */
    dessinsAnterieurs?: boolean;
}
/** Localisation géographique associée à un plan */
export interface GeoLocation extends GeoAnchorParams {
    lat: number;
    lng: number;
    /** Zoom **effectif** de la capture (`maxZoom: 19` écrête le zoom demandé). */
    zoom: number;
    /**
     * Ancre exploitable pour un géoréférencement ? **Champ dérivé** : il est
     * recalculé à chaque écriture de projet par `computeGeoValidity()` et ne doit
     * pas être renseigné à la main. Il valait `true` en dur avant la 2.2.0 — les
     * projets antérieurs le portent donc à `true` sans que rien ne l'ait vérifié.
     */
    valid: boolean;
}
/** Niveau de plancher (RDC, étage, sous-sol...) */
export interface FloorLevel {
    id: string;
    name: string;
    /** Ordre relatif : 0 = RDC, positif = étage, négatif = sous-sol */
    order: number;
    objects: unknown[];
}
/** Surface détectée d'une pièce avec métadonnées */
export interface RoomAreaEntry {
    areaM2: number;
    /** true si le cycle est contenu dans un autre (ex : placard dans une chambre) */
    isNested: boolean;
    centroid: {
        x: number;
        y: number;
    };
}
/** Structure d'un projet de plan d'étage sérialisé */
export interface FloorplanProject {
    version: '5.3.0';
    pixelsPerMeter: number;
    geo?: GeoLocation;
    /** Objets du niveau courant (backward compat — utilisé si floors est absent) */
    objects: unknown[];
    /** Niveaux du bâtiment (RDC, étage 1, sous-sol…) */
    floors?: FloorLevel[];
    meta?: {
        createdAt: string;
        updatedAt: string;
        name?: string;
        /** Adresse du bien diagnostiqué */
        address?: string;
        /** Nom du diagnostiqueur */
        diagnostician?: string;
        /** Numéro de mission */
        missionId?: string;
        /** Modes métier actifs au moment de la sauvegarde (diag, aep, eu, spanc, vrd) */
        workModes?: WorkMode[];
    };
}
/** Descriptif d'une pièce exporté via roomsChanged */
export interface RoomEntry {
    label: string;
    areaM2: number;
    sol?: string;
    solEtat?: string;
    mur?: string;
    murEtat?: string;
    plafond?: string;
    plafondEtat?: string;
    notes?: string;
}
/** Pièces d'un niveau, exportées via roomsChanged */
export interface FloorRooms {
    floorId: string;
    floorName: string;
    order: number;
    rooms: RoomEntry[];
    totalArea: number;
}
/** Statistiques calculées d'un projet */
export interface ProjectStats {
    roomCount: number;
    /** Surface totale brute (hors cycles imbriqués) en m² */
    totalArea: number;
    wallCount: number;
    wallLength: number;
    /** Détail des pièces détectées. Surface brute sur axe des murs — pas une surface Carrez/Boutin. */
    roomAreas?: RoomAreaEntry[];
    /** Linéaires des réseaux par type, en mètres */
    pipeLengths?: Record<string, number>;
}
/** Payload pour l'import de murs détectés dans l'éditeur */
export interface WallsImportPayload {
    walls: WallSegment[];
    bounds: {
        x: number;
        y: number;
        w: number;
        h: number;
    };
    backgroundImageDataUrl?: string;
    /**
     * Pixels de l'image analysée par mètre réel.
     *
     * **Ne vaut quelque chose que si `scaleCalibrated` est `true`.** Jusqu'à la
     * 2.13.0, ce champ était rempli par un ternaire dont les deux branches
     * valaient 50 : le scanner n'avait aucune notion d'échelle et en simulait le
     * calcul, si bien que toutes les surfaces produites étaient fausses **en
     * silence**. Il porte désormais soit l'échelle issue du calage de la photo
     * (brique B), soit le repli `SCANNER_FALLBACK_PIXELS_PER_METER`, et c'est
     * `scaleCalibrated` qui dit lequel.
     */
    pixelsPerMeter: number;
    /**
     * L'échelle vient-elle d'un calage réel — photo redressée puis calée sur une
     * distance relevée au télémètre ?
     *
     * Facultatif, donc absent des charges utiles produites avant la 2.13.0 :
     * `scannerImportScale` traite cette absence comme un refus, ce qui est la
     * lecture juste (rien ne garantissait l'échelle de ces charges-là).
     */
    scaleCalibrated?: boolean;
    /** Distance réelle saisie au calage, en mètres. Purement informatif — sert à
     *  afficher *sur quoi* l'échelle repose. */
    knownDistanceM?: number;
}
