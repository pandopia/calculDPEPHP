# G-Plan

Bibliothèque Angular (19 → 22) pour l'édition de plans d'étage — dessin vectoriel, détection de pièces, import OSM, réseaux, vue 3D.

**Modes métier cumulables** : Diag Immo · AEP · EU · SPANC · AC · VRD — la barre d'outils s'adapte au métier en cours (toggles dans le header). Cf. [docs/API.md → Modes métier](docs/API.md#modes-métier).

**Mode visualisation** : input `[readOnly]="true"` pour passer l'éditeur en lecture seule (consultation de CRI archivé, partage, audit…). Cf. [docs/API.md → Mode visualisation](docs/API.md#mode-visualisation-readonly).

**Navigation dans le plan** : **clic droit maintenu + glisser** déplace la vue (pan) partout ; glisser gauche sur le fond pan aussi (sur un objet, il le déplace) ; `Alt`+glisser, clic molette ou l'outil « Déplacer la vue » (`H`) fonctionnent également. Cf. [docs/API.md → Navigation](docs/API.md#navigation-dans-le-plan-pan).

**Réseaux en polyligne** *(2.1.0)* : un tracé de réseau est désormais **un seul objet**, et non une suite de segments — on le sélectionne, le déplace et le supprime d'un bloc, et son linéaire est sa longueur développée. L'outil **« Nœuds » (`N`)** permet d'en retoucher chaque sommet, comme il le fait pour les murs. Les plans antérieurs restent lus et éditables sans conversion. Cf. [docs/API.md → Réseaux : polyligne](docs/API.md#réseaux--polyligne-et-édition-des-sommets).

**Vue CARTE** *(2.3.0, ouvrages en 2.4.0)* : troisième vue à côté de la 2D et de la 3D — le plan affiché **à sa vraie place** sur nos tuiles (satellite, vectoriel, cadastre IGN en overlay), avec filtre par niveau et export GeoJSON. **En lecture seule**, comme la vue 3D. Sur un plan non géoréférencé le bouton est désactivé **avec le motif** : une carte est persuasive, il n'y a pas de mode « forcer ». Cf. [docs/API.md → Vue CARTE](docs/API.md#vue-carte--ng-gplan-viewer-map).

**Géoréférencement** *(2.2.0)* : un plan dessiné sur un fond de carte s'exporte en **GeoJSON WGS84** (RFC 7946), à afficher sur le MapLibre de l'application hôte. L'ancre de capture est désormais **persistée** — `project.geo` était jusqu'ici purement entrant, donc perdu au premier autosave. ⚠ Deux conséquences pour les hôtes : la **position GPS du bien entre dans chaque projet émis**, et les plans antérieurs doivent être **recapturés** pour être exportables. Cf. [docs/API.md → Géoréférencement](docs/API.md#géoréférencement--export-geojson).

**Formes d'annotation** *(2.1.0)* : rectangle (`X`), cercle (`O`) et flèche (`A`) au glisser, dans l'une des 5 couleurs de la palette — pour commenter un plan comme on annote une photo. Cf. [docs/API.md → Formes d'annotation](docs/API.md#formes-dannotation).

**Intégration dans une app hôte** (navigation/pan au glisser, pièges type modale déplaçable, diagnostic) : [docs/INTEGRATION-EDITEUR.md](docs/INTEGRATION-EDITEUR.md).

**Distribution** : la librairie se livre aujourd'hui sous forme de **tarball** (`make pack`) — cf. [INSTALL.md](INSTALL.md). La publication sur le GitLab Package Registry est câblée dans la CI (job manuel sur tag) mais **pas encore activée** : arbitrage et bascule côté application hôte dans [docs/PUBLICATION-REGISTRY.md](docs/PUBLICATION-REGISTRY.md).

> Version courante : voir [`projects/g-plan/package.json`](projects/g-plan/package.json). Pour récupérer la version installée d'un projet : `node -p "require('g-plan/package.json').version"`.

---

## Table des matières

- [Prérequis](#prérequis)
- [Migration 1.x → 2.0.0](#migration-1x--200)
- [Installation de la librairie](#installation-de-la-librairie)
- [Démarrage rapide](#démarrage-rapide)
- [Mode visualisation](#mode-visualisation)
- [Dessiner un croquis](#dessiner-un-croquis)
- [Zoom et cadrage](#zoom-et-cadrage)
- [Accessibilité — le plan sans le canvas](#accessibilité--le-plan-sans-le-canvas)
- [Composants disponibles](#composants-disponibles)
- [Développement local](#développement-local)
- [Commandes Make](#commandes-make)

---

## Prérequis

- Node.js ≥ 18
- **Angular `>=19.0.0 <23.0.0`** (peers `@angular/common`, `@angular/core`, `@angular/forms`) — soit Angular **19, 20, 21 ou 22**, chaque majeure ayant été validée par un `ng build` de production **et** un test de rendu sur une app hôte réelle. La borne haute n'est relevée d'une majeure qu'après cette validation (cf. [`INSTALL.md → Plage de versions Angular supportée`](INSTALL.md#plage-de-versions-angular-supportée)).
- Fonctionne en application **zoneless** (sans zone.js), mode par défaut des hôtes Angular 21+ — cf. [docs/API.md → Compatibilité zoneless](docs/API.md#compatibilité-zoneless).
- `fabric` **^7.0.0** (peer dependency, installée par npm). ⚠ **Changement majeur en g-plan 2.0.0** : Fabric n'est plus chargé par balise `<script>` — la v6 a supprimé le build global. Cf. [§ Migration 1.x → 2.0.0](#migration-1x--200).
- `maplibre-gl` **`>=5.0.0 <7.0.0`** *(depuis 2.26.0 : v5 **et** v6, un seul paquet)* — ⚠ **sous une v6, deux gestes sont obligatoires**, sans quoi les fonds **vectoriels** (carte vectorielle, cadastre) restent **blancs sans une seule erreur** : servir `maplibre-gl-worker.mjs` **et** `maplibre-gl-shared.mjs`, puis déclarer `maplibreWorkerUrl`. Cf. [INSTALL.md → Compatibilité maplibre-gl](INSTALL.md#compatibilité-maplibre-gl). En v5 le réglage est ignoré, rien à faire. Une v4 ou antérieure reste refusée : WebGL2 par défaut, classes CSS `maplibregl-*` au lieu de `mapboxgl-*`, plugin RTL retiré du core.
- `three` `>=0.160.0 <1.0.0` (peer dependency — utilisée par `<ng-gplan-viewer-3d>`)

---

## Migration 1.x → 2.0.0

**g-plan 2.0.0 passe de Fabric.js v5 à v7.** C'est une version majeure parce que le
**contrat d'intégration change** : Fabric v6 a supprimé son build UMD/global, donc la
balise `<script>` disparaît et Fabric entre dans le bundle de l'application hôte.

Trois gestes côté application hôte :

| # | Geste | Détail |
|---|---|---|
| 1 | **Supprimer** la balise `<script>` Fabric de `index.html` | Elle pointe vers `dist/fabric.min.js`, qui n'est plus publié en v6+ |
| 2 | **Installer** `fabric@^7` | `npm install "fabric@^7"` — c'est une peer dependency |
| 3 | **Relever les budgets** de bundle | +260 ko bruts environ (~+70 ko transférés) sur l'app de démo |

**Rien à faire sur vos données.** Les plans enregistrés sous g-plan 1.x se rechargent tels
quels : le cycle de sérialisation v5 → v7 est couvert par des tests automatisés
(`fabric-serialization.spec.ts`), qui vérifient que `myType`, `data`, `roomName` et
`isPrimary` survivent au rechargement **et** à une re-sérialisation. Un contrôle sur vos
propres plans reste recommandé.

**Guide pas-à-pas pour l'application hôte**, avec vérifications et dépannage :
[`docs/MIGRATION-2.0.md`](docs/MIGRATION-2.0.md).
Contexte technique côté librairie : [`FEATURE-migration-fabric-v5-v7.md`](FEATURE-migration-fabric-v5-v7.md).

---

## Installation de la librairie

### 1. Installer le package

```bash
npm install g-plan
```

> `g-plan` n'est **pas publié sur npmjs.org**. Concrètement, l'installation se fait aujourd'hui depuis le tarball produit par `make pack` : [INSTALL.md → Installer dans le projet cible](INSTALL.md#2-installer-dans-le-projet-cible). La commande ci-dessus ne deviendra exacte qu'une fois la publication sur le registry interne activée ([docs/PUBLICATION-REGISTRY.md](docs/PUBLICATION-REGISTRY.md)).

### 2. Ajouter les peer dependencies

```bash
npm install "fabric@^7" "maplibre-gl@^5" three
```

> ⚠ **Épingle bien `maplibre-gl@^5`.** Depuis la sortie de la v6, un `npm install maplibre-gl`
> nu installe **6.0.0** (`latest`), que le peer `^5.0.0` de g-plan refuse — l'installation du
> tarball échoue alors en `ERESOLVE`, sans le moindre rapport avec Angular :
> `Found: maplibre-gl@6.0.0 … Could not resolve dependency: peer maplibre-gl@"^5.0.0" from g-plan`.
> La v6 n'est pas encore validée avec g-plan (cf. [§ Compatibilité maplibre-gl](INSTALL.md#compatibilité-maplibre-gl)).

`three` est requis uniquement pour la vue 3D (`<ng-gplan-viewer-3d>`) ; tree-shaké si non utilisée.

### 3. Fabric.js — plus rien à faire

Depuis **g-plan 2.0.0**, Fabric est importé par la librairie et résolu par votre
bundler. Il n'y a **plus de balise `<script>` à ajouter** : le paquet `fabric` v6+
ne publie plus de build global (`dist/fabric.min.js` n'existe plus), uniquement
des entrées ESM/CJS.

Si vous migrez depuis g-plan 1.x, **retirez** la ligne suivante de votre
`index.html` — elle ne sert plus à rien et pointe vers un fichier disparu :

```html
<!-- À SUPPRIMER -->
<script src="https://…/fabric@5.5.2/dist/fabric.min.js"></script>
```

> Détail et raison du changement : [INSTALL.md § 4](INSTALL.md#4-fabricjs--installé-par-npm-plus-aucun-script).

### 4. Ajouter les styles MapLibre GL

Dans `angular.json`, section `styles` de votre projet :

```json
"styles": [
  "node_modules/maplibre-gl/dist/maplibre-gl.css",
  "src/styles.scss"
]
```

---

## Démarrage rapide

### Configurer le provider

```typescript
// app.config.ts
import { provideGPlan } from 'g-plan';

export const appConfig: ApplicationConfig = {
  providers: [
    provideGPlan({})    // tout est optionnel — valeurs par défaut suffisent
  ]
};
```

> `provideGPlan` accepte un `Partial<FloorplanConfig>` (`pixelsPerMeter`, `defaultGridSize`, `defaultSnapDistance`, `opencvUrl`, `tileServerUrl`, `tileStyle`, `detection`). Il n'y a **pas** de champ `maplibreToken` — les tuiles OSM publiques fonctionnent sans clé. Détail des champs : [`docs/API.md → FloorplanConfig`](docs/API.md#configuration--floorplanconfig).

### Utiliser le composant tout-en-un

```typescript
import { FloorplanComponent } from 'g-plan';
import { FloorplanProject } from 'g-plan';

@Component({
  standalone: true,
  imports: [FloorplanComponent],
  template: `
    <ng-gplan
      [(project)]="project"
      layout="tabs"
    />
  `
})
export class AppComponent {
  project = signal<FloorplanProject | null>(null);
}
```

### Utiliser l'éditeur seul

```typescript
import { PlanEditorComponent } from 'g-plan';

@Component({
  standalone: true,
  imports: [PlanEditorComponent],
  template: `
    <ng-gplan-plan-editor
      [project]="project()"
      (projectSaved)="onSaved($event)"
      (projectChange)="project.set($event)"
    />
  `
})
```

### Utiliser la vue 3D

```typescript
import { Viewer3DComponent } from 'g-plan';

@Component({
  standalone: true,
  imports: [Viewer3DComponent],
  template: `<ng-gplan-viewer-3d [project]="project()" />`
})
```

---

## Mode visualisation

Pour exposer un plan en consultation seule (CRI archivé, partage, audit…) :

```typescript
@Component({
  standalone: true,
  imports: [PlanEditorComponent],
  template: `
    <ng-gplan-plan-editor
      [project]="project()"
      [readOnly]="true"
    />
  `
})
export class ViewerComponent {
  project = signal<FloorplanProject | null>(null);
}
```

Avec un signal pour basculer entre édition et visualisation à la volée :

```typescript
viewOnly = signal(true);
// puis viewOnly.set(false) pour repasser en édition
```

```html
<ng-gplan-plan-editor
  [project]="project()"
  [readOnly]="viewOnly()"
/>
```

En mode visualisation :

- **Sidebar et boutons d'édition masqués** — badge `👁 Mode visualisation` à la place
- **Canvas inerte** — aucun cadre de sélection ni poignées : `selectable: false` + `evented: false` sur tous les objets (défense en profondeur : `lockMovement*/Rotation/Scaling*`)
- **Inspecteur inactif** — le panneau reste sur « Sélectionnez un objet » puisque rien n'est sélectionnable
- **Outils restants** : sélection (`V`), navigation au doigt (`H`, mode pan)
- **Vue 3D disponible** — toggle `🧊 Vue 3D` dans le header (fonctionne aussi en lecture seule)
- **Panneau « Pièces » masqué** — vue épurée
- **Exports conservés** — JPEG / PNG / SVG accessibles depuis `📁 Exporter`
- **Niveaux navigables** — onglets `RDC / Étage 1 / …` actifs, mais `+` et copie masqués
- **Bascule dynamique** — un effet Angular ré-applique les verrous quand `readOnly` change

Détail complet du comportement : [docs/API.md → Mode visualisation](docs/API.md#mode-visualisation-readonly).

---

## Dessiner un croquis

*Depuis 2.9.0.* Un diagnostiqueur trace vite, souvent au doigt : l'éditeur redresse le geste
au lieu d'exiger de la précision.

- **Angle contraint** — chaque segment de mur s'aligne sur le multiple de **15°** le plus
  proche (±4°, et **±8° sur les multiples de 90°**, l'équerre étant ce qu'on cherche le plus
  souvent). Un trait tracé à 2° de l'horizontale ressort exactement horizontal.
- **Fermeture de boucle** — revenir à moins de **50 cm** du point de départ, après trois murs
  au moins, referme la pièce et clôt le tracé. L'écart de fermeture est réparti sur tous les
  sommets au prorata du chemin parcouru (**répartition de Bowditch**), ce qui referme
  *exactement* sans détruire les angles qu'on vient d'obtenir.
- **Retour visuel** — l'aperçu affiche la cote et l'angle en cours (`3,20 m · 90°`) et change
  de couleur selon l'accroche : ambre sur un nœud ou un mur, sarcelle sur un angle contraint,
  violet sur un alignement, vert quand la boucle peut se fermer.
- **`Maj` maintenue suspend tout le magnétisme** : le trait suit exactement le doigt.

Les tracés de **réseau** restent libres — angles et positions sans contrainte, comme avant.
Détail complet et API exportée : [`docs/API.md`](docs/API.md#magnétisme-de-croquis--angle-contraint-et-fermeture).

### Corriger un croquis — les angles sont partagés

*Depuis 2.10.0.* Les extrémités de murs qui se rejoignent forment un **nœud partagé**, et non
plus deux coordonnées recopiées côte à côte.

- **Tirer un angle entraîne les deux murs qui s'y rejoignent**, dès le **mode Sélection** —
  l'outil « Nœuds » (`N`) n'est plus nécessaire pour cela. Les poignées rondes posées sur les
  extrémités *sont* les nœuds ; une poignée plus grosse et ambrée signale une jonction (trois
  murs ou plus).
- **Glisser un mur entier** emmène avec lui les murs qui s'y rattachent.
- **Une pièce nommée survit au déplacement d'un mur** : son contour suit les nœuds, et son nom,
  ses notes et son lien CRI ne se perdent plus en route.

> **Rien n'est ajouté au format enregistré** : l'identité des nœuds vit en mémoire, le graphe se
> reconstruit de la géométrie au chargement. Un plan enregistré avant ou après la 2.10.0 est le
> même fichier — aucune migration côté application hôte.
> Détail : [`docs/API.md`](docs/API.md#graphe-de-nœuds-partagés).

### Coter un mur au télémètre

*Depuis 2.11.0.* Relever une pièce sans plan ne demande pas que le téléphone mesure à votre
place : le télémètre laser est déjà dans la trousse. Ce qui manquait, c'était de **saisir ce
qu'on vient de lire**.

- **Sélectionner un mur, saisir sa longueur en mètres** (inspecteur → « 📐 Coter (télémètre) »).
  Le mur prend sa cote, **les murs voisins suivent**, et une pièce fermée le reste. Cela vaut
  pour n'importe quelle forme — le rectangle `RoomBox` n'était plus d'aucun secours dès qu'il y
  avait un placard ou un pan coupé.
- **Coter plusieurs murs** : chaque nouvelle saisie tient compte des précédentes.
- **L'écart est affiché, jamais tu.** Six cotes relevées à la main ne sont jamais exactement
  compatibles : le croquis est arbitré au **moindre écart** (les murs cotés sont tenus, les
  autres absorbent), refermé par répartition de Bowditch, et le compte rendu annonce l'écart
  réparti et le pire écart par mur coté. Au-delà de 8 % du périmètre, il passe en orangé.
- **Ce n'est pas la calibration** : « 📏 Calibrer » règle l'échelle du plan, « 📐 Coter » ne
  touche pas à l'échelle et conforme le croquis aux mesures.

> Détail, limites et API exportée : [`docs/API.md`](docs/API.md#cote-saisie-au-mur).

### Décalquer une photo de plan — redressée et calée

*Depuis 2.12.0.* Une photo de plan papier prise de biais restait de biais, et rien ne donnait
son échelle. Le menu **🖼 Fond → 📐 Calque photo (redresser)…** ouvre un assistant en trois
gestes :

1. **Choisir la photo.** Elle est réduite à 2048 px et compressée en WebP, sous un plafond de
   1,5 Mo — les réglages du fond de carte, pour la même raison : une image lourde fait échouer
   l'enregistrement du brouillon, **en silence**.
2. **Poser les quatre coins** du document, à la traîne. La perspective en est déduite : le
   **rapport d'aspect et la focale sont recouvrés**, pas supposés. C'est ce qui fait la
   différence entre 0,1 % et près de 6 % d'erreur sur une prise de vue à 28°.
3. **Caler sur une seule distance connue.** Placez les deux poignées sur une longueur relevée
   au télémètre, saisissez-la, et toute l'image est à l'échelle. Pas de Bluetooth, pas de
   permission, hors ligne, sur tous les téléphones.

- **Le plan ne bouge pas** : c'est le calque qui se met à l'échelle du plan, jamais l'inverse —
  recaler `pixelsPerMeter` réécrirait toutes les longueurs et surfaces déjà saisies.
- **Il reste de la place autour du dessin** *(2.21.0)* : le document est posé au centre d'une
  image plus grande de 12 % de chaque côté. Sans cette marge, les murs de l'enveloppe tombent
  sur la frontière même de l'image redressée, où on ne peut ni les saisir ni les prolonger —
  alors que tracer le contour du bâtiment est le premier geste du relevé. C'est une
  translation : l'échelle, les longueurs et les surfaces sont inchangées.
- **Seule la photo d'origine est enregistrée**, avec la matrice 3×3 : jamais les pixels
  redressés. Plus léger (une image au lieu de deux) et réversible — les coins restent
  modifiables. Le redressement est rejoué à chaque chargement.
- **Zéro WASM, zéro dépendance ajoutée** : ~120 lignes de TypeScript pur (système 8×8,
  élimination de Gauss à pivot partiel), contre les 8 Mo d'OpenCV.js chargés d'un CDN externe.

> Détail, limites et API exportée : [`docs/API.md`](docs/API.md#calque-photo--redressement-et-calage).

### Scanner OpenCV — enfin à l'échelle, et franc quand il ne l'est pas

*Depuis 2.13.0.* Le scanner n'avait **aucune notion d'échelle** : il remplissait le
`pixelsPerMeter` de son export par `clusterDistance > 0 ? 50 : 50`, un ternaire dont les deux
branches valaient 50 — et l'éditeur ne lisait même pas ce champ. Toutes les surfaces qu'il
produisait étaient donc fausses, **en silence**.

- **📐 Redresser et caler la photo…** (barre latérale du scanner) fait passer l'image par le
  même assistant que le calque photo, **avant** la détection : les traits sont cherchés sur une
  image plane et calée, et les murs sortent à moins de 5 % du réel (mesuré à **0,1 %** sur une
  photo à 28° d'inclinaison).
- **Sans calage, l'export est bloqué.** Un bloc d'alerte nomme le manque, et il faut cocher
  explicitement « Envoyer quand même, à l'échelle arbitraire de 50 px/m (surfaces sans valeur) ».
  La case se décoche à chaque changement d'image.
- **L'apport s'adapte au plan**, jamais l'inverse : le `pixelsPerMeter` du plan n'est pas
  réécrit, sinon les cotes déjà saisies et les objets des autres niveaux changeraient de taille
  sans que rien ne le demande.
- **Réinitialiser le plan** *(2.28.0)* : menu **Fichier → ⟲ Réinitialiser le plan…**. La
  confirmation **dit ce qui va disparaître** (« 12 murs, 2 pièces et 3 tracés de réseau »)
  plutôt que de demander « êtes-vous sûr ? », le **fond de plan est conservé** sauf demande
  explicite — il a coûté une capture et parfois un géoréférencement — et l'effacement est
  empilé comme **une seule** commande d'historique : un `Ctrl+Z` rend le plan entier. Seul le
  niveau courant est touché. [Détails](docs/API.md#réinitialiser-le-plan-2280)
- **Outil ⇌ Porteur / cloison** *(2.25.0, mode diag)* : un clic sur un mur le bascule d'un type à
  l'autre, sans le sélectionner — raccourci `T`. La bascule n'existait que comme bouton
  contextuel, ce qui rendait fastidieuse la requalification d'un plan importé, où tout arrive en
  mur porteur. Le matériau saisi et le `wallId` sont conservés.
- **La fusion n'invente pas de mur, et la gomme retire un tronçon** *(2.24.0)* : une extrémité
  déjà posée sur un mur ne se prolonge pas — sans quoi la tolérance large qu'il faut pour
  refermer une pièce traversait les ouvertures — et un vide où la gomme est passée n'est plus
  jamais recollé. La gomme, elle, découpe le mur à ses croisements et n'efface que le tronçon
  visé : après une fusion, un mur de façade est un seul objet, et l'effacer l'effaçait en entier.
- **Les corrections manuelles sont réversibles** *(2.23.0)* : **↶ Annuler / ↷ Rétablir**
  (`Ctrl+Z`, `Ctrl+Maj+Z`) sur tous les gestes — gomme, crayon, fusion, nettoyages. Et
  **recliquer sur un mur effacé le rétablit** : la bascule existait mais était inatteignable, si
  bien qu'effacer était définitif et qu'il fallait redessiner le mur au crayon.
- **Distance de raccord réglable** *(2.23.0)* : jusqu'où un mur inachevé peut être étiré pour en
  rejoindre un autre, affiché en centimètres réels. Elle ne touche **pas** les vides entre murs
  alignés — ce sont les passages de porte, et une tolérance généreuse les reboucherait tous en
  silence.
- **🧲 Aligner et fusionner** *(2.22.0)* : le geste qui manquait après une détection. Les murs
  parallèles qui se ratent de quelques pixels sont ramenés sur un axe commun, les morceaux
  colinéaires deviennent **un seul mur**, et les extrémités libres sont soudées au mur
  perpendiculaire qu'elles frôlent — celui-ci étant **prolongé** s'il s'arrêtait juste avant.
  Fonctionne sur tout le plan ou sur une zone, et rend un compte-rendu chiffré : `40 → 26 murs,
  14 alignés, 9 raccords, déplacement max 7,4 px`. Les tolérances viennent des réglages déjà
  posés (épaisseur de mur, extension) — pas de curseur supplémentaire. L'opération est
  **idempotente** : relancer ne déforme plus rien.
- **Le redressement automatique se raconte en console** *(2.21.0)* : `[G-Plan] Redressement
  auto : …` dit ce qui a été vu (traits par famille, angles, nombre de segments) et, quand il
  n'aboutit pas, **pourquoi** — familles trop pauvres, quadrilatère écrasé, aucun segment.
  Jusque-là il ne disait rien, donc il n'y avait rien à corriger, ni dans les réglages de
  détection, ni dans la prise de vue.
- **OpenCV.js reste chargé du CDN** (~8 Mo de WASM depuis `docs.opencv.org`) : le scanner est
  donc **inutilisable hors ligne**, en vide sanitaire ou en sous-sol. Le sort du composant reste
  ouvert — le retirer serait une majeure.

> Détail, limites et API exportée : [`docs/API.md`](docs/API.md#échelle-du-scanner).

---

## Accessibilité — le plan sans le canvas

*Depuis 2.15.0.* Un `<canvas>` ne contient **rien** pour un lecteur d'écran : tout ce que
g-plan dessine était jusqu'ici strictement inaccessible. L'éditeur publie désormais, en
permanence, une **description textuelle structurée** du plan.

- **Toujours présente dans le DOM**, masquée à l'œil (technique « visually hidden », jamais
  `display: none` qui la retirerait aussi de l'arbre d'accessibilité). Rien ne change à
  l'écran, tout change au lecteur d'écran.
- **Navigable** : un titre par niveau, puis Réseaux et Repérage, en listes imbriquées —
  pièces et surfaces, murs et longueurs, portes et fenêtres avec leur mur porteur,
  revêtements, linéaires de réseau, prélèvements et zones à risque.
- **Le canvas est étiqueté** (`role="img"`, `aria-label`, `aria-describedby`) et renvoie à
  cette description.
- **Un bouton escamoté** — visible à la première tabulation dans la zone du plan — bascule la
  description en panneau lisible à l'œil. Pratique aussi sans handicap : relire les cotes
  d'une pièce sans zoomer, copier la description dans un rapport.
- **Aucun second modèle** : la description dérive du `PlanSummary` déjà produit par
  `PlanAnalysisService`, celui-là même qu'émet `summaryChange`. Elle ne peut donc pas décrire
  autre chose que ce que l'analyse a vu.

```typescript
import { PlanEditorComponent, PlanOutline, planOutlineText } from 'g-plan';

@ViewChild(PlanEditorComponent) editor!: PlanEditorComponent;

const outline: PlanOutline = this.editor.getPlanOutline();   // structure
const texte = planOutlineText(outline);                      // texte brut, pour un rapport
```

Le composant est aussi utilisable seul, sur n'importe quelle synthèse :

```html
<ng-gplan-plan-outline [summary]="summary()" [visible]="true" />
```

**Contraste des tracés.** Quatre couleurs de réseau n'atteignaient pas le seuil de **3:1**
sur le fond blanc du plan (WCAG 2.1 §1.4.11) — EP à 1,81:1, Élec à 1,92:1, Gaz à 2,15:1,
Fibre à 2,43:1 — alors que la couleur est la **seule** chose qui distingue un réseau d'un
autre. Elles ont été assombries (Élec passe au rouge et Fibre au vert, suivant la convention
NF P 98-332), et un test garde le seuil. **Les plans existants ne sont pas retouchés** : la
couleur est sérialisée dans chaque objet, et la légende d'export la dérive du tracé réel.

> Détail, structure produite et API exportée :
> [`docs/API.md`](docs/API.md#alternative-textuelle-du-canvas--accessibilité).

---

## Zoom et cadrage

*Depuis 2.16.0.* Molette pour zoomer (centré sur le curseur), **− / +** et **⤢** (ajuster) dans
la barre d'outils. Bornes 10 % – 800 %.

Un document **s'ouvre cadré**, mais **dès le premier appui sur le plan les cadrages automatiques
cessent** : une capture satellite qui finit de charger ne doit pas déplacer le plan sous
quelqu'un qui a commencé à dessiner.

Poser une image de fond sur un plan vierge **déduit l'échelle de l'image** (document supposé
large d'environ 12 m) et l'annonce ; la calibration (📏) refuse toute échelle sous 10 px/m, qui
ne peut venir que d'un trait trop court. Détail : [`docs/API.md`](docs/API.md#zoom-et-cadrage).

---

## Composants disponibles

| Sélecteur | Composant | Description |
|---|---|---|
| `<ng-gplan>` | `FloorplanComponent` | Scanner + éditeur tout-en-un |
| `<ng-gplan-plan-editor>` | `PlanEditorComponent` | Éditeur de plan seul |
| `<ng-gplan-scanner>` | `ScannerComponent` | Détection de murs via OpenCV.js — redressement et calage intégrés depuis 2.13.0 ([détails](docs/API.md#échelle-du-scanner)) |
| `<ng-gplan-viewer-3d>` | `Viewer3DComponent` | Vue 3D Three.js des murs extrudés |
| `<ng-gplan-viewer-map>` | `ViewerMapComponent` | Vue carte MapLibre — le plan géoréférencé sur nos tuiles (lecture seule) |
| `<ng-gplan-inspector-panel>` | `InspectorPanelComponent` | Panneau d'inspection des objets |
| `<ng-gplan-plan-outline>` | `PlanOutlineComponent` | Description textuelle du plan pour lecteur d'écran ([détails](docs/API.md#alternative-textuelle-du-canvas--accessibilité)) |

### Inputs / Outputs principaux — `PlanEditorComponent`

| Input | Type | Description |
|---|---|---|
| `project` | `FloorplanProject \| null` | Projet à charger |
| `initialWalls` | `WallsImportPayload \| null` | Murs issus du scanner |
| `showHeader` | `boolean` (défaut `true`) | Affiche la barre d'outils en haut |
| `showSidebar` | `boolean` (défaut `true`) | Affiche la palette d'outils à gauche |
| `compactMode` | `boolean` (défaut `false`) | Force le layout mobile (drawer/sheet) sur grand viewport — utile pour iframe / modal |
| `readOnly` | `boolean` (défaut `false`) | Mode visualisation — éditeur en lecture seule, sidebar masquée |
| `autoGeoLayer` | `'osm' \| 'satellite' \| null` | Charge automatiquement le fond carte depuis `project.geo` |
| `geoPoint` | `{ lat; lng; zoom?; layer? } \| null` | Coordonnées GPS envoyées par l'app hôte → fond de carte chargé au zoom max sans modale ([détails](docs/API.md#chargement-géo-direct-geopoint)) |
| `criRooms` | `{ id; name }[]` | Pièces du CRI à lier aux pièces dessinées ([détails](docs/API.md#lier-une-pièce-à-un-cri)) |
| `pendingSamples` | `{ id; label }[]` | Prélèvements CRI à positionner en pose guidée ([détails](docs/API.md#pose-guidée-des-prélèvements)) |
| `canvasWidth` / `canvasHeight` | `number` (1600 / 1200) | Dimensions du canvas Fabric |

| Output | Type | Description |
|---|---|---|
| `projectSaved` | `FloorplanProject` | Projet sérialisé (bouton ↓ JSON) |
| `projectChange` | `FloorplanProject` | Mise à jour continue |
| `summaryChange` | `PlanSummary` | Synthèse structurée du plan (pièces, surfaces, matériaux, ouvertures, réseaux…), émise à chaque modif ([détails](docs/API.md#résumé-du-plan-summarychange--getplansummary)) |
| `roomLinked` | `{ roomId; criRoomId; name }` | Liaison pièce dessinée ↔ pièce CRI validée |
| `samplePlaced` | `{ criSampleId; label; position; floorId }` | Prélèvement CRI posé sur le plan |
| `jpgExported` | `Blob` | Export JPG (avec légende intégrée) |

> **Tablette et stylet** *(2.27.0)* — l'éditeur détecte le pointeur grossier (`pointer: coarse`) **à toute largeur d'écran**, et pas seulement sous le seuil mobile. Une tablette de 960 px CSS garde donc la mise en page bureau, mais reçoit les cibles tactiles : marge de visée sur les murs et les réseaux (cible de 4 → 18 px), poignées de nœuds agrandies, entrées de menu à 44 px. Les menus déroulants se recadrent d'eux-mêmes dans la fenêtre, et le cadrage centre le dessin dans la zone **visible** et non au milieu du canvas. Rien à régler côté hôte, rien n'entre dans le document. [Détails](docs/API.md#le--trou-de-la-tablette--pointeur-grossier-sur-grand-viewport-2270)

> Méthode publique `getPlanSummary(): PlanSummary` (via `@ViewChild`) pour récupérer la synthèse à la demande (ex : au clic « Valider le plan »).

> **Légende automatique** — les exports image (JPEG / PNG) intègrent désormais un panneau « Légende » des éléments réellement présents sur le plan (murs, cloisons, réseaux, ouvertures, zones de risque, équipements…), avec leur symbole et couleur. Placement automatique : **à droite** si l'image est en paysage, **en bas** si elle est en portrait. Le SVG n'est pas concerné. La construction de la légende est exposée via `collectLegendItems()` et les exports correspondants : `ExportService.toJpgWithLegend()` / `toPngWithLegend()`.

### Structure du projet sérialisé

```typescript
interface FloorplanProject {
  version: '5.3.0';
  pixelsPerMeter: number;
  objects: unknown[];          // objets Fabric.js du niveau actif
  floors?: FloorLevel[];       // niveaux (RDC, Étage 1, Sous-sol 1…)
  geo?: GeoLocation;           // coordonnées OSM
  meta?: { name; address; diagnostician; missionId; ... };
}

interface FloorLevel {
  id: string;
  name: string;
  order: number;               // 0 = RDC, >0 = étage, <0 = sous-sol
  objects: unknown[];
}
```

#### Charger un document venu de l'extérieur — `parsePlanDocument`

*Depuis 2.14.0.* Un plan importé, un brouillon `localStorage` ou une charge utile d'app hôte
est **vérifié avant d'être chargé**. Auparavant, `fromFile` regardait deux champs de la racine
puis, sur une version inattendue, écrivait un `console.warn`… **et chargeait quand même** : un
document tronqué se rechargeait à moitié, sans erreur.

```typescript
import { parsePlanDocumentText, planParseErrorMessage } from 'g-plan';

const lu = parsePlanDocumentText(texte);
if (!lu.ok) {
  // « Plan refusé (« floors[2].objects[7].type ») : Objet sans type Fabric… »
  alert(planParseErrorMessage(lu.error));
  return;
}
const plan = lu.value;   // FloorplanProject — inchangé si déjà en 5.3.0
```

- **Refus motivé, jamais de chargement partiel** — l'erreur porte le **chemin JSON** de la
  première violation, donc réparable.
- **Un plan 5.3.0 est rendu inchangé**, par référence : sérialiser → lire → re-sérialiser rend
  un texte identique.
- **Chaîne de migrations, une fonction par saut de version** (`PLAN_MIGRATIONS`, vide
  aujourd'hui : `5.3.0` est le seul format jamais écrit). Le moteur est là **avant** le premier
  saut, parce qu'après il serait trop tard.
- `ExportService.fromFile` continue de rejeter une `Error` — son message **est** le motif.

> Détail des gardes, tolérances et API exportée :
> [`docs/API.md`](docs/API.md#lecture-dun-document-de-plan--parseplandocument).

---

## Développement local

### Cloner et installer

```bash
git clone git@gitlab.com:agileosolutions/g-ordon/g-plan.git
cd g-plan
npm install
```

### Lancer la démo

```bash
make dev
# ou
npm start
```

Ouvre `http://localhost:4200`

### Compiler la librairie (watch)

```bash
make watch
```

### Compiler pour la production

```bash
make build
```

---

## Commandes Make

| Commande | Description |
|---|---|
| `make install` | Installe les dépendances npm |
| `make dev` | Lance la démo en mode développement |
| `make build` | Compile la librairie + la démo |
| `make build-lib` | Compile uniquement la librairie |
| `make build-demo` | Compile uniquement la démo |
| `make watch` | Compile la librairie en mode watch |
| `make pack` | Génère `dist/g-plan-X.Y.Z.tgz` installable dans un projet externe (cf. [INSTALL.md](INSTALL.md)) |
| `make pack-clean` | Supprime les tarballs générés |
| `make test` | Lance les tests unitaires (Karma). Résout `CHROME_BIN` tout seul — Chromium de Playwright, puis Chrome système ; échoue avec un message clair si aucun navigateur n'est disponible |
| `make lint` | Vérifie le code |
| `make clean` | Supprime les artefacts de build |

---

## Licence

MIT — © Agile O Solutions
