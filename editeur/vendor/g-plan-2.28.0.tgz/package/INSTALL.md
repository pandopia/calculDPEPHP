# Installation de g-plan dans un projet externe

Guide pas-à-pas pour intégrer la librairie `g-plan` dans une application Angular existante (**Angular 19, 20, 21 ou 22**), à partir d'un tarball local généré par `make pack`.

> **Le tarball est la voie officielle aujourd'hui.** Une publication sur le GitLab Package Registry est câblée dans la CI (job manuel, déclenché sur tag) mais **n'a pas encore été activée** : tant qu'elle ne l'est pas, c'est bien la procédure ci-dessous qui s'applique. Motivation, arbitrage sur le nom du paquet et procédure de bascule côté application hôte : [`docs/PUBLICATION-REGISTRY.md`](docs/PUBLICATION-REGISTRY.md).

---

## 1. Générer le tarball depuis ce dépôt

```bash
make pack
```

Produit `dist/g-plan-<version>.tgz`. Version courante : **2.28.0** — source de vérité `projects/g-plan/package.json` (`node -p "require('./projects/g-plan/package.json').version"`). Dans les commandes ci-dessous, remplace `<version>` par ce numéro.

> Pour repartir de zéro : `make pack-clean && make pack`

> **Sans rien construire** : chaque push produit le tarball en artefact GitLab, sous une URL
> stable — page du pipeline → job `tarball`, ou
> `…/-/jobs/artifacts/main/raw/dist/g-plan-latest.tgz?job=tarball`. Sur la branche par défaut il
> est en plus déposé, de façon **permanente**, dans le Package Registry du projet. Détail :
> [`docs/PUBLICATION-REGISTRY.md`](docs/PUBLICATION-REGISTRY.md#1bis-récupérer-le-tarball-sans-rien-publier-depuis-2264).

> **La documentation voyage avec le paquet** *(depuis 2.26.3)*. Le tarball embarque `README.md`,
> `INSTALL.md` et `docs/` (API, migration 2.0, intégration éditeur) : après installation, tout est
> lisible dans `node_modules/g-plan/`, sans avoir à retrouver le dépôt. Il ne contenait
> auparavant que le `README.md` du dossier de la librairie — le gabarit laissé par
> `ng generate library` (« This project was generated using Angular CLI »), sans le moindre
> rapport avec g-plan.

---

## 2. Installer dans le projet cible

Dans le projet Angular qui consommera la librairie :

```bash
cd /chemin/vers/projet-cible
npm install /chemin/absolu/vers/g-plan/dist/g-plan-<version>.tgz
```

Ou, plus pratique pour le versionner via `package.json` :

```jsonc
{
  "dependencies": {
    "g-plan": "file:../g-plan/dist/g-plan-<version>.tgz"
  }
}
```

> **Cache npm + Angular** : si tu réinstalles le **même** numéro de version après modification du tarball, le cache npm peut servir l'ancienne version. Nettoyer avant de réinstaller :
>
> ```bash
> npm uninstall g-plan
> rm -rf node_modules/g-plan .angular/cache node_modules/.cache
> npm install /chemin/absolu/vers/g-plan/dist/g-plan-<version>.tgz
> ```
>
> Le repo bumpe désormais la version à chaque correctif (`projects/g-plan/package.json`) pour défaire ce piège — vérifie `package.json` du projet hôte pour confirmer la version effectivement installée.

---

## 3. Peer dependencies

`g-plan` déclare les peer dependencies suivantes — installe-les côté projet cible :

```bash
npm install "fabric@^7" "maplibre-gl@^5" three
```

> ⚠ **Si tu installes une v6, lis [§ Compatibilité maplibre-gl](#compatibilité-maplibre-gl) avant
> de conclure que la carte est cassée.** Depuis g-plan 2.26.0 les deux majeures sont acceptées,
> mais la v6 exige deux gestes de configuration : sans eux, le fond satellite s'affiche et **tous
> les fonds vectoriels restent blancs, sans la moindre erreur**.

Versions attendues :

| Peer dep             | Version       | Note                                                                 |
|----------------------|---------------|----------------------------------------------------------------------|
| `@angular/common`    | `>=19.0.0 <23.0.0` | Angular 19, 20, 21 ou 22 — cf. [§ Plage de versions Angular](#plage-de-versions-angular-supportée). |
| `@angular/core`      | `>=19.0.0 <23.0.0` | idem                                                            |
| `@angular/forms`     | `>=19.0.0 <23.0.0` | idem                                                            |
| `fabric`             | `^7.0.0`      | **Importée par la librairie** depuis g-plan 2.0.0 — plus aucune balise `<script>` (cf. § 4). |
| `maplibre-gl`        | `>=5.0.0 <7.0.0` | v5 **ou** v6. ⚠ Sous une **v6**, deux gestes obligatoires — voir [§ Compatibilité maplibre-gl](#compatibilité-maplibre-gl) — sans quoi les fonds vectoriels restent blancs, en silence. |
| `three`              | `>=0.160.0 <1.0.0` | Utilisé par `<ng-gplan-viewer-3d>`. Importé en bundle via ES modules. Borne haute explicite : `three` n'a pas encore atteint la 1.0, dont l'API sera potentiellement remaniée. |

### Plage de versions Angular supportée

Depuis la **1.8.0**, les peers `@angular/common`, `@angular/core` et `@angular/forms` sont
déclarés en `>=19.0.0 <23.0.0` — la librairie s'installe donc sans `--legacy-peer-deps` sur un
hôte **Angular 19, 20, 21 ou 22**.

**Ce qui a réellement été validé.** Chaque majeure de la plage a été éprouvée par une application
hôte jetable, générée par la CLI de cette majeure, dans laquelle le tarball produit par ce
workspace (compilé en Angular 19, en **Ivy partiel**) a été installé puis construit :

| Hôte | Install sans `--legacy-peer-deps` | `ng build --configuration production` | Rendu + interaction (Playwright) |
|---|---|---|---|
| Angular 20.3.26 (TS 5.9.3, mode zone) | ✅ | ✅ | ✅ canvas, tracé de mur, 0 erreur console |
| Angular 21.2.18 (TS 5.9.3, **zoneless**) | ✅ | ✅ | ✅ canvas, outils, modes métier, 0 erreur |
| Angular 22.0.8 (TS 6.0.3, **zoneless**) | ✅ | ✅ | ✅ canvas, tracé, undo réactif, 0 erreur |

Les builds ont tous été faits **`skipLibCheck: false`**, pour que les `.d.ts` de g-plan (émis par
TypeScript 5.7) soient réellement confrontés au TypeScript de la majeure cible — sans cela une
incompatibilité de typage resterait masquée. Le linker Ivy de l'hôte a bien été exercé
(0 `ɵɵngDeclare*` résiduel dans les bundles produits).

**Politique de relèvement — major par major** : la borne haute n'est relevée d'un cran
(`<23` → `<24`, etc.) **qu'après** validation effective sur cette majeure, par le job de matrice
de compatibilité (`.gitlab-ci.yml`, étape `compat`). Tant que ce n'est pas fait, npm doit signaler
franchement l'incompatibilité plutôt que de laisser un hôte partir sur une version non testée. Le
relèvement de borne est publié en **version mineure** de g-plan (élargir la compatibilité déclarée
modifie le contrat public du paquet, sans être un correctif).

> **Budget de bundle** : sur une application neuve, g-plan pousse le bundle initial autour de
> 1,2 Mo, au-delà du budget par défaut de 1 Mo du schematic Angular. Le build échoue alors sur
> `bundle initial exceeded maximum budget` — ce n'est pas une incompatibilité : relève les budgets
> dans `angular.json` (`initial` à 3 Mo par exemple).

> **Note zoneless** : la librairie fonctionne dans une application configurée en
> `provideExperimentalZonelessChangeDetection()` (Angular 19) /
> `provideZonelessChangeDetection()` (Angular 20+) — voir
> [`docs/API.md → Compatibilité zoneless`](docs/API.md#compatibilité-zoneless). Aucune
> configuration particulière n'est requise côté hôte.

> **Fabric.js** s'installe par npm depuis g-plan 2.0.0 (cf. § 4) — il n'est plus chargé par balise `<script>`. Si tu migres depuis une 1.x, lis [`docs/MIGRATION-2.0.md`](docs/MIGRATION-2.0.md).
>
> **Three.js** est utilisé uniquement par la vue 3D — si tu n'utilises pas `<ng-gplan-viewer-3d>`, tu peux l'installer en `--save-dev` (Angular tree-shake l'import inutilisé en build prod).

### Compatibilité maplibre-gl

*Depuis g-plan **2.26.0**, le peer est `>=5.0.0 <7.0.0` : **v5 et v6 sont acceptées par le même
paquet**.* Les deux ont été éprouvées sur la même application, le même navigateur et le même plan
(cf. [`FEATURE-compatibilite-maplibre-5-6.md`](FEATURE-compatibilite-maplibre-5-6.md)). Une **v4
ou antérieure** reste refusée : upgrade nécessaire, npm refusant deux versions concurrentes en
peer.

#### Sous une v6 : deux gestes obligatoires

**À défaut, le fond satellite s'affiche et TOUS les fonds vectoriels — carte vectorielle,
cadastre — restent blancs, sans la moindre erreur en console.** Ce n'est ni un défaut de g-plan
ni un défaut de MapLibre : la v6 est livrée en trois modules et déduit l'URL de son **worker** de
`import.meta.url`, laquelle désigne le chunk de l'application une fois la librairie empaquetée.
MapLibre cherche alors un fichier que le build n'émet pas ; le worker ne démarre jamais, et c'est
lui qui décode les tuiles **vectorielles** — le raster, lui, est décodé sur le fil principal.

**1. Servir les deux fichiers, côte à côte.** Le worker importe son chunk partagé *relativement à
sa propre URL* : n'en copier qu'un donne exactement le même écran blanc.

```jsonc
// angular.json → projects/<app>/architect/build/options/assets
{
  "glob": "maplibre-gl-{worker,shared}.mjs",
  "input": "node_modules/maplibre-gl/dist",
  "output": "/"
}
```

**2. Déclarer l'URL du worker.**

```ts
provideGPlan({
  // … le reste de la configuration
  maplibreWorkerUrl: '/maplibre-gl-worker.mjs',
})
```

En **v5**, `setWorkerUrl` n'existe pas : le réglage est **ignoré**, le glob ne copie rien, et il
n'y a rien à faire. La même configuration vaut donc pour les deux majeures — c'est ce qui permet
de n'entretenir qu'un seul paquet.

> **Oubli sous une v6 ?** g-plan l'écrit en console au premier chargement de carte, avec les deux
> gestes : `[G-Plan] maplibre-gl 6 détecté sans maplibreWorkerUrl : les fonds VECTORIELS
> resteront BLANCS…`. C'est le seul signal possible — MapLibre, lui, ne dit rien.

> **En développement** : `ng serve` ne sert pas un asset ajouté après son démarrage. Après avoir
> touché à `angular.json`, **redémarrer** — sinon le worker répond 404 et l'écran reste blanc,
> réglage correct ou non.

#### Trois points à instruire avant de passer un parc en v6

Remontés par une intégration réelle (Gordon-PWA), et **hors du périmètre de g-plan** — mais ils
décident du calendrier :

1. **Service worker Angular (`ngsw`).** `ngsw-config.json` ne met en cache **ni les `.mjs`**, ni
   le dossier où atterrissent les deux fichiers : le groupe `app` prend `/*.js` à la racine, le
   groupe `assets` seulement images et polices. Sans ajout explicite, **plus de carte hors
   ligne** — et l'échec ne se voit qu'hors réseau. Les deux fichiers pèsent ~487 ko.
2. **WebGL2 exigé.** Un appareil qui n'en dispose pas perd la carte **entièrement**, là où la v5
   savait retomber sur WebGL1. À confronter au parc réellement déployé.
3. **style-spec v25 et expressions héritées.** Le changelog annonce une erreur *de sévérité
   avertissement* sur les expressions héritées. **Mesuré de notre côté** : le style `osm-bright`
   du TileServer maison en contient **72**, et la v6.1.0 le rend **sans broncher** (vérifié sur
   page nue, hors bundler). Un style client qui en contient davantage est donc à éprouver, mais
   le simple décompte ne prédit rien.

> **Rien n'oblige à migrer.** Le peer accepte les deux majeures : rester en `maplibre-gl@5`
> reste pleinement supporté, et c'est ce que le workspace de g-plan utilise par défaut.


**Vérifier la version installée** :
```bash
npm ls maplibre-gl
# ou
node -p "require('maplibre-gl/package.json').version"
```

**Si v4.x détectée** → upgrader en v5 puis valider les composants cartographiques existants du projet hôte. Breaking changes notables 4 → 5 :

| Changement | Impact côté consommateur |
|---|---|
| WebGL2 par défaut (fallback WebGL1 désactivé) | Vérifier que les environnements cibles supportent WebGL2. Réactivable via `webGLContextAttributes: { failIfMajorPerformanceCaveat: false }`. |
| Classes CSS renommées `mapboxgl-*` → `maplibregl-*` | Adapter les sélecteurs/styles personnalisés. Les styles natifs `maplibre-gl/dist/maplibre-gl.css` utilisent déjà le bon préfixe. |
| Plugin RTL retiré du core | Réinstaller `@mapbox/mapbox-gl-rtl-text` séparément si nécessaire et l'enregistrer via `maplibregl.setRTLTextPlugin(...)`. |
| Types TypeScript renforcés | Peut révéler des `any` implicites — corriger les assertions. |
| `LngLatLike` plus strict | `[lng, lat]` ou `{lng, lat}` uniquement, plus de chaînes string. |

**Smoke-test à passer** sur le projet hôte après upgrade :
- Initialisation `new maplibregl.Map(...)` ne lève pas d'erreur WebGL
- Les markers/popups/contrôles natifs restent stylés
- Les sources/layers personnalisés (`addSource`, `addLayer`) fonctionnent identiquement
- Les événements `move`, `click`, `mousemove`, `idle` se déclenchent
- Le fond de carte de g-plan (`<ng-gplan-osm-modal>` puis `applyBackdrop`) capture correctement la tuile

Si l'upgrade global est impossible à court terme, alternative : **scoper** `g-plan` via `npm` workspaces ou `pnpm` overrides pour qu'il utilise son propre `maplibre-gl@5` — solution palliative et non recommandée car deux instances WebGL coexistantes peuvent entrer en conflit.

---

## 4. Fabric.js — installé par npm, plus aucun `<script>`

```bash
npm install "fabric@^7"
```

C'est tout. Depuis **g-plan 2.0.0**, la librairie fait `import { Canvas, Line, … } from 'fabric'`
et c'est le bundler de l'application hôte qui le résout.

> **Pourquoi ce changement ?** Fabric **v6 a supprimé son build UMD/global** : le fichier
> `dist/fabric.min.js` n'est plus publié (vérifié : 404 en 6.9.1 comme en 7.4.0), le paquet
> n'expose plus que des entrées ESM et CJS via une carte `exports`. Il n'y a donc plus de
> `window.fabric` à charger. Ce n'était pas un choix de confort de notre part : le mode CDN
> n'existe tout simplement plus en amont.
>
> **Effet de bord appréciable** : toute la classe de pannes liée au chargement CDN disparaît —
> notamment le mode d'échec silencieux où une URL invalide laissait l'application démarrer avec
> un canvas jamais initialisé (« Fabric.js non chargé »).

### Si tu migres depuis g-plan 1.x

> Guide pas-à-pas dédié, avec vérifications et dépannage : [`docs/MIGRATION-2.0.md`](docs/MIGRATION-2.0.md).

1. **Supprime** la balise `<script>` Fabric de `src/index.html` — elle pointe vers un fichier
   qui n'existe plus en v6+.
2. **Installe** `fabric@^7` en dépendance npm.
3. **Re-mesure ton bundle** : Fabric passe du CDN au bundle de l'application. Sur l'app de démo
   de ce dépôt, le total initial passe de ~1,16 Mo à ~1,42 Mo (+260 ko bruts, ~+70 ko transférés).
   Les budgets Angular par défaut sont à relever en conséquence.
4. **Recharge tes plans existants** et vérifie-les. La sérialisation a changé de mécanisme (les
   propriétés métier `myType`, `data`, `roomName`, `isPrimary` sont désormais déclarées une fois
   pour toutes au lieu d'être passées à chaque `toJSON`), et g-plan couvre ce cycle par des tests
   automatisés — mais rien ne remplace un contrôle sur tes propres données.

---

## 5. Styles MapLibre GL

Dans `angular.json` du projet cible, section `styles` :

```json
"styles": [
  "node_modules/maplibre-gl/dist/maplibre-gl.css",
  "src/styles.scss"
]
```

---

## 6. Configuration Angular

Dans `app.config.ts` :

```ts
import { ApplicationConfig } from '@angular/core';
import { provideGPlan } from 'g-plan';

export const appConfig: ApplicationConfig = {
  providers: [
    // Tout est optionnel — provideGPlan({}) suffit pour utiliser les valeurs par défaut.
    provideGPlan({
      pixelsPerMeter:      50,
      defaultGridSize:     20,
      defaultSnapDistance: 15,
      // Optionnels (rarement surchargés) :
      // opencvUrl:     'https://docs.opencv.org/4.8.0/opencv.js',
      // tileServerUrl: '',                 // vide = tuiles OSM publiques via MapLibre
      // tileStyle:     'styles/osm-bright',
    }),
  ],
};
```

> Le type `FloorplanConfig` est défini dans `g-plan` — `provideGPlan` accepte un `Partial<FloorplanConfig>`, tu peux ne passer que ce que tu veux surcharger (ou `{}` pour tout laisser par défaut). Il n'existe **pas** de champ `maplibreToken` — les tuiles OSM publiques ne nécessitent pas de clé.

---

## 7. Utilisation minimale

> **Intégrer l'éditeur dans une modale ?** Lis [`docs/INTEGRATION-EDITEUR.md`](docs/INTEGRATION-EDITEUR.md) :
> navigation (pan au glisser), prérequis côté hôte et diagnostic si « le
> déplacement de la carte au clic gauche ne marche pas » (piège n°1 : modale
> déplaçable qui capte le glisser).

### Éditeur complet (édition)

```ts
// app.component.ts
import { Component, signal } from '@angular/core';
import { FloorplanComponent, FloorplanProject } from 'g-plan';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FloorplanComponent],
  template: `<ng-gplan [(project)]="project" layout="tabs" />`,
})
export class AppComponent {
  project = signal<FloorplanProject | null>(null);
}
```

### Mode visualisation (consultation seule)

Pour exposer un plan déjà saisi en lecture seule (CRI archivé, partage public,
audit) — voir aussi [`docs/API.md → Mode visualisation`](docs/API.md#mode-visualisation-readonly) :

```ts
import { PlanEditorComponent, FloorplanProject } from 'g-plan';

@Component({
  selector: 'app-viewer',
  standalone: true,
  imports: [PlanEditorComponent],
  template: `
    <ng-gplan-plan-editor
      [project]="project()"
      [readOnly]="true"
      autoGeoLayer="satellite"
    />
  `
})
export class ViewerComponent {
  project = signal<FloorplanProject | null>(/* ... charger depuis API ... */);
}
```

Avec un signal pour basculer édition ↔ visualisation à la volée :

```ts
viewOnly = signal(true);
// puis viewOnly.set(false) pour repasser en édition — la bascule est dynamique
```

```html
<ng-gplan-plan-editor [project]="project()" [readOnly]="viewOnly()" />
```

---

## 8. Vérification

```bash
ng serve
```

Si le composant s'affiche et que les outils répondent, l'installation est OK.

En cas d'erreur :
- `Cannot find module 'fabric'` au build → Fabric n'est pas installé côté hôte : `npm install "fabric@^7"`
- `bundle initial exceeded maximum budget` → relever les budgets d'`angular.json` (Fabric est désormais bundlé, ~+300 ko)
- Le canvas ne s'affiche pas → vérifier dans la console que `typeof window.fabric` vaut bien `"undefined"` : s'il est défini, une balise `<script>` Fabric traîne encore et fait cohabiter deux versions. Cf. [`docs/MIGRATION-2.0.md`](docs/MIGRATION-2.0.md)
- `provideGPlan is not a function` → la version installée ne correspond peut-être pas, faire `npm install --force g-plan`
- Styles MapLibre cassés → vérifier la section `styles` de `angular.json`

---

## Workflow de développement croisé (lib + projet cible)

Si tu modifies souvent la lib pendant que tu intègres dans le projet cible :

```bash
# Terminal 1 — repo g-plan : rebuild auto à chaque sauvegarde
make watch

# Terminal 2 — repo g-plan : régénère le tarball après chaque rebuild stable
make pack

# Terminal 3 — projet cible : réinstalle le tarball mis à jour
npm install --force /chemin/vers/g-plan/dist/g-plan-*.tgz
```

Pour un cycle plus rapide, tu peux aussi utiliser un lien symbolique avec `npm link` (cf. doc npm), mais le tarball reste la méthode la plus fiable car elle teste exactement ce qui sera publié.

---

## Mise à jour

Quand une nouvelle version de g-plan est publiée :

1. `cd <g-plan-repo> && git pull && make pack`
2. `cd <projet-cible> && npm uninstall g-plan && npm install /chemin/vers/g-plan-X.Y.Z.tgz`
3. Si le projet hôte met en cache un build Angular : `rm -rf .angular/cache node_modules/.cache` avant `ng build` / `ng serve`.

Pour voir le numéro de version courante du dépôt :
```bash
node -p "require('./projects/g-plan/package.json').version"
```

Pour voir la version installée côté projet hôte :
```bash
node -p "require('g-plan/package.json').version"
```

> **À terme, plus de tarball à recopier.** Une fois la publication sur le registry activée, les étapes 1 et 2 se réduisent à `npm install g-plan@X.Y.Z` (ou un `^X.Y.Z` dans le `package.json`), sans binaire committé ni `make pack` sur un poste. Voir [`docs/PUBLICATION-REGISTRY.md`](docs/PUBLICATION-REGISTRY.md).

---

## Tableau récapitulatif des composants exposés

| Sélecteur | Composant | Usage type |
|---|---|---|
| `<ng-gplan>` | `FloorplanComponent` | Scanner + éditeur en onglets ou split |
| `<ng-gplan-plan-editor>` | `PlanEditorComponent` | Éditeur seul (édition **ou** visualisation via `[readOnly]`) |
| `<ng-gplan-scanner>` | `ScannerComponent` | Détection de murs OpenCV à partir d'une image. **OpenCV.js (~8 Mo de WASM) est chargé depuis `docs.opencv.org`** : ce composant, et lui seul, exige une connexion. Depuis la 2.13.0 il redresse et cale la photo avant de détecter, et refuse d'exporter sans calage ([détails](docs/API.md#échelle-du-scanner)) |
| `<ng-gplan-viewer-3d>` | `Viewer3DComponent` | Rendu Three.js du projet (murs extrudés, pipes, regards) |
| `<ng-gplan-inspector-panel>` | `InspectorPanelComponent` | Panneau d'inspection autonome (input `[readOnly]` disponible) |

Référence détaillée : [`docs/API.md`](docs/API.md).
