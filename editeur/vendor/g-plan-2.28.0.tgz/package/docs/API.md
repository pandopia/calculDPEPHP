# G-Plan — API Reference

## Versions d'Angular supportées

Depuis la **1.8.0**, les peer dependencies Angular sont déclarées en
`>=19.0.0 <23.0.0` — la librairie est donc consommable par un hôte **Angular 19, 20, 21 ou 22** :

| Peer                | Plage déclarée      |
|---------------------|---------------------|
| `@angular/common`   | `>=19.0.0 <23.0.0`  |
| `@angular/core`     | `>=19.0.0 <23.0.0`  |
| `@angular/forms`    | `>=19.0.0 <23.0.0`  |
| `three`             | `>=0.160.0 <1.0.0`  |
| `fabric`            | `^7.0.0`            |
| `maplibre-gl`       | `^5.0.0`            |

La borne haute est délibérément conservatrice : elle n'inclut que les majeures validées.
Elle est relevée **une majeure à la fois** (`<22` → `<23`…) après vérification, et ce
relèvement fait l'objet d'une **version mineure** de g-plan. Détails et procédure dans
[`INSTALL.md → Plage de versions Angular supportée`](../INSTALL.md#plage-de-versions-angular-supportée).

### Compatibilité zoneless

La librairie n'utilise pas zone.js : elle repose sur des composants `OnPush`, des
`signal()` / `computed()` et des `output()`. Elle fonctionne donc dans une application
configurée en détection de changement **zoneless** — mode par défaut visé par les hôtes
Angular 21+ :

```ts
// Angular 19
import { provideExperimentalZonelessChangeDetection } from '@angular/core';
// Angular 20+ (même API, renommée)
// import { provideZonelessChangeDetection } from '@angular/core';

export const appConfig: ApplicationConfig = {
  providers: [
    provideExperimentalZonelessChangeDetection(),
    provideGPlan({}),
  ],
};
```

Aucune configuration supplémentaire n'est requise côté hôte, y compris pour les
interactions Fabric (sélection, tracé) et les raccourcis clavier, dont les événements sont
émis hors du contexte Angular.

L'application de démonstration du dépôt (`projects/g-plan-demo`) tourne en zoneless
(zone.js retiré des `polyfills` de `angular.json`), et la suite Playwright `e2e/zoneless.spec.ts`
vérifie en conditions réelles que `window.Zone` est bien absent et que raccourcis clavier,
annuler/rétablir, sélection Fabric et bascule de mode métier rafraîchissent correctement l'UI.

---

## Installation & Setup

```ts
// app.config.ts
import { provideGPlan } from 'g-plan';

export const appConfig: ApplicationConfig = {
  providers: [
    // Tout est optionnel — provideGPlan({}) suffit pour utiliser les valeurs par défaut.
    provideGPlan({
      opencvUrl:           'https://docs.opencv.org/4.8.0/opencv.js',
      pixelsPerMeter:      50,
      tileServerUrl:       '',                  // vide = tuiles OSM publiques via MapLibre
      tileStyle:           'styles/osm-bright',
      defaultGridSize:     20,
      defaultSnapDistance: 15,
    })
  ]
};
```

> Le champ `maplibreToken` **n'existe pas** : MapLibre GL n'a pas besoin de token pour des tuiles OSM publiques (à l'inverse de Mapbox). `provideGPlan` accepte un `Partial<FloorplanConfig>` — passe `{}` pour tout laisser par défaut.

**Fabric.js** est une peer dependency **importée par la librairie** depuis g-plan 2.0.0 —
il suffit de l'installer, il n'y a plus rien à charger dans `index.html` :

```bash
npm install "fabric@^7"
```

> Jusqu'à g-plan 1.x, Fabric était chargé globalement par une balise `<script>` et consommé
> via `window.fabric`. Fabric v6 ayant supprimé son build UMD/global, ce mode n'existe plus :
> la librairie fait désormais `import { Canvas, Line, … } from 'fabric'` et c'est le bundler
> de l'application hôte qui le résout. Cf. [`../FEATURE-migration-fabric-v5-v7.md`](../FEATURE-migration-fabric-v5-v7.md).

Three.js est utilisé par `<ng-gplan-viewer-3d>` et déclaré en peer dependency — l'installer via npm :

```bash
npm install three "maplibre-gl@^5" "fabric@^7"
```

> **three** est exigée en `>=0.160.0 <1.0.0` (borne haute explicite : la 1.0 de Three.js n'est pas encore sortie et son API pourra changer).
>
> **maplibre-gl** est exigée en `^5.0.0` strictement — épingle `@^5` à l'installation, car `latest` vaut désormais 6.0.0 et provoque un `ERESOLVE`. Si le projet hôte est encore sur v4 ou antérieur, voir [`INSTALL.md → Compatibilité maplibre-gl`](../INSTALL.md#compatibilité-maplibre-gl) pour la procédure d'upgrade et les breaking changes à valider.

---

## Composant principal — `<ng-gplan>`

Composant tout-en-un : onglet scanner + éditeur de plan, ou affichage côte-à-côte.

```html
<ng-gplan
  [(project)]="myProject"
  layout="tabs"
  autoGeoLayer="satellite"
  [scannerParams]="{ minLineLength: 30 }"
  (projectChange)="onProjectChange($event)"
  (statsChanged)="onStats($event)"
  (roomsChanged)="onRooms($event)"
  (jpgExported)="onJpg($event)"
  (pngExported)="onPng($event)"
  (svgExported)="onSvg($event)"
/>
```

### Inputs

| Input           | Type                              | Défaut    | Description                                                                  |
|-----------------|-----------------------------------|-----------|------------------------------------------------------------------------------|
| `project`       | `FloorplanProject \| null`        | `null`    | Projet à charger (two-way binding via `model()`)                             |
| `layout`        | `'tabs' \| 'split'`               | `'tabs'`  | Disposition : onglets ou vue partagée                                        |
| `scannerParams` | `Partial<DetectionParams>`        | `{}`      | Surcharge des paramètres de détection du scanner                             |
| `autoGeoLayer`  | `'osm' \| 'satellite' \| null`    | `null`    | Si défini et que `project.geo` est valide, charge automatiquement le fond de carte au démarrage (sans modal) |
| `compactMode`   | `boolean`                         | `false`   | Force le layout compact (drawer/sheet) sur grand viewport — utile pour intégration iframe ou modal étroite. Propagé à `<ng-gplan-plan-editor>`. |
| `readOnly`      | `boolean`                         | `false`   | Active le [Mode visualisation](#mode-visualisation-readonly). Propagé à `<ng-gplan-plan-editor>`. Le scanner reste accessible dans l'onglet « Scanner » — pour masquer le scanner entièrement en consultation, utilisez plutôt `<ng-gplan-plan-editor>` directement. |

### Outputs

| Output          | Type              | Déclencheur                                                                |
|-----------------|-------------------|----------------------------------------------------------------------------|
| `projectChange` | `FloorplanProject`| À chaque modification du canvas (debounce 500 ms) et à la sauvegarde      |
| `statsChanged`  | `ProjectStats`    | Après chaque recalcul de surfaces (ajout/suppression/déplacement de murs)  |
| `roomsChanged`  | `FloorRooms[]`    | Après chaque recalcul de pièces (liste typée par étage)                    |
| `jpgExported`   | `Blob`            | Lors de l'export JPEG                                                      |
| `pngExported`   | `Blob`            | Lors de l'export PNG haute résolution (×3)                                 |
| `svgExported`   | `string`          | Lors de l'export SVG (chaîne XML)                                          |

---

## Composant éditeur seul — `<ng-gplan-plan-editor>`

À utiliser si vous n'avez pas besoin du scanner.

```html
<ng-gplan-plan-editor
  [project]="myProject"
  [initialWalls]="detectedWalls"
  autoGeoLayer="satellite"
  [showSidebar]="true"
  [showHeader]="true"
  [canvasWidth]="1600"
  [canvasHeight]="1200"
  (projectSaved)="onSaved($event)"
  (projectChange)="onChange($event)"
  (statsChanged)="onStats($event)"
  (roomsChanged)="onRooms($event)"
  (jpgExported)="onJpg($event)"
  (pngExported)="onPng($event)"
  (svgExported)="onSvg($event)"
/>
```

### Inputs

| Input           | Type                             | Défaut  | Description                                                                  |
|-----------------|----------------------------------|---------|------------------------------------------------------------------------------|
| `project`       | `FloorplanProject \| null`       | `null`  | Projet JSON sérialisé à charger au démarrage                                 |
| `initialWalls`  | `WallsImportPayload \| null`     | `null`  | Murs détectés par le scanner à importer directement                          |
| `autoGeoLayer`  | `'osm' \| 'satellite' \| null`   | `null`  | Charge automatiquement le fond de carte depuis `project.geo` (sans modal)    |
| `geoPoint`      | `{ lat; lng; zoom?; layer? } \| null` | `null` | Coordonnées GPS fournies par l'app hôte → charge un fond de carte au démarrage **sans passer par la modale**. `zoom` absent → **zoom max (19)**. `layer` absent → `autoGeoLayer` sinon `'satellite'`. **Prioritaire sur `project.geo`.** Cf. § [Chargement géo direct](#chargement-géo-direct-geopoint). |
| `showSidebar`   | `boolean`                        | `true`  | Affiche/masque la barre d'outils latérale                                    |
| `showHeader`    | `boolean`                        | `true`  | Affiche/masque l'en-tête (exports, échelle, niveaux…)                        |
| `canvasWidth`   | `number`                         | `1600`  | Largeur du canvas Fabric en pixels                                           |
| `canvasHeight`  | `number`                         | `1200`  | Hauteur du canvas Fabric en pixels                                           |
| `compactMode`   | `boolean`                        | `false` | Force le layout mobile (drawer sidebar, inspector bottom-sheet) même sur grand viewport. Utile pour les conteneurs étroits (iframe, modal). Sinon le breakpoint 768px déclenche automatiquement le mode compact. |
| `readOnly`      | `boolean`                        | `false` | Mode visualisation seulement — cf. § [Mode visualisation](#mode-visualisation-readonly). Seuls les modes `select` et `pan` restent actifs, tous les objets sont verrouillés en motion, la sidebar/Annuler/Modèles/Fond sont masqués, l'inspecteur passe en lecture seule. |
| `criRooms`      | `{ id; name }[]`                 | `[]`    | Pièces du CRI proposées dans l'inspecteur pour lier une pièce dessinée. Cf. § [Lier une pièce à un CRI](#lier-une-pièce-à-un-cri). |
| `pendingSamples`| `{ id; label }[]`                | `[]`    | Prélèvements amiante du CRI à positionner (pose guidée). Cf. § [Pose guidée des prélèvements](#pose-guidée-des-prélèvements). |

### Outputs

| Output          | Type              | Déclencheur                                                              |
|-----------------|-------------------|--------------------------------------------------------------------------|
| `projectSaved`  | `FloorplanProject`| Clic sur "Sauvegarder" (déclenche aussi le téléchargement JSON)          |
| `projectChange` | `FloorplanProject`| Chaque modification du canvas (debounce 500 ms)                          |
| `statsChanged`  | `ProjectStats`    | Après chaque recalcul de surfaces                                        |
| `roomsChanged`  | `FloorRooms[]`    | Après chaque recalcul de pièces                                          |
| `jpgExported`   | `Blob`            | Lors de l'export JPEG (déclenche aussi le téléchargement)                |
| `pngExported`   | `Blob`            | Lors de l'export PNG haute résolution (déclenche aussi le téléchargement)|
| `svgExported`   | `string`          | Lors de l'export SVG (déclenche aussi le téléchargement)                 |
| `canvasReady`   | `HTMLCanvasElement` | Émis une fois après l'initialisation du canvas Fabric — passe l'élément `<canvas>` natif pour que le parent puisse capturer une vignette à la demande. |
| `loadingState`  | `boolean`         | Relais du chargement interne (importation projet, recalcul, etc.) — utile pour afficher un loader côté parent. |
| `summaryChange` | `PlanSummary`     | Synthèse structurée du plan, émise (debounce ~500ms) à chaque modification. Cf. § [Résumé du plan](#résumé-du-plan-summarychange--getplansummary). |
| `roomLinked`    | `{ roomId; criRoomId; name }` | Émis quand l'utilisateur lie une pièce dessinée à une pièce CRI. |
| `samplePlaced`  | `{ criSampleId; label; position; floorId }` | Émis quand un prélèvement CRI de la file guidée est posé sur le plan. |

Méthodes publiques (via `@ViewChild`) :

- **`getPlanSummary(): PlanSummary`** — synthèse synchrone et à jour, tous niveaux confondus. Idéal au clic « Valider le plan ».
- **`getPlanOutline(): PlanOutline`** *(2.15.0)* — la même chose mise en mots, structurée pour un lecteur d'écran ou un rapport. Cf. § [Alternative textuelle du canvas](#alternative-textuelle-du-canvas--accessibilité).

---

## Composant visionneuse 3D — `<ng-gplan-viewer-3d>`

```html
<ng-gplan-viewer-3d [project]="myProject" />
```

| Input     | Type                       | Description                         |
|-----------|----------------------------|-------------------------------------|
| `project` | `FloorplanProject \| null` | Projet à visualiser en 3D           |

> La visionneuse 3D est aussi **intégrée directement dans l'éditeur** via un toggle `🧊 Vue 3D` dans le header (cf. § [Bascule 2D / 3D](#bascule-2d--3d)) — pas besoin de l'instancier séparément si tu utilises `<ng-gplan-plan-editor>`.

---

## Bascule 2D / 3D

`<ng-gplan-plan-editor>` expose un bouton `🧊 Vue 3D` dans le header qui superpose
la visionneuse Three.js par-dessus le canvas 2D, sans démontage ni perte d'état.
Disponible **en édition comme en mode visualisation** (`readOnly`).

- Au passage en 3D, le projet courant est resérialisé (`buildProjectWithFloors()`) →
  la 3D reflète les dernières modifications, y compris le fond de carte (rendu au sol),
  les murs extrudés, les réseaux (cylindres) et les pictogrammes SPANC/AC.
- Le bouton devient `🗺 Vue 2D` pour revenir au canvas d'édition.
- Bascule **non destructive** : le canvas 2D est juste masqué (`overflow: hidden` +
  overlay `position: absolute`), aucun objet n'est touché.
- La 3D fonctionne même sans mur (plan SPANC/AC à partir d'un simple fond de carte).
- **Rotation auto** : la vue 3D propose un bouton `▶ Rotation` qui fait orbiter la
  caméra autour du plan en continu (effet « démo », ~1 tour / 30 s). Elle s'arrête
  automatiquement à la première interaction (drag/zoom) ou via `⏸ Rotation`.

---

## Modèles de données

### `FloorplanProject`

Structure principale sérialisée (JSON).

```ts
interface FloorplanProject {
  version: '5.3.0';
  pixelsPerMeter: number;
  objects: unknown[];           // objets du niveau courant (compat < multi-étages)
  floors?: FloorLevel[];        // niveaux (RDC, étage, sous-sol…)
  geo?: GeoLocation;
  meta?: {
    createdAt: string;          // ISO 8601
    updatedAt: string;
    name?: string;
    address?: string;
    diagnostician?: string;
    missionId?: string;
    workModes?: WorkMode[];     // modes métier actifs (cf. § Modes métier)
  };
}
```

> **Depuis la 2.14.0, un document venu de l'extérieur se lit par
> [`parsePlanDocument`](#lecture-dun-document-de-plan--parseplandocument)** : gardes écrites à
> la main, chaîne de migrations, et refus motivé portant le **chemin JSON** de la première
> violation (`floors[2].objects[7].type`). Un plan `5.3.0` est rendu **inchangé**.

### `FloorLevel`

```ts
interface FloorLevel {
  id: string;
  name: string;
  order: number;   // 0 = RDC, >0 = étage, <0 = sous-sol
  objects: unknown[];
}
```

### `ProjectStats`

```ts
interface ProjectStats {
  roomCount: number;
  totalArea: number;     // m² bruts (axe des murs)
  wallCount: number;
  wallLength: number;    // mètres linéaires
  roomAreas?: RoomAreaEntry[];
  /** Linéaires des réseaux par type, en mètres (clé = FloorplanObjectType) */
  pipeLengths?: Record<string, number>;
}
```

### `FloorRooms` / `RoomEntry`

Émis via `roomsChanged` pour chaque étage détecté.

```ts
interface FloorRooms {
  floorId:   string;
  floorName: string;
  order:     number;
  rooms:     RoomEntry[];
  totalArea: number;     // m² bruts cumulés de l'étage
}

interface RoomEntry {
  label:       string;   // nom de la pièce (ex: "Salon")
  areaM2:      number;
  sol?:        string;   // matériau sol
  solEtat?:    string;   // état du sol
  mur?:        string;
  murEtat?:    string;
  plafond?:    string;
  plafondEtat?: string;
  notes?:      string;
}
```

### `WallsImportPayload`

Résultat du scanner, passable directement à `initialWalls`.

```ts
interface WallsImportPayload {
  walls: WallSegment[];
  bounds: { x: number; y: number; w: number; h: number };
  backgroundImageDataUrl?: string;
  /** Pixels de l'image analysée par mètre réel — ne vaut quelque chose que si
   *  `scaleCalibrated` est `true`. */
  pixelsPerMeter: number;
  /** Depuis 2.13.0 — l'échelle vient-elle d'un calage réel ? */
  scaleCalibrated?: boolean;
  /** Depuis 2.13.0 — distance relevée au télémètre ayant servi au calage (m). */
  knownDistanceM?: number;
}
```

> **`scaleCalibrated` n'est pas décoratif.** Jusqu'à la 2.13.0, `pixelsPerMeter` était rempli
> par `clusterDistance > 0 ? 50 : 50` — un ternaire dont les deux branches valaient 50 — et
> **l'éditeur ne lisait pas ce champ**. Une charge utile sans `scaleCalibrated: true` est donc
> traitée comme non calée : les murs entrent à leurs pixels bruts et un avertissement part en
> console. Cf. § [Échelle du scanner](#échelle-du-scanner).

### `GeoLocation`

```ts
interface GeoLocation {
  lat: number;
  lng: number;
  zoom: number;
  valid: boolean;
}
```

---

## Configuration — `FloorplanConfig`

```ts
interface FloorplanConfig {
  opencvUrl:            string;   // CDN OpenCV.js
  pixelsPerMeter:       number;   // échelle initiale (px/m)
  tileServerUrl:        string;   // TileServer GL (vide = OSM raster)
  tileStyle:            string;   // nom du style (ex: 'osm-bright')
  defaultGridSize:      number;   // grille snap (px)
  defaultSnapDistance:  number;   // distance snap nœuds (px)
  backdropCaptureWidth?:  number; // largeur capture fond carte (px CSS, défaut 1280)
  backdropCaptureHeight?: number; // hauteur capture fond carte (px CSS, défaut 960)
  maplibreWorkerUrl?:   string;   // OBLIGATOIRE sous maplibre-gl 6 — voir ci-dessous
  detection?:           Partial<DetectionParams>;
}
```

### `maplibreWorkerUrl` — v5 et v6 dans un seul paquet *(2.26.0)*

Le peer est `>=5.0.0 <7.0.0` : **les deux majeures passent par le même paquet**, la surface
d'API utilisée par g-plan n'ayant pas changé (mesuré ligne à ligne contre le changelog 6.0.0,
cf. [`FEATURE-compatibilite-maplibre-5-6.md`](../FEATURE-compatibilite-maplibre-5-6.md)).

**Un seul point demande une configuration, et il est vicieux.** La v6 est livrée en trois
modules et déduit l'URL de son **worker** de `import.meta.url` — laquelle, une fois la librairie
empaquetée dans l'application, désigne le **chunk de l'application**. MapLibre cherche alors un
`maplibre-gl-worker.mjs` que le build n'émet pas, et le worker ne démarre jamais. Or c'est lui
qui décode les tuiles **vectorielles** : le raster est décodé sur le fil principal. D'où un
symptôme dissymétrique et **muet** — satellite intact, carte vectorielle et cadastre **blancs**,
zéro erreur de page, l'échec ayant lieu dans un worker mort-né.

> **Ce que casse un worker absent, exactement.** Tout ce qui passe par lui : les tuiles
> **vectorielles** *et* les données **GeoJSON**, c'est-à-dire **le plan lui-même** — murs, réseaux,
> pièces. Le raster, décodé sur le fil principal, continue de s'afficher. On obtient donc une
> carte qui paraît fonctionner, avec un fond satellite net et **pas un seul trait dessus**.

Deux gestes côté hôte, détaillés dans
[`INSTALL.md → Compatibilité maplibre-gl`](../INSTALL.md#compatibilité-maplibre-gl) :
servir `maplibre-gl-worker.mjs` **et** `maplibre-gl-shared.mjs` **côte à côte** (le premier
importe le second relativement à sa propre URL), puis déclarer `maplibreWorkerUrl`.

**Sous une v5, le réglage est ignoré** — `setWorkerUrl` n'y existe pas, le worker étant embarqué
dans l'UMD. La même configuration vaut donc pour les deux majeures.

| Symbole | Rôle |
|---|---|
| `loadMapLibre(workerUrl?)` | Import **dynamique** de maplibre-gl (≈1 Mo : une application qui n'ouvre jamais de carte ne le télécharge pas), pose l'URL du worker si la version l'exige, et rend `{ Map, Popup, LngLatBounds }`. |
| `applyMaplibreWorkerUrl(racine, url?)` | `'not-needed'` · `'applied'` · `'missing'` (v6 sans URL). Exportée et testée : c'est elle qui décide si les fonds vectoriels **et les données du plan** s'afficheront. **C'est la VERSION qui décide, pas la présence de `setWorkerUrl`** — cette fonction existe aussi en v5 (héritage des builds CSP), et s'y fier posait une URL inexistante sous une v5 : le worker ne démarrait plus, et avec lui ni les tuiles vectorielles ni le GeoJSON du plan. Corrigé en 2.26.5. |
| `MAPLIBRE_WORKER_WARNING` | Le message écrit **une fois** en console quand le réglage manque sous une v6. Il porte les **deux gestes**, pas seulement le constat — un message qui dit « ça ne marche pas » sans dire quoi faire est un demi-signal. |

> **Taille du fond de carte** : la capture cartographique (auto via `geoPoint`/`project.geo`)
> fait par défaut **1280×960 px CSS** (× `devicePixelRatio` pour les pixels réels). À zoom
> constant, augmenter ces valeurs capture **plus de terrain** autour du point — au prix d'une
> image base64 plus lourde dans le projet. Surcharge globale via `provideGPlan({ backdropCaptureWidth, backdropCaptureHeight })`,
> ou par instance via `geoPoint.width` / `geoPoint.height`.

---

## Responsive & mobile

L'éditeur s'adapte automatiquement au viewport et au type de pointeur — aucun réglage n'est nécessaire côté consommateur dans la plupart des cas.

### Breakpoints

| Trigger                                         | Effet                                                                                          |
|-------------------------------------------------|------------------------------------------------------------------------------------------------|
| `@media (max-width: 768px)`                     | Layout compact complet (drawer sidebar, inspector bottom-sheet, floor tabs en bottom-bar)      |
| `@media (max-height: 500px) and (max-width: 932px)` | Paysage compact (téléphone à l'horizontale) — header ultra-réduit, floor tabs en haut         |
| `@media (pointer: coarse)`                      | Touch targets élargis à 44×44px sur tous les boutons + grille de snap auto à 30px (vs 20) + **précision de visée sur le canvas** (voir ci-dessous) |
| Input `compactMode={true}`                      | Force le layout compact, même sur grand viewport (utile pour iframe / modal étroite)           |

### Layout compact

| Élément          | Desktop                              | Compact (mobile / `compactMode`)                                                  |
|------------------|--------------------------------------|-----------------------------------------------------------------------------------|
| Sidebar          | Fixe à gauche, 200px                  | Drawer slide-in depuis la gauche (78vw, max 280px), backdrop, ferme après l'outil |
| Inspector        | Panneau latéral droit, 224px          | Bottom-sheet rétractable, max 50vh, poignée visuelle                              |
| Floor tabs       | Inline dans le header                 | Bottom-bar fixe, scroll horizontal, touch targets 44px                            |
| Modals (OSM, ajout niveau, etc.) | Centré, taille fixe         | Plein écran (100vw / 100dvh)                                                      |
| Header           | Une seule ligne, dropdowns visibles   | Pile multi-ligne, scroll horizontal des modes/floor tabs                           |
| Bouton hamburger | Caché                                | Visible à gauche du titre, ouvre le drawer sidebar                                |

### Variables CSS exposées

```scss
:host {
  --gplan-touch-target-min: 44px;   // surchargeable par le parent
  --gplan-mobile-bp: 768px;
}
```

### `touch-action: none`

Appliqué automatiquement aux deux canvas (Fabric et Three.js) — empêche les conflits pinch-zoom / scroll de la page parente sur tactile. Si tu intègres l'éditeur dans un conteneur scrollable, c'est déjà géré.

### Le « trou de la tablette » — pointeur grossier sur grand viewport *(2.27.0)*

Le responsive connaissait deux mondes : le téléphone (`max-width: 768px` → layout compact) et le poste de travail (pointeur fin). Une tablette n'est ni l'un ni l'autre : une Galaxy Tab S10 Lite expose **960 px CSS de large** en paysage — au-dessus du seuil compact, donc layout bureau, ce qui est le bon choix — **avec un pointeur grossier**. Elle héritait donc des cibles pensées pour la souris.

Le critère retenu est `@media (pointer: coarse)`, **sans condition de largeur** : c'est la seule requête qui parle de la *façon de viser*, et la seule qui distingue une tablette d'un portable de même largeur.

#### Sur le canvas — `pointer-precision.const`

Le CSS ne peut rien pour ce qui est dessiné dans un `<canvas>`. Un mur est une `fabric.Line` : sa zone de visée fait la largeur du trait, soit **4 px**. Le service pose donc une **marge de visée** sur les objets fins.

| Réglage | Pointeur fin | Pointeur grossier | Effet |
|---|---|---|---|
| `hitPaddingPx` | 0 | 7 | `padding` Fabric — la cible d'un mur passe de 4 à **18 px** |
| `targetFindTolerance` | 0 | 7 | tolérance du test « par pixel », dont dépendent les polylignes de réseau |
| `handleScale` | 1 | 1,4 | rayon des poignées de nœuds (murs et réseaux) |
| `gridScale` | 1 | 1,5 | pas de grille du magnétisme (20 → 30 px) |

```ts
import { pointerPrecision, coarsePointer, isFineTarget, PointerPrecision } from 'g-plan';

const p: PointerPrecision = pointerPrecision(coarsePointer()); // lit `(pointer: coarse)`
```

Deux points de conception :

- **rien n'entre dans le document.** `padding` ne figure pas dans la liste sérialisée par `toObject()` de Fabric, et la tolérance vit sur le canvas. Un plan dessiné sur tablette et un plan dessiné au bureau restent le même fichier ;
- **la liste `FINE_TARGET_TYPES` est fermée** (murs, cloisons, les neuf réseaux, portes, fenêtres, cotes). Élargir la cible d'un objet déjà large ne gagne rien et coûte un vol de clic : une `RoomBox` élargie de 7 px déborderait sous le mur qui la borde. `FabricCanvasService.pointerPrecision()` expose les réglages en vigueur.

#### Menus déroulants — `KeepInViewportDirective`

Les menus « Fond », « Fichier » et « Copier depuis » sont ancrés sous leur bouton en `position: absolute`. Collé au bord droit, le menu « Fond » (240 px) sortait de **moitié** sur une fenêtre de 960 px : l'entrée « Supprimer le fond », en bas, devenait inatteignable. Aucune propriété CSS ne borne un élément absolu sur la *fenêtre* — il faut mesurer.

```html
<div class="ngf-dropdown-panel" ngGplanKeepInViewport>…</div>
```

Le calcul est pur et testable sans navigateur (`clampShiftX` dans `viewport-clamp.const`) ; la directive ne fait que mesurer et écrire. Elle corrige **à l'horizontale seulement**, réagit au redimensionnement et à la rotation, et est idempotente. Elle écrit la propriété `translate` et non `transform`, qui appartient à l'animation d'ouverture du panneau.

#### Cadrage — centrer dans la vue, pas dans le canvas

`zoomToFit` calculait son zoom sur la zone visible mais recentrait sur le **milieu du canvas** (1600 × 1200 par défaut, une entrée de l'hôte sans rapport avec la place disponible). Tant que le canvas tient dans la fenêtre, les deux milieux coïncident et personne ne voit rien ; dès qu'il déborde, `.ngf-editor__canvas-area` l'aligne au début et le milieu du canvas tombe **hors écran**. Mesuré sur 960 × 500 visibles : le fond de carte atterrissait à (800, 600), soit au-delà des deux bords — d'où « le fond de carte ne se met pas au milieu de l'écran ».

Corrigé pour `zoomToFit`, `zoomBy` et `resetZoom`, qui acceptent désormais la taille de la vue :

```ts
fabricSvc.zoomToFit(48, { width: 960, height: 500 });
fabricSvc.zoomBy(1.25, { width: 960, height: 500 });  // point fixe = milieu de la VUE
fabricSvc.resetZoom({ width: 960, height: 500 });
```

Sans l'argument, le comportement est celui d'avant (milieu du canvas) — le poste de travail ne bouge pas.

#### Cibles tactiles ajoutées au bandeau

Entrées de menu déroulant (44 px), boutons de zoom (40 px), curseurs d'échelle et de rotation (piste de 32 px), cases à cocher (20 px). Le panneau déroulant s'élargit à 264 px.

### Bouton « Recadrer » (3D)

`<ng-gplan-viewer-3d>` expose une méthode publique `resetCamera()` et un bouton ⟲ en haut-gauche du canvas qui recadre la caméra autour du bâtiment.

---

## Réinitialiser le plan *(2.28.0)*

Menu **Fichier → ⟲ Réinitialiser le plan…** — masqué en lecture seule. C'est la seule commande de l'éditeur qui détruit tout d'un coup ; elle est construite autour de trois précautions.

**1. La confirmation dit ce qui va disparaître.** « Êtes-vous sûr ? » n'informe de rien et on y répond oui par réflexe. La modale affiche le décompte réel — *« Le niveau RDC contient 12 murs, 2 pièces et 3 tracés de réseau. Tout sera effacé. »* — et rappelle, quand il y a plusieurs niveaux, que les autres ne sont pas touchés.

**2. Le fond de plan ne part pas par défaut.** Un fond de carte a coûté une capture réseau, un calage, parfois un géoréférencement : le reprendre parce qu'on recommence son croquis serait une punition. Une case « Supprimer aussi le fond de plan » apparaît s'il y en a un ; cochée sur un plan géoréférencé, elle affiche un avertissement (les coordonnées sont conservées, mais la carte devra être recapturée). La case repart décochée à chaque ouverture — un choix destructeur ne se garde pas d'une fois sur l'autre.

**3. C'est annulable.** Les suppressions sont encadrées par `pauseSaving()` / `resumeSaving()` : l'historique les empile en **une seule** commande de groupe, donc **un** Ctrl+Z rend le plan entier — pas un par objet.

Le bouton « Tout effacer » est **désactivé avec le motif** quand il n'y a rien à effacer, plutôt que d'ouvrir une confirmation qui ne confirmerait rien. Tant que la modale est ouverte, elle capte le clavier : Échap annule, et ni « Suppr » ni les raccourcis d'outils ne passent derrière elle.

### API exportée — `plan-reset.const`

Couche pure : ni Fabric, ni DOM. Elle travaille sur tout objet portant un `myType`, donc aussi bien sur les objets vivants du canvas que sur leur forme sérialisée.

| Symbole | Rôle |
|---|---|
| `planReset(objects, scope?)` | Décrit ce que la réinitialisation retirerait : `{ removed, kept, counts, empty }`. Ne modifie rien. |
| `resetSummaryText(counts)` | Phrase française du décompte — « 2 murs, 1 pièce et 3 tracés de réseau ». Chaîne **vide** si rien n'est compté : « 0 objet » se lit comme une erreur. |
| `ResetPlan<T>` / `ResetCounts` / `ResetScope` | Types associés. |

```ts
import { planReset, resetSummaryText } from 'g-plan';

const plan = planReset(canvas.getObjects(), { includeBackground: false });
if (!plan.empty) console.log(resetSummaryText(plan.counts)); // « 12 murs et 2 pièces »
```

Deux règles de périmètre, toutes deux délibérées : les **calques de fond** (`Backdrop`, `PhotoLayer`) sont conservés sauf demande explicite ; les **objets dérivés** (cotes, étiquettes, pièces détectées, poignées) partent avec le reste mais ne sont **pas comptés** — ils sont régénérés depuis la géométrie, et les annoncer gonflerait le décompte d'objets que l'utilisateur n'a jamais posés.

C'est la **même fonction** qui alimente la confirmation et l'exécution : l'annonce ne peut pas diverger de ce qui sera fait.

---

## Modes métier

L'éditeur expose en haut de l'interface une rangée de toggles **cumulables** qui filtrent les outils visibles dans la barre latérale. Les objets déjà tracés sur le canvas restent visibles quel que soit le mode sélectionné — seul le menu d'outils est filtré.

```ts
type WorkMode = 'diag' | 'aep' | 'eu' | 'spanc' | 'ac' | 'vrd';
```

| Mode    | Libellé                  | Outils visibles                                                                          |
|---------|--------------------------|------------------------------------------------------------------------------------------|
| `diag`  | Diagnostic immobilier    | Structure · Ouvertures · Équipements techniques · Repérage diagnostic · Annotations      |
| `aep`   | Adduction Eau Potable    | Structure · Pipe AEP · Annotations                                                       |
| `eu`    | Eaux usées               | Structure · Pipe EU/EP · Annotations                                                     |
| `spanc` | SPANC                    | Structure · Pipes EU/EM/EV/EP/Vent · Schéma SPANC (5 sous-groupes) · Points SPANC · Ann. |
| `ac`    | Assainissement collectif | Structure · Pipes EU/EM/EV/EP/Vent · AC Regards · AC Repères réseau · AC Étiquettes · Ann. |
| `vrd`   | Voirie Réseaux Divers    | Structure · Tous les pipes (AEP/EU/EP/Gaz/Élec/Fibre) · Annotations                      |

### Persistance

Précédence : `project.meta.workModes` > `localStorage['gplan-work-modes']` > `['diag']` (défaut).

À la sauvegarde, les modes actifs sont sérialisés dans `meta.workModes`. Au rechargement d'un projet, ces modes prennent le dessus sur la préférence locale — utile pour qu'un projet SPANC réactive automatiquement le bon outillage chez n'importe quel diagnostiqueur.

### Comportement

- Au moins un mode reste actif en permanence (impossible de tout désactiver).
- Si l'outil courant disparaît suite à la désactivation d'un mode, l'éditeur retombe en mode `select`.
- Le filtre se fait **par outil** (chaque outil déclare ses `WorkMode[]`) — pas de doublon dans la sidebar quand plusieurs modes partagent un même outil (ex : pipe EU partagé entre EU/SPANC/VRD).

---

## Réseaux & pictogrammes SPANC

### Types de pipes

| Mode `EditorMode` | `myType`     | Couleur    | Style        | Disponible en mode |
|-------------------|--------------|------------|--------------|--------------------|
| `pipe-aep`        | `PipeAEP`    | `#2563eb`  | continu      | aep, vrd            |
| `pipe-eu`         | `PipeEU`     | `#7c3aed`  | continu      | eu, spanc, ac, vrd  |
| `pipe-em`         | `PipeEM`     | `#a16207`  | continu      | spanc, ac           |
| `pipe-ev`         | `PipeEV`     | `#78350f`  | continu      | spanc, ac           |
| `pipe-ep`         | `PipeEP`     | `#0e7490`  | tirets 8/4   | eu, spanc, ac, vrd  |
| `pipe-vent`       | `PipeVent`   | `#6b7280`  | pointillé 3/3 | spanc, ac          |
| `pipe-gaz`        | `PipeGaz`    | `#d97706`  | tirets 10/4  | vrd                |
| `pipe-elec`       | `PipeElec`   | `#b91c1c`  | tirets 6/3   | vrd                |
| `pipe-fibre`      | `PipeFibre`  | `#15803d`  | tirets 4/4   | vrd                |

Les linéaires de tous ces types apparaissent dans `ProjectStats.pipeLengths`.

> **Quatre couleurs ont changé en 2.15.0** (EP, Gaz, Élec, Fibre) : elles n'atteignaient pas
> le contraste de 3:1 exigé sur le fond blanc du plan, alors que la couleur est la seule chose
> qui distingue un réseau d'un autre. Détail des mesures, teintes retenues et effet sur les
> plans existants (aucun) : [Contraste des tracés](#contraste-des-tracés--mesuré-puis-corrigé).
> La palette est désormais **exportée** (`PIPE_COLORS`) et non plus recopiée à cinq endroits.

### Comportement de tracé des réseaux

> **Depuis la 2.0.0** — pendant qu'un tracé est **en cours**, les dessins existants sont rendus **inertes** : un appui qui retombe sur un objet pose un point de plus au lieu de clôturer la polyligne. C'est indispensable au doigt, où la zone de contact est large et où l'appui suivant retombait presque toujours sur le segment qu'on venait de tracer — Fabric prenait alors la main (cadre de sélection et poignées) et le tracé était perdu. Le **déplacement au clic reste possible hors tracé**, outil réseau actif. Par ailleurs, un appui à moins de **6 px** du point précédent ne crée plus de segment : cela supprime le segment de longueur nulle produit par le 2e clic d'un double-clic ou d'un double-tap.

Les outils de réseau (`pipe-*`) se distinguent des murs/cloisons sur plusieurs points :

- **Un tracé = un objet** (voir « Réseaux : polyligne » ci-dessous).
- **Angles libres** : aucun magnétisme (ni grille, ni nœud) n'est appliqué aux traits de réseau — chaque point suit exactement le curseur, pour tracer les angles voulus. Les murs/cloisons gardent leur snap intelligent (nœud → mur → grille).
- **Toujours sous les autres dessins** : le tracé est renvoyé au fond, juste au-dessus du fond de carte, donc **sous** les pictogrammes (fosses, boîtes de branchement, regards…). Le classement est aussi ré-appliqué au chargement d'un projet.
- **Fin au double-clic** (souris) : un double-clic termine le tracé en cours. Le clic droit et `Échap` terminent également le tracé.
- **Bouton « ✓ Terminer le tracé »** (en-tête) : il ne s'affiche **que pendant un tracé** — pas dès qu'un outil de tracé est actif. *Corrigé en 2.26.1* : il suivait l'outil, si bien qu'après un double-clic ou un clic droit il restait affiché, proposant de terminer ce qui l'était déjà. Le motif d'origine du découplage (« l'état bascule hors zone Angular, la détection de changements ne suivrait pas ») ne tenait plus : `FabricCanvasService.isPolylineDrawing` est un **signal**, et un signal lu dans un gabarit notifie Angular par le graphe de dépendances — zone ou pas, ce qui est d'ailleurs la seule façon fiable en application zoneless.
- **Déplacement en cours de tracé** : pendant qu'un outil réseau est actif, un **clic gauche sur un dessin existant** (pictogramme, boîte, tuyau…) le rend déplaçable — le tracé en cours est clôturé et l'objet peut être repositionné sans quitter l'outil. Un clic dans le vide continue le tracé.

### Cadastre — une définition, deux cartes *(2.26.2)*

Le cadastre est posé à deux endroits : la **vue carte** et la **capture de fond de plan**
(« Fond → Importer depuis la carte »). Les deux écrivaient leurs couches chacune de leur côté, et
elles avaient divergé : la capture ajoutait une couche `type: 'raster'` sur une source devenue
**vectorielle** (le PCI est lu en `.pbf` depuis la 2.4.0). MapLibre refuse cet attelage — la
couche n'est jamais peinte, et le refus part dans `map.on('error')`, que la capture n'écoutait
pas. **Cocher « Cadastre » ne faisait donc rien du tout, sans un mot** : le même motif de panne
muette que le `STYLE=bdparcellaire` inexistant, corrigé en 2.4.0.

`cadastreOverlayLayers(config, source, prefixe?)` est désormais la **définition unique** — le
type des couches suit le type de la source, en un seul endroit :

| Source | Couches rendues |
|---|---|
| vectorielle (défaut, PCI `.pbf`) | `fill` sur `batiment` · `line` sur `parcelle` · `symbol` sur `localisant` (numéros) |
| raster (hôte servant ses propres tuiles, `cadastreTilesUrl`) | une seule couche `raster` |

Le motif de numéro répété dans la parcelle (`fill-pattern`) reste **propre à la vue carte** : il
exige de fabriquer les images à la demande (`styleimagemissing`), ce qu'une capture n'a ni les
moyens ni l'usage de faire.

**Mesuré** : avec l'ancien code, **0 tuile PCI** demandée après avoir coché « Cadastre » dans la
modale de capture — une source qu'aucune couche valide ne consomme n'est jamais chargée. Avec la
définition partagée : **15 tuiles, toutes en 200**.

### Réseaux : polyligne et édition des sommets

> **Depuis la 2.1.0** — un tracé de réseau est **un seul objet `fabric.Polyline`** portant tous ses sommets, là où les versions antérieures produisaient une suite de `fabric.Line` indépendantes. Le sélectionner, le déplacer ou le supprimer agit sur le tracé entier ; son linéaire est la **longueur développée**, et sa cote (`PipeMeasurement`) se pose au milieu de ce développé.

Les murs et cloisons restent, eux, **un objet par segment** : chacun porte son matériau, sa lettre de repérage et ses ouvertures propres.

**Édition des sommets.** L'outil **« Nœuds » (`N`)** pose une poignée carrée sur chaque sommet de réseau, de la couleur du tracé ; la tirer déforme le tracé sans en ajouter ni en retirer. Ces poignées (`myType: 'PipeNode'`) n'existent **que** dans cet outil — un plan VRD compte facilement cent sommets, les afficher en permanence masquerait le tracé qu'elles servent à corriger — et ne sont **jamais enregistrées** : elles se recalculent depuis la géométrie.

Un tracé de réseau n'a **pas de poignées de redimensionnement** (`hasControls: false`) : une mise à l'échelle ou une rotation fausserait silencieusement les linéaires, `scaleX`/`angle` n'entrant dans aucun calcul de longueur. On le remodèle sommet par sommet.

**Compatibilité.** Les plans enregistrés avant la 2.1.0 contiennent des réseaux en `fabric.Line` à deux points. Ils restent **lus, mesurés, cotés, rendus en 3D et éditables au nœud** sans conversion : g-plan ne réécrit pas un plan existant hors d'une action explicite. Les helpers `pipeAbsPoints` / `pipeSegments` / `pipeLengthPx` / `pipeMidpoint` (exportés depuis `'g-plan'`) absorbent les deux formats, sur objet Fabric vivant comme sur sa forme sérialisée.

### Formes d'annotation

> **Depuis la 2.1.0** — trois outils de forme dans le groupe **Annotations**, pour commenter un plan comme on annote une photo : **Rectangle (`X`)**, **Cercle (`O`)**, **Flèche (`A`)**. Ils se tracent au **glisser**, sans magnétisme.

Une palette de **5 couleurs** (rouge, orange, vert, bleu, noir — `ANNOTATION_COLORS`) s'affiche sous le groupe dès qu'une forme est l'outil actif ; la couleur choisie s'applique aux trois formes. Le jaune en est volontairement absent : illisible sur le fond blanc d'un plan comme sur une capture satellite claire.

| Forme | Objet Fabric | Géométrie |
|---|---|---|
| `shape-rect` | `Rect` | épouse le rectangle du geste |
| `shape-circle` | `Ellipse` | ellipse **inscrite** dans le rectangle du geste (donc aussi bien cercle qu'ovale) |
| `shape-arrow` | `Group` (`Line` + `Triangle`) | de l'origine du geste vers son extrémité, pointe comprise |

Toutes sont sérialisées sous `myType: 'Annotation'` avec `data: { shape, color }`, et passent **au-dessus** des autres dessins. Un geste de moins de **12 px** ne crée rien — un clic n'a pas à semer une forme microscopique invisible mais bien présente dans le plan.

Les annotations ne portent **aucune sémantique métier** : elles n'entrent dans aucun calcul de surface, de linéaire ou de synthèse (`PlanSummary`), et **n'apparaissent pas dans la légende** des exports image, qui décrit les éléments du plan et non les commentaires portés dessus.

### Pictogrammes SPANC

Le mode SPANC active 5 groupes d'outils contenant 21 pictogrammes vectoriels (Fabric.js Groups, primitives Rect/Line/Circle/Text). Chaque picto est sérialisé sous `myType: 'SpancPictogram'` avec `data: { spancKind, label }`.

| Groupe        | Pictogrammes (mode → libellé) |
|---------------|--------------------------------|
| Prétraitement | `spanc-bac-graisses` · `spanc-fosse-septique` · `spanc-fosse-toutes-eaux` · `spanc-fosse-toutes-eaux-prefiltre` · `spanc-prefiltre` · `spanc-fosse-etanche` |
| Traitement    | `spanc-tranchees-epandage` · `spanc-filtre-sable` · `spanc-filtre-compact` · `spanc-microstation` · `spanc-filtre-plante` · `spanc-toilettes-seches` · `spanc-compost` · `spanc-lit-epandage` |
| Rejet         | `spanc-puits-infiltration` · `spanc-puits-perdu` · `spanc-evacuation` · `spanc-tranchee-infiltration` |
| Regards       | `spanc-regard` · `spanc-pompe-relevage` |
| Ventilation   | `spanc-ventilation-secondaire` |

Catalogue exporté : `SPANC_PICTOGRAMS` (`Record<string, SpancPictogramDef>`) depuis `'g-plan'`. Helper `isSpancPictogramMode(mode)` pour identifier un mode picto.

### Pictogrammes AC (Assainissement Collectif)

Le mode AC active 3 groupes d'outils minimalistes (11 pictogrammes vectoriels). Chaque picto est sérialisé sous `myType: 'AcPictogram'` avec `data: { acKind, label }`. Les pictogrammes SPANC partagés (fosse, micro-station…) ne sont pas dupliqués — activer SPANC + AC pour disposer des deux palettes.

| Groupe                  | Pictogrammes (mode → libellé) |
|-------------------------|--------------------------------|
| Regards                 | `ac-regard-eu` · `ac-regard-em` · `ac-regard-ev` · `ac-regard-ep` (cercle + carré, color-codé selon le type d'eau) |
| Repères réseau          | `ac-noeud` (nœud/branchement avec flèche) · `ac-pied` (pied de descente) · `ac-boite-branchement` (boîte de branchement, carré) |
| Étiquettes type d'eau   | `ac-label-eu` · `ac-label-em` · `ac-label-ev` · `ac-label-ep` (badges colorés à poser le long d'un tracé) |

Catalogue exporté : `AC_PICTOGRAMS` (`Record<string, AcPictogramDef>`) depuis `'g-plan'`. Helper `isAcPictogramMode(mode)` pour identifier un mode picto AC.

---

## Exports image & légende automatique

Les exports **JPEG et PNG** (menu `📁 Fichier → Exporter`, outputs `jpgExported` / `pngExported`)
composent automatiquement le plan avec un panneau **« Légende »** des éléments réellement
présents (murs, cloisons, réseaux, ouvertures, zones de risque, équipements, pictogrammes
SPANC/AC…). L'export **SVG** n'est pas concerné.

- **Placement automatique** : à **droite** si l'image est en paysage, en **bas** si elle est
  en portrait. Bande sur **fond blanc**, sans cadre ni séparateur.
- **Fidélité des couleurs** : la couleur de chaque entrée est **dérivée de l'objet dessiné**
  (`stroke`/`fill`, en descendant dans les groupes) — la légende reprend donc exactement les
  couleurs du plan, y compris le color-code par type d'eau (EU violet, EP cyan…).
- **Symboles ponctuels** (regards, badges EU/EP, équipements, prélèvements…) : rendus comme
  **vignette du vrai pictogramme** dessiné (via `toDataURL`), pour une reconnaissance immédiate.
  Les traits (réseaux) et zones gardent une pastille de synthèse (trait / pointillé / rectangle).
- Résolution adaptée à l'export (×2 JPEG, ×3 PNG) pour rester net à l'impression.

### API exportée

| Symbole | Rôle |
|---|---|
| `collectLegendItems(objects)` | Construit la liste dédoublonnée et ordonnée des entrées de légende (`LegendItem[]`) à partir des objets Fabric (ou de leur forme sérialisée). |
| `LegendItem` / `LegendSwatch` | Types d'une entrée de légende (libellé, couleur, forme de pastille). |
| `ExportService.toJpgWithLegend(canvas)` · `toPngWithLegend(canvas)` | Composent un `Blob` image avec la légende (utilisés par les boutons d'export de l'éditeur). |

---

## Historique — commandes réversibles

> **Depuis la 2.8.0**, `HistoryService` enregistre des **commandes réversibles** au lieu
> d'instantanés JSON du plan entier. Rien ne change dans son API : `undo()`, `redo()`,
> `canUndo`, `canRedo`, `pauseSaving()`, `resumeSaving()`, `save()`.

Ce que cela corrige, mesuré sur un plan de 40 murs avec fond de carte :

| | Instantanés (≤ 2.7.0) | Commandes (2.8.0) |
|---|---|---|
| Une action | recopie du plan entier (~465 Ko) | ~366 octets |
| Historique après 100 gestes | ~23 Mo (50 entrées plafonnées) | **62 Ko** |
| Profondeur | 50 | **100** |

C'est la même recopie intégrale qui saturait le quota `localStorage` de l'autosave et cassait
la restauration du brouillon (cf. `FEATURE-refonte-moteur-croquis.md § 1.1`).

**Ce qui n'est pas historisé** : les objets transitoires (`WallNode`, `PipeNode`, `GhostFloor`,
aperçus de tracé) et les objets **dérivés** (`WallLabel`, `WallMeasurement`, `PipeMeasurement`,
`RoomLabel`, `RoomWallLabel`, `LockedLabel`, `DetectedRoom`), régénérés par
`recalculateRooms` après chaque annulation — les historiser les ferait réapparaître en double.

**Deux comportements à connaître :**

- `pauseSaving()` / `resumeSaving()` **regroupent** désormais ce qu'ils encadrent en une seule
  annulation, au lieu de suspendre l'enregistrement. C'est le besoin réel des appelants :
  générer l'enveloppe d'un croquis produit une vingtaine de murs, que personne ne veut annuler
  un par un.
- `save()` reste utile : `object:modified` n'est émis que pour les manipulations à la souris.
  Une mutation programmatique (`obj.set(...)` depuis l'inspecteur, normalisation de
  coordonnées) passe sous le radar de Fabric — `save()` la rattrape en comparant chaque objet à
  son dernier état connu.

| Symbole | Rôle |
|---|---|
| `HistoryService.poidsHistorique()` | Poids total de la pile en octets. Exposé pour être **mesuré**, le gain étant le critère d'acceptation du chantier. |

> **Identité des objets** : elle vit en mémoire (`WeakMap`), **pas dans le document**. Aucun
> champ n'est ajouté au format sérialisé — donc aucune rupture pour les applications hôtes.

---

## Graphe de nœuds partagés

*Depuis 2.10.0.* Les murs restent des `fabric.Line` autonomes, mais leurs extrémités
**partagent désormais une identité** : un angle est un **nœud**, un mur une **arête** qui
désigne deux nœuds, une pièce validée une **boucle** de nœuds.

Ce que cela corrige : jusqu'ici, deux murs qui se rejoignent ne le savaient pas — chacun
portait sa propre copie du point, et tout code ayant besoin de la topologie la refabriquait par
tolérance de distance (`refreshNodeHandles` à 5 px, `onNodeMoving` à 10 px,
`snapLineEndpoints` à 20 px, `GeometryService.buildGraph` à ~15 px). Déplacer un angle
n'entraînait donc pas franchement ses deux murs, et une pièce nommée perdait son nom dès que
son centre bougeait de plus de 25 px.

### Ce que ça change à l'usage

- **Déplacer un angle entraîne les deux murs**, en **mode Sélection** — l'outil « Nœuds » (`N`)
  n'est pas nécessaire. Les poignées rondes posées sur les extrémités de murs sont la
  représentation visible des nœuds : une poignée plus grosse et ambrée signale une **jonction**
  (trois extrémités ou plus).
- **Les deux murs reçoivent exactement le même point** — plus de dérive d'un demi-trait à
  chaque passage : `left`/`top` sont réécrits dans le même `set()` que `x1..y2`, sans quoi
  Fabric les recalcule trait compris.
- **Glisser un mur entier** déplace ses deux nœuds : les murs qui s'y rattachent suivent.
- **Une pièce validée survit au déplacement d'un mur sans être recalculée** : son contour se
  relit du graphe, et son centroïde (`data._cx`/`_cy`) suit — c'est par lui que l'éditeur
  retrouve nom, description, notes et lien CRI après recalcul.

### Ce que ça ne change pas — cohabitation, pas rupture

> **Aucun champ n'est ajouté au document.** L'identité des arêtes vit en mémoire (`WeakMap`
> indexée par l'objet Fabric), comme celle de l'historique depuis la 2.8.0. Un plan enregistré
> avant ou après la 2.10.0 est **strictement le même fichier** : le graphe se reconstruit de la
> géométrie au chargement. Pas de majeure, pas de migration côté hôte.

`GeometryService.findMinimalCycles` est **conservé en assistance** : il propose les boucles,
que le graphe matérialise ensuite. La détection de pièces au relâchement reste inchangée.

**Deux limites assumées :**

- une pièce dont un sommet n'est **pas** une extrémité de mur — le cas du raccord en T, où
  `findMinimalCycles` place un sommet au milieu du mur traversé — n'est **pas** liée du tout.
  La lier à moitié la ferait dériver au premier déplacement, ce qui est pire que ne pas la
  suivre : elle reste alors gérée comme avant, par recalcul au relâchement ;
- l'**aire** d'une pièce liée n'est pas recalculée pendant le glisser (elle demanderait
  `pixelsPerMeter`, que `FabricCanvasService` ne connaît pas) ; `recalculateRooms` la rétablit
  au relâchement.

Le rattrapage historique par tolérance de distance n'a **pas** été supprimé : il reste en
second rideau pour les extrémités que le graphe ne relie pas encore (deux murs jamais recollés,
distants de quelques pixels, ou une poignée antérieure à la première synchronisation).

### API exportée — `plan-graph.const`

Fonctions **pures** — ni Fabric, ni DOM, ni canvas — sur un graphe immuable.

| Symbole | Rôle |
|---|---|
| `syncGraph(previous, geometries, tol?)` | Reconstruit le graphe depuis la géométrie des murs **en conservant les identités** des nœuds encore reconnaissables. Lâche les boucles dont un nœud a disparu. |
| `moveNode(graph, nodeId, pt)` | Déplace un nœud : murs et pièces qui le désignent suivent. |
| `mergeNodes(graph, keepId, dropId)` | Fusionne deux angles en un seul. |
| `nodeAt(graph, pt, tol?)` · `edgesAtNode` · `nodeDegree` · `edgeGeometry` | Lectures : nœud le plus proche, murs d'un nœud, nombre d'extrémités arrivant dessus, géométrie d'une arête **lue depuis les nœuds**. |
| `addLoop(graph, nodeIds)` · `loopFromPoints(graph, pts, tol?)` · `loopPoints` · `removeLoop` | Pièces validées : matérialisation, traduction d'un contour en nœuds (`null` si un sommet ne tombe sur aucun nœud), relecture du contour, retrait. |
| `edgeChain(graph, edgeId)` | *Depuis 2.11.0.* Remonte la suite de murs enchaînés bout à bout autour d'une arête : le contour de la pièce s'il est fermé, sinon le tronçon délimité par les **jonctions** (la marche ne traverse que les nœuds de degré 2). Rend `NodeChain` ou `null`. |
| `emptyGraph()` | Graphe vide. |
| `NODE_MERGE_PX` | 10 px — distance sous laquelle deux extrémités sont **le même nœud**. Reprend la tolérance historique de `onNodeMoving` ; doit rester au-dessus du biais du demi-trait (2,5 px) et sous les 20 px d'accroche. |
| `PlanGraph` · `PlanNode` · `PlanEdge` · `PlanLoop` · `EdgeGeometry` · `NodeChain` | Types du contrat. |

### API exportée — `WallGraphService`

Le **pont** : il tient l'identité des arêtes et lit la géométrie du canvas, mais **n'écrit
jamais** dans Fabric — il rend ce qu'il faut poser, `FabricCanvasService` le pose.

| Symbole | Rôle |
|---|---|
| `sync(walls, rooms?)` | Resynchronise le graphe sur les murs vivants et lie les pièces (`{ key, points }`). Appelé par `refreshNodeHandles`, point de passage obligé de tout changement de mur. |
| `moveNode(nodeId, pt)` · `moveWall(wall, p1, p2)` · `mergeNodes(keepId, dropId)` | Rendent les `WallEndsUpdate[]` à appliquer. `moveWall` **exclut** le mur déplacé, dont Fabric tient déjà la position pendant le glisser. |
| `nodes()` · `degree(id)` · `nodeIdAt(pt, tol?)` · `wallsAtNode(id)` · `snapshot()` | Lectures pour poser les poignées et pour le diagnostic. |
| `roomUpdates()` · `roomPoints(key)` · `boundRooms()` | Contour et centroïde à jour des pièces liées. |
| `chainAt(wall)` | *Depuis 2.11.0.* Chaîne de murs à laquelle appartient ce mur (`WallChain`), dans la convention qu'attend `solveWallDimensions`. `null` si le mur n'est pas dans le graphe. |
| `applyChain(nodeIds, points)` | *Depuis 2.11.0.* Repose les nœuds d'un cheminement coté et rend les `WallEndsUpdate[]` de **tous** les murs touchés — y compris les voisins hors chaîne, sinon la cotation décolle le croquis là où on ne regardait pas. |
| `reset()` | Repart de zéro (chargement d'un projet, changement d'étage). |
| `WallEndsUpdate` · `RoomBinding` · `RoomUpdate` · `WallChain` | Types du contrat. |

---

## Cote saisie au mur

*Depuis 2.11.0.* Le diagnostiqueur qui relève une pièce **sans plan** a déjà son télémètre
laser dans la poche : il ne demande pas que le téléphone mesure à sa place, il veut **saisir ce
qu'il vient de lire** et que le croquis s'y conforme. Jusqu'ici la saisie de dimensions
n'existait que pour un `RoomBox` — un rectangle, largeur et hauteur : dès qu'une pièce avait un
placard ou un pan coupé, elle ne servait plus à rien, et **aucun mur d'un tracé ne pouvait
recevoir sa longueur**.

### Le geste

1. sélectionner un mur ou une cloison ;
2. dans l'inspecteur, section **📐 Coter (télémètre)**, saisir la longueur en mètres ;
3. valider : le mur prend sa longueur, **les murs voisins suivent** (graphe de nœuds partagés,
   2.10.0), et une pièce fermée le reste.

La cote est mémorisée dans `data.lockedLengthM` — le champ que la calibration utilise déjà, un
mur n'ayant qu'une longueur imposée — donc **persistée** et réaffichée par l'étiquette
« ⊛ x.xx m ». Coter un second mur tient compte du premier.

> **Ce n'est pas la calibration.** « 📏 Calibrer » règle l'**échelle** du plan : le premier mur
> calibré fixe le nombre de pixels par mètre. « 📐 Coter » ne touche pas à l'échelle et se
> contente de conformer le **croquis** aux mesures.

> **Où se saisit la cote.** Dans l'**inspecteur**, pas au clic sur la cote affichée. Les cotes
> sont des `fabric.Text` non sélectionnables posées en 11 px ; en faire des cibles cliquables
> demanderait un objet évènementiel par-dessus le dessin, en concurrence avec la sélection du
> mur et le clic-pour-déplacer des réseaux. Sélectionner le mur ouvre déjà l'inspecteur : même
> nombre de gestes, risque bien moindre. Le déclencheur est changeable sans toucher au moteur.

### Le point de conception : c'est un problème surdéterminé

Contraindre des longueurs dans un polygone fermé **n'a pas de solution exacte**. Six cotes
relevées à la main sur une pièce en L ne sont jamais compatibles au millimètre : le tour
horizontal ne retombe pas sur la somme des tronçons, ni le tour vertical. Une implémentation
qui prétendrait satisfaire les six exactement fausserait la géométrie ailleurs — **en silence**.

La réponse retenue est celle du géomètre qui ferme un cheminement :

1. **moindre écart pondéré** — les murs cotés pèsent 100, les non cotés 1 ; les seconds
   absorbent donc l'essentiel de l'incompatibilité. La fermeture est posée en contrainte dure,
   ce qui se résout en **forme close** (deux multiplicateurs de Lagrange, une matrice 2×2) :
   déterministe, sans réglage, exact au millimètre — donc testable ;
2. **fermeture de Bowditch** (`repartirBowditch`, la même fonction que le tracé au doigt) pour
   le résidu : calcul flottant, écrêtage d'un mur qui voudrait passer sous zéro, ou système
   singulier (tous les murs colinéaires) ;
3. **l'écart résiduel est affiché**, mur par mur. Ce n'est pas un échec à masquer : c'est la
   donnée qui dit à l'utilisateur laquelle de ses lectures est douteuse. Au-delà de 8 % du
   périmètre (`SEUIL_ALERTE_FERMETURE`), le compte rendu passe en orangé et un avertissement
   part en console — **sans bloquer**.

**Les directions ne sont pas touchées.** Redresser un angle est le travail du magnétisme au
moment du tracé (`contraindreAngle`, ±4°, ±8° sur l'équerre) : un croquis tracé depuis la 2.9.0
arrive déjà d'équerre. Re-contraindre ici ferait pivoter des murs que l'utilisateur n'a pas
désignés, et mettrait silencieusement d'équerre un plan importé de biais. Conséquence assumée :
la surface obtenue est celle du produit des cotes **à l'obliquité près du croquis** — exacte
sur un tracé d'équerre, basse de ~0,3 % sur un tracé à 2° de travers.

**Limite assumée** : la chaîne s'arrête aux **jonctions** (nœud de degré 3 ou plus, typiquement
une cloison qui bute sur un mur). Le cheminement est alors *ouvert* : le mur coté prend
exactement sa longueur, les suivants se décalent, et rien n'est refermé — plutôt que de choisir
au hasard un chemin que l'utilisateur ne voit pas.

### API exportée — `wall-dimension.const`

Fonctions **pures** — ni Fabric, ni DOM, ni canvas.

| Symbole | Rôle |
|---|---|
| `solveWallDimensions(chain)` | Résout un cheminement coté et rend une `DimensionSolution` (`null` si l'entrée est inexploitable : échelle absente, nombre de murs incohérent avec le nombre de sommets). Le **premier sommet est l'ancre** et ne bouge pas. |
| `DimensionChain` | Entrée : `points` (sommets dessinés ; pour une boucle le premier n'est **pas** répété), `walls` (`{ id, targetM }`, une par segment, `targetM: null` = non coté), `closed`, `pixelsPerMeter`. |
| `DimensionSolution` | Sortie : `points` corrigés (même nombre qu'à l'entrée), `walls`, `closureErrorPx` / `closureRatio` (écart **des cotes telles que saisies**, pas du résultat — le résultat, lui, ferme), `maxResidualM`, `maxRotationDeg`, `warning`. |
| `maxRotationDeg` | *Depuis 2.15.1.* Pire rotation subie par un mur, en degrés — **zéro sur un relevé compatible**. Le solveur ne redresse jamais un angle, mais refermer une boucle que les cotes rendent impossible déplace des sommets, donc fait tourner des murs. Le taire reviendrait à déformer le croquis en silence. |
| `ROTATION_ALERTE_DEG` | Seuil (1°) au-delà duquel `warning` passe à `true`, en plus du seuil de fermeture. Un demi-degré sur 4 m fait 3,5 cm au bout — invisible ; deux degrés en font 14 — ça se voit. |
| `WallDimensionResult` | Par mur : `targetM`, `lengthM` obtenue, `residualM` = obtenu − saisi (`null` si non coté). **C'est la donnée à afficher.** |

> **Les directions ne sont pas garanties intactes, et c'est mesuré.** Tant que le relevé est
> compatible, seules les longueurs bougent. Dès qu'il ne l'est pas — deux murs opposés dont les
> cotes imposeraient au troisième côté une longueur négative — l'écrêtage rompt la fermeture, et
> refermer fait tourner au moins un mur. Sur le cas type : **54°** concentrés sur le dernier mur
> sans répartition, **17°** partagés entre deux avec `repartirBowditch`, au prix de cotes qui
> s'écartent. C'est le bon arbitrage pour un croquis — une figure lisible et un écart annoncé
> valent mieux qu'une figure cassée et des chiffres exacts — mais il doit se **voir** :
> `maxRotationDeg` est rendu au même titre que `residualM`.
| `MEASURED_WEIGHT` (100) · `FREE_WEIGHT` (1) | Pondération : un mur coté encaisse 1 % de ce qu'encaisse un mur libre voisin. |
| `MIN_WALL_PX` (1) | Plancher de longueur après résolution : un mur ne s'inverse jamais, l'écart correspondant ressort dans `residualM` au lieu de se perdre. |

### API exportée — `FabricCanvasService`

| Symbole | Rôle |
|---|---|
| `applyWallDimension(wall, lengthM, pixelsPerMeter)` | Le **pont** : relit la chaîne depuis le graphe, passe les cotes déjà posées sur les murs voisins, réécrit les extrémités par `setWallEnds`, met à jour les pièces liées et les poignées, et enregistre **un seul** pas d'annulation. Rend la `DimensionSolution` pour que l'appelant l'affiche, ou `null`. |

---

## Calque photo — redressement et calage

*Depuis 2.12.0.* Une photo de plan papier prise de biais **restait de biais** : un
`grep -riE "perspective|homograph|warp"` ne trouvait aucun redressement dans la bibliothèque,
et le scanner OpenCV rendait un `pixelsPerMeter` de 50 arbitraire (un ternaire dont les deux
branches valaient 50). Le calque photo remet la photo à plat **et** lui donne son échelle.

### Le geste

Menu **🖼 Fond → 📐 Calque photo (redresser)…**, puis trois étapes :

1. **Choisir la photo.** Réduite à 2048 px de côté, encodée en WebP qualité 0,8, sous un
   plafond de 1,5 Mo — les réglages du fond de carte. Au-delà du plafond, la qualité baisse
   (0,7 · 0,6 · 0,5) *puis* la définition ; si rien ne passe, la photo est **refusée avec un
   motif** plutôt que de faire échouer l'autosave plus tard, ailleurs.
2. **Poser les quatre coins** du document, à la traîne (quatre poignées déjà placées à 10 % du
   cadre). Taper quatre points marche à la souris et échoue au doigt.
3. **Caler sur une distance connue.** Deux poignées sur l'aperçu **redressé**, la longueur
   relevée au télémètre saisie une fois, et toute l'image est à l'échelle.

### Les trois décisions de conception

**Le rapport d'aspect est recouvré, pas supposé.** Prendre le rectangle de destination « à la
moyenne des côtés » revient à supposer la photo fronto-parallèle. Comme le calage se fait
ensuite sur **une seule** distance, l'erreur d'aspect se reporte intégralement sur les murs
mesurés dans l'autre direction. Mesuré sur une prise de vue à 28° / 22° : **−5,7 %** avec le
rectangle naïf, **0,04 %** avec l'aspect recouvré (`photo-homography.const.spec.ts`). La
méthode est celle des points de fuite (Zhang & He) : orthogonalité des deux directions du
rectangle → focale ; norme des colonnes de l'homographie → rapport d'aspect. Quand la
perspective ne porte plus d'information exploitable (quadrilatère quasi parallélogramme,
focale recouvrée > 20 × la diagonale du quadrilatère), on bascule sur la moyenne des côtés —
et `method` le **dit** au lieu de le taire.

**On stocke l'image d'origine et la matrice, jamais les pixels déformés.** Le calque est un
`FabricImage` dont `_originalElement` reste la photo — c'est elle que `getSrc()` rend, donc
elle seule que `toObject()` écrit — et dont `_element` est un canvas redressé regénéré à
chaque chargement. C'est exactement le mécanisme des filtres Fabric. Conséquence : une seule
image par calque dans le document (un test le garde), et les coins restent modifiables.
Corollaire : le redressement doit être **rejoué** après chaque chargement, ce que fait
`PhotoLayerService.rehydrate` depuis `syncBackdropState`.

**Le calque s'adapte à l'échelle du plan, jamais l'inverse.** Recaler `pixelsPerMeter` sur la
photo réécrirait toutes les longueurs et toutes les surfaces déjà saisies — les cotes du
télémètre comprises. Le facteur est appliqué à l'image (`photoLayerScale`).

**Le document n'est pas collé aux bords** *(2.21.0)*. Il est posé au centre d'une image plus
grande de `MARGE_REDRESSEMENT` (12 %) de chaque côté. Sans cette marge, les quatre coins
atterrissent sur les bords mêmes de l'image redressée : les murs de l'enveloppe tombent sur la
frontière, où on ne peut plus ni les saisir, ni les prolonger, ni tracer le contour du bâtiment
— qui est pourtant le premier geste du relevé. La marge est une **translation**, jamais un
changement d'échelle : `pixelsPerMeter`, les longueurs et les surfaces sont rigoureusement les
mêmes avec ou sans elle (un test le garde). Elle porte le pourtour de la photo, et du
transparent au-delà. `PhotoRectification` distingue donc l'image (`width`/`height`) du document
(`contentWidth`/`contentHeight`, `offsetX`/`offsetY`) : **les dimensions réelles annoncées à
l'utilisateur sont celles du document**, y inclure la marge les fausserait de 24 %.

### Ce que le calque n'est pas

- **Ce n'est pas un géoréférencement.** Il est calé sur une distance relevée, pas sur des
  coordonnées terrain : `PhotoLayer` est donc **exclu** de l'export GeoJSON, comme le fond de
  carte, et n'apparaît pas dans la légende ni dans `PlanSummary`.
- **Ce n'est pas un relevé de pièce.** Le redressement suppose une surface plane, entièrement
  visible, à quatre coins identifiables et à contour rectangulaire : un plan papier les offre,
  le sol d'une pièce meublée non (cf. `FEATURE-releve-piece-sans-plan.md § 3`).
- **Zéro WASM ajouté** : ~120 lignes de TypeScript pur, contre les 8 Mo d'OpenCV.js chargés
  d'un CDN externe — donc indisponibles hors ligne, c'est-à-dire en vide sanitaire.

### API exportée — `photo-homography.const`

Fonctions **pures** — ni Fabric, ni DOM, ni canvas.

| Symbole | Rôle |
|---|---|
| `solveHomography(src, dst)` | Homographie envoyant quatre points sur quatre points. Système 8×8, **élimination de Gauss à pivot partiel**, normalisation de Hartley, puis **vérification de la solution** : la matrice doit reproduire les quatre correspondances. `null` sinon — trois points alignés, deux points confondus, contour croisé. Le seul pivot ne suffisait pas : sur trois points alignés il reste de l'ordre de 1e-11 et rendait du bruit (mesuré). |
| `applyHomography(h, p)` | Image d'un point. `null` sur la **droite de fuite** (`w = 0`, l'horizon de la photo) plutôt qu'un `Infinity` silencieux. |
| `invertHomography(h)` | Inverse par la comatrice. C'est elle que parcourt le rendu (image inverse), sans quoi la photo étirée laisserait des trous. |
| `orderQuadCorners(quad)` | Réordonne quatre coins en **HG, HD, BD, BG** (tri angulaire, sens horaire écran, départ au plus petit `x + y`). `null` si dégénéré. Suppose le document *à peu près* debout dans le cadre. |
| `quadAspectRatio(quad, principal)` | `AspectResult` : `ratio` largeur/hauteur du rectangle réel, `focalPx` (ou `null`), `method` (`'vanishing-points'` \| `'mean-sides'`). |
| `rectifyQuad(quad, opts)` | `PhotoRectification` : `corners` réordonnés, `width`/`height` de l'image **marge comprise**, `contentWidth`/`contentHeight` et `offsetX`/`offsetY` du **document seul** *(2.21.0)*, `matrix` (source → redressé), `inverse`, `ratio`, `focalPx`, `method`. `opts` exige `imageWidth`/`imageHeight` — le point principal s'en déduit, le supposer ailleurs fausserait la focale — et accepte `maxSize` (borne l'image **totale**) et `margin` *(2.21.0)*. |
| `MARGE_REDRESSEMENT` (0,12) | *Depuis 2.21.0.* Marge laissée **autour** du document dans l'image redressée, en part de sa taille, sur les quatre côtés. |
| `scaleFromKnownDistance(matrix, a, b, knownM)` | Pixels **redressés** par mètre, à partir de deux points de l'image source et de la distance relevée. `null` si inexploitable. |
| `photoLayerData(rect, sourceW, sourceH, calibration?)` | Assemble la charge utile persistée (`PhotoLayerData`). Un calage absent n'est pas une erreur : `pixelsPerMeter` vaut alors `null` et le calque reste posable comme simple décalque. |
| `photoLayerScale(photo, planPixelsPerMeter)` | Facteur d'échelle du calque pour qu'un mètre du calque soit un mètre du plan. `null` si le calque n'est pas calé. |
| `toHomography(raw)` | Garde de relecture : neuf nombres finis, ou `null`. Un plan est un contrat public — la matrice peut revenir tronquée ou retapée à la main. |
| `fitWithin(w, h, max)` | Réduction sous un côté maximal, à rapport conservé. Ne grandit jamais. |
| `PhotoLayerData` | Persisté dans `data.photo` : `homography` (9), `corners` (4, dans l'image persistée), `width`/`height` redressés, `sourceWidth`/`sourceHeight`, `ratio`, `method`, `focalPx`, `knownDistanceM`, `knownPoints` (repère redressé), `pixelsPerMeter`. Quelques dizaines d'octets — la seule donnée lourde est la photo, portée **une fois** par le `src` de l'objet Fabric. |
| `MAX_PHOTO_SIZE_PX` (2048) · `PHOTO_WEBP_QUALITY` (0,8) · `MAX_PHOTO_BYTES` (1 500 000) · `FOCAL_TRUST_RATIO` (20) | Réglages, tous documentés à leur définition. |

### API exportée — `PhotoLayerService`

Le **pont** : tout ce qui exige un canvas ou un objet Fabric, et rien d'autre.

| Symbole | Rôle |
|---|---|
| `prepareSource(file)` | `PhotoSource` = photo réduite, encodée WebP sous plafond, **et décodée** — c'est sur cet élément que l'utilisateur pose ses coins, donc celui auquel l'homographie se rapporte. Rejette avec un message explicite plutôt que de rendre une photo hors plafond. |
| `warp(source, sw, sh, matrix, w, h)` | Redressement par **image inverse**, échantillonnage **bilinéaire** (au plus proche voisin, les traits fins d'un plan se hachent). Hors photo → transparent, jamais noir. Coût **mesuré** : 68 ms pour un rectangle de 1495 × 1148 issu d'une photo de 2048 × 1536 (Chromium headless, poste de développement) — une seule fois à la pose, une seule fois par chargement. |
| `applyRectification(img, photo)` | Pose les pixels redressés sur un `FabricImage` **sans toucher à `_originalElement`**. `false` — sans lever — si la charge utile est inexploitable. |
| `createLayer(dataUrl, photo, pose)` | Construit l'objet Fabric complet : `myType: 'PhotoLayer'`, inerte (verrous de mouvement), `data.photo`. |
| `rectifiedCanvas(dataUrl, photo)` | *Depuis 2.13.0.* Redresse une photo **persistée** (sa `data:` URL et sa charge utile) et rend le canvas redressé, **sans passer par Fabric**. Le calque n'en a pas besoin ; le **scanner** si — il détecte sur des `<canvas>` bruts et n'a aucun objet Fabric. Sans elle, le scanner aurait dupliqué le décodage et l'appel à `warp`, soit un second chemin vers la même géométrie. `null` sans lever si la charge utile est inexploitable. |
| `rehydrate(canvas)` | Rejoue le redressement de tous les calques après chargement ; rend le nombre traité. Sans lui, le calque revient de biais et étiré — plausible, calé à côté, et rien pour le signaler. |
| `PHOTO_LAYER_TYPE` | `'PhotoLayer'`, ajouté à `FABRIC_SAVED_TYPES`. |

### API exportée — `fabric-types.const`

| Symbole | Rôle |
|---|---|
| `BACKGROUND_LAYER_TYPES` · `isBackgroundLayer(myType)` | Les **calques de fond** : `Backdrop` et `PhotoLayer`. Une douzaine d'endroits partagent leur comportement (non déplaçables au doigt, ignorés par le panoramique sur le vide, comptés à part dans l'empilement des réseaux, exclus des « dessins existants », vidés de leur image dans le brouillon de repli). Ils testaient `=== 'Backdrop'` en dur ; le second type en aurait oublié la moitié. |

### Composant — `<ng-gplan-photo-layer-modal>`

`PhotoLayerModalComponent` : l'assistant en trois étapes. Sorties `import`
(`PhotoLayerImport` = `{ dataUrl, photo }`) et `close`. Il est utilisé par
`PlanEditorComponent` **et par `ScannerComponent`** (depuis 2.13.0) ; un hôte n'a normalement
pas à le monter lui-même.

| Input | Type | Défaut | Rôle |
|---|---|---|---|
| `title` | `string` | `'Calque photo — redresser et caler'` | Titre affiché en tête. *Depuis 2.13.0* : les trois gestes servent deux usages (poser un décalque, caler le scanner), et annoncer « Calque photo » à qui vient caler une détection de murs serait mensonger. |
| `confirmLabel` | `string` | `'Poser le calque'` | Libellé du bouton de validation, pour la même raison. |

---

## Échelle du scanner

*Depuis 2.13.0.* Le scanner OpenCV **n'avait aucune notion d'échelle** : la charge utile qu'il
remettait à l'éditeur portait

```ts
pixelsPerMeter: this.params().clusterDistance > 0 ? 50 : 50
```

— un ternaire dont les **deux** branches valaient 50. Quelle que soit la photo, le plan sortait
à 50 px/m arbitraires, donc **toutes les surfaces produites étaient fausses**, et fausses *en
silence*. Le champ n'était d'ailleurs lu **nulle part** dans l'éditeur : l'échelle inventée
n'allait même pas jusqu'au plan.

### Le geste

Barre latérale du scanner → **📐 Redresser et caler la photo…** ouvre le **même** assistant que
le calque photo (§ [Calque photo](#calque-photo--redressement-et-calage)) : choisir la photo,
poser les quatre coins du plan papier, saisir une distance relevée au télémètre. À la
validation (« Détecter les murs »), l'image redressée **remplace** l'image analysée et la
détection repart dessus.

**Le redressement a lieu avant la détection, jamais après.** Les seuils de la détection
(épaisseur de mur, longueur minimale, écart de rebouchage) sont exprimés en pixels et n'ont de
sens que sur une image plane : redresser des segments déjà détectés reviendrait à corriger la
perspective sur des traits que la perspective avait déjà fusionnés ou fragmentés. La rotation
manuelle reste applicable par-dessus — c'est une isométrie, elle ne change aucune longueur.

### Sans calage, le scanner le dit — et refuse

C'est le point qui compte. Une image chargée directement par le sélecteur de fichier reste
analysable (le scanner sert aussi à dégrossir un tracé qu'on cotera ensuite au mur,
§ [Cote saisie au mur](#cote-saisie-au-mur)), mais alors :

- la barre latérale affiche un **bloc d'alerte** nommant les deux manques (« ni redressée ni
  calée ») et le geste qui les corrige ;
- le bouton **« Envoyer à l'éditeur »** est **inerte** tant que l'utilisateur n'a pas coché
  « Envoyer quand même, à l'échelle arbitraire de 50 px/m (surfaces sans valeur) ». La case se
  décoche à chaque changement d'image : accepter une fois ne vaut pas acceptation pour la photo
  suivante, sans quoi l'avertissement deviendrait une formalité ;
- la charge utile emporte `scaleCalibrated: false`, et l'éditeur **pose les murs tels quels**
  en l'annonçant en console — plutôt que de les redimensionner d'après un 50 inventé.

Deux manques différents donnent deux messages différents : *aucune photo redressée* et *photo
redressée mais non calée* (la perspective est corrigée, le mètre reste inconnu).

Une fois calé, le scanner affiche l'échelle (`px/m`), la distance qui l'a produite, et
**l'emprise réelle des murs retenus** en mètres — le seul contrôle de vraisemblance qu'un
diagnostiqueur puisse faire d'un coup d'œil : un séjour qui sort à 40 m de large se voit, un
`pixelsPerMeter` faux ne se voit pas.

### Côté éditeur — l'apport s'adapte au plan

`importWallsFromScanner` applique `scannerImportScale` aux murs **et au fond importé**, comme
un calque photo l'est par `photoLayerScale`. **Le `pixelsPerMeter` du plan n'est jamais
réécrit** : l'aligner sur le scanner redimensionnerait silencieusement les cotes déjà saisies
et les objets des **autres niveaux**, que `canvas.clear()` ne vide pas.

### OpenCV.js reste chargé du CDN

Volontairement non modifié : ~8 Mo de WASM chargés de `docs.opencv.org`, donc **indisponibles
hors ligne** — c'est-à-dire en vide sanitaire ou en sous-sol, exactement le terrain du
diagnostiqueur. Le sort du scanner (le retirer, ou assumer ce coût) reste ouvert et constitue
une **majeure** : `ScannerComponent`, `wallsDetected` et `initialWalls` sont publics
(`FEATURE-releve-piece-sans-plan.md § 4.3`).

### API exportée — `scanner-scale.const`

Fonctions **pures** — ni OpenCV, ni Fabric, ni DOM, ni canvas.

| Symbole | Rôle |
|---|---|
| `scannerScale(photo)` | `ScannerScale` = `{ pixelsPerMeter, calibrated, source, knownDistanceM, warning }`, déduit de la charge utile du redressement (`PhotoLayerData`). Rend **toujours** un objet exploitable : l'absence de calage est une valeur de retour, pas une exception — lever aurait fait avaler l'erreur, rendre `null` aurait fait réapparaître un `?? 50` quelque part. |
| `scannerImportScale(payload, planPixelsPerMeter)` | Facteur à appliquer aux murs détectés pour qu'ils entrent **à leur longueur réelle** dans le plan. Symétrique de `photoLayerScale`. `null` sans calage (`scaleCalibrated !== true`) ou sur une échelle absurde : une échelle inventée ne se propage pas. |
| `wallLengthM(wall, pixelsPerMeter)` | Longueur réelle d'un segment détecté, en mètres. `null` plutôt qu'un `NaN` silencieux. |
| `wallsExtentM(walls, pixelsPerMeter)` | `{ widthM, heightM }` — l'emprise réelle d'un lot de murs, le contrôle de vraisemblance du coup d'œil. `null` sur un lot vide ou une échelle inexploitable. |
| `SCANNER_FALLBACK_PIXELS_PER_METER` (50) | L'échelle de repli, **nommée** au lieu d'être écrite deux fois dans une condition. Elle ne prétend rien : `calibrated: false` et `warning` l'accompagnent partout où elle circule. |
| `SCANNER_NO_PHOTO_WARNING` · `SCANNER_NOT_SCALED_WARNING` | Les deux messages, en français, portés par la donnée — un message reconstruit dans chaque gabarit finit par manquer quelque part. |
| `ScannerScale` · `ScannerScaleSource` · `MeasurableSegment` · `ScannerImportScaleInput` | Types associés. |

### Le critère d'acceptation, mesuré

Avec une **caméra synthétique** (rectangle connu, focale connue, inclinaison connue, donc bonne
réponse connue) — `scanner-scale.const.spec.ts` : un plan papier de 4,00 × 3,00 m photographié à
28° / 22°, redressé et calé sur **une seule** distance de 3,60 m, rend les murs détectés à
**moins de 0,1 %** du réel (seuil : 5 %). Les mêmes murs sortent faux de **plus de 5 %** sans
redressement, et de **plus de 50 %** avec l'échelle de repli — ce que l'avertissement annonce.

---

## Fusion propre des murs — `mergeWalls`

*Depuis 2.22.0.* Ce que rend le scanner n'est pas un plan mais une collection de traits : un mur
photographié sort en deux ou trois morceaux décalés de quelques pixels, un mur redessiné à la
main tombe à côté de celui qu'il prolonge, deux murs qui devraient se croiser se ratent. À
l'écran le résultat **ressemble** à un plan — ce sont les pastilles rouges (extrémités libres)
qui trahissent que rien ne se touche, et l'éditeur qui hérite ensuite d'un graphe sans pièces.

### Le geste

Barre latérale du scanner → **🧲 Aligner et fusionner**. Sans sélection, l'opération porte sur
tout le plan ; avec une zone active, sur elle seule — et ce qui est en dehors n'est **pas**
déplacé. Le compte-rendu s'affiche sous le bouton et part en console :

```
[G-Plan] Scanner : fusion du plan — 40 → 26 murs, 14 alignés, 9 raccords, déplacement max 7.4 px (alignement 45 px, recollage 60 px, raccord 120 px).
```

### Deux distances qu'il ne faut surtout pas confondre *(2.23.0)*

Le curseur **« Distance de raccord »** (20 → 400 px, 120 par défaut, affiché en centimètres réels
dès que l'échelle est calée) règle **uniquement** la soudure : la longueur dont un mur inachevé
peut être étiré pour en rejoindre un autre, perpendiculaire. Mesuré sur un relevé réel, il
manquait **146 px** entre le bas d'une cloison et le mur qu'elle devait rejoindre, soit 1,3 m au
calage de cette photo : aucune valeur déduite de l'image ne pouvait le deviner, parce que ce
n'est pas une question de pixels — c'est l'utilisateur qui sait si ce vide est un mur inachevé
ou une pièce ouverte.

**Le recollage, lui, reste borné par « Extension ».** Un vide entre deux morceaux **alignés**
est très exactement ce qu'est un passage de porte : 83 cm, soit ~91 px au calage de cette
photo. Une tolérance de recollage généreuse **reboucherait donc toutes les portes du plan, en
silence** — le motif de panne que ce dépôt traque. C'est pourquoi le curseur ne s'applique qu'au
raccord perpendiculaire, et pourquoi il fallait deux réglages là où la 2.22.0 n'en avait qu'un.

### Murs importés : origine centrée, pièces jamais détectées *(2.23.2)*

Signalé à l'usage : « je ne sais pas à quoi correspondent tous les cercles bleus, et je n'ai pas
l'impression que les pièces soient détectées ». **Une seule cause pour les deux.**

L'import posait ses murs en `originX/originY: 'center'` avec des points relatifs, alors
qu'`absLineEnds` — définition **unique** des extrémités dans la bibliothèque, dont dépendent
`GeometryService`, `PlanAnalysisService`, `WallGraphService` et `pipeAbsPoints` — supposait
l'origine en haut à gauche (ce que la bibliothèque impose pourtant par défaut,
`FabricObject.ownDefaults`). Les extrémités ressortaient donc décalées d'une **demi-longueur de
mur**, avec trois conséquences :

- les **poignées de nœuds** (`WallNode`, cercles blancs cerclés d'indigo ; orange sur une
  jonction de degré ≥ 3) flottaient à côté du plan, puisqu'elles *sont* la représentation
  visible du graphe ;
- **aucune pièce n'était détectée** : deux murs voisins ne partageaient plus aucun point, donc le
  graphe n'avait plus un seul cycle, donc `findMinimalCycles` ne proposait rien ;
- les longueurs, elles, restaient justes — la formule conservait l'écart `p2 − p1`. Le plan
  *paraissait* donc correct, ce qui est exactement le motif de panne que ce dépôt traque.

Deux corrections, l'une pour le cas signalé, l'autre pour tous les autres : `absLineEnds` **tient
compte de l'origine déclarée**, et l'import pose désormais ses murs dans la **forme canonique**
de la bibliothèque (quatre coordonnées de scène passées à `fabric.Line`, origine par défaut). Les
murs importés reçoivent au passage le `wallId` qui leur manquait — sans lui, une ouverture posée
sur un mur importé n'était rattachée à rien, ni pour la suppression en cascade ni pour
`PlanSummary`.

> Le biais de **demi-trait** de `absLineEnds` (`left = min(x1,x2) − strokeWidth/2`) reste assumé
> et documenté : il est identique pour tous les murs, donc sans effet sur le partage des nœuds.

### « Envoyer à l'éditeur » — deux défauts d'ordonnancement *(2.23.1)*

Signalé à l'usage : « je vois bien le fond de plan mais pas les murs détectés ».

1. **Les murs étaient balayés par le chargement du projet.** L'import était
   **synchrone** à l'init de l'éditeur, alors que `loadFromProject` finit par un
   `loadFromJSON` qui **remplace** le contenu du canvas : à la résolution de la promesse, les
   murs disparaissaient. Le fond, lui, était posé dans un `.then()` et arrivait *après* — d'où le
   symptôme, un décalque sans un seul mur. L'import se fait désormais **après** le chargement du
   projet.
2. **Un éditeur déjà monté ignorait tout envoi ultérieur.** `initialWalls` n'était lu qu'une
   fois, à l'init. Onglet masqué plutôt que détruit, disposition `split`, hôte qui garde
   l'éditeur en vie : « Envoyer à l'éditeur » ne faisait **rien**, sans un mot. Un effet suit
   maintenant l'entrée, avec une garde **par référence** — deux envois successifs du même plan
   sont deux objets distincts et doivent tous deux être importés.

L'import **cadre** ensuite la vue (`zoomToFit`) : les murs entrent au centre du canvas, qui n'est
pas la fenêtre, et à l'échelle du calage — un plan importé pouvait donc atterrir hors du champ
visible, ce qui se lit exactement comme « les murs ne sont pas là ». Et il journalise
`[G-Plan] Éditeur : N murs importés du scanner (facteur …, échelle calée|de repli)`.

> **Fond satellite dans la démo.** L'application de démonstration posait `autoGeoLayer="satellite"`
> en dur, avec un projet par défaut géolocalisé à Paris : toute session de test du scanner
> commençait donc par une orthophoto sans rapport. C'est désormais une case à cocher, **décochée
> par défaut**. La librairie, elle, n'a jamais chargé de fond de sa propre initiative — il faut
> `autoGeoLayer` ou `geoPoint`.

### Les corrections manuelles sont réversibles *(2.23.0)*

**↶ Annuler / ↷ Rétablir** (et `Ctrl/⌘+Z`, `Ctrl/⌘+Maj+Z`) couvrent tous les gestes de
correction : gomme, crayon, fusion, « Fusionner la sélection », « Supprimer isolés », « Supprimer
impasses ». Profondeur 50.

L'instantané est ici la **liste des murs** — quelques dizaines d'objets de six champs. C'est ce
qui autorise la solution simple que `HistoryService` a dû abandonner pour l'éditeur, où un
instantané est le document entier, fond de carte en base64 compris (cf.
[§ Historique — commandes réversibles](#historique--commandes-réversibles)). Une **nouvelle
détection vide l'historique** : elle remplace tous les murs, et les instantanés d'avant
décriraient un plan qui n'existe plus.

**La gomme rétablit aussi.** Recliquer sur un mur effacé le remet. La bascule existait dans le
code (`ignored: !w.ignored`) mais était **inatteignable** : la recherche du mur le plus proche
écartait d'emblée les murs ignorés. Effacer était donc définitif, et il fallait redessiner le
mur au crayon. La recherche se fait désormais en deux temps — les murs **actifs** d'abord, les
effacés seulement si aucun actif n'est sous le curseur — sans quoi un mur effacé passant sous un
mur actif serait rétabli à la place de celui qu'on visait, et la gomme deviendrait imprévisible
là où le plan est dense, c'est-à-dire aux angles.

### Ce que les outils existants ne faisaient pas

| Outil | Limite |
|---|---|
| `mergeCollinearSegments` (« Fusionner la sélection ») | Exige une sélection, zone par zone, **et** des murs déjà quasi alignés (10 px en dur). |
| `extendToIntersections` | Ne regarde que **le premier** mur perpendiculaire trouvé, et exige que le croisement tombe déjà **dans** son étendue — donc ne referme jamais un mur qui s'arrête trop tôt, qui est le cas courant. |
| `snapCorners` | Ne traite que les **coins**, jamais les T ni les croix. |

### Les quatre passes, et pourquoi cet ordre

1. **Aligner** — les murs parallèles distants de moins de `alignTolerance` sont le même mur, et
   sont ramenés sur un axe commun. Sans cette passe d'abord, les suivantes travailleraient sur
   des coordonnées qui se ratent de trois pixels et ne recolleraient rien.
2. **Recoller** — sur cet axe, les morceaux qui se chevauchent ou ne sont séparés que de
   `gapTolerance` deviennent **un seul mur**. Au-delà, c'est une porte, pas un défaut.
3. **Souder** — une extrémité libre à moins de `weldTolerance` d'un mur perpendiculaire est posée
   sur le croisement, **et ce mur est prolongé** s'il s'arrêtait juste avant. C'est cette
   réciprocité qui referme un mur inachevé.
4. **Recoller à nouveau** — la soudure peut rendre jointifs deux murs qui ne l'étaient pas. Sans
   cette passe, l'opération ne serait pas **idempotente** : relancer la fusion continuerait de
   déformer le plan et on ne saurait jamais quand c'est fini. Un test le garde.

### Ce que la fusion s'interdit *(2.24.0)*

Signalé à l'usage : « cela me crée un mur en trop », puis, sur ma première hypothèse, « non je
n'ai pas supprimé le mur, il n'existait pas ». La soudure **inventait** donc du mur. Deux règles
la bornent désormais.

**Une extrémité déjà posée sur un mur ne se prolonge pas.** La soudure existe pour refermer un
mur *inachevé* — un bout qui flotte, la pastille rouge de l'écran — jamais pour rallonger un mur
qui arrive déjà quelque part. Sans cette garde, la tolérance large qu'il faut pour refermer une
pièce à 1,3 m faisait traverser les ouvertures : une cloison proprement arrivée sur un mur était
tirée jusqu'au mur suivant. Le piège était que **ce n'est pas le bout traité qui bougeait**,
mais celui d'en face — un troisième mur cherchait un raccord de son côté et étirait le premier
par réciprocité. La garde couvre donc les deux sens.

**Un vide où l'utilisateur a passé la gomme est un vide voulu.** Les murs effacés ne participent
à aucun calcul, mais ils **témoignent** : le recollage refuse de franchir l'endroit qu'ils
occupent. Sans cette règle, effacer un morceau puis relancer la fusion le faisait reparaître —
et reparaître *réuni à ses voisins en un seul mur plus long*, qu'on ne pouvait plus effacer sans
perdre tout le reste.

### La gomme retire un tronçon, pas tout le mur *(2.24.0)*

Corollaire de la fusion : après elle, un mur de façade est **un seul objet** de bout en bout, et
la gomme — qui efface un objet — l'effaçait en entier. `splitAtJunctions` le découpe d'abord à
ses croisements, et seul le tronçon visé est effacé. Rendre à la gomme la granularité que la
fusion lui retire, sans renoncer à la fusion.

| Symbole | Rôle |
|---|---|
| `junctionsAlong(wall, others, tol?)` | Positions des croisements le long d'un mur, dans son propre axe. Ni ses extrémités, ni les murs qui le frôlent. |
| `splitAtJunctions(wall, others, nextId, tol?)` | Découpe le mur à ses croisements ; rend `[wall]` s'il n'y en a aucun. Le premier morceau **garde l'identité** du mur d'origine. |
| `JONCTION_PX` (2) | Distance sous laquelle une extrémité est tenue pour posée sur un mur. Volontairement serrée : elle décide si la soudure a le droit d'agir. |

### Trois décisions

**L'axe commun est la moyenne pondérée par la longueur, et le groupe est ancré sur le mur le plus
long.** Un mur de façade porte la vérité du plan, un moignon de vingt pixels ne porte rien : à
moyenne simple, le moignon tirerait la façade à lui. L'ancrage évite en outre l'**effet de
chaîne** — en agrégeant de proche en proche, dix murs décalés chacun de trois pixels finiraient
dans le même groupe et le dernier serait déplacé de trente. Chaque membre est à moins de
`alignTolerance` **de l'ancre**, jamais de son voisin.

**Le rapport dit ce qui a bougé, et de combien** (`maxShiftPx`, converti en centimètres dans le
panneau via l'échelle calée). Une fusion qui déplace un mur de quarante pixels sans le dire
retouche le relevé dans le dos de celui qui l'a fait. Même parti que `solveWallDimensions`, qui
rend son résidu.

**Les murs ignorés ne sont pas touchés** : ils ont été effacés à la gomme, les faire reparaître
fusionnés défairait un geste explicite. Ils traversent le module inchangés et ne participent à
aucun calcul.

### API exportée — `wall-merge.const`

Fonctions **pures** — ni Fabric, ni DOM, ni canvas, ni Angular.

| Symbole | Rôle |
|---|---|
| `mergeWalls(walls, options?, scope?)` | `WallMergeResult` = `{ walls, report }`. `scope` restreint l'opération à un prédicat ; les murs écartés, comme les murs ignorés, sont rendus **inchangés**. Idempotent. |
| `WallMergeOptions` | `alignTolerance` · `gapTolerance` · `weldTolerance`, en pixels. |
| `wallMergeOptions(params)` | Déduit les tolérances des réglages **déjà posés** par l'utilisateur : `clusterDistance` (épaisseur de mur) → alignement, `extensionDistance` → recollage. Le scanner écrase ensuite `weldTolerance` avec le curseur « Distance de raccord » — voir ci-dessus pourquoi cette seule tolérance-là est réglable. |
| `DEFAULT_WALL_MERGE_OPTIONS` | 30 / 40 / 40 px — repli quand aucun réglage n'est disponible. |
| `WallMergeReport` | `before`, `after`, `aligned`, `welded`, `maxShiftPx`. |
| `orientationOf(segment)` | `'H'` ou `'V'` selon la plus grande étendue. |

---

## Lecture d'un document de plan — `parsePlanDocument`

> **Depuis la 2.14.0.** Un document de plan venu de l'extérieur (fichier importé, brouillon
> `localStorage`, charge utile d'une app hôte) est **vérifié avant d'être chargé**, et refusé
> avec un motif et le **chemin JSON** de la première violation.

### Ce que ça remplace

Toute la gestion de version tenait dans `ExportService.fromFile` :

```ts
if (!project.version || !Array.isArray(project.objects)) reject(…);
if (project.version !== '5.3.0') console.warn(`… compatibilité non garantie.`);
resolve(project);   // ← chargé quand même
```

Deux champs de la racine, puis un avertissement en console — **suivi d'un chargement**. Un
document tronqué passait donc la porte : un `floors[2]` sans `objects`, un objet sans `type`
(que Fabric écarte **sans rien dire**), un `pixelsPerMeter` à zéro. Le plan se rechargeait à
moitié, sans erreur. Et le premier changement de format aurait corrompu des plans en silence,
faute de migration.

### Le contrat

```ts
const lu = parsePlanDocumentText(texte);       // ou parsePlanDocument(objetDéjàParsé)
if (!lu.ok) {
  console.warn(planParseErrorMessage(lu.error));   // « Plan refusé (« floors[2].objects[7].type ») : … »
  return;
}
const plan: FloorplanProject = lu.value;
```

- **Un plan à la version courante est rendu inchangé, par référence** — aucune copie, aucune
  normalisation. C'est le critère d'acceptation du lot (round-trip strict : sérialiser → lire →
  re-sérialiser rend un texte identique), et c'est aussi la seule façon de ne pas dupliquer en
  mémoire un plan qui porte un fond de carte en base64.
- **Le refus est une valeur de retour, pas une exception** : une exception se rattrape en
  `catch {}` et se perd. `ExportService.fromFile` continue toutefois de rejeter une `Error`
  (dont le message **est** le motif) pour ne rien casser chez ses appelants.
- **Le message est en français** et voyage avec l'erreur : un motif reconstruit dans chaque
  gabarit finit par manquer quelque part.

### Ce que les gardes exigent — et ce qu'elles tolèrent

Gardes **écrites à la main** : le schéma est fermé et petit, le coût bundle d'un validateur
runtime ne se justifie pas. Contrepartie assumée : `plan-document.const.ts` est à relire quand
`FloorplanProject` change.

| Champ | Règle |
|---|---|
| `version` | Chaîne non vide, **obligatoire**. Version inconnue sans migration → refus (plus de `console.warn` suivi d'un chargement). |
| `pixelsPerMeter` | Nombre fini **> 0**, obligatoire. Sans échelle, aucune longueur ni surface n'a de sens. |
| `objects` | Tableau, obligatoire. Chaque entrée : objet portant un `type` Fabric **non vide**. |
| `objects[i].type` | **Obligatoire** — sans lui, `loadFromJSON` écarte l'objet *sans erreur* : le plan se rechargerait amputé et rien ne le dirait. |
| `objects[i].myType` | Facultatif ; chaîne non vide s'il est là. Absent, l'objet est dessiné mais muet pour le métier — défaut partiel et réparable, qui ne justifie pas de refuser tout un plan. |
| `objects[i].data` | Facultatif ; objet s'il est là. |
| `floors[i]` | `id` obligatoire (les objets d'un niveau sont rangés par cet identifiant) et `objects` obligatoire. `name` et `order` **facultatifs** : le chargement les lit déjà avec un repli (`f.order ?? 0`), refuser aujourd'hui ce qu'on acceptait hier serait une régression. |
| `geo` | Facultatif ; `lat` ∈ [−90, 90] et `lng` ∈ [−180, 180] obligatoires s'il est présent — une ancre à moitié écrite placerait le plan ailleurs avec toutes les apparences du juste. `zoom` facultatif (une ancre d'hôte n'en porte pas toujours), `valid` booléen s'il est là. |
| `meta` | Facultatif ; chaînes et `workModes: string[]` s'ils sont là. |
| Champs inconnus | **Tolérés.** Le format n'est fermé que dans un sens : une version plus récente, ou une app hôte, peut avoir ajouté un champ. |

L'erreur porte la **première** violation, pas toutes : continuer à interpréter un document dont
on vient d'établir qu'il ne respecte pas le format ne produirait que des violations en cascade
dérivées de la première.

`error.received` **résume** la valeur fautive et ne la recopie jamais : un `Backdrop` porte son
image en base64, et l'écrire dans un motif mettrait des mégaoctets dans la console, dans les
journaux de l'hôte et dans le presse-papier de l'utilisateur qui recopie le message.

### La chaîne de migrations

Une **fonction par saut de version**, composables. `migratePlanDocument` les enchaîne jusqu'à
`PLAN_DOCUMENT_VERSION`, puis les gardes s'appliquent — dans cet ordre, puisqu'elles décrivent
le format **courant**.

`PLAN_MIGRATIONS` est **vide aujourd'hui, et c'est exact** : `5.3.0` est le seul format que
g-plan ait jamais écrit. Le moteur est là **avant** le premier saut, précisément parce
qu'après il serait trop tard. Une entrée inventée « pour l'exemple » transformerait des
documents qui n'existent pas.

**Pour ajouter un format** : bumper le littéral de `FloorplanProject['version']` et
`PLAN_DOCUMENT_VERSION`, puis pousser une entrée `{ from, to, describe, migrate }` dans
`PLAN_MIGRATIONS`. Trois protections sont déjà en place :

- la version d'arrivée est **reposée par le moteur**, pas laissée à l'étape — une migration qui
  oublierait de l'écrire ferait rechercher indéfiniment le même saut, soit un plan qui ne
  charge jamais, sans message et sans pile ;
- une chaîne **cyclique** est détectée et refusée au lieu de boucler ;
- une migration qui lève, ou qui ne rend pas un objet, produit un refus **nommant l'étape**
  (`describe`) : « la migration a échoué » sans dire laquelle n'est pas un motif.

### API exportée — `plan-document.const`

Fonctions **pures** — ni Fabric, ni DOM, ni canvas, ni `localStorage`.

| Symbole | Rôle |
|---|---|
| `parsePlanDocument(raw, migrations?)` | `Result<FloorplanProject, PlanParseError>` depuis un objet déjà désérialisé. Racine → migration → gardes. |
| `parsePlanDocumentText(text, migrations?)` | Idem depuis le **texte** JSON. C'est ici que s'arrête un fichier tronqué (`code: 'invalid-json'`). |
| `migratePlanDocument(doc, migrations?)` | Amène un document à `PLAN_DOCUMENT_VERSION` en composant les sauts. Rend le document **inchangé, par référence**, s'il y est déjà. |
| `planParseErrorMessage(error)` | Motif prêt à afficher : « Plan refusé (« *chemin* ») : *message* ». Chemin vide → « la racine du document ». |
| `PLAN_DOCUMENT_VERSION` | Version du format écrite par cette bibliothèque (`'5.3.0'`), synchronisée avec le littéral de `FloorplanProject['version']` — le type littéral fait échouer la compilation si les deux divergent. |
| `PLAN_MIGRATIONS` | La chaîne réelle. Vide aujourd'hui. |
| `Result<T, E>` · `ok(value)` · `err(error)` | Succès/échec explicite, discriminé par `ok`. |
| `PlanParseError` · `PlanParseErrorCode` | `{ code, path, message, expected?, received? }`. Codes : `invalid-json`, `not-an-object`, `missing-field`, `wrong-type`, `unsupported-version`, `migration-failed`. |
| `PlanMigration` · `PlanRecord` | Types de la chaîne. `migrate` doit être **pure** : ne pas muter `doc`. |

### Où c'est branché

| Point d'entrée | Comportement |
|---|---|
| `ExportService.fromFile(file)` | Rejette une `Error` dont le message est le motif complet (chemin compris). |
| `PlanEditorComponent.restoreAutosave()` | Un brouillon refusé est **journalisé avec son motif puis supprimé** : il ne se chargera jamais, et le laisser reproposerait indéfiniment une bannière qui ne mène nulle part. |

---

## Géoréférencement & export GeoJSON

> **Depuis la 2.2.0.** Un plan dessiné sur un fond de carte peut être exporté en **GeoJSON
> WGS84 (RFC 7946)**, que l'application hôte affiche sur son propre MapLibre. g-plan n'affiche
> pas de carte géoréférencée lui-même : c'est un problème de **données**, pas de rendu.

### Ce que ça change pour l'hôte — à lire avant tout

- **`project.geo` est désormais réémis.** Il était purement entrant (lu au démarrage, jamais
  réécrit), d'où la perte des coordonnées au premier autosave. **Conséquence directe : la
  position GPS précise du bien entre maintenant dans `projectChange`, `projectSaved`,
  l'autosave `localStorage` et l'export JSON.** Un hôte qui compare les projets en JSON verra
  une différence permanente.
- **`GeoLocation.valid` est un champ dérivé**, recalculé à chaque écriture — ne le renseigne
  plus à la main. Il valait `true` en dur avant la 2.2.0 : les projets antérieurs le portent
  donc à `true` sans que rien ne l'ait vérifié. La dérivation ne s'applique qu'aux ancres
  **posées par g-plan** (`porteAncreGPlan`) : un `geo` réduit à `lat`/`lng`/`zoom` fourni par
  l'hôte est réémis tel quel.
- **`OsmService.captureCurrentView()` change de signature** : `Promise<OsmCapture>` au lieu de
  `Promise<string>`, et elle **rejette** au lieu de rendre une image vide. `captureAt()` garde
  un retour compatible en déstructuration (`{ dataUrl, scaleVal }`), simplement élargi.
- **Le curseur d'échelle est gelé** tant que le plan est ancré sur une carte : changer
  `pixelsPerMeter` invaliderait l'ancre en silence.
- **`config.defaultGridSize` est enfin lu** par le magnétisme (défaut 20 px, 30 en tactile —
  comportement inchangé). Un hôte qui avait réglé cette valeur « sans effet » verra son réglage
  prendre effet.

### L'ancre

Le centre de l'image de capture **est** `geo.lat`/`geo.lng` : c'est l'ancre. Elle est portée
**deux fois**, volontairement — par `project.geo` et par `backdrop.data.geo` : le `data` du fond
absorbe gratuitement un déplacement de l'image, `project.geo` survit à la suppression du fond
et au dépouillement du base64 par l'hôte. **En cas de divergence, `project.geo` fait foi.**

`GeoAnchorParams` (tous les champs facultatifs, pour ne rien casser) : `dpr`, `captureWidth`,
`captureHeight`, `capturedAt`, `layer`, `anchorX`, `anchorY`, `angle`, `scaleX`, `scaleY`,
`bearing`, `source`, `retouchee`, `fondRemplace`, `dessinsAnterieurs`.
`anchorX`/`anchorY` sont explicites parce que la pose au centre du canvas dépend de
`canvasWidth`/`canvasHeight`, qui sont des **entrées de l'hôte que le projet ne persiste pas**.

### Projection — `GeoProjectionService`

La conversion passe par les **pixels-monde Web Mercator au zoom de capture**, et **jamais** par
`pixelsPerMeter` (arrondi à 0,1 à l'écriture, et pollué par le facteur `cos φ`). L'inverse
Mercator est alors **exact** : c'est une bijection définie par la grille de tuiles elle-même.

| Symbole | Rôle |
|---|---|
| `resolveAnchor(project)` | Retrouve l'ancre — cherche le `Backdrop` dans `floors[*].objects` **puis** dans `project.objects` (il n'appartient qu'à **un seul** niveau). |
| `sceneToLngLat(pt, anchor)` · `lngLatToScene(lngLat, anchor)` | Réciproques exactes, tenant compte de `left`/`top`/`angle`/`scaleX`/`scaleY` du fond. |
| `metersPerPixel(lat, zoom)` | Résolution en mètres **sol** par pixel-monde. Définition **unique** de la bibliothèque — la formule était dupliquée à l'identique en trois endroits. |
| `mercatorWorldSize(zoom)` · `lngLatToWorld` · `worldToLngLat` | Mercator direct/inverse en pixels-monde. |
| `MERCATOR_TILE_SIZE` (512) · `MERCATOR_MAX_LATITUDE` (85,051128779806604) | Constantes de la grille. |
| `computeGeoValidity` · `withGeoValidity` · `backdropDeplace` · `memeVueGeo` · `porteAncreGPlan` | Dérivation de `valid` et détection de retouche. |
| `GeoAnchor` · `LngLat` | Types. |

### Garde-fous — une ancre fausse est pire qu'une ancre absente

Un fond déplacé ou remplacé produit un GeoJSON **parfaitement formé et entièrement faux**.
D'où le marquage :

- Déverrouiller le fond marque l'ancre **retouchée** ; la reverrouiller lève le doute **si le
  fond n'a pas bougé**.
- Remplacer le fond de carte par une image locale pose `fondRemplace` — un doute
  **irréversible**, et c'est tout l'intérêt de le distinguer : une image posée exactement à la
  place de la capture ne laisse **aucune** trace géométrique, un reverrouillage effacerait donc
  le doute à tort.
- Poser un fond sur un plan **déjà dessiné** pose `dessinsAnterieurs` : ces objets n'ont pas
  été tracés sur cette carte.
- Une **recapture** repose l'image sur `anchorX`/`anchorY`, à l'angle et à l'échelle
  enregistrés — et non au centre du canvas. La pose enregistrée fait foi ; un écart de dpr ou
  de zoom effectif est absorbé par l'échelle de pose, de sorte que `dpr · scaleX` reste
  invariant.

### Export — `GeoJsonExportService`

| Méthode | Rôle |
|---|---|
| `motifsDeRefus(project): GeoJsonRefus[]` | Ce qui empêche l'export, ou liste vide. À utiliser pour griser un bouton **et expliquer pourquoi**. |
| `peutExporter(project): boolean` | Raccourci booléen. |
| `toFeatureCollection(project)` | Le `FeatureCollection`. Lève `GeoJsonExportError` (propriété `motifs`) sur les mêmes motifs. |
| `toJson(project, indentation?)` · `downloadGeoJson(project, filename?)` | Sérialisation et téléchargement. |

Il travaille sur un `FloorplanProject` **sérialisé** — pas besoin de canvas vivant, ce qui
permet d'exporter depuis un projet stocké.

**Correspondance des types** — table exportée `GEOJSON_GEOMETRY_BY_TYPE` :
`Mur`/`Cloison` et les 9 `Pipe*` → **LineString** ; `DetectedRoom`, `RoomBox`, `HazardZone`,
`Stair` → **Polygon** ; ouvertures, équipements, pictogrammes, prélèvements, tags et flèche
Nord → **Point**. Sont **exclus** les objets dérivés (`WallLabel`, `WallMeasurement`,
`PipeMeasurement`, `RoomLabel`), les calques de fond (`Backdrop`, et `PhotoLayer` depuis la
2.12.0 — calé sur une distance relevée, pas sur des coordonnées terrain) et les `Annotation`,
qui n'ont pas de sémantique métier. Un test de garde échoue si un type de `FABRIC_SAVED_TYPES` n'est pas classé — sans
quoi un type ajouté plus tard disparaîtrait en silence de l'export.

Chaque feature porte `floorId`, `floorName` et `floorOrder` : les niveaux se superposent sur
une carte 2D, **l'hôte doit filtrer**.

**Refus** (`GeoJsonRefusCode`) — strict, sans échappatoire, chacun avec un message actionnable :
`ancre-absente`, `ancre-retouchee`, `ancre-divergente`, `dpr-inconnu`, `dessins-anterieurs`,
`echelle-anisotrope`.

> ⚠ **Tous les plans antérieurs à la 2.2.0 sont refusés** — soit pour `ancre-absente` (le cas
> général : `geo` n'était jamais réémis), soit pour `dpr-inconnu` quand un `geo` partiel
> subsiste. C'est délibéré : sans le dpr **mesuré**, une capture retina rend toutes les
> distances fausses d'un facteur 2, sans que rien ne le signale. Le remède est de **recapturer
> la carte**.

### Précision — ce qui est annoncé, et pourquoi

Le `FeatureCollection` porte trois membres étrangers : `ancre`, `precision`
(`GeoJsonPrecision`) et `avertissement`. Deux constantes sont exportées et **doivent** être
reprises telles quelles par l'hôte qui réaffiche ces données :

- **`GEOREF_DISCLAIMER`** — plan tracé à la main sur un fond lui-même faux de 1 à 5 m ; les
  ouvrages enterrés (fosses, filtres, puits, boîtes, réseaux) sont une **estimation de
  l'opérateur** ; précision **±2 à 5 m en absolu, de l'ordre du mètre en relatif** ; **ce
  document n'est pas un plan de récolement et ne vaut pas réponse à une DT-DICT**.
- **`GEOREF_MESURE_NOTE`** — les longueurs et surfaces de g-plan sont des **mètres sol**.
  Mesurer le GeoJSON directement en EPSG:3857 surestime les distances de `1/cos φ` et les
  surfaces de son carré (**×1,9 à Toulouse**). Mesurer en Lambert-93 (EPSG:2154) ou en
  géodésique.

Deux écarts sont **annoncés et non corrigés**, par cohérence interne : le pas de magnétisme
(20 px, soit ~1 à 3 m au sol selon le dpr) et le biais du demi-trait des extrémités de murs
(~13 cm au sol). Corriger ce dernier dans le seul export rendrait le GeoJSON incohérent avec
lui-même — les polygones `DetectedRoom` sont construits sur ces mêmes extrémités.

### Poids du fond de carte et brouillon

> **Depuis la 2.5.0**, le fond de carte capturé est encodé en **WebP** (qualité 0,85,
> réglable par `config.backdropImageQuality`) et non plus en PNG.

Ce n'est pas une optimisation de confort. Le fond voyage en base64 dans **chaque**
`projectChange`, chaque instantané d'historique et chaque brouillon — et
`buildProjectWithFloors` le sérialise **deux fois**, dans `objects` (niveau courant) *et* dans
`floors[*].objects`. Mesuré sur une capture satellite 2560 × 1920 :

| | PNG (≤ 2.4.0) | WebP (2.5.0) |
|---|---|---|
| Fond | 2 714 Ko | **231 Ko** |
| Projet complet | 5 290 Ko | **465 Ko** |
| Écriture `localStorage` | ❌ `QuotaExceededError` | ✅ |

**Le symptôme que cela corrige** : le quota `localStorage` (~5 Mo) étant dépassé, la sauvegarde
du brouillon échouait **en silence**. Le brouillon proposé au démarrage restait donc celui
d'*avant* la pose du fond, et le restaurer remplaçait le plan en cours par un état vide.

Deux replis subsistent, le quota pouvant être saturé par l'application hôte : le brouillon est
réenregistré **sans l'image du fond** (`meta.brouillonAllege`), qui sera recapturé depuis `geo`
à la restauration ; et si même cela échoue, le brouillon périmé est **supprimé** plutôt que
proposé — restaurer un état obsolète détruit le travail en cours.

> L'encodage est **natif** (`canvas.toDataURL`) : aucun codec WASM à télécharger, et le
> fonctionnement hors ligne est inchangé. Un navigateur sans encodeur WebP retombe sur le PNG,
> avec un avertissement en console plutôt qu'un gain imaginaire.

### Vue CARTE — `<ng-gplan-viewer-map>`

> **Depuis la 2.3.0.** Troisième vue à côté de la 2D et de la 3D : le plan affiché **à sa vraie
> place** sur nos tuiles. **En lecture seule**, comme la vue 3D — on regarde, on ne dessine pas.

```html
<ng-gplan-viewer-map [project]="project" (mapReady)="onCartePrete($event)" />
```

| Membre | Type | Rôle |
|---|---|---|
| `project` | `FloorplanProject \| null` | Projet à afficher. **Doit être géoréférencé** — sinon la vue affiche les motifs de refus. |
| `mapReady` | `boolean` | Émis quand la carte a fini de charger (`true`) ou a échoué (`false`). |

Elle ne fait que **consommer** `GeoJsonExportService` : géométries WGS84, `bbox`, niveaux,
précision et avertissement viennent tous de la collection. Ce qu'elle apporte :

- **Bascule de fond** : satellite, vectoriel, et le cadastre IGN en overlay — marqué comme
  **externe**, un incident IGN n'étant pas un incident g-plan. Le style alternatif
  (`config.tileStyle`) n'apparaît **que s'il diffère réellement** du style principal : sa valeur
  par défaut (`styles/osm-bright`) est celle du style de base, les deux entrées pointaient donc
  la même URL et proposaient deux fois la même carte.
- **Bâtiments 3D** *(2.7.0)* : volumes extrudés depuis la couche `building` du fond vectoriel,
  vue inclinée à 55°, et **rotation au clic droit**. La bascule n'apparaît que si elle a quelque
  chose à montrer — fond **vectoriel** *et* style déclarant des bâtiments : sur satellite
  l'orthophoto porte déjà les toits, et sans données de bâti l'inclinaison ne montrerait qu'un
  plan vide. La rotation est réservée à la 3D : hors 3D le nord reste en haut, seule orientation
  qui se raccorde à la vue 2D, et éteindre la 3D redresse le cap. Le tactile reste exclu de la
  rotation — le geste à deux doigts est involontaire par excellence.
- **Filtre par niveau**, affiché dès qu'il y en a plus d'un. Ce n'est pas cosmétique : les
  niveaux **se superposent** sur une carte 2D. Décocher un niveau **ne recadre pas** — la vue ne
  doit pas bouger sous les yeux de qui compare deux étages.
- **Recadrage** sur `collection.bbox`.
- **Infobulle** au clic : titre métier lisible (« Eaux usées », pas « PipeEU » — repris de la
  légende, donc une seule source de vérité), pastille de la couleur du plan, **mesure
  géodésique** (longueur d'un tracé, périmètre d'une emprise) et propriétés métier. Les
  identifiants techniques (`wallId`, `roomId`…) sont masqués. Une **couche de préhension
  invisible de 18 px** rend les tracés cliquables : un trait de 2,5 px se vise mal à la souris
  et pas du tout au doigt.
- **Récapitulatif des linéaires** *(bouton « 📏 Cotes »)* : longueur par type de réseau et
  total, calculés **en haversine sur les coordonnées projetées** — mesurer en Mercator
  surestimerait les distances de `1/cos(latitude)`, soit ~38 % à Toulouse. C'est la mesure que
  `GEOREF_MESURE_NOTE` recommande aux consommateurs du GeoJSON ; la vue ne s'en dispense pas
  elle-même. Le récapitulatif suit le filtre de niveau.
- **Bandeau de précision permanent**, et non replié derrière un « en savoir plus » : c'est lui
  qui empêche de prendre un tracé indicatif pour un relevé. Bouton d'export GeoJSON à côté.

**Ouvrages d'assainissement.** *(2.4.0)* Les pictogrammes SPANC et AC sont exportés en
**Polygon** et non en Point : une fosse, un filtre à sable ou une tranchée d'épandage occupent
le terrain, et c'est cette emprise qu'on vient lire sur une carte. La vue pose en plus **le
pictogramme lui-même** sur l'emprise, à son angle — un polygone uni dit « il y a quelque chose
ici », le dessin dit *quoi*, et c'est le même qu'en 2D.

> ⚠ **L'étendue est celle réellement dessinée**, pas une dimension relevée. Par défaut c'est une
> taille de **symbole** : à 5 px/m, un pictogramme de 120 px fait 24 m au sol. Elle ne vaut
> mesure que si l'opérateur a redimensionné l'ouvrage. Un pictogramme sans étendue (plan
> antérieur) est **dégradé en Point** plutôt que perdu.
>
> Au-delà de **60 ouvrages**, les suivants restent en polygone uni, sans pictogramme, et un
> avertissement est journalisé — une troncature muette se lirait comme « tout est affiché ».

**Couleurs.** Chaque feature porte une propriété `couleur`, dérivée du trait **réellement
dessiné** (`dominantColor`, exporté depuis `legend.const`) — le même mécanisme que la légende
des exports image. Un réseau EU violet sur le plan reste violet sur la carte, et l'hôte qui
affiche le GeoJSON sur son propre MapLibre dispose de la même information. Sans cela, on aurait
deux nuanciers pour un seul plan.

**Refus.** Un plan non géoréférençable n'affiche **aucune carte** : les motifs de
`motifsDeRefus()` sont listés à la place, et le bouton de l'éditeur est désactivé **avec le
motif en infobulle**. Il n'existe aucun mode « forcer l'affichage » — une carte est persuasive,
un plan mal ancré posé sur du satellite serait cru.

**Trois imprécisions se cumulent** et il faut le savoir avant de juger un rendu « faux » : la
quantification de la grille (1 à 3 m au sol), le calage du fond (1 à 5 m), et le **déport des
toitures** sur une orthophoto non nadirale (0,5 à plusieurs mètres pour une maison à étage).

### Tuiles — `map-styles.const`

| Symbole | Rôle |
|---|---|
| `baseStyle(config)` · `customStyle(config)` · `satelliteStyle(config)` · `layerStyle(layer, config)` | Résolution des feuilles de style, partagée par `OsmService` et la vue carte. |
| `DEFAULT_SATELLITE_TILES_URL` | Serveur de tuiles satellite par défaut. |
| `PROJECTION_LOCK` · `enforceMercator(map)` | Verrouillage Mercator, `bearing`/`pitch` nuls. |
| `cadastreTiles(config)` · `DEFAULT_CADASTRE_TILES_URL` | Overlay cadastre, configuration de l'hôte comprise. |
| `FALLBACK_OSM_STYLE` | Repli OSM public quand l'hôte n'a pas de tileserver. |
| `loadMapLibre()` | Chargement **dynamique** de maplibre-gl (~1 Mo) : une application qui n'ouvre jamais de carte ne le télécharge pas. |

> **Erreurs de fond — ce qui est signalé, et ce qui ne l'est pas** *(2.7.0)*
>
> Une incohérence entre la feuille de style et le jeu de tuiles (`Source layer "railway" does
> not exist on source "openmaptiles"`) est un défaut d'exploitation **du serveur de tuiles** :
> le style réclame une couche que les tuiles ne fournissent pas. La couche décorative manque, le
> fond reste parfaitement lisible. C'est donc journalisé en console pour l'exploitant, **sans
> bandeau** — tout signaler à l'écran reviendrait à crier au loup et masquerait les vraies pannes.
> Les échecs de chargement réels, eux, restent affichés.

> **Feuille de style MapLibre** *(2.4.0)* — g-plan embarque lui-même les règles de mise en page
> indispensables de `maplibre-gl.css`, scopées à ses composants. **Aucun hôte n'importait cette
> feuille**, et sans elle `.maplibregl-canvas` n'est pas positionné en absolu : le canvas WebGL
> tombe dans le flux normal, la carte pousse la page vers le bas et les contrôles s'empilent
> n'importe où. Rien à ajouter côté application — et la modale OSM, qui en souffrait depuis
> l'origine, est corrigée du même coup.
>
> L'infobulle de la carte est rendue **par le composant**, et non par `maplibregl.Popup`, pour
> la même raison : elle sortait sans mise en forme, en bas de page, hors de la carte.

> **Cadastre** *(corrigé en 2.6.0)* — la couche employait `STYLE=bdparcellaire`, **qui n'existe
> pas** sur la Géoplateforme IGN : chaque tuile revenait en `HTTP 400 — Style bdparcellaire
> unknown`. Le style correct est `PCI vecteur`. Le défaut était invisible parce que **MapLibre ne
> dit rien d'une tuile raster en échec** : la case se cochait, rien n'apparaissait, aucune erreur.
> `config.cadastreTilesUrl` permet désormais de servir le cadastre depuis une infrastructure
> maison plutôt que de dépendre de la disponibilité de l'IGN.
>
> **Mentions de source — obligation de licence, pas décoration** *(2.6.0)*
>
> Le Plan Cadastral Informatisé est diffusé sous **Licence Ouverte 2.0 (Etalab)** : l'usage
> **commercial est autorisé**, à la condition expresse de citer la source et sa date de mise à
> jour. g-plan déclare donc désormais l'attribution sur la couche cadastre
> (`DEFAULT_CADASTRE_ATTRIBUTION`, surchargeable par `config.cadastreAttribution`), et la carte
> de la modale affiche son contrôle d'attribution — il était **désactivé**, donc aucune mention
> n'apparaissait nulle part.
>
> Pour l'**imagerie satellite**, g-plan ne fournit **aucune valeur par défaut** et signale son
> absence en console. Ce n'est pas un oubli : *héberger* les tuiles ne dit rien des droits sur
> les **pixels**. Si l'imagerie dérive de la BD ORTHO de l'IGN, elle relève de la même Licence
> Ouverte 2.0 — usage commercial permis, attribution due. Si elle vient d'un fournisseur
> commercial, c'est son contrat qui s'applique, et en héberger une copie peut y contrevenir.
> Seule l'application hôte connaît cette réponse : `config.satelliteAttribution`.
>
> La capture hors-écran servant de fond de plan **n'affiche pas** de contrôle d'attribution :
> la mention serait gravée dans l'image et suivrait le plan partout. C'est à l'application hôte
> de l'afficher à côté du plan, dans ses exports et ses rapports.

> **`config.satelliteTilesUrl`** *(nouveau en 2.3.0)* — l'URL des tuiles satellite était
> **gravée dans la bibliothèque** : un hôte recevait notre serveur qu'il le veuille ou non, sans
> pouvoir pointer un miroir ni distinguer recette et production, là où le fond vectoriel passait
> depuis toujours par `tileServerUrl`. Le champ est facultatif — sans lui, rien ne change.

### Géométrie de plan — `plan-geometry.const`

Extracteur commun à tous les objets, en coordonnées scène absolues, sur objet Fabric vivant
comme sérialisé : `absLineEnds`, `absPolylinePoints`, `absTracePoints`, `absRectCorners`,
`absRingPoints`, `absCenter`. `pipeAbsPoints` s'appuie dessus.

---

## Redressement automatique par points de fuite

*Depuis 2.20.0.* On avait d'abord essayé de détecter **la feuille** — le plus grand
quadrilatère de l'image — puis de la redresser. Mesuré sur une photo réelle : aucun
quadrilatère. On cadre serré pour que le plan remplisse l'image, le contour du support sort
donc du champ, et `approxPolyDP` ne rend jamais quatre côtés. Cette voie est un cul-de-sac dès
que la photo est bien cadrée, c'est-à-dire toujours.

Les points de fuite se lisent sur **le dessin**, qui est toujours entier dans l'image. Un plan
est fait de deux familles de parallèles perpendiculaires ; en perspective chacune converge, et
les deux directions suffisent à retrouver l'orientation de la feuille. Deux traits extrêmes de
chaque famille donnent quatre intersections — un quadrilatère qui est un **rectangle dans le
monde réel**, exactement l'hypothèse dont `rectifyQuad` a besoin pour recouvrer la focale et le
rapport d'aspect.

| Symbole | Rôle |
|---|---|
| `separerFamilles(segments)` | Sépare en deux familles perpendiculaires. Ne suppose **pas** 0°/90° : une photo tenue de travers les décale toutes deux. Direction dominante par histogramme pondéré par la **longueur** — un croquis compte beaucoup de petits traits parasites et peu de longs murs, or ce sont les murs qui portent l'orientation. |
| `quadrilatereDeReference(segments, marge?)` | Les quatre coins, ou `null` si une famille est trop pauvre (`TRAITS_MIN_FAMILLE`) ou si le quadrilatère dégénère. Façade de `diagnostiquerRedressement`. **`marge` vaut 0 par défaut depuis la 2.21.0.** |
| `diagnostiquerRedressement(segments, marge?)` | *Depuis 2.21.0.* `RedressementDiag` : le quadrilatère **et ce qui a été vu** — `raison` rédigée en cas de refus, `nbSegments`, `nbHorizontaux`/`nbVerticaux`, `angleH`/`angleV`. |
| `intersection(a, b)` · `ecartAngulaire(a, b)` | Primitives homogènes ; `null` sur des droites parallèles. |
| `reduireDansCadre(poly, l, h)` | Ramène un polygone dans le cadre en le **réduisant en bloc** autour de son centre. |
| `ECART_FAMILLE_DEG` · `TRAITS_MIN_FAMILLE` · `QUANTILE_EXTREME` | 30°, 4 traits, 10 %. |
| `MARGE_CADRAGE` | 12 %. **Déprécié en 2.21.0**, plus appliqué par défaut — voir ci-dessous. |

### La marge a changé de côté *(2.21.0)*

La marge de tracé — la place qu'il faut autour du dessin pour pouvoir tracer l'enveloppe du
bâtiment — est désormais prise **à la destination du redressement**
(`MARGE_REDRESSEMENT`, dans `photo-homography.const`), et non plus en dilatant le quadrilatère
détecté. Deux raisons, l'une de comportement, l'autre de justesse :

1. **elle ne survivait pas.** Dilaté de 12 %, le quadrilatère sortait du cadre dès que la photo
   était cadrée serré — c'est-à-dire toujours, puisqu'on cadre pour que le plan remplisse
   l'image — et `reduireDansCadre` le ramenait en le réduisant en bloc, annulant exactement ce
   que la dilatation venait d'ajouter. La marge était donc **nulle précisément dans le cas
   courant**, et rien ne le disait ;
2. **elle se payait en justesse.** `dilaterConvexe` pousse les sommets à distance constante
   depuis le centroïde : ce n'est pas une homothétie, donc la forme du quadrilatère change,
   donc le rapport d'aspect et la focale que `rectifyQuad` en déduit changent aussi.

Prise à la destination, la marge vaut en outre pour **tous** les chemins — coins déduits des
points de fuite comme coins posés au doigt dans l'assistant.

`reduireDansCadre` reste en place comme filet : quand un coin sort de la photo, le
quadrilatère est **réduit en bloc** autour de son centre, jamais rabattu sommet par sommet — le
rabattement indépendant change la **forme**, donc fausse l'aspect et la focale, et le
redressement sortirait plausible et faux.

### Le diagnostic en console *(2.21.0)*

`quadrilatereDeReference` rend `null` dans cinq situations distinctes, et un `null` ne dit pas
laquelle — or c'est la seule question qui compte devant une photo qui ne se redresse pas.
`diagnostiquerRedressement` rend le motif **rédigé en français**, comme `parsePlanDocument` et
`scannerScale`, et le scanner l'écrit en console à chaque changement de diagnostic (jamais en
boucle : le message n'est réécrit que s'il change, sinon traîner un curseur de réglage
inonderait la console) :

```
[G-Plan] Redressement auto : quadrilatère déduit — 37 traits à 12.4° et 21 à 102.4° sur 96 segments. [{x: …}, …]
[G-Plan] Redressement auto indisponible : familles trop pauvres (2 trait(s) à 8.0° et 11 à 98.0°, il en faut 4 de chaque) — le dessin n'a pas assez de parallèles pour porter la perspective.
[G-Plan] Scanner : image redressée 1836×1402 px (rapport 1.31 — points de fuite, focale ~1820 px), échelle 47.2 px/m.
[G-Plan] Calque photo : document redressé 1640×1252 px, image 2034×1552 px avec la marge de tracé (197 px / 150 px) — rapport 1.31 (points de fuite, focale ~1820 px).
```

Les cinq motifs possibles : aucun segment détecté · aucune direction dominante · trop peu de
segments (moins de 8, la détection n'a rien rendu) · familles trop pauvres, avec le compte et
les angles de chacune · quadrilatère écrasé (droites presque concourantes).

**Sur les segments BRUTS, jamais sur les murs.** `DetectionResult.houghSegments` conserve les
segments tels que Hough les a vus : les `walls`, eux, sont plaqués sur les axes, si bien que
leurs points de fuite sont à l'infini et le quadrilatère obtenu un rectangle — un redressement
qui ne redresse rien.

Les traits extrêmes sont pris au **quantile** (10 %) et non aux bornes absolues : un seul
artefact résiduel — un pli du papier, une ombre — tirerait sinon tout le quadrilatère jusqu'au
bord de l'image.

### Ce que cela donne, et ce que cela ne donne pas

Le scanner ouvre désormais l'assistant de redressement **directement à l'étape des coins**, la
photo déjà chargée et les quatre poignées posées sur le dessin. C'est une **proposition à
ajuster**, pas une réponse définitive : les coins suivent les traits extrêmes du plan, donc
approchent le contour de la feuille sans le viser. L'échelle, elle, continue de venir du calage
sur une distance connue — rien dans une photo ne permet de la deviner.

---

## Détection de murs — réglages dérivés de l'image

*Depuis 2.19.0.* Les réglages du scanner étaient des **pixels absolus** : un bloc de seuillage
de 3, une longueur minimale de 40 px. Or une photo de plan fait 1 000 px sur un téléphone et
4 000 sur un autre — les mêmes chiffres n'y décrivent pas la même chose, et un bloc de 3 ne voit
que le grain du crayon, jamais le trait.

### Ce qui a changé dans le pipeline

| Étape | Avant | Maintenant |
|---|---|---|
| Seuillage adaptatif | `blockSize` = réglage brut (3 par défaut) | **3 % du grand côté**, impair |
| Morphologie | `MORPH_OPEN` avec un élément **1×1** — sans effet | **Ouvertures H et V séparées**, noyaux à 1/28 du côté |
| Longueur minimale | 40 px absolus | max(réglage hôte, **4 % de la hauteur**) |
| Bords de support | — | segments longeant le cadre **ou** traversant la photo, écartés |

L'ouverture morphologique en H puis en V, réunies par `bitwise_or`, est ce qui **sépare un mur
d'une écriture** : une cloison court sur une fraction notable de la feuille, tandis que les
lettres de « SÉJOUR » ou les chiffres d'une cote n'ont de longue course dans aucune des deux
directions et ne survivent pas à l'ouverture.

### API — `wall-detection-tuning.const`

| Symbole | Rôle |
|---|---|
| `reglagesPour(largeur, hauteur)` | Réglages effectifs déduits de l'image (`blocSeuil` impair, `noyauH`/`noyauV`, `longueurMin`, `ecartMax`, `bandeBord`). |
| `estCadre(segment, l, h, bande)` | Vrai si le segment **longe** un bord de la photo : il doit tenir dans la bande **et** courir parallèlement à elle — un mur qui traverse la bande n'est pas un cadre. |
| `estBordDeSupport(segment, l, h)` | Vrai si le segment traverse la photo de part en part (≥ 90 % dans sa direction). Attrape ce que la bande laisse passer : un bord de cahier en retrait du cadre. |

Les deux filtres s'appliquent **avant et après** le regroupement : un bord de cahier se détecte
en morceaux courts, que le regroupement recolle ensuite en un unique trait traversant — c'est
seulement là qu'il devient reconnaissable.

### Ce que cela ne fait pas

Le redressement de perspective reste **manuel** (« Redresser et caler la photo »). La détection
automatique de la feuille a été essayée et écartée : sur une photo cadrée serré, le contour du
support est coupé par le bord de l'image et aucun quadrilatère complet n'existe. L'échelle,
elle, continue de venir du calage — sans lui, l'export reste bloqué.

---

## Emprise au sol — `plan-geometry.const`

*Depuis 2.18.4.* La vue 3D posait sa dalle et sa pelouse sur une **boîte englobante alignée
sur les axes**. C'est juste pour un bâtiment d'équerre, et faux dès qu'il est tracé de biais —
ce qui est le cas ordinaire d'un croquis suivant l'orientation réelle du bâti sur une
orthophoto. Sur une pièce tournée de 30°, la boîte déborde de plusieurs mètres sur les quatre
côtés.

| Symbole | Rôle |
|---|---|
| `convexHull(points)` | Enveloppe convexe (parcours monotone d'Andrew), sommets en sens trigonométrique, doublons et coordonnées non finies écartés. Moins de trois points distincts : rend l'entrée. |
| `dilaterConvexe(poly, marge)` | Dilate un polygone **convexe** en poussant chaque sommet le long de sa bissectrice depuis le centroïde. Approximation suffisante pour une dalle qui déborde des murs ; **pas** un offset exact. |

Une enveloppe convexe comble le renfoncement d'un bâtiment en L : la dalle y est légèrement
plus grande que l'emprise, ce qui reste physiquement juste — une dalle déborde sous les murs —
là où une boîte non orientée est visiblement fausse.

---

## Géométrie des réseaux — API exportée

Ces fonctions pures absorbent les **deux formats** de tracé (polyligne 2.1+ et
`fabric.Line` à deux points des plans antérieurs) et acceptent aussi bien un objet Fabric
vivant que sa forme sérialisée — indispensable, `PlanAnalysisService` et la vue 3D
n'ayant jamais de canvas sous la main.

| Symbole | Rôle |
|---|---|
| `pipeAbsPoints(obj)` | Sommets **absolus** du tracé, en coordonnées scène. |
| `pipeSegments(obj)` | Couples de sommets consécutifs (`{p1, p2}[]`). |
| `pipeLengthPx(obj)` | Longueur **développée** en pixels (somme des segments). |
| `pipeMidpoint(obj)` | Point au milieu du développé — là où se pose la cote. |
| `isPipeType(myType)` | Vrai pour un tracé de réseau ; **faux** pour `PipeMeasurement`, qui est une étiquette de cote. |

---

## Magnétisme de croquis — angle contraint et fermeture

*Depuis 2.9.0.* Un diagnostiqueur fait un **croquis**, pas un relevé métré : il trace vite,
souvent au doigt sur une tablette, et ce qui doit ressortir juste, c'est la **forme** — des
angles droits là où il y en a, une pièce qui se referme. Jusqu'ici g-plan n'accrochait que des
*positions* (nœud, mur, grille) et rien ne contraignait la **direction** d'un segment : un
rectangle tracé à la main sortait avec des angles à 87° et 93°, et la grille n'y pouvait rien —
son pas de 20 px ne dit rien de l'angle entre deux points qui tombent tous deux dessus.

### Ordre d'accroche (murs et cloisons)

Le premier critère satisfait l'emporte :

| # | Accroche | Portée | Couleur de l'aperçu |
|---|---|---|---|
| 1 | **Nœud existant** ou extrémité de mur | 20 px | ambre |
| 2 | **Milieu** de mur, puis projection sur son corps (raccord en T) | `defaultSnapDistance` (15 px) | ambre |
| 3 | **Angle contraint** — multiple de 15° depuis le sommet précédent | ±4°, **±8°** sur les multiples de 90° | sarcelle |
| 4 | **Alignement** sur l'abscisse ou l'ordonnée d'un point existant | 8 px | violet |
| 5 | **Grille** (`defaultGridSize`) | — | gris |

Les accroches positionnelles passent **avant** l'angulaire à dessein : un croquis dont les murs
ne se touchent pas ne produit aucune pièce, alors qu'un croquis d'équerre à 2° près reste
parfaitement lisible.

La zone d'attraction est **doublée sur les multiples de 90°** — l'équerre est ce qu'on cherche
neuf fois sur dix, et c'est là que l'erreur du doigt se voit le plus. Elle reste volontairement
inférieure au demi-pas (7,5°), sans quoi toute direction tomberait dans une zone et le tracé
libre deviendrait impossible : autour de 0°, la capture va jusqu'à 8° et ne reprend qu'à 11°.

**`Maj` enfoncée suspend tout le magnétisme** — le trait suit exactement le doigt. Les tracés de
**réseau** restent libres comme avant : angles et positions sans contrainte.

### Retour visuel

Pendant le tracé, l'aperçu porte une **cote vivante** (`3,20 m · 90°`) et change de couleur
selon l'accroche obtenue (tableau ci-dessus) ; il passe du pointillé au trait plein dès qu'une
contrainte s'applique. Sans cela le magnétisme serait invisible : rien ne distinguerait un angle
droit exact d'un 89° convaincant.

### Fermeture de boucle et répartition de Bowditch

Revenir à moins de **50 cm** du point de départ (`RAYON_FERMETURE_M`, converti par
`pixelsPerMeter`), après **trois murs au moins**, ferme la boucle et clôt le tracé. Un repère
vert marque le point de départ dès qu'on entre dans le rayon.

La fermeture n'est pas un simple rappel du dernier sommet sur le premier : ce serait faire
pivoter le dernier segment de tout l'écart, en détruisant l'angle qu'on venait de contraindre.
g-plan applique la **répartition de Bowditch** (règle de la boussole, empruntée au cheminement
topographique) : chaque sommet est décalé de l'erreur de fermeture **au prorata du chemin
parcouru depuis le départ**. Le premier ne bouge pas, le dernier encaisse la totalité et retombe
exactement sur le premier — et chaque angle ne se déplace que d'une fraction de l'écart.

Au-delà de **8 %** du périmètre (`SEUIL_ALERTE_FERMETURE`), la correction s'applique quand même
— c'est un croquis, pas un relevé — mais un avertissement console explique que les murs ont été
déplacés, pour que l'utilisateur puisse relier ce qu'il voit à ce qu'il a tracé.

À l'intérieur du rayon de fermeture, l'accroche au nœud de départ est **volontairement
désactivée** : elle poserait le point exactement sur le premier sommet et il ne resterait aucun
écart à répartir — le dernier mur garderait alors son angle de travers.

### API exportée — `sketch-snap.const`

| Symbole | Rôle |
|---|---|
| `accrocherCroquis(pt, ctx)` | Point retenu et **nature** de l'accroche (`{x, y, type}`), selon l'ordre ci-dessus. |
| `contraindreAngle(origine, pt, pas?)` | Projection sur le multiple d'angle le plus proche, ou `null` hors zone d'attraction. |
| `aligner(pt, references, tol?)` | Alignement sur l'abscisse et/ou l'ordonnée d'un point existant, ou `null`. |
| `repartirBowditch(sommets)` | Cheminement fermé + `erreurPx`, `perimetrePx`, `ratio` ; `null` si moins de quatre sommets ou longueur nulle. |
| `rayonFermeturePx(pixelsPerMeter)` | Rayon de fermeture en pixels (50 cm à l'échelle du plan). |
| `PAS_ANGULAIRE` · `TOLERANCE_ANGLE` · `TOLERANCE_ORTHO` · `TOLERANCE_ALIGNEMENT` | Réglages du magnétisme (15°, 4°, 8°, 8 px). |
| `RAYON_FERMETURE_M` · `SEUIL_ALERTE_FERMETURE` | 0,5 m ; 8 % du périmètre. |
| `TypeAccroche` · `Accroche` · `ContexteAccroche` | Types du contrat. |

Ces fonctions sont **pures** — ni Fabric, ni DOM, ni canvas. `FabricCanvasService` se contente
de leur fournir un contexte lu sur le canvas et d'appliquer le résultat.

---

## Annotations — API exportée

| Symbole | Rôle |
|---|---|
| `ANNOTATION_COLORS` | Palette proposée (`{ id, label, color }[]`), la première entrée étant la couleur par défaut. |
| `ANNOTATION_TYPE` | `myType` porté par toutes les formes d'annotation (`'Annotation'`). |
| `AnnotationShape` | `'rect' \| 'circle' \| 'arrow'` — valeur de `data.shape`. |
| `isAnnotationMode(mode)` | Vrai si le mode d'édition dessine une forme d'annotation. |
| `ANNOTATION_MIN_PX` · `ANNOTATION_STROKE_WIDTH` · `ANNOTATION_ARROW_HEAD_PX` | Réglages de tracé (seuil de création, épaisseur, taille de pointe). |
| `FabricCanvasService.annotationColor()` · `setAnnotationColor(c)` | Couleur active de la palette, partagée par les trois formes. |

---

## Cas d'usage courants

### Charger un projet existant

```ts
// Depuis un fichier JSON précédemment sauvegardé
import { FloorplanProject } from 'g-plan';

// Méthode 1 — input direct
myProject: FloorplanProject = JSON.parse(savedJson);

// Méthode 2 — two-way binding (ng-gplan met à jour myProject à chaque changement)
// <ng-gplan [(project)]="myProject" />
```

### Récupérer les données (surfaces, pièces)

```ts
onRooms(floors: FloorRooms[]): void {
  for (const floor of floors) {
    console.log(`${floor.floorName} — ${floor.totalArea.toFixed(1)} m²`);
    for (const room of floor.rooms) {
      console.log(`  ${room.label}: ${room.areaM2.toFixed(1)} m²`);
    }
  }
}
```

### Récupérer le PNG pour l'envoyer à un serveur

```ts
onPng(blob: Blob): void {
  const form = new FormData();
  form.append('plan', blob, 'plan.png');
  this.http.post('/api/upload', form).subscribe();
}
```

### Charger automatiquement un fond de carte depuis une position GPS

Renseignez `project.geo` et passez `autoGeoLayer` pour qu'un fond satellite (ou vectoriel)
soit chargé automatiquement en offscreen sans que l'utilisateur ouvre la modal :

```ts
// projet avec coordonnées GPS
const project: FloorplanProject = {
  version: '5.3.0',
  pixelsPerMeter: 50,
  objects: [],
  geo: { lat: 43.6628, lng: -1.3921, zoom: 18, valid: true }
};
```

```html
<!-- fond satellite automatique au zoom 18 -->
<ng-gplan [(project)]="project" autoGeoLayer="satellite" />

<!-- fond vectoriel OSM -->
<ng-gplan [(project)]="project" autoGeoLayer="osm" />
```

Le fond est chargé **une seule fois** au démarrage, uniquement si aucun `Backdrop` n'est déjà
présent dans le projet. L'échelle est calculée automatiquement depuis le zoom/latitude.

### Chargement géo direct (`geoPoint`)

Quand l'app hôte (mobile / administration) connaît déjà les coordonnées du point à
diagnostiquer, elle peut les passer directement via `geoPoint` — l'éditeur charge alors
le fond de carte au démarrage **sans que l'utilisateur ait à ouvrir la modale OSM ni à
chercher l'adresse**.

```ts
// Coordonnées envoyées par l'app hôte
point = signal<{ lat: number; lng: number } | null>(null);
// ex : this.point.set({ lat: 43.6028, lng: 1.4339 });
```

```html
<!-- Zoom max (19) + fond satellite par défaut -->
<ng-gplan-plan-editor [project]="project()" [geoPoint]="point()" />

<!-- Surcharge possible du zoom et de la couche -->
<ng-gplan-plan-editor
  [project]="project()"
  [geoPoint]="{ lat: 43.6028, lng: 1.4339, zoom: 18, layer: 'osm' }" />
```

Comportement :
- `zoom` omis → **zoom maximum (19)** pour le plus de détail.
- `layer` omis → valeur de `autoGeoLayer` si défini, sinon `'satellite'`.
- **Prioritaire sur `project.geo`** : si les deux sont fournis, `geoPoint` gagne.
- Ne charge **rien** si un `Backdrop` est déjà présent (pas d'écrasement).
- **Dynamique** : modifier `geoPoint` après l'init recharge le fond (tant qu'aucun backdrop n'existe encore).
- Fonctionne **avec ou sans projet** chargé.
- Disponible aussi sur le wrapper `<ng-gplan [geoPoint]="…">`.
- **Taille de capture** : `width` / `height` (px CSS) surchargent la taille pour cette
  capture précise ; sinon valeurs de la config (`backdropCaptureWidth/Height`, défaut 1280×960).
  Plus grand = plus de terrain autour du point.

```html
<!-- Capture plus large (plus de terrain autour du point) -->
<ng-gplan-plan-editor
  [project]="project()"
  [geoPoint]="{ lat: 43.6028, lng: 1.4339, width: 1600, height: 1200 }" />
```

### Passer les finitions de pièces en JSON

Les descriptions de pièces (sol, mur, plafond) sont persistées dans les objets `DetectedRoom`
du projet. Elles survivent aux recalculs de surfaces (les métadonnées sont restaurées par
appariement de centroïde à ±25 px).

Structure dans le JSON du projet (dans `objects` ou `floors[n].objects`) :

```json
{
  "type": "polygon",
  "myType": "DetectedRoom",
  "data": {
    "areaM2": 14.5,
    "isNested": false,
    "label": "Salon",
    "notes": "Humidité en angle NE",
    "roomDescription": {
      "sol":         { "material": "Parquet", "etat": "Bon" },
      "mur":         { "material": "Peinture", "etat": "Moyen" },
      "plafond":     { "material": "Plâtre", "etat": "Bon" }
    }
  }
}
```

Ces données sont également émises via `roomsChanged` dans chaque `RoomEntry`.

---

## Navigation dans le plan (pan)

Le déplacement de la vue (pan) se déclenche de plusieurs façons, sans forcément activer l'outil dédié :

- **Clic DROIT maintenu + glisser** : pan **universel**, quel que soit le mode ou l'objet sous le curseur (sauf en plein tracé réseau, où le clic droit termine le tracé). C'est le geste le plus robuste : le bouton droit n'est **pas** capté par une éventuelle modale déplaçable côté hôte (un `cdkDrag` n'écoute que le bouton principal), donc il fonctionne même là où le glisser gauche est intercepté.
- **Glisser gauche sur le fond** en mode sélection (zone vide **ou** fond de carte) déplace la vue (souris **ou** doigt). Un glisser gauche qui démarre **sur un dessin** le déplace (comportement Fabric) ; un clic simple sur un objet le sélectionne. La sélection-rectangle au lasso n'est donc pas disponible en mode sélection.
- **Outil « Déplacer la vue »** (`H`, mode `pan`) : tout glisser pan, quel que soit le bouton — pratique au doigt.
- **`Alt`+glisser** ou **clic molette** : pan ponctuel sans changer d'outil.

Techniquement, le canvas Fabric est configuré avec `fireRightClick`, `fireMiddleClick` et `stopContextMenu` (sinon Fabric n'émet aucun événement souris pour les boutons droit/milieu). Le **menu contextuel du navigateur est en plus neutralisé** sur toute la zone de dessin (`.canvas-container`), de sorte que le clic droit maintenu ne fait jamais surgir de menu.

> Si le pan ne fonctionne pas alors que g-plan ≥ 1.7.2 est bien chargé, le problème vient en général de l'app hôte qui intercepte le glisser (modale déplaçable, overlay…). Le **clic droit** contourne la plupart de ces cas ; sinon voir le guide [`INTEGRATION-EDITEUR.md`](INTEGRATION-EDITEUR.md) (prérequis d'hôte + diagnostic console).

## Zoom et cadrage

*Depuis 2.16.0, complété en 2.18.0.* L'éditeur n'avait **aucun** zoom : ni molette, ni bouton,
ni `setZoom`. Un plan devenu minuscule — après une calibration malheureuse, un import, ou
simplement une échelle basse — n'était plus récupérable autrement qu'en rechargeant, donc en
perdant le travail en cours.

| Geste | Effet |
|---|---|
| **Molette** sur le plan | Zoom **centré sur le curseur** — le point regardé reste sous la souris |
| **− / +** dans la barre d'outils | Zoom par crans de 1,25 |
| **⤢** | **Ajuster** : cadre tout le dessin dans la vue |

Bornes : **10 % à 800 %**. En deçà un logement tient dans quelques pixels ; au-delà on place une
ouverture au centimètre.

### Ce qui est cadré automatiquement, et ce qui ne l'est plus

Un document **s'ouvre cadré** : projet chargé, fond posé, capture satellite. Ce cadrage
automatique n'a lieu qu'**une fois par document** — une capture qui arrive tardivement ne
déplace plus rien. Le premier regard
sur un plan doit le montrer en entier.

Mais **dès le premier appui sur le plan, tout cadrage automatique cesse** (`zoomToFitAuto`).
Régler le zoom n'est pas la seule façon de s'approprier la vue : commencer à dessiner en est
une. Une capture satellite arrive parfois plusieurs secondes après l'ouverture, et recadrer à
ce moment-là déplace le plan sous quelqu'un qui a déjà posé un point — l'appui suivant tombe à
côté. Le bouton **⤢**, lui, cadre toujours : c'est une demande explicite.

Le cadrage vise la **zone réellement visible**, pas le canvas : `canvasWidth`/`canvasHeight`
sont des entrées de l'hôte (1600×1200 par défaut) et ne disent rien de la place disponible.

### API — `FabricCanvasService`

| Symbole | Rôle |
|---|---|
| `zoom()` | Signal en lecture seule : facteur courant (1 = 100 %). |
| `zoomBy(facteur)` | Zoom d'un cran, centré sur la vue. Marque la vue comme réglée par l'utilisateur. |
| `resetZoom()` | Retour à 100 % sans toucher au déplacement. |
| `zoomToFit(margePx?, vue?)` | Cadre le dessin. `vue` = dimensions **visibles** ; sans elle, le canvas fait foi. **Cadre toujours.** |
| `zoomToFitAuto(margePx?, vue?)` | Idem, mais **s'abstient** si l'utilisateur a déjà zoomé, déplacé la vue ou touché le plan. |
| `resetViewState()` | Oublie le réglage de vue — à l'ouverture d'un document. |

Les **poignées de nœud** sont dimensionnées en unités de scène compensées du zoom : leur taille
est donc constante **à l'écran**. Une poignée est une commande, pas un objet du plan ; à 800 %,
un rayon de 5 unités devenait un disque de 40 px qui recouvrait le dessin qu'il sert à modifier.

### Fermeture de boucle — plancher à l'écran

*Depuis 2.18.1.* Le rayon de fermeture vaut 50 cm dans le monde réel, ce qui se
traduit à l'écran par un rayon qui **rétrécit avec le zoom** : à 40 %, refermer une pièce
demanderait de viser à moins d'un pixel, alors que rien dans le plan n'a changé. Le rayon
effectif est donc le plus grand des deux — la mesure métier, et **20 px d'écran** ramenés en
unités de scène (`FERMETURE_MIN_ECRAN_PX`), soit à peu près la précision d'un doigt.

### Échelle déduite d'une image posée

Une photo de plan n'apporte **aucune** échelle : ses pixels ne disent rien des mètres. Poser un
fond sur un plan **encore vierge** fixe donc `pixelsPerMeter` en supposant le document large
d'environ **12 m** (`LARGEUR_PLAN_SUPPOSEE_M`) — l'ordre de grandeur d'un pavillon ou d'un
étage. L'hypothèse est **affichée**, jamais tue : une échelle devinée qu'on ne dit pas passe
pour une échelle mesurée.

Si des murs existent déjà, l'échelle n'est **pas** touchée : leur géométrie est posée à
l'échelle courante, la changer les déplacerait tous.

La calibration (📏) **refuse** de déduire une échelle sous **10 px/m** : sur un trait de 10 px
annoncé à 2 m elle donnait 5 px/m, le bornage à `[1, 500]` n'y voyait rien, et
`applyLayoutConstraints` reposait ensuite tout le plan à cette échelle — le croquis s'effondrait
en une tache de quelques pixels, sans un mot.

---

## Outil « Porteur / cloison » *(2.25.0)*

*Mode métier **diag** uniquement — c'est le seul qui distingue un mur porteur d'une cloison.*

Outil **⇌ Porteur / cloison** (`T`) du groupe Structure : chaque clic sur un mur le bascule d'un
type à l'autre, et l'on enchaîne sans rien sélectionner.

La bascule elle-même existait depuis longtemps, mais **seulement comme bouton contextuel** :
il fallait sélectionner le mur, puis viser un bouton de la barre latérale. Requalifier un plan
importé — où tout arrive en `Mur` — en devenait fastidieux. Le bouton contextuel reste en place
pour le geste unitaire.

Deux points de mise en œuvre :

- **La cible est le mur visé, pas la sélection courante**, et elle est cherchée par distance
  (12 px) en repli de ce que Fabric a retenu : Fabric n'attrape un objet que sur son trait —
  cinq pixels pour un mur, trois pour une cloison — ce qui, au doigt sur tablette, relève du
  hasard. `FabricCanvasService.wallAt(point, tolerance?)` est exporté pour cela.
- **Le matériau saisi est conservé.** Une cloison en agglo existe ; `Plâtre` n'est qu'un repli
  quand rien n'a été renseigné. Écraser un relevé pour un changement de type serait pire que de
  le laisser. Le `wallId` est conservé lui aussi, sans quoi les ouvertures posées sur ce mur
  deviendraient orphelines.

---

## Raccourcis clavier (éditeur)

| Touche       | Action                        | Actif en `readOnly` |
|--------------|-------------------------------|:-:|
| `V`          | Mode sélection                | ✓ |
| `H`          | Mode navigation (pan au doigt) | ✓ |
| `N`          | Édition de nœuds (murs **et** sommets de réseau) | — |
| `W`          | Tracer un mur                 | — |
| `C`          | Tracer une cloison            | — |
| `T`          | Basculer un mur porteur ⇄ cloison (mode métier **diag**) | — |
| `R`          | Dessiner une pièce            | — |
| `K`          | Croquis (RoomBox)             | — |
| `D`          | Placer une porte              | — |
| `F`          | Placer une fenêtre            | — |
| `X`          | Annotation — rectangle        | — |
| `O`          | Annotation — cercle           | — |
| `A`          | Annotation — flèche           | — |
| `Maj` (maintenue) | Suspend le magnétisme de croquis pendant le tracé | — |
| `Escape`     | Retour au mode sélection      | ✓ |
| `Ctrl+Z`     | Annuler                       | — |
| `Ctrl+Y`     | Rétablir                      | — |
| `Suppr` / `Backspace` | Supprimer la sélection | — |

---

## Mode visualisation (`readOnly`)

L'input `readOnly` du `<ng-gplan-plan-editor>` (et du wrapper `<ng-gplan>`) bascule
l'éditeur dans un état de consultation pure. Idéal pour afficher un CRI archivé,
un plan déjà validé, ou pour exposer un plan dans une vue lecture-seule (PWA
back-office, partage de lien public, audit, etc.) sans risquer une modification
involontaire.

### Activation

```html
<!-- Statique -->
<ng-gplan-plan-editor [project]="project" [readOnly]="true" />

<!-- Pilotable via signal -->
<ng-gplan-plan-editor [project]="project" [readOnly]="viewOnly()" />
```

```ts
viewOnly = signal(true);
// puis viewOnly.set(false) pour repasser en édition
```

La bascule est **dynamique** : un effet Angular ré-applique les verrous (ou les
lève) à chaque changement du signal. À la transition `false → true`, l'outil
courant est forcé à `select`.

### Ce que `readOnly = true` change

| Zone | Comportement |
|---|---|
| **Header** | Badge `👁 Mode visualisation` (gris ardoise) à la place d'Annuler/Rétablir. Modes métier (Diag/AEP/EU/…), curseur d'échelle, bouton `⊡ Modèles`, bouton `📋 Pièces`, dropdown `🖼 Fond` : masqués. Le dropdown `📁 Fichier` ne propose plus que les exports (JPEG / PNG / SVG). Le toggle `🧊 Vue 3D` reste disponible. Les onglets de niveaux restent navigables, mais le `+` et la copie de murs entre niveaux sont retirés. |
| **Panneau Pièces** | Le panneau latéral droit « Pièces / Linéaires réseaux » est masqué (pas de consultation détaillée en visualisation). |
| **Sidebar (palette d'outils)** | Entièrement masquée — aucun outil de tracé n'est exposé. Le bouton menu mobile est lui aussi caché. |
| **Inspector** | Aucun objet n'étant sélectionnable, le panneau reste sur le message « Sélectionnez un objet ». À titre de défense en profondeur, si l'input `readOnly` est propagé à `<ng-gplan-inspector-panel>` (cas d'usage autonome), tous les contrôles sont encapsulés dans un `<fieldset disabled>` — inputs, selects, textareas et boutons deviennent lecture seule, panneau légèrement atténué (`opacity: 0.85`), bouton `🗑 Supprimer l'élément` masqué. |
| **Canvas** | `setMode` force `select` ; seuls `select` et `pan` sont autorisés. Tous les objets passent en `selectable: false` + `evented: false` → **aucun cadre de sélection ni poignées** ne s'affichent au clic, l'inspecteur reste vide. Défense en profondeur : `lockMovementX/Y`, `lockRotation`, `lockScalingX/Y = true` même si la sélectabilité était ré-activée par erreur. Backdrop conserve ses verrous propres. Au repassage en édition, portes et fenêtres conservent leur lock de scaling natif. |
| **Clavier** | Seuls `Escape`, `V` (select) et `H` (pan) répondent. `Suppr`/`Backspace`, `Ctrl+Z`/`Ctrl+Y`, et les raccourcis d'outils sont ignorés. |
| **Bannières** | Récupération autosave et copie murs extérieurs sont masquées (rien à restaurer ou copier en consultation). |
| **Mobile / tactile** | Le mode `pan` reste accessible via le badge `👋 Déplacer la vue` du header pour naviguer au doigt. La touch-target reste à 44 px sur le badge mode visualisation et les onglets de niveaux. |

### Exports et 3D

Les exports JPEG/PNG/SVG restent disponibles depuis le menu `📁 Exporter` : un
utilisateur en mode visualisation peut récupérer un rendu du plan sans pouvoir
modifier le projet. Le composant `<ng-gplan-viewer-3d>` est en lecture seule par
nature et ne nécessite pas le flag.

### Cas d'usage

| Contexte | Recommandation |
|---|---|
| Consultation d'un CRI archivé | `readOnly=true` + `autoGeoLayer="satellite"` pour le contexte géo |
| Lien de partage public d'un plan | `readOnly=true` + `showHeader=true` (laisser exports JPG/PNG/SVG) |
| Mode preview avant validation | `readOnly=true` puis bascule `false` à la confirmation |
| Audit / revue par un tiers | `readOnly=true` — pas de risque de modification involontaire |

---

## Résumé du plan (`summaryChange` / `getPlanSummary()`)

Pour alimenter une intelligence côté CRI, l'éditeur expose une **synthèse structurée**
du plan, disponible de deux manières :

- **Dynamique** : l'output `summaryChange` émet un `PlanSummary` à chaque modification
  (debounce ~500ms).
- **À la demande** : la méthode `getPlanSummary(): PlanSummary` (via `@ViewChild`) renvoie
  une synthèse **synchrone et à jour**, idéale au clic « Valider le plan ».

```ts
import { PlanEditorComponent, PlanSummary } from 'g-plan';

@Component({ /* … */ })
export class HostComponent {
  @ViewChild(PlanEditorComponent) editor!: PlanEditorComponent;

  onValiderLePlan(): void {
    const summary: PlanSummary = this.editor.getPlanSummary();
    // → envoyer summary au backend CRI
  }

  onSummaryChange(s: PlanSummary): void { /* suivi temps réel */ }
}
```

```html
<ng-gplan-plan-editor [project]="project()" (summaryChange)="onSummaryChange($event)" />
```

### Forme de `PlanSummary`

```ts
interface PlanSummary {
  generatedAt: string;            // ISO
  pixelsPerMeter: number;
  floors: FloorSummary[];         // par niveau
  rooms: RoomSummary[];           // toutes pièces aplaties (tous niveaux)
  network: NetworkSummary;
  hazards: HazardSummary;
  stats: { roomCount; totalAreaM2; wallCount; wallLengthM };
}

interface RoomSummary {
  id: string | null;              // identifiant stable (data.roomId)
  name: string | null;            // nom renseigné
  areaM2: number;
  isNested: boolean;              // placard/enveloppe imbriquée
  floor: { id; name; order };
  centroid: { x; y };
  materials: { sol; mur; plafond: { material?; etat?; notes? } };
  notes: string | null;
  walls: { letter; wallId; lengthM }[];           // murs de la pièce (A, B…)
  openings: {
    doors:   { wall; letter; type; isPrimary }[];
    windows: { wall; letter; glazing }[];
    doorCount: number; windowCount: number;
  };
  linkedCri: { id; name } | null; // pièce CRI liée (cf. roomLinked)
}

interface NetworkSummary {
  pipes: { type; label; lengthM }[];   // linéaire par type de canalisation
  totalLengthM: number;
  elements: { family: 'spanc' | 'ac'; kind; label; position; floorId }[]; // fosses, regards…
}

interface HazardSummary {
  samples: { id; label; surface; result?; position; floorId; linkedCriId? }[];
  zones:   { hazardType; label; surface; linkedSampleId?; position; floorId }[];
}
```

> **Couverture multi-niveaux** : la synthèse couvre tous les niveaux. Les lettres de murs
> (A, B…) et l'association porte/fenêtre↔pièce sont calculées sur le **niveau actif** ; pour
> les autres niveaux elles reflètent la dernière fois où le niveau a été affiché. Le décompte
> `doorCount`/`windowCount` reste fiable même sans lettre (`letter: ''`).

---

## Alternative textuelle du canvas — accessibilité

*Depuis 2.15.0.*

Un `<canvas>` est un rectangle de pixels : pour une technologie d'assistance, il ne contient
**rien**. Tout ce que g-plan produit — pièces, surfaces, ouvertures, linéaires, prélèvements —
était donc invisible à qui n'a pas la vue, ce qui est rédhibitoire en marché public
(RGAA 4.1 / WCAG 2.1 §1.1.1 : tout contenu non textuel doit avoir un équivalent textuel
remplissant la **même fonction**).

L'éditeur publie désormais cette description en permanence, et le canvas y renvoie.

### Ce que ça change dans le DOM

```html
<canvas role="img"
        aria-label="Plan du niveau RDC. 2 niveaux, 4 pièces, 62,3 m² au total… "
        aria-describedby="ngf-plan-outline-1"></canvas>

<button class="ngf-outline-toggle">Afficher la description textuelle du plan</button>

<section id="ngf-plan-outline-1" role="region" aria-label="Description textuelle du plan">
  <h2>Description textuelle du plan</h2>
  <p>2 niveaux, 4 pièces, 62,3 m² au total, 14 murs pour 48,2 m, 12,4 m de réseaux.</p>
  <h3>Niveau RDC</h3>
  <p>3 pièces, 45,2 m² au total.</p>
  <ul>
    <li>Séjour — 24,5 m²
      <ul>
        <li>4 murs : A 6,0 m, B 4,0 m, C 6,0 m, D 4,0 m</li>
        <li>1 porte : mur A (simple vantail, entrée principale)</li>
        <li>1 fenêtre : mur B (double vitrage)</li>
        <li>Sol : Parquet (bon)</li>
      </ul>
    </li>
  </ul>
  <h3>Réseaux</h3> …
  <h3>Repérage et zones à risque</h3> …
</section>
```

- **Toujours dans le DOM**, masquée à l'œil par la technique « visually hidden » (1 px
  découpé). **Jamais `display: none` ni `visibility: hidden`** : ils retireraient le texte de
  l'arbre d'accessibilité en même temps que de l'écran, et l'alternative n'existerait plus
  pour personne — sans que rien ne le montre.
- **Titres et listes réels**, pas un pavé : le lecteur d'écran saute de titre en titre et
  entre dans la seule liste qui l'intéresse. C'est la différence entre une alternative
  utilisable et une alternative de conformité.
- **Un bouton escamoté** (visible à la prise de focus clavier, comme un lien d'évitement)
  bascule la même description en panneau visible. Aucune modification de la mise en page
  pour l'utilisateur à la souris.
- **`id` unique par éditeur** (`ngf-plan-outline-<n>`) : deux éditeurs dans la même page ne
  peuvent pas se décrire l'un l'autre.

### Aucun second modèle du plan

La description dérive du `PlanSummary` que `PlanAnalysisService` produit déjà et que
`summaryChange` émet — **la même analyse, calculée une seule fois**. Rien ne peut donc
diverger entre le dessin et sa description : le jour où l'analyse compte une pièce de plus,
le texte la dit sans qu'une ligne ne bouge.

La synthèse est rafraîchie au même rythme que `summaryChange` (debounce ~500 ms), et
immédiatement au chargement d'un projet.

### API exportée — `plan-outline.const`

| Symbole | Rôle |
|---|---|
| `buildPlanOutline(summary, opts?)` | `PlanSummary \| null` → `PlanOutline`. Une synthèse absente rend une structure valide qui **dit** qu'elle est vide, jamais `null` |
| `planOutlineText(outline)` | Rendu texte brut (rapport, copier-coller). **Ce n'est pas la forme accessible** |
| `formatArea(m2)` / `formatLength(m)` | « 24,5 m² » / « 4,2 m » — virgule décimale, une décimale, comme la liste des pièces à l'écran |
| `frNumber(n, decimals?)` | Nombre à la française. Écrit à la main : `Intl` dépend de la locale du navigateur, et un plan lu en `en-US` annoncerait « 24.5 » là où l'écran montre « 24,5 » |
| `PLAN_OUTLINE_TITLE` | `'Description textuelle du plan'` |
| `PlanOutline`, `PlanOutlineSection`, `PlanOutlineEntry`, `PlanOutlineOptions` | Types de la structure |

```ts
interface PlanOutline {
  title: string;
  intro: string;                    // résumé d'ouverture, une phrase
  sections: PlanOutlineSection[];   // un par niveau, puis Réseaux, puis Repérage
  notice: string | null;            // mention légale fournie par l'appelant
  isEmpty: boolean;
}

interface PlanOutlineSection {
  id: string;                       // 'floor-rdc', 'network', 'hazards'
  heading: string;
  summary: string | null;
  entries: PlanOutlineEntry[];
  empty: string | null;             // « Aucune pièce relevée sur ce niveau. »
}

interface PlanOutlineEntry {
  key: string;                      // clé de suivi stable
  text: string;                     // « Séjour — 24,5 m² » : la surface est TOUJOURS ici
  details: string[];                // murs, ouvertures, revêtements, observations, lien CRI
}
```

La mention légale n'est **pas** recopiée dans le module : elle est passée par
`opts.notice` (l'éditeur y met `SURFACE_DISCLAIMER`, la même que les exports JSON). Un texte
juridique dupliqué finit toujours par diverger.

### Composant — `<ng-gplan-plan-outline>`

| Input | Type | Défaut | Rôle |
|---|---|---|---|
| `summary` | `PlanSummary \| null` | `null` | Synthèse à décrire |
| `notice` | `string \| null` | `null` | Mention légale jointe en fin de description |
| `visible` | `boolean` | `false` | `false` : lisible par lecteur d'écran, invisible à l'œil |
| `regionId` | `string` | `'ngf-plan-outline'` | `id` de la région, cible d'un `aria-describedby` |

Méthode publique `asText(): string` — la description en texte brut.

### Côté éditeur

```ts
@ViewChild(PlanEditorComponent) editor!: PlanEditorComponent;

const outline: PlanOutline = this.editor.getPlanOutline();   // synchrone et à jour
```

`getPlanOutline()` dérive de `getPlanSummary()` et joint `SURFACE_DISCLAIMER`.

### Contraste des tracés — mesuré, puis corrigé

WCAG 2.1 §1.4.11 exige **3:1** pour tout élément graphique porteur d'information. Sur le fond
blanc du canvas, quatre couleurs de réseau échouaient — et la couleur est la *seule* chose qui
distingue un réseau d'un autre :

| Réseau | Avant | Contraste | Après | Contraste |
|---|---|---|---|---|
| EP | `#22d3ee` | 1,81:1 | `#0e7490` | 5,36:1 |
| Élec | `#eab308` | 1,92:1 | `#b91c1c` | 6,47:1 |
| Gaz | `#f59e0b` | 2,15:1 | `#d97706` | 3,19:1 |
| Fibre | `#06b6d4` | 2,43:1 | `#15803d` | 5,02:1 |

Élec et Fibre **changent de teinte**, faute de mieux : aucun jaune ni aucun cyan clair
n'atteint 3:1 sur blanc sans virer au brun, où ils deviendraient indiscernables de EM
(`#a16207`) et EV (`#78350f`). Les nouvelles teintes suivent la convention française des
grillages avertisseurs (NF P 98-332) : rouge pour l'électricité, vert pour les télécoms.

Les cinq autres réseaux sont inchangés (4,8:1 à 9,1:1). Les **fonds** de pictogrammes et de
zones à risque ne sont pas touchés : ils portent un contour sombre et une étiquette, la
couleur n'y est pas seule porteuse de sens.

**Les plans existants ne sont pas retouchés.** La couleur est sérialisée dans chaque objet
Fabric (`stroke`) et la légende d'export la dérive de l'objet réellement dessiné
(`dominantColor`) : un plan ancien reste cohérent avec sa propre légende. Seuls les tracés
faits à partir de la 2.15.0 prennent les nouvelles couleurs — réécrire les anciens serait
modifier le document de l'utilisateur sans qu'il l'ait demandé.

### API exportée — `pipe-labels.const` et `contrast.const`

| Symbole | Rôle |
|---|---|
| `PIPE_COLORS` | **Source unique** de la couleur de tracé de chaque réseau (`myType` → hex). Auparavant recopiée à cinq endroits : tracé Fabric, cotes, vue 3D, légende, pastilles d'outils |
| `contrastRatio(a, b)` | Rapport de contraste WCAG, de 1 à 21. `null` si une couleur n'est pas lisible |
| `relativeLuminance(color)` | Luminance relative (0 = noir, 1 = blanc) |
| `parseCssColor(color)` | `#rgb`, `#rrggbb`, `rgb()`, `rgba()` → `Rgba \| null`. Les couleurs **nommées** rendent `null` plutôt qu'une valeur inventée |
| `meetsGraphicContrast(color, bg?, min?)` | Seuil §1.4.11. Une couleur illisible rend `false` : ce qu'on ne sait pas mesurer n'est pas déclaré conforme |
| `MIN_GRAPHIC_CONTRAST` (`3`), `PLAN_BACKGROUND` (`'#ffffff'`) | Seuil et fond de référence |

L'alpha n'est pas pris en compte dans le calcul : composer une couleur semi-transparente
demanderait tout l'empilement, et une valeur approchée serait pire qu'une absence de valeur
sur un critère normatif.

---

## Lier une pièce à un CRI

Passez la liste des pièces du CRI via `criRooms`. Un sélecteur apparaît dans l'inspecteur
quand une pièce dessinée est sélectionnée. Valider une correspondance **renomme** la pièce
dessinée d'après le CRI, émet `roomLinked`, et peuple `RoomSummary.linkedCri`.

```html
<ng-gplan-plan-editor
  [project]="project()"
  [criRooms]="[{ id: 'c1', name: 'Chambre 1' }, { id: 's1', name: 'Salon' }]"
  (roomLinked)="onRoomLinked($event)" />
```

`roomLinked` émet `{ roomId, criRoomId, name }` — `roomId` est l'identifiant stable de la
pièce dessinée (`RoomSummary.id`), à conserver côté hôte pour la corrélation.

---

## Pose guidée des prélèvements

Passez les prélèvements amiante du CRI via `pendingSamples`. Quand l'outil **Prélèvement**
est actif, un bandeau « 📍 À placer : P1, P2… » s'affiche ; chaque clic pose le prochain
prélèvement de la file avec son id/label CRI, émet `samplePlaced`, et avance la file.

```html
<ng-gplan-plan-editor
  [project]="project()"
  [pendingSamples]="[{ id: 's1', label: 'P1' }, { id: 's2', label: 'P2' }]"
  (samplePlaced)="onSamplePlaced($event)" />
```

`samplePlaced` émet `{ criSampleId, label, position: {x,y}, floorId }`. Le marqueur posé porte
`data.criSampleId` (corrélation CRI) et apparaît aussi dans `summary.hazards.samples[].linkedCriId`.

> **Réinitialiser la file** : passez une **nouvelle référence** de tableau à `pendingSamples`
> (sémantique standard des signal inputs — une mutation en place ne déclenche pas la mise à jour).
> Désactivé en `readOnly`.
