# Migrer une application hôte vers g-plan 2.0.0 (Fabric.js v7)

Guide destiné aux **applications qui consomment g-plan** (Gordon-PWA et autres).
Compter **15 à 30 minutes**, dont l'essentiel en vérification.

> Contexte technique côté librairie : [`../FEATURE-migration-fabric-v5-v7.md`](../FEATURE-migration-fabric-v5-v7.md).
> Installation générale : [`../INSTALL.md`](../INSTALL.md).

---

## En une phrase

g-plan 2.0.0 passe de Fabric.js v5 à v7. **Fabric n'est plus chargé par une balise
`<script>` : il faut désormais l'installer par npm dans le projet hôte**, et c'est votre
bundler qui le résout. Vos plans enregistrés se rechargent sans rien changer.

---

## 1. Pourquoi ce changement (et pourquoi il n'était pas évitable)

Jusqu'à g-plan 1.x, Fabric était chargé globalement :

```html
<!-- index.html de l'application hôte, en 1.x -->
<script src="https://cdn.jsdelivr.net/npm/fabric@5.5.2/dist/fabric.min.js"></script>
```

…et la librairie le consommait via `window.fabric`, sans jamais l'importer.

**Fabric v6 a supprimé ce build.** Le fichier `dist/fabric.min.js` n'est plus publié —
vérifié : `404` en 6.9.1 comme en 7.4.0. Le paquet n'expose plus que des entrées ESM et
CJS via une carte `exports`, et n'a même plus de champ `main`. Il n'existe donc plus
aucun moyen d'obtenir un `window.fabric`.

Ce n'est pas un choix de confort de notre part : le mode CDN a disparu en amont. C'est
pour cela que g-plan passe en **version majeure** — le contrat d'intégration change.

---

## 2. Les trois gestes

### Geste 1 — Installer Fabric par npm

```bash
npm install "fabric@^7"
```

`fabric` est déclaré en **peer dependency** de g-plan (`^7.0.0`), au même titre que
`maplibre-gl` et `three` : c'est l'application hôte qui en fixe la version installée,
ce qui garantit une instance unique si vous utilisez Fabric ailleurs.

Après coup, vérifiez ce qui a été réellement résolu :

```bash
npm ls fabric
# doit afficher fabric@7.x.x, et AUCUN « invalid » ni « UNMET PEER DEPENDENCY »
```

### Geste 2 — Supprimer la balise `<script>` de `index.html`

```diff
  <body>
    <app-root></app-root>
-   <script src="https://cdn.jsdelivr.net/npm/fabric@5.5.2/dist/fabric.min.js"></script>
  </body>
```

Laisser la balise n'est pas neutre : selon l'URL, soit elle échoue en 404 silencieux,
soit elle réintroduit un `window.fabric` d'une **autre version** que celle que g-plan
importe — deux Fabric coexistants, avec des symptômes difficiles à diagnostiquer.
**Supprimez-la.**

Si vous serviez une copie locale (`assets/fabric.min.js`, entrée `scripts` dans
`angular.json`), retirez-la aussi.

### Geste 3 — Relever les budgets de bundle

Fabric quitte le CDN pour entrer dans votre bundle : comptez **environ +300 ko bruts**
(~+70 ko transférés). Mesuré sur les quatre applications de test de la matrice de
compatibilité : bundle initial **~1,18 Mo → ~1,48 Mo**.

Le build échoue alors sur le budget par défaut du schematic Angular :

```
ERROR bundle initial exceeded maximum budget. Budget 1.00 MB was not met by …
```

Ce n'est pas une incompatibilité, c'est une limite de configuration. Dans
`angular.json` :

```jsonc
"budgets": [
  { "type": "initial", "maximumWarning": "2MB", "maximumError": "3MB" }
]
```

---

## 3. Ce que vous n'avez PAS à faire

- **Aucune migration de données.** Les plans enregistrés sous g-plan 1.x (sérialisés par
  Fabric v5) se rechargent tels quels. Le mécanisme de sérialisation a changé — les
  propriétés métier `myType`, `data`, `roomName` et `isPrimary` sont désormais déclarées
  une fois pour toutes au lieu d'être passées à chaque `toJSON()` — mais **cela se passe
  entièrement dans la librairie**, et le cycle complet est couvert par des tests
  automatisés (`fabric-serialization.spec.ts` : rechargement d'un JSON v5, double cycle,
  et les modèles d'appartement livrés).
- **Aucun changement d'API** de g-plan : mêmes composants, mêmes inputs/outputs, même
  `provideGPlan()`.
- **Rien à écrire dans votre `app.config.ts`.** En particulier, vous **n'avez pas** à
  déclarer `FabricObject.customProperties` : la librairie s'en charge. Si un guide de
  migration Fabric vous le suggère, il parle d'une application qui utilise Fabric
  directement, pas d'un consommateur de g-plan.

---

## 4. Vérifier que la migration est réussie

Dans cet ordre — chaque étape a sa propre valeur de diagnostic :

| # | Vérification | Attendu |
|---|---|---|
| 1 | `npm ls fabric g-plan` | `fabric@7.x`, `g-plan@2.x`, aucun conflit de peer |
| 2 | `ng build --configuration production` | passe (après relèvement des budgets) |
| 3 | Ouvrir l'éditeur | le plan s'affiche, la barre d'outils répond |
| 4 | Console : `typeof window.fabric` | **`"undefined"`** — c'est le signe que la migration est complète |
| 5 | Tracer un mur, annuler, rétablir | fonctionne |
| 6 | **Charger un plan enregistré avant la migration** | pièces nommées, matériaux et réseaux intacts |

L'étape 4 surprend souvent : en 1.x, `window.fabric` **devait** être défini ; en 2.0.0,
il **doit** être absent. S'il est encore là, c'est qu'une balise `<script>` traîne
quelque part (geste 2).

L'étape 6 est la seule qui touche vos données réelles — ne la sautez pas, même si les
tests de la librairie la couvrent sur des cas synthétiques.

---

## 5. Diagnostic

| Symptôme | Cause probable | Correctif |
|---|---|---|
| `Cannot find module 'fabric'` au build | Fabric pas installé côté hôte | Geste 1 |
| `bundle initial exceeded maximum budget` | Budgets par défaut | Geste 3 |
| Le canvas ne s'affiche pas, console muette | Reste d'une balise `<script>` pointant vers un 404, ou build non refait | Geste 2, puis rebuild complet |
| `window.fabric` encore défini | Balise `<script>` ou entrée `scripts` d'`angular.json` résiduelle | Geste 2 |
| Comportement erratique du canvas, objets en double | Deux versions de Fabric chargées (globale + bundlée) | Geste 2, puis `npm ls fabric` pour confirmer une seule instance |
| Un plan rechargé perd ses pièces / matériaux | **Anomalie — à signaler.** Ce cas est couvert par les tests de la librairie | Joindre le JSON du plan concerné |
| `ERESOLVE` mentionnant `maplibre-gl` | Sans rapport avec Fabric : `latest` vaut 6.0.0, le peer exige `^5` | `npm install "maplibre-gl@^5"` |
| PWA : l'ancien bundle persiste | Service worker | DevTools → Application → Service Workers → *Unregister*, puis rechargement forcé |

Après réinstallation du tarball, purgez les caches avant de reconstruire :

```bash
rm -rf node_modules/g-plan .angular/cache node_modules/.cache
```

---

## 6. Revenir en arrière

Le retour à g-plan 1.8.0 est possible sans perte : réinstaller la 1.8.0, remettre la
balise `<script>` (avec une URL **jsDelivr**, pas cdnjs qui ne publie fabric.js que
jusqu'à la 5.3.1), et désinstaller `fabric` si vous ne l'utilisez pas par ailleurs.
Les plans enregistrés sous 2.0.0 restent lisibles par la 1.8.0 : le format sérialisé
n'a pas changé de structure, seule la casse du champ `type` diffère (`"Line"` en v7 vs
`"line"` en v5) et **les deux versions acceptent les deux casses**.

---

## 7. Checklist

- [ ] `npm install "fabric@^7"` fait, `npm ls fabric` propre
- [ ] Balise `<script>` Fabric supprimée d'`index.html`
- [ ] Entrée `scripts` Fabric supprimée d'`angular.json`, le cas échéant
- [ ] Budgets de bundle relevés
- [ ] `ng build --configuration production` passe
- [ ] `typeof window.fabric === "undefined"` dans la console
- [ ] Tracé, annuler/rétablir, sauvegarde vérifiés à la main
- [ ] **Un plan antérieur à la migration rechargé et contrôlé**
- [ ] Cache PWA / service worker purgé si applicable
