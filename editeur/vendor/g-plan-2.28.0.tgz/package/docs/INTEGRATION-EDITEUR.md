# Intégrer `<ng-gplan-plan-editor>` — navigation & pièges d'hôte

Guide pratique pour intégrer l'éditeur de plan g-plan dans une application hôte
(ex. Gordon), **sans casser la navigation** (déplacement de la vue au glisser).
À lire si « le déplacement de la carte au clic gauche ne fonctionne pas » alors
que la bonne version de g-plan est pourtant installée.

> Prérequis d'install (tarball, peer deps dont **`fabric@^7` à installer par npm**) :
> voir [`../INSTALL.md`](../INSTALL.md).
> Tu viens d'une g-plan 1.x ? Commence par [`MIGRATION-2.0.md`](MIGRATION-2.0.md) :
> Fabric n'est plus chargé par balise `<script>`.
> Référence API complète : voir [`API.md`](API.md) § *Navigation dans le plan (pan)*.

---

## 1. Comment marche la navigation dans le plan (depuis g-plan 1.7.2)

Gestes de déplacement de la vue et d'édition :

| Geste | Effet |
|---|---|
| **Clic DROIT maintenu + glisser** | **Déplace la vue** (pan) — universel, tout mode, **recommandé en modale** |
| Glisser gauche sur le fond (zone vide **ou** fond de carte), en mode sélection | Déplace la vue (pan) |
| Glisser gauche sur un **dessin** (mur, pièce, pictogramme…) | Déplace l'objet |
| Clic simple sur un objet | Sélection |
| `Alt`+glisser, ou clic molette | Pan ponctuel |
| Outil **« Déplacer la vue »** (`H`) | Tout glisser pan, quel que soit le bouton |

> **Le clic droit maintenu est le geste de pan le plus fiable en intégration** :
> le bouton droit n'est pas capté par une modale déplaçable (`cdkDrag` n'écoute
> que le bouton principal), donc il fonctionne même quand le glisser gauche est
> intercepté par l'app hôte.

Points clés d'implémentation (déjà gérés dans la lib) :

- La **sélection-rectangle (lasso) est désactivée** en mode sélection : sinon
  Fabric démarre son lasso au `mousedown` **avant** le handler de la lib, et le
  pan ne peut pas prendre la main.
- Le **menu contextuel du navigateur est neutralisé** sur la zone de dessin
  (`.canvas-container`) : le clic droit sert à clôturer un tracé de réseau, et
  l'appui long / clic maintenu ne fait plus surgir de menu.
- Le pan agit sur le `viewportTransform` du canvas Fabric (pas sur le scroll).

Rien de tout cela n'exige de configuration côté hôte : **si les événements
souris arrivent au canvas, ça marche**. Le problème, quand ça ne marche pas,
vient presque toujours de l'app hôte qui **intercepte le glisser avant Fabric**.

---

## 2. Prérequis côté application hôte

Le canvas d'interaction de Fabric est `<canvas class="upper-canvas">`, placé dans
`<div class="canvas-container">`, lui-même dans `.ngf-editor__canvas-area`.
Pour que le pan fonctionne, **le glisser gauche doit atteindre ce canvas** :

1. **Ne pas recouvrir le canvas** d'un overlay transparent qui capterait les
   événements (`position: absolute` au-dessus, `::after` plein cadre, etc.).
2. **Ne pas rendre le conteneur draggable.** Si l'éditeur est dans une **modale
   déplaçable** (Angular CDK `cdkDrag`, `mat-dialog` custom, `setPointerCapture`
   sur un wrapper…), le glisser sur le canvas **déplace la modale** au lieu de
   panner. C'est la cause n°1.
3. **Ne pas neutraliser les événements** via `pointer-events: none` hérité, ni
   bloquer le drag via un `touch-action`/handler global de scroll.
4. **Laisser l'éditeur en mode sélection** à l'ouverture (ne pas forcer un outil
   de dessin par défaut).

---

## 3. Diagnostic express (console DevTools)

Ouvre l'éditeur (dans sa modale), colle ceci dans la **console**, puis
**fais un glisser gauche sur le plan** :

```js
(() => {
  const c = document.querySelector('ng-gplan-plan-editor canvas.upper-canvas');
  if (!c) return console.warn('Canvas éditeur introuvable');
  const r = c.getBoundingClientRect();
  const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  console.log('pointer-events du canvas :', getComputedStyle(c).pointerEvents);
  console.log('élément au centre du canvas :', document.elementFromPoint(cx, cy));
  let downs = 0, moves = 0;
  c.addEventListener('mousedown', () => console.log('✅ mousedown reçu par le canvas', ++downs));
  c.addEventListener('mousemove', e => { if (e.buttons === 1) moves++; });
  window.addEventListener('mouseup', () => { console.log('→ mousemove(bouton gauche) pendant ce glisser =', moves); moves = 0; });
  console.log('Prêt. Fais un glisser gauche sur le plan.');
})();
```

### Lecture des résultats

| Observation | Cause probable | Correctif côté hôte |
|---|---|---|
| `élément au centre` ≠ `<canvas class="upper-canvas">` | Un overlay recouvre le canvas | Retirer/abaisser l'overlay (`z-index`, `pointer-events: none` sur l'overlay décoratif) |
| `mousedown` reçu, mais `mousemove(gauche) = 0` | Un parent capture le drag (**modale draggable**, `setPointerCapture`) | Désactiver le drag de la modale sur la zone du plan (cf. §4) |
| `mousedown` **jamais** reçu | Overlay transparent au-dessus, ou `pointer-events: none` sur le canvas | Corriger le CSS de l'overlay / du conteneur |
| `mousedown` reçu **et** `mousemove > 0`, mais pas de pan | Rare — vérifier la version g-plan ≥ 1.7.2 | Voir §5 |

---

## 4. Correctifs pour les causes fréquentes

### a) Modale déplaçable (Angular CDK `cdkDrag`) — cause n°1

Empêcher le drag de la modale de démarrer depuis la zone du plan :

```html
<!-- La poignée de déplacement de la modale est limitée à l'en-tête -->
<div class="ma-modale" cdkDrag cdkDragRootElement=".ma-modale">
  <header cdkDragHandle>Titre de la modale</header>

  <!-- Le corps (dont l'éditeur) ne déclenche pas le drag de la modale -->
  <div class="ma-modale__corps">
    <ng-gplan-plan-editor [project]="project()" />
  </div>
</div>
```

- Avec `cdkDragHandle`, **seul l'en-tête** déplace la modale ; le glisser sur le
  plan est laissé à g-plan.
- Alternative : sur le conteneur de l'éditeur, `cdkDrag` peut être neutralisé
  localement, ou le drag désactivé (`cdkDragDisabled`) tant que le pointeur est
  sur le plan.

### b) Overlay au-dessus du canvas

```css
/* Tout calque décoratif au-dessus du plan doit laisser passer les événements */
.mon-overlay-decoratif { pointer-events: none; }
```

### c) Handler global de drag / scroll

Si l'app hôte pose un `mousedown`/`touchmove` global (ex. drawer, pull-to-refresh
PWA) qui `preventDefault()` ou capture le pointeur, l'exclure de la zone du plan
(`event.target.closest('.ngf-editor__canvas-area')` → ne rien faire).

---

## 5. Vérifier que g-plan fait bien le pan (indépendamment de l'hôte)

Le comportement est couvert par un test e2e Playwright (`e2e/pan.spec.ts`) qui
prouve que le `viewportTransform` se translate sur un glisser gauche en mode
sélection, y compris avec un fond de carte. Si le diagnostic §3 montre que les
événements **arrivent** au canvas mais que rien ne pan :

1. Confirmer la version chargée réellement :
   `node -p "require('g-plan/package.json').version"` **≥ 1.7.2**.
2. En **PWA**, purger le service worker (DevTools → Application → Service Workers
   → *Unregister*, ou *Clear site data*) : un ancien bundle peut rester en cache
   malgré une réinstallation.
3. Reconstruire l'app hôte après réinstallation du tarball
   (`rm -rf node_modules/g-plan .angular/cache node_modules/.cache`).

---

## Checklist d'intégration

- [ ] g-plan **≥ 1.7.2** effectivement chargé (pas un ancien cache PWA).
- [ ] L'éditeur s'ouvre en **mode sélection**.
- [ ] Aucun overlay ne recouvre `canvas.upper-canvas` (diagnostic §3).
- [ ] Si modale déplaçable : drag limité à une **poignée d'en-tête** (`cdkDragHandle`).
- [ ] Aucun handler global ne `preventDefault()` le glisser sur `.ngf-editor__canvas-area`.
- [ ] Glisser gauche sur le fond = la vue se déplace ; glisser sur un objet = l'objet se déplace.
