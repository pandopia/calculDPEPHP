import * as i0 from "@angular/core";
/**
 * Directive de drag & drop pour le canvas de l'éditeur de plan.
 * Émet un événement `fileDrop` lorsqu'un fichier image est déposé sur l'élément hôte.
 *
 * Usage:
 * ```html
 * <canvas ngGplanCanvasDrop (fileDrop)="onFileDrop($event)"></canvas>
 * ```
 */
export declare class CanvasDropDirective {
    /** Émis lorsqu'un fichier image valide est déposé */
    readonly fileDrop: import("@angular/core").OutputEmitterRef<File>;
    onDragOver(event: DragEvent): void;
    onDrop(event: DragEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CanvasDropDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CanvasDropDirective, "[ngGplanCanvasDrop]", never, {}, { "fileDrop": "fileDrop"; }, never, never, true, never>;
}
