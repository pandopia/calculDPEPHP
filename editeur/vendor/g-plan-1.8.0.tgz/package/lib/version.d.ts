export declare const GPLAN_VERSION = "1.8.0";
