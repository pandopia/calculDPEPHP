export interface FloorplanConfig {
    /** URL CDN d'OpenCV.js */
    opencvUrl: string;
    /** Pixels par mètre (échelle initiale) */
    pixelsPerMeter: number;
    /** URL du serveur de tuiles (TileServer GL) */
    tileServerUrl: string;
    /** Nom du style de tuile */
    tileStyle: string;
    /** Taille de la grille (snap) en px */
    defaultGridSize: number;
    /** Distance de snap pour les nœuds en px */
    defaultSnapDistance: number;
    /** Largeur (px CSS) de la capture cartographique servant de fond de plan.
     *  Taille réelle de l'image = cette valeur × devicePixelRatio. Plus grand =
     *  plus d'emprise géographique capturée autour du point (à zoom constant),
     *  mais image plus lourde (embarquée en base64 dans le projet). */
    backdropCaptureWidth?: number;
    /** Hauteur (px CSS) de la capture cartographique servant de fond de plan. */
    backdropCaptureHeight?: number;
    /** Valeurs par défaut des paramètres de détection */
    detection?: Partial<DetectionParams>;
}
export interface DetectionParams {
    /** Seuil adaptatif (blockSize, impair, 3–99) */
    threshold: number;
    /** Longueur minimale d'un segment (px) */
    minLineLength: number;
    /** Gap maximal pour relier segments (px) */
    maxLineGap: number;
    /** Distance de clustering (épaisseur mur) (px) */
    clusterDistance: number;
    /** Extension vers intersections (px) */
    extensionDistance: number;
    /** Rotation de l'image source (degrés, -10 à +10) */
    rotation: number;
}
