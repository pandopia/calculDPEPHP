import { WallSegment } from './wall.model';
import { WorkMode } from './floorplan-object.model';
/** Localisation géographique associée à un plan */
export interface GeoLocation {
    lat: number;
    lng: number;
    zoom: number;
    valid: boolean;
}
/** Niveau de plancher (RDC, étage, sous-sol...) */
export interface FloorLevel {
    id: string;
    name: string;
    /** Ordre relatif : 0 = RDC, positif = étage, négatif = sous-sol */
    order: number;
    objects: unknown[];
}
/** Surface détectée d'une pièce avec métadonnées */
export interface RoomAreaEntry {
    areaM2: number;
    /** true si le cycle est contenu dans un autre (ex : placard dans une chambre) */
    isNested: boolean;
    centroid: {
        x: number;
        y: number;
    };
}
/** Structure d'un projet de plan d'étage sérialisé */
export interface FloorplanProject {
    version: '5.3.0';
    pixelsPerMeter: number;
    geo?: GeoLocation;
    /** Objets du niveau courant (backward compat — utilisé si floors est absent) */
    objects: unknown[];
    /** Niveaux du bâtiment (RDC, étage 1, sous-sol…) */
    floors?: FloorLevel[];
    meta?: {
        createdAt: string;
        updatedAt: string;
        name?: string;
        /** Adresse du bien diagnostiqué */
        address?: string;
        /** Nom du diagnostiqueur */
        diagnostician?: string;
        /** Numéro de mission */
        missionId?: string;
        /** Modes métier actifs au moment de la sauvegarde (diag, aep, eu, spanc, vrd) */
        workModes?: WorkMode[];
    };
}
/** Descriptif d'une pièce exporté via roomsChanged */
export interface RoomEntry {
    label: string;
    areaM2: number;
    sol?: string;
    solEtat?: string;
    mur?: string;
    murEtat?: string;
    plafond?: string;
    plafondEtat?: string;
    notes?: string;
}
/** Pièces d'un niveau, exportées via roomsChanged */
export interface FloorRooms {
    floorId: string;
    floorName: string;
    order: number;
    rooms: RoomEntry[];
    totalArea: number;
}
/** Statistiques calculées d'un projet */
export interface ProjectStats {
    roomCount: number;
    /** Surface totale brute (hors cycles imbriqués) en m² */
    totalArea: number;
    wallCount: number;
    wallLength: number;
    /** Détail des pièces détectées. Surface brute sur axe des murs — pas une surface Carrez/Boutin. */
    roomAreas?: RoomAreaEntry[];
    /** Linéaires des réseaux par type, en mètres */
    pipeLengths?: Record<string, number>;
}
/** Payload pour l'import de murs détectés dans l'éditeur */
export interface WallsImportPayload {
    walls: WallSegment[];
    bounds: {
        x: number;
        y: number;
        w: number;
        h: number;
    };
    backgroundImageDataUrl?: string;
    pixelsPerMeter: number;
}
