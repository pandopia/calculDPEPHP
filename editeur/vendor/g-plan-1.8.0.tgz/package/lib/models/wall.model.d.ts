import { DetectionParams } from './config.model';
/** Orientation d'un segment */
export type WallOrientation = 'H' | 'V';
/** Statut d'un segment dans l'éditeur */
export type WallStatus = 'active' | 'ignored' | 'selected';
/**
 * Segment de mur issu de la détection (Scanner) ou dessiné manuellement.
 * Coordonnées en pixels bruts (espace image).
 */
export interface WallSegment {
    readonly id: string;
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    type: WallOrientation;
    ignored: boolean;
    readonly length?: number;
}
/** Format intermédiaire pour l'algorithme de clustering */
export interface RawSegment {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    type: WallOrientation;
}
/** Résultat complet d'une détection */
export interface DetectionResult {
    walls: WallSegment[];
    imageWidth: number;
    imageHeight: number;
    params: DetectionParams;
    timestamp: Date;
}
/** Export JSON compatible Fabric.js (format V22/V70) */
export interface FabricWallObject {
    type: 'line';
    version: '5.3.0';
    originX: 'center';
    originY: 'center';
    left: number;
    top: number;
    width: number;
    height: number;
    stroke: string;
    strokeWidth: number;
    myType: 'Mur';
    data: {
        material: string;
    };
    x1: number;
    y1: number;
    x2: number;
    y2: number;
}
