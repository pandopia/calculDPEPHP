/** Point 2D */
export interface Point {
    x: number;
    y: number;
}
/** Boîte englobante */
export interface BoundingBox {
    x: number;
    y: number;
    w: number;
    h: number;
}
/** Boîte de sélection avec état actif */
export interface SelectionBox extends BoundingBox {
    active: boolean;
}
/** Intervalle numérique */
export interface Interval {
    s: number;
    e: number;
}
/** Nœud de graphe pour la détection de pièces */
export interface GraphNode {
    p: Point;
    neighbors: Array<{
        id: string;
        p: Point;
        angle: number;
    }>;
}
/** Graphe indexé par identifiant de nœud */
export type Graph = Record<string, GraphNode>;
