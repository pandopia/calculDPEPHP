/** Types d'objets supportés dans l'éditeur */
export type FloorplanObjectType = 'HazardSample' | 'Mur' | 'Cloison' | 'PipeAEP' | 'PipeEU' | 'PipeEM' | 'PipeEV' | 'PipeVent' | 'PipeGaz' | 'PipeElec' | 'PipeFibre' | 'PipeEP' | 'Door' | 'Window' | 'Stair' | 'RoomBox' | 'Equipment' | 'SpancPictogram' | 'AcPictogram' | 'HazardZone' | 'NorthArrow' | 'PTag' | 'ETag' | 'STag' | 'RoomLabel' | 'WallLabel' | 'WallMeasurement' | 'PipeMeasurement' | 'DetectedRoom' | 'LockedLabel' | 'RoomWallLabel' | 'Backdrop';
/** Mode métier — filtre les outils visibles (cumulables) */
export type WorkMode = 'diag' | 'aep' | 'eu' | 'spanc' | 'ac' | 'vrd';
/** Mode d'édition actif */
export type EditorMode = 'select' | 'node-edit' | 'pan' | 'wall' | 'cloison' | 'room' | 'room-sketch' | 'stair' | 'door' | 'window' | 'pipe-aep' | 'pipe-eu' | 'pipe-em' | 'pipe-ev' | 'pipe-vent' | 'pipe-gaz' | 'pipe-elec' | 'pipe-fibre' | 'pipe-ep' | 'spanc-bac-graisses' | 'spanc-fosse-septique' | 'spanc-fosse-toutes-eaux' | 'spanc-fosse-toutes-eaux-prefiltre' | 'spanc-prefiltre' | 'spanc-fosse-etanche' | 'spanc-tranchees-epandage' | 'spanc-filtre-sable' | 'spanc-filtre-compact' | 'spanc-microstation' | 'spanc-filtre-plante' | 'spanc-toilettes-seches' | 'spanc-compost' | 'spanc-lit-epandage' | 'spanc-puits-infiltration' | 'spanc-puits-perdu' | 'spanc-evacuation' | 'spanc-tranchee-infiltration' | 'spanc-regard' | 'spanc-pompe-relevage' | 'spanc-ventilation-secondaire' | 'ac-regard-eu' | 'ac-regard-em' | 'ac-regard-ev' | 'ac-regard-ep' | 'ac-label-eu' | 'ac-label-em' | 'ac-label-ev' | 'ac-label-ep' | 'ac-noeud' | 'ac-pied' | 'ac-boite-branchement' | 'equip-elec' | 'equip-boiler' | 'equip-vmc' | 'equip-daaf' | 'equip-gas' | 'equip-hwt' | 'hazard-amiante' | 'hazard-plomb' | 'hazard-humidite' | 'prelevement' | 'north-arrow' | 'tag' | 'tag-eau' | 'tag-spanc' | 'draw-red' | 'draw-blue';
/** Sous-types d'équipements techniques */
export type EquipmentSubtype = 'elec-panel' | 'boiler' | 'vmc' | 'daaf' | 'gas-meter' | 'water-heater';
/** Types de zones à risque pour le diagnostic */
export type HazardType = 'amiante' | 'plomb' | 'humidite';
/** Surface sur laquelle se situe un prélèvement / une zone de risque */
export type HazardSurface = 'sol' | 'mur' | 'plafond';
/** Type de vitrage d'une fenêtre */
export type GlazingType = 'simple' | 'double' | 'triple' | 'quadruple';
/** Type de porte (simple ou double vantail) */
export type DoorType = 'simple' | 'double';
/** Groupe d'outils dans la barre d'outils */
export interface ToolGroup {
    label: string;
    tools: ToolDefinition[];
    /** Modes auxquels appartient le groupe par défaut. Hérité par les outils sans `modes` explicite. */
    modes?: WorkMode[];
}
/** Définition d'un outil */
export interface ToolDefinition {
    mode: EditorMode;
    icon: string;
    label: string;
    shortcut?: string;
    borderColor?: string;
    /** Modes métier auxquels appartient l'outil. Override le `modes` du groupe. */
    modes?: WorkMode[];
}
/** Nœud de contrôle pour l'édition de segments */
export interface ControlNode {
    x: number;
    y: number;
    lines: Array<{
        obj: any;
        type: 'start' | 'end';
    }>;
}
/** Finition d'une surface (sol, mur, plafond) */
export interface SurfaceFinish {
    material?: string;
    etat?: string;
    notes?: string;
}
/** Descriptif complet d'une pièce */
export interface RoomDescription {
    sol?: SurfaceFinish;
    mur?: SurfaceFinish;
    plafond?: SurfaceFinish;
    notes?: string;
}
/** Données affichées dans le panneau inspecteur */
export interface InspectorData {
    objectType: FloorplanObjectType | null;
    label?: string;
    material?: string;
    length?: number;
    area?: number;
    isPrimary?: boolean;
    equipSubtype?: EquipmentSubtype;
    hazardType?: HazardType;
    hazardLabel?: string;
    /** Surface visée par un prélèvement ou une zone à risque */
    hazardSurface?: HazardSurface;
    notes?: string;
    roomDescription?: RoomDescription;
    /** Référence du mur sur lequel se trouve une porte/fenêtre, ex : "A — Salon" */
    wallRef?: string;
    /** Type de vitrage d'une fenêtre */
    glazingType?: GlazingType;
    /** Type de porte */
    doorType?: DoorType;
    /** Asbestos sampling result */
    amianteResult?: 'unknown' | 'positive' | 'negative';
    /** ID of the linked HazardSample (for HazardZone) */
    linkedSampleId?: string | null;
    /** Available HazardSample markers on the canvas (for HazardZone inspector) */
    availableSamples?: {
        sampleId: string;
    }[];
    /** Pièce CRI liée à cette pièce dessinée (for DetectedRoom) */
    criRoomId?: string | null;
    /** Pièces CRI proposées dans le sélecteur (for DetectedRoom inspector) */
    availableCriRooms?: {
        id: string;
        name: string;
    }[];
}
