import { SurfaceFinish, HazardSurface, GlazingType, DoorType } from './floorplan-object.model';
/** Position d'un élément sur le plan, en pixels canvas. */
export interface PlanPoint {
    x: number;
    y: number;
}
/** Une ouverture (porte) rattachée à un mur d'une pièce. */
export interface DoorSummary {
    /** Id du mur porteur (wallId). */
    wall: string;
    /** Lettre du mur dans la pièce (A, B…). '' si pas encore calculée. */
    letter: string;
    type: DoorType;
    isPrimary: boolean;
}
/** Une ouverture (fenêtre) rattachée à un mur d'une pièce. */
export interface WindowSummary {
    wall: string;
    letter: string;
    glazing: GlazingType;
}
/** Synthèse d'une pièce détectée. */
export interface RoomSummary {
    /** Identifiant stable (data.roomId) — null si la pièce n'a jamais été re-détectée. */
    id: string | null;
    /** Nom renseigné (data.label) — null si non renseigné. */
    name: string | null;
    areaM2: number;
    /** true si la pièce est imbriquée (placard dans une chambre, enveloppe…). */
    isNested: boolean;
    floor: {
        id: string;
        name: string;
        order: number;
    };
    centroid: PlanPoint;
    materials: {
        sol: SurfaceFinish;
        mur: SurfaceFinish;
        plafond: SurfaceFinish;
    };
    notes: string | null;
    /** Murs de la pièce avec leur lettre et longueur. */
    walls: {
        letter: string;
        wallId: string;
        lengthM: number;
    }[];
    openings: {
        doors: DoorSummary[];
        windows: WindowSummary[];
        doorCount: number;
        windowCount: number;
    };
    /** Pièce CRI liée si l'utilisateur a validé la correspondance. */
    linkedCri: {
        id: string;
        name: string;
    } | null;
}
/** Synthèse des réseaux (ANC/AC/VRD). */
export interface NetworkSummary {
    /** Linéaire par type de canalisation. */
    pipes: {
        type: string;
        label: string;
        lengthM: number;
    }[];
    totalLengthM: number;
    /** Éléments ponctuels dessinés (fosses, regards, etc.). */
    elements: {
        family: 'spanc' | 'ac';
        kind: string;
        label: string;
        position: PlanPoint;
        floorId: string;
    }[];
}
/** Synthèse des éléments de repérage diagnostic (amiante…). */
export interface HazardSummary {
    samples: {
        id: string;
        label: string;
        surface: HazardSurface;
        result?: 'unknown' | 'positive' | 'negative';
        position: PlanPoint;
        floorId: string;
        /** Id du prélèvement CRI associé si posé via la file guidée. */
        linkedCriId?: string;
    }[];
    zones: {
        hazardType: string;
        label: string;
        surface: HazardSurface;
        linkedSampleId?: string;
        position: PlanPoint;
        floorId: string;
    }[];
}
/** Synthèse d'un niveau. */
export interface FloorSummary {
    id: string;
    name: string;
    order: number;
    rooms: RoomSummary[];
    totalAreaM2: number;
}
/** Synthèse structurée complète d'un plan — destinée à l'app hôte (CRI). */
export interface PlanSummary {
    generatedAt: string;
    pixelsPerMeter: number;
    floors: FloorSummary[];
    /** Toutes les pièces aplaties (tous niveaux confondus), pour itération directe. */
    rooms: RoomSummary[];
    network: NetworkSummary;
    hazards: HazardSummary;
    stats: {
        roomCount: number;
        totalAreaM2: number;
        wallCount: number;
        wallLengthM: number;
    };
}
