import { DetectionParams } from '../models/config.model';
import { DetectionResult } from '../models/wall.model';
import * as i0 from "@angular/core";
export declare class WallDetectionService {
    private readonly opencvSvc;
    private readonly geometrySvc;
    detect(srcCanvas: HTMLCanvasElement, binCanvas: HTMLCanvasElement, params: DetectionParams): DetectionResult;
    detectAsync(srcCanvas: HTMLCanvasElement, binCanvas: HTMLCanvasElement, params: DetectionParams): Promise<DetectionResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WallDetectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WallDetectionService>;
}
