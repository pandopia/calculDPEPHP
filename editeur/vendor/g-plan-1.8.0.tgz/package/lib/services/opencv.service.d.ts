import * as i0 from "@angular/core";
export declare class OpenCvService {
    private readonly config;
    private loadPromise;
    private readonly _isReady;
    readonly isReady: import("@angular/core").Signal<boolean>;
    load(): Promise<void>;
    get cv(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenCvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpenCvService>;
}
