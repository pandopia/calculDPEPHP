import { FloorplanProject, ProjectStats } from '../models/project.model';
import * as i0 from "@angular/core";
/**
 * Disclaimer légal affiché sur tout export de surface.
 * La surface calculée est brute (axe des murs, sans gestion HSP) — pas une surface Carrez/Boutin.
 */
export declare const SURFACE_DISCLAIMER: string;
export declare class ExportService {
    toProject(canvas: any, pixelsPerMeter: number): FloorplanProject;
    fromFile(file: File): Promise<FloorplanProject>;
    /** Export JPEG — qualité 90%, multiplicateur x2 pour l'impression.
     *  Le JPEG ne gère pas la transparence : on force un fond blanc le temps de
     *  l'export (sinon les zones transparentes du canvas ressortent en noir),
     *  puis on restaure l'état précédent. */
    toJpg(canvas: any): Blob;
    /** Export PNG haute résolution (300 dpi équivalent, multiplicateur x3) */
    toPng(canvas: any, multiplier?: number): Blob;
    toSvg(canvas: any): string;
    /** JPEG (qualité 90%, x2) avec légende automatique des éléments dessinés. */
    toJpgWithLegend(canvas: any, multiplier?: number): Promise<Blob>;
    /** PNG haute résolution (x3) avec légende automatique des éléments dessinés. */
    toPngWithLegend(canvas: any, multiplier?: number): Promise<Blob>;
    downloadJpgWithLegend(canvas: any, filename?: string, multiplier?: number): Promise<Blob>;
    downloadPngWithLegend(canvas: any, filename?: string, multiplier?: number): Promise<Blob>;
    /** Rend le plan en dataURL. Le JPEG ne gère pas la transparence : on force un
     *  fond blanc le temps de l'export puis on restaure l'état précédent. */
    private planDataUrl;
    /**
     * Recompose l'image du plan avec un panneau de légende. Placement automatique :
     * à droite si l'image est en paysage, en bas si elle est en portrait.
     * S'il n'y a aucun élément à légender, renvoie l'image telle quelle.
     */
    private composeWithLegend;
    /**
     * Pré-rend une vignette PNG du vrai symbole dessiné pour chaque entrée
     * « marker » (pictogrammes AC/SPANC, équipements, prélèvements, Nord…), via
     * `fabricObject.toDataURL()`. Les traits et zones gardent leur pastille de
     * synthèse. Échecs silencieux → repli sur la pastille générique.
     */
    private renderSymbolThumbnails;
    /** Dessine la pastille d'un item : vignette du symbole réel si fournie, sinon
     *  pastille de synthèse (trait, trait pointillé, rectangle ou point). */
    private drawSwatch;
    /** `#rrggbb` → `rgba(r,g,b,a)`. Renvoie la couleur telle quelle si non hex. */
    private withAlpha;
    private loadImage;
    private canvasToBlob;
    downloadJson(project: FloorplanProject, filename?: string): void;
    downloadJpg(canvas: any, filename?: string): void;
    /** Télécharge un PNG haute résolution (x3 = ~300 dpi pour A4) */
    downloadPng(canvas: any, filename?: string, multiplier?: number): void;
    downloadSvg(canvas: any, filename?: string): void;
    /**
     * Export JSON structuré métier (distinct du JSON Fabric.js interne).
     * Inclut le disclaimer légal et les surfaces par pièce si disponibles.
     */
    toStructuredJson(canvas: any, pixelsPerMeter: number, stats?: ProjectStats, meta?: {
        address?: string;
        diagnostician?: string;
        missionId?: string;
    }): object;
    downloadStructuredJson(canvas: any, pixelsPerMeter: number, stats?: ProjectStats, meta?: {
        address?: string;
        diagnostician?: string;
        missionId?: string;
    }, filename?: string): void;
    private dataUrlToBlob;
    private triggerDownload;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExportService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExportService>;
}
