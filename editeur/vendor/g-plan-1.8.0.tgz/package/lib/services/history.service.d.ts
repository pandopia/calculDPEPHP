import * as i0 from "@angular/core";
export declare class HistoryService {
    private canvas;
    private history;
    private step;
    private isRestoring;
    private savePaused;
    private readonly _step;
    private readonly _historyLength;
    readonly canUndo: import("@angular/core").Signal<boolean>;
    readonly canRedo: import("@angular/core").Signal<boolean>;
    init(canvas: any): void;
    /** Bloque temporairement les sauvegardes automatiques (undo/redo + recalcul). */
    pauseSaving(): void;
    resumeSaving(): void;
    save(): void;
    undo(): Promise<void>;
    redo(): Promise<void>;
    private restore;
    static ɵfac: i0.ɵɵFactoryDeclaration<HistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HistoryService>;
}
