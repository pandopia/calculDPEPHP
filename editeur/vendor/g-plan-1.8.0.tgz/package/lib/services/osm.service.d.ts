import { FloorplanConfig } from '../models/config.model';
import { GeoLocation } from '../models/project.model';
import * as i0 from "@angular/core";
export interface GeocodeResult {
    lat: number;
    lng: number;
    label: string;
}
export declare class OsmService {
    private map;
    /**
     * Résout la classe Map quelle que soit la forme de distribution de maplibre-gl :
     * - ESM natif → `mod.Map`
     * - UMD/CJS empaqueté comme ESM par certains bundlers → `mod.default.Map`
     *   (le package.json upstream déclare `"type": "module"` alors que le main
     *   est un UMD sans `export` nommé, ce qui peut faire que `mod.Map` est
     *   undefined dans certains contextes esbuild/webpack et plante avec
     *   « r is not a constructor »).
     */
    private loadMapClass;
    initMap(container: HTMLElement, config: FloorplanConfig): void;
    /**
     * Bascule la couche affichée :
     * - 'osm'       → style vecteur du tileserver (ou raster OSM en fallback)
     * - 'satellite' → imagerie satellite raster
     * - 'cadastre'  → ajoute le cadastre en overlay par-dessus le fond courant
     * - 'custom'    → style alternatif du tileserver (config.tileStyle)
     */
    setLayer(type: 'osm' | 'satellite' | 'cadastre' | 'custom', config: FloorplanConfig): void;
    /** Géocode une adresse via Nominatim et retourne les résultats. */
    geocode(query: string): Promise<GeocodeResult[]>;
    /** Déplace la carte vers les coordonnées données, zoom minimum 18. */
    flyTo(lat: number, lng: number, zoom?: number): void;
    getCenter(): {
        lat: number;
        lng: number;
        zoom: number;
    } | null;
    /** Résolution en mètres/px CSS à la position courante (formule MapLibre 512px). */
    getMetersPerPixel(): number | null;
    captureCurrentView(): Promise<string>;
    destroy(): void;
    /**
     * Capture une vue cartographique en offscreen à la position `geo` donnée.
     * Crée un div temporaire hors-écran, initialise une carte MapLibre, attend le chargement
     * des tuiles (idle), capture le canvas et retourne le dataUrl + l'échelle px/m.
     */
    captureAt(geo: GeoLocation, layer: 'osm' | 'satellite', config: FloorplanConfig, width?: number, height?: number): Promise<{
        dataUrl: string;
        scaleVal: number;
    }>;
    private getBaseStyle;
    private getCustomStyle;
    private getSatelliteStyle;
    /** Ajoute le cadastre comme couche raster par-dessus le style vectoriel courant. */
    private addCadastreOverlay;
    private removeCadastreOverlay;
    static ɵfac: i0.ɵɵFactoryDeclaration<OsmService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OsmService>;
}
