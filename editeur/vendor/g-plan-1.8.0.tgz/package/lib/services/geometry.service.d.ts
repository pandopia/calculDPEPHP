import { WallSegment, RawSegment } from '../models/wall.model';
import { ProjectStats } from '../models/project.model';
import { Point, SelectionBox, Graph } from '../models/geometry.types';
import * as i0 from "@angular/core";
export declare class GeometryService {
    performClustering(segments: RawSegment[], clusterDist: number): WallSegment[];
    extendToIntersections(walls: WallSegment[], extDist: number): WallSegment[];
    snapCorners(walls: WallSegment[], snapDist: number): WallSegment[];
    fragmentWalls(walls: WallSegment[]): WallSegment[];
    getConnectivity(x: number, y: number, walls: WallSegment[], scopeBox?: SelectionBox): number;
    mergeCollinearSegments(walls: WallSegment[], indices: number[]): WallSegment[];
    buildGraph(segments: Array<{
        x1: number;
        y1: number;
        x2: number;
        y2: number;
    }>, snapPx?: number): Graph;
    findMinimalCycles(graph: Graph): Point[][];
    getSignedArea(points: Point[]): number;
    getCentroid(points: Point[]): Point;
    /**
     * Test point-dans-polygone (ray casting).
     * Utilisé pour détecter les cycles imbriqués (ex : placard dans une chambre).
     */
    isPointInPolygon(point: Point, polygon: Point[]): boolean;
    distanceToSegment(p: Point, v: Point, w: Point): number;
    recalculateRooms(canvas: any, pixelsPerMeter: number, showMeasurements: boolean): {
        stats: ProjectStats;
    };
    private getAbsoluteLineEnds;
    /**
     * Pour chaque extrémité de segment qui se trouve à moins de `snapDist` px de l'intérieur
     * d'un autre segment, déplace cette extrémité sur la surface du mur (snap exact).
     * Garantit des T-jonctions précises avant la fragmentation, même si les murs sont légèrement
     * désalignés (tracé manuel, croquis).
     */
    private snapEndpointsToWalls;
    private splitIntersectingFabricLines;
    private lineIntersect;
    /**
     * Vérifie qu'un point est à l'intérieur d'un segment (hors extrémités).
     * Utilise la distance perpendiculaire normalisée par la longueur du segment
     * pour être robuste sur les murs diagonaux (contrairement à un EPS absolu).
     */
    private pointOnSegment;
    private generateStablePastelColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeometryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeometryService>;
}
