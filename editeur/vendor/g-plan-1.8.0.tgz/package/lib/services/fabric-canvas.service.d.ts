import { EditorMode } from '../models/floorplan-object.model';
import { FloorplanProject } from '../models/project.model';
import * as i0 from "@angular/core";
export declare class FabricCanvasService {
    private canvas;
    private readonly _isPolylineDrawing;
    private activePolylineLines;
    private lastPoint;
    private previewLine;
    private readonly _currentMode;
    private isDragging;
    private lastPosX;
    private lastPosY;
    private isDrawingRect;
    private rectStart;
    private previewRect;
    private activeNodes;
    private readonly WALL_CONN_SNAP;
    /** Callback déclenché après chaque ajout/modification — utilisé pour recalculateRooms. */
    onWallsChanged?: () => void;
    /** Prochain prélèvement CRI à poser au clic (pose guidée). null = pose libre (P{n+1}). */
    private _nextSample;
    setNextSample(s: {
        id: string;
        label: string;
    } | null): void;
    /** Callback déclenché quand un prélèvement de la file guidée vient d'être posé. */
    onSamplePlaced?: (e: {
        criSampleId: string;
        label: string;
        position: {
            x: number;
            y: number;
        };
    }) => void;
    readonly isPolylineDrawing: import("@angular/core").Signal<boolean>;
    readonly currentMode: import("@angular/core").Signal<EditorMode>;
    init(canvas: any): void;
    setMode(mode: EditorMode): void;
    /**
     * En mode sélection : tous les objets sont sélectionnables/évènementiels.
     * Dans les autres modes : seuls les WallNodes restent évènementiels (drag de nœud possible),
     * le reste est verrouillé pour ne pas interférer avec le dessin.
     * En lecture seule : aucun objet n'est sélectionnable — masque le cadre de
     * sélection et les poignées qui laissaient croire à une modification possible.
     */
    private applyModeSelectability;
    private _readOnly;
    /** Active/désactive le mode lecture seule au niveau du service Fabric.
     *  À jour dès l'appel — re-applique la sélectabilité de tous les objets. */
    setReadOnly(ro: boolean): void;
    isReadOnly(): boolean;
    /**
     * Recrée tous les nœuds visibles sur les extrémités de murs/cloisons.
     * Appelé après chaque ajout/modification de mur.
     */
    refreshNodeHandles(): void;
    private onNodeMoving;
    /**
     * Enregistre les positions initiales et les connexions d'un mur/cloison
     * AVANT tout déplacement (appelé depuis mouse:down pour avoir les bonnes coords).
     *
     * Deux types de connexions détectées :
     *  - endpoint-to-endpoint : extrémité d'un autre mur coïncide avec P1 ou P2
     *  - endpoint-to-body : extrémité d'une cloison posée sur le CORPS du mur (milieu)
     */
    private initWallMoveState;
    /**
     * Déplacement d'un mur/cloison en temps réel avec maintien des connexions.
     * L'état (_moveInit) doit être initialisé dans mouse:down pour des positions correctes.
     */
    private onWallMoving;
    /**
     * Calcule les coordonnées canvas à partir d'un MouseEvent en utilisant
     * getBoundingClientRect() directement, évitant le bug de scroll traversal
     * de canvas.getPointer() dans les conteneurs scrollables.
     */
    /** Coordonnées écran d'un événement souris OU tactile (les TouchEvent
     *  n'exposent pas clientX/Y à la racine). */
    private eventClient;
    private getCanvasPointer;
    /** Pas de grille effectif — élargi sur tactile pour viser plus facilement au doigt. */
    private get effectiveGrid();
    private snapToGrid;
    /**
     * Snap intelligent pour le dessin de murs/cloisons.
     * Priorité : 1) nœud existant (extrémité de mur), 2) projection sur un mur, 3) grille.
     */
    private snapPolylinePoint;
    private onMouseDown;
    private onMouseMove;
    private onMouseUp;
    private handlePolylineClick;
    /**
     * Crée un mur porteur (fabric.Line) avec un wallId unique pour le cascade delete.
     * Utilise des coords relatives au centre pour être compatible avec calcLinePoints().
     */
    private createWallLine;
    /**
     * Crée une cloison (non porteur) — trait plus fin et tirets.
     */
    private createCloisonLine;
    private createPipeLine;
    finishPolyline(): void;
    /** Double-clic : termine le tracé en cours. Le 2ᵉ clic du double-clic a créé
     *  un segment quasi nul (le curseur n'a pas bougé) — on le retire avant de
     *  clôturer pour ne pas laisser de point parasite. */
    private onDoubleClick;
    /** Longueur (px) d'un segment fabric.Line, indépendante du recentrage. */
    private lineLength;
    /** Vrai si le mode courant est un tracé de réseau (canalisation). */
    private isPipeMode;
    /** Vrai si l'objet peut être déplacé au clic pendant un tracé réseau. */
    private isUserMovable;
    /** Renvoie un objet réseau au fond, juste au-dessus du fond de carte et des
     *  étages fantômes (qui doivent rester tout en bas). */
    private sendNetworkToBack;
    /** Reclasse tous les traits de réseau sous les autres dessins (appelé au
     *  chargement d'un projet pour garantir l'ordre même sur les plans anciens). */
    private restackNetworksBelow;
    private createStairObject;
    private createHazardZone;
    private createRoomBox;
    /**
     * Snap d'un point sur les bords (X et Y) des RoomBox existantes.
     * Utilise la grille (20px) comme fallback si aucune boîte n'est assez proche.
     */
    private snapForRoomSketch;
    /**
     * Génère l'enveloppe de l'appartement à partir des RoomBox présentes sur le canvas.
     * - Les segments partagés par ≥ 2 pièces → Cloison
     * - Les segments extérieurs (1 seule pièce) → Mur porteur
     * Supprime ensuite tous les RoomBox.
     */
    generateEnvelope(): void;
    /**
     * Bascule un mur porteur en cloison ou vice-versa.
     */
    toggleWallType(obj: any): void;
    private handleDoorWindow;
    private handleClickEquipment;
    private handleNorthArrow;
    private handleClickSymbol;
    private handleClickSpancPictogram;
    private handleClickAcPictogram;
    private handleClickPrelevement;
    /** Distance from point p to segment (a, b) */
    private ptSegDist;
    /**
     * Contraint une porte/fenêtre à glisser sur son mur parent pendant le drag.
     * Si le mur n'est pas trouvé, on laisse libre.
     */
    private constrainOpeningToWall;
    /**
     * Remet toutes les portes/fenêtres d'un mur sur sa nouvelle géométrie
     * (appelé pendant le drag d'un nœud).
     */
    private updateOpeningsOnWall;
    /** Projette le centre d'une ouverture sur le segment [p1,p2] et met à jour angle. */
    private projectOpeningOntoWall;
    /**
     * Après déplacement d'un mur, recolle ses extrémités aux extrémités voisines
     * des autres murs (tolérance 20px) et aligne sur la grille sinon.
     * Retourne true si un snap a eu lieu.
     */
    private snapLineEndpoints;
    private findNearestWallSnap;
    private getAbsoluteLineEnds;
    cascadeDeleteOpenings(deletedWallIds: string[]): void;
    /** Affiche les objets d'un étage précédent en très atténué (8% opacité). */
    showGhostFloor(rawObjects: any[]): void;
    /** Supprime tous les objets fantôme du canvas. */
    clearGhostFloor(): void;
    /**
     * Copie les murs extérieurs (Mur) d'un étage sur le canvas courant.
     * Utilisé pour repartir des murs de l'étage inférieur sur un nouvel étage.
     */
    copyObjectsFromFloor(rawObjects: any[]): void;
    loadFromProject(project: FloorplanProject): Promise<void>;
    destroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FabricCanvasService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FabricCanvasService>;
}
