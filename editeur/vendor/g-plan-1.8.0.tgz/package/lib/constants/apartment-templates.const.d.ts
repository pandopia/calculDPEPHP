import { FloorplanProject } from '../models/project.model';
export type ApartmentShape = 'rectangle' | 'square' | 'L' | 'U' | 'T';
export interface ApartmentTemplate {
    id: string;
    typology: string;
    shape: ApartmentShape;
    label: string;
    description: string;
    areaSqm: number;
    rooms: string[];
    project: FloorplanProject;
}
export declare const APARTMENT_TEMPLATES: ApartmentTemplate[];
