import { DetectionParams } from '../models/config.model';
/** Paramètres de détection par défaut utilisés par le scanner */
export declare const DEFAULT_DETECTION_PARAMS: DetectionParams;
