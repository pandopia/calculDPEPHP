/** Liste des noms de pièces proposés par défaut dans l'éditeur */
export declare const ROOM_NAMES: string[];
/**
 * Pièces exclues de la surface habitable loi Carrez (décret 97-532).
 * À utiliser pour informer l'utilisateur lors de l'export.
 */
export declare const ROOM_NAMES_CARREZ_EXCLUDED: string[];
