/** Libellés courts des canalisations par `myType` Fabric. */
export declare const PIPE_LABELS: Record<string, string>;
/** Ordre d'affichage des linéaires de réseaux. */
export declare const PIPE_ORDER: string[];
