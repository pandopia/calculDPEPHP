import { FloorplanObjectType, ToolGroup } from '../models/floorplan-object.model';
/** Types d'objets Fabric.js persistés lors de la sauvegarde */
export declare const FABRIC_SAVED_TYPES: FloorplanObjectType[];
/** Groupes d'outils de la barre d'outils de l'éditeur */
export declare const TOOL_GROUPS: ToolGroup[];
