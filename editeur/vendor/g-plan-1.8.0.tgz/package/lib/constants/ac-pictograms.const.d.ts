import { EditorMode, FloorplanObjectType } from '../models/floorplan-object.model';
/**
 * Pictogrammes pour le mode Assainissement Collectif (AC).
 * Set minimaliste — la palette ne contient que :
 *  - Regards EU/EM/EV/EP (4 manholes color-codés)
 *  - Labels EU/EM/EV/EP (badges textuels à placer le long d'un tracé)
 *  - Nœud de connexion (image 13 du xlsx)
 *  - Pied de descente / collecteur terminus (image 14 du xlsx)
 *
 * Les pictogrammes SPANC partagés (fosse, micro-station…) ne sont pas dupliqués
 * ici : ils peuvent être visibles aussi en mode AC en ajoutant 'ac' à leur
 * tableau `modes` côté TOOL_GROUPS si besoin un jour.
 */
export interface AcPictogramDef {
    mode: EditorMode;
    label: string;
    width: number;
    height: number;
    build: (fabric: any) => any[];
}
export declare const AC_PICTOGRAMS: Record<string, AcPictogramDef>;
/** Vrai si le mode correspond à un pictogramme AC */
export declare function isAcPictogramMode(mode: EditorMode): boolean;
/** Type d'objet Fabric persisté pour tous les pictogrammes AC */
export declare const AC_PICTOGRAM_TYPE: FloorplanObjectType;
