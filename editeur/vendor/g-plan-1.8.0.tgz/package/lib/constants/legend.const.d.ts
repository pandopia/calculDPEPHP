/**
 * Légende des éléments dessinés — intégrée aux exports image (PNG/JPEG).
 *
 * Principe : la couleur de chaque entrée est **dérivée de l'objet Fabric
 * réellement dessiné** (`stroke`/`fill`, en descendant dans les groupes), de
 * sorte que la légende reprenne toujours exactement les couleurs du plan — y
 * compris pour les repères color-codés par type d'eau (AC : EU violet, EP
 * cyan…). Les couleurs ci-dessous ne servent que de repli quand l'objet ne
 * porte pas de couleur exploitable (ex. forme sérialisée sans enfants).
 *
 * Les types non « physiques » (labels, mesures, nœuds, fond de carte, repères
 * de cote) ne sont pas mappés et sont donc ignorés par `collectLegendItems`.
 */
/** Forme de la pastille de légende dessinée à gauche du libellé. */
export type LegendSwatch = 'line' | 'dashed' | 'box' | 'marker';
export interface LegendItem {
    /** Clé de dédoublonnage (un seul item par clé dans la légende finale). */
    key: string;
    label: string;
    color: string;
    swatch: LegendSwatch;
    /** Objet Fabric représentatif (premier rencontré pour cette clé). Permet au
     *  rendu d'export d'afficher une vignette du vrai symbole dessiné pour les
     *  pictogrammes (regards, labels, équipements…). Non sérialisé. */
    ref?: any;
}
/**
 * Construit la liste dédoublonnée des entrées de légende à partir des objets
 * Fabric (vivants ou sérialisés). La couleur est dérivée de l'objet dessiné
 * (cf. `dominantColor`) et retombe sur la couleur de repli si indisponible.
 * L'ordre suit `LEGEND_ORDER`, puis le libellé.
 */
export declare function collectLegendItems(objects: readonly any[]): LegendItem[];
