import { EditorMode, FloorplanObjectType } from '../models/floorplan-object.model';
/**
 * Pictogrammes SPANC dessinés en vectoriel (Fabric.js Groups).
 * Chaque builder construit les primitives autour de l'origine (0,0)
 * dans une zone W×H, puis le groupe est placé via { left: cx, top: cy, originX/Y: 'center' }.
 */
export interface SpancPictogramDef {
    /** EditorMode déclencheur (depuis TOOL_GROUPS) */
    mode: EditorMode;
    label: string;
    /** Largeur logique du dessin en pixels canvas (avant zoom) */
    width: number;
    height: number;
    /** Construit les primitives Fabric à partir de l'objet `fabric` global */
    build: (fabric: any) => any[];
}
export declare const SPANC_PICTOGRAMS: Record<string, SpancPictogramDef>;
/** Vrai si le mode correspond à un pictogramme SPANC */
export declare function isSpancPictogramMode(mode: EditorMode): boolean;
/** Type d'objet Fabric persisté pour tous les pictogrammes SPANC */
export declare const SPANC_PICTOGRAM_TYPE: FloorplanObjectType;
