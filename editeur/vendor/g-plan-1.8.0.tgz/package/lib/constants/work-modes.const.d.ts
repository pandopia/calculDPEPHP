import { WorkMode } from '../models/floorplan-object.model';
export interface WorkModeDefinition {
    id: WorkMode;
    label: string;
    shortLabel: string;
    /** Couleur d'accent pour le toggle */
    color: string;
    /** Icône (emoji court) du toggle */
    icon: string;
}
/**
 * Modes métier — cumulables.
 * Le mapping outil ↔ mode vit dans `fabric-types.const.ts` (champ `modes` de chaque
 * ToolDefinition / ToolGroup). Un outil est visible si l'intersection entre ses
 * modes et les modes actifs est non vide.
 */
export declare const WORK_MODES: WorkModeDefinition[];
export declare const ALL_WORK_MODES: WorkMode[];
export declare const DEFAULT_WORK_MODES: WorkMode[];
export declare const WORK_MODES_STORAGE_KEY = "gplan-work-modes";
