/** Matériaux de sol */
export declare const SOL_MATERIALS: string[];
/** Matériaux / finitions de mur */
export declare const MUR_FINISHES: string[];
/** Matériaux / finitions de plafond */
export declare const PLAFOND_FINISHES: string[];
/** États génériques (sol, mur, plafond) */
export declare const ETAT_OPTIONS: string[];
