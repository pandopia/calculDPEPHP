import { OnDestroy, AfterViewInit } from '@angular/core';
import { FloorplanConfig } from '../../../models/config.model';
import { GeoLocation } from '../../../models/project.model';
import { GeocodeResult } from '../../../services/osm.service';
import * as i0 from "@angular/core";
type MapLayer = 'osm' | 'satellite' | 'cadastre';
export declare class OsmModalComponent implements AfterViewInit, OnDestroy {
    config: import("@angular/core").InputSignal<FloorplanConfig>;
    import: import("@angular/core").OutputEmitterRef<{
        dataUrl: string;
        geo: GeoLocation;
        scaleVal: number;
    }>;
    close: import("@angular/core").OutputEmitterRef<void>;
    private mapContainerRef;
    private readonly osmSvc;
    protected readonly searchQuery: import("@angular/core").WritableSignal<string>;
    protected readonly searchResults: import("@angular/core").WritableSignal<GeocodeResult[]>;
    protected readonly isSearching: import("@angular/core").WritableSignal<boolean>;
    protected readonly showResults: import("@angular/core").WritableSignal<boolean>;
    protected readonly activeLayer: import("@angular/core").WritableSignal<MapLayer>;
    ngAfterViewInit(): void;
    onSearch(): Promise<void>;
    onSearchKeydown(event: KeyboardEvent): void;
    selectResult(result: GeocodeResult): void;
    setLayer(layer: MapLayer): void;
    onImport(): Promise<void>;
    onClose(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OsmModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OsmModalComponent, "ng-gplan-osm-modal", never, { "config": { "alias": "config"; "required": true; "isSignal": true; }; }, { "import": "import"; "close": "close"; }, never, never, true, never>;
}
export {};
