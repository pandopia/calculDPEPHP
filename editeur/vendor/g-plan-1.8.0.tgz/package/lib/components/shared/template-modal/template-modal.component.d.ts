import { ApartmentTemplate, ApartmentShape } from '../../../constants/apartment-templates.const';
import * as i0 from "@angular/core";
type ShapeFilter = ApartmentShape | 'all';
interface ShapeOption {
    value: ShapeFilter;
    label: string;
    svgPath: string;
}
export declare class TemplateModalComponent {
    readonly close: import("@angular/core").OutputEmitterRef<void>;
    readonly templateSelected: import("@angular/core").OutputEmitterRef<ApartmentTemplate>;
    readonly selectedShape: import("@angular/core").WritableSignal<ShapeFilter>;
    readonly shapeOptions: ShapeOption[];
    readonly filteredTemplates: import("@angular/core").Signal<ApartmentTemplate[]>;
    select(tpl: ApartmentTemplate): void;
    isMur(obj: any): boolean;
    isCloison(obj: any): boolean;
    shapeLabel(shape: ApartmentShape): string;
    shapeColor(shape: ApartmentShape): string;
    /** Reconstruct absolute X1 from Fabric.js line JSON */
    svgX(obj: any): number;
    svgY(obj: any): number;
    svgX2(obj: any): number;
    svgY2(obj: any): number;
    svgViewBox(tpl: ApartmentTemplate): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TemplateModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TemplateModalComponent, "ng-gplan-template-modal", never, {}, { "close": "close"; "templateSelected": "templateSelected"; }, never, never, true, never>;
}
export {};
