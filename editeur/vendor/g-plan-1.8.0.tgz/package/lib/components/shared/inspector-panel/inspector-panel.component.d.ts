import { InspectorData, RoomDescription, SurfaceFinish, GlazingType, DoorType, HazardSurface } from '../../../models/floorplan-object.model';
import * as i0 from "@angular/core";
export declare class InspectorPanelComponent {
    data: import("@angular/core").InputSignal<InspectorData | null>;
    /** Mode visualisation : tous les champs deviennent en lecture seule. */
    readOnly: import("@angular/core").InputSignal<boolean>;
    dataChange: import("@angular/core").OutputEmitterRef<InspectorData>;
    protected readonly materials: string[];
    protected readonly solMaterials: string[];
    protected readonly murFinishes: string[];
    protected readonly plafondFinishes: string[];
    protected readonly etatOptions: string[];
    protected readonly glazingOptions: {
        value: GlazingType;
        label: string;
    }[];
    protected readonly doorTypeOptions: {
        value: DoorType;
        label: string;
    }[];
    protected readonly hazardSurfaceOptions: {
        value: HazardSurface;
        label: string;
    }[];
    onLabelChange(value: string): void;
    onMaterialChange(value: string): void;
    onIsPrimaryChange(value: boolean): void;
    onGlazingTypeChange(value: GlazingType): void;
    onDoorTypeChange(value: DoorType): void;
    onHazardSurfaceChange(value: HazardSurface): void;
    onRoomDescChange(surface: keyof RoomDescription, field: keyof SurfaceFinish, value: string): void;
    onAmianteResultChange(value: 'unknown' | 'positive' | 'negative'): void;
    onLinkedSampleChange(value: string): void;
    onNotesChange(value: string): void;
    onRoomNotesChange(value: string): void;
    onCriRoomChange(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InspectorPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InspectorPanelComponent, "ng-gplan-inspector-panel", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; }, { "dataChange": "dataChange"; }, never, never, true, never>;
}
