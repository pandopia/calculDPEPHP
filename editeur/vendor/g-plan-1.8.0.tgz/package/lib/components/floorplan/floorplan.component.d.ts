import { DetectionParams } from '../../models/config.model';
import { WallsImportPayload, FloorplanProject, ProjectStats, FloorRooms } from '../../models/project.model';
import { PlanSummary } from '../../models/plan-summary.model';
import * as i0 from "@angular/core";
export declare class FloorplanComponent {
    project: import("@angular/core").ModelSignal<FloorplanProject | null>;
    layout: import("@angular/core").InputSignal<"tabs" | "split">;
    scannerParams: import("@angular/core").InputSignal<Partial<DetectionParams>>;
    /** Charge automatiquement un fond de carte depuis project.geo : 'osm' | 'satellite' | null */
    autoGeoLayer: import("@angular/core").InputSignal<"osm" | "satellite" | null>;
    /** Coordonnées GPS (lat/lng, zoom max par défaut) pour charger un fond de carte
     *  au démarrage sans passer par la modale. Propagé à l'éditeur. */
    geoPoint: import("@angular/core").InputSignal<{
        lat: number;
        lng: number;
        zoom?: number;
        layer?: "osm" | "satellite";
        width?: number;
        height?: number;
    } | null>;
    /** Force le layout compact (drawer/sheet) sur grand viewport — utile pour iframe/modal étroites. */
    compactMode: import("@angular/core").InputSignal<boolean>;
    /** Mode visualisation : seuls select & pan, tous les objets verrouillés, sidebar/menus d'édition masqués. */
    readOnly: import("@angular/core").InputSignal<boolean>;
    /** Pièces du CRI proposées pour lier une pièce dessinée. Propagé à l'éditeur. */
    criRooms: import("@angular/core").InputSignal<{
        id: string;
        name: string;
    }[]>;
    /** Prélèvements CRI à positionner (pose guidée). Propagé à l'éditeur. */
    pendingSamples: import("@angular/core").InputSignal<{
        id: string;
        label: string;
    }[]>;
    projectChange: import("@angular/core").OutputEmitterRef<FloorplanProject>;
    statsChanged: import("@angular/core").OutputEmitterRef<ProjectStats>;
    roomsChanged: import("@angular/core").OutputEmitterRef<FloorRooms[]>;
    jpgExported: import("@angular/core").OutputEmitterRef<Blob>;
    pngExported: import("@angular/core").OutputEmitterRef<Blob>;
    svgExported: import("@angular/core").OutputEmitterRef<string>;
    summaryChange: import("@angular/core").OutputEmitterRef<PlanSummary>;
    roomLinked: import("@angular/core").OutputEmitterRef<{
        roomId: string;
        criRoomId: string;
        name: string;
    }>;
    samplePlaced: import("@angular/core").OutputEmitterRef<{
        criSampleId: string;
        label: string;
        position: {
            x: number;
            y: number;
        };
        floorId: string;
    }>;
    protected readonly activeTab: import("@angular/core").WritableSignal<"scanner" | "editor">;
    protected readonly detectedWalls: import("@angular/core").WritableSignal<WallsImportPayload | null>;
    setTab(tab: 'scanner' | 'editor'): void;
    onWallsDetected(payload: WallsImportPayload): void;
    onProjectSaved(project: FloorplanProject): void;
    onStatsChanged(stats: ProjectStats): void;
    onRoomsChanged(rooms: FloorRooms[]): void;
    onJpgExported(blob: Blob): void;
    onPngExported(blob: Blob): void;
    onSvgExported(svg: string): void;
    onSummaryChange(s: PlanSummary): void;
    onRoomLinked(e: {
        roomId: string;
        criRoomId: string;
        name: string;
    }): void;
    onSamplePlaced(e: {
        criSampleId: string;
        label: string;
        position: {
            x: number;
            y: number;
        };
        floorId: string;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FloorplanComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FloorplanComponent, "ng-gplan", never, { "project": { "alias": "project"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "scannerParams": { "alias": "scannerParams"; "required": false; "isSignal": true; }; "autoGeoLayer": { "alias": "autoGeoLayer"; "required": false; "isSignal": true; }; "geoPoint": { "alias": "geoPoint"; "required": false; "isSignal": true; }; "compactMode": { "alias": "compactMode"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; "criRooms": { "alias": "criRooms"; "required": false; "isSignal": true; }; "pendingSamples": { "alias": "pendingSamples"; "required": false; "isSignal": true; }; }, { "project": "projectChange"; "projectChange": "projectChange"; "statsChanged": "statsChanged"; "roomsChanged": "roomsChanged"; "jpgExported": "jpgExported"; "pngExported": "pngExported"; "svgExported": "svgExported"; "summaryChange": "summaryChange"; "roomLinked": "roomLinked"; "samplePlaced": "samplePlaced"; }, never, never, true, never>;
}
