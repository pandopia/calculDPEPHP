import { AfterViewInit, OnDestroy } from '@angular/core';
import { HistoryService } from '../../services/history.service';
import { WallsImportPayload, FloorplanProject, ProjectStats, FloorRooms } from '../../models/project.model';
import { EditorMode, InspectorData } from '../../models/floorplan-object.model';
import { GeoLocation } from '../../models/project.model';
import { ApartmentTemplate } from '../../constants/apartment-templates.const';
import { WorkMode, ToolGroup } from '../../models/floorplan-object.model';
import { PlanSummary } from '../../models/plan-summary.model';
import * as i0 from "@angular/core";
export declare class PlanEditorComponent implements AfterViewInit, OnDestroy {
    initialWalls: import("@angular/core").InputSignal<WallsImportPayload | null>;
    project: import("@angular/core").InputSignal<FloorplanProject | null>;
    showSidebar: import("@angular/core").InputSignal<boolean>;
    showHeader: import("@angular/core").InputSignal<boolean>;
    canvasHeight: import("@angular/core").InputSignal<number>;
    canvasWidth: import("@angular/core").InputSignal<number>;
    /** Charge automatiquement un fond de carte depuis project.geo au démarrage */
    autoGeoLayer: import("@angular/core").InputSignal<"osm" | "satellite" | null>;
    /** Coordonnées GPS fournies par l'app hôte (mobile / administration) pour
     *  charger automatiquement un fond de carte au démarrage, sans passer par la
     *  modale OSM. `zoom` absent → zoom max (19). `layer` absent → valeur de
     *  `autoGeoLayer` sinon 'satellite'. Prioritaire sur `project.geo`. */
    geoPoint: import("@angular/core").InputSignal<{
        lat: number;
        lng: number;
        zoom?: number;
        layer?: "osm" | "satellite";
        width?: number;
        height?: number;
    } | null>;
    /** Force le mode compact (drawer mobile) même sur grand viewport — utile pour
     *  les conteneurs étroits comme une iframe ou une modal Gordon-PWA. */
    compactMode: import("@angular/core").InputSignal<boolean>;
    /** Mode lecture seule : sélection/zoom/pan possibles, mais aucune création
     *  ni édition d'objet. Utile pour la consultation d'un CRI archivé. */
    readOnly: import("@angular/core").InputSignal<boolean>;
    /** Liste des pièces du CRI à proposer dans l'inspecteur pour lier une pièce
     *  dessinée à une pièce CRI (« cette pièce = Chambre 1 »). */
    criRooms: import("@angular/core").InputSignal<{
        id: string;
        name: string;
    }[]>;
    /** Prélèvements amiante du CRI à positionner. Quand l'outil « Prélèvement » est
     *  actif, chaque clic pose le prochain de la file avec son id/label CRI.
     *  Passer une NOUVELLE référence de tableau pour réinitialiser la file. */
    pendingSamples: import("@angular/core").InputSignal<{
        id: string;
        label: string;
    }[]>;
    projectSaved: import("@angular/core").OutputEmitterRef<FloorplanProject>;
    projectChange: import("@angular/core").OutputEmitterRef<FloorplanProject>;
    statsChanged: import("@angular/core").OutputEmitterRef<ProjectStats>;
    roomsChanged: import("@angular/core").OutputEmitterRef<FloorRooms[]>;
    jpgExported: import("@angular/core").OutputEmitterRef<Blob>;
    pngExported: import("@angular/core").OutputEmitterRef<Blob>;
    svgExported: import("@angular/core").OutputEmitterRef<string>;
    /** Émis une fois le canvas Fabric initialisé — passe l'élément `<canvas>` natif
     *  pour que le parent puisse capturer une vignette à la demande. */
    canvasReady: import("@angular/core").OutputEmitterRef<HTMLCanvasElement>;
    /** Émis à chaque transition de l'état de chargement interne. */
    loadingState: import("@angular/core").OutputEmitterRef<boolean>;
    /** Synthèse structurée du plan, émise (debounce ~500ms) à chaque modification.
     *  Voir aussi la méthode impérative `getPlanSummary()`. */
    summaryChange: import("@angular/core").OutputEmitterRef<PlanSummary>;
    /** Émis quand l'utilisateur lie une pièce dessinée à une pièce CRI. */
    roomLinked: import("@angular/core").OutputEmitterRef<{
        roomId: string;
        criRoomId: string;
        name: string;
    }>;
    /** Émis quand un prélèvement CRI de la file est posé sur le plan. */
    samplePlaced: import("@angular/core").OutputEmitterRef<{
        criSampleId: string;
        label: string;
        position: {
            x: number;
            y: number;
        };
        floorId: string;
    }>;
    private canvasRef;
    /** Conteneur scrollable du canvas — sert à recentrer la vue sur le fond de carte. */
    private canvasAreaRef;
    protected readonly currentMode: import("@angular/core").WritableSignal<EditorMode>;
    protected readonly stats: import("@angular/core").WritableSignal<ProjectStats>;
    protected readonly inspectorData: import("@angular/core").WritableSignal<InspectorData | null>;
    protected readonly showInspector: import("@angular/core").WritableSignal<boolean>;
    protected readonly isLoading: import("@angular/core").WritableSignal<boolean>;
    protected readonly pixelsPerMeter: import("@angular/core").WritableSignal<number>;
    protected readonly showMeasurements: import("@angular/core").WritableSignal<boolean>;
    protected readonly isOsmModalOpen: import("@angular/core").WritableSignal<boolean>;
    protected readonly isTemplateModalOpen: import("@angular/core").WritableSignal<boolean>;
    protected readonly calibrationLength: import("@angular/core").WritableSignal<string>;
    protected readonly roomBoxWidthM: import("@angular/core").WritableSignal<string>;
    protected readonly roomBoxHeightM: import("@angular/core").WritableSignal<string>;
    protected readonly backgroundLocked: import("@angular/core").WritableSignal<boolean>;
    protected readonly bgRotation: import("@angular/core").WritableSignal<number>;
    protected readonly scaleLocked: import("@angular/core").WritableSignal<boolean>;
    protected readonly hasBackdrop: import("@angular/core").WritableSignal<boolean>;
    /** Affiche la vue 3D par-dessus le canvas 2D (toggle non destructif). */
    protected readonly show3D: import("@angular/core").WritableSignal<boolean>;
    /** Projet sérialisé passé au viewer 3D — recalculé à chaque entrée en 3D. */
    protected readonly project3D: import("@angular/core").WritableSignal<FloorplanProject | null>;
    /** File des prélèvements CRI restant à poser (pose guidée). Initialisée depuis
     *  l'input `pendingSamples`, consommée tête en premier à chaque pose. */
    protected readonly pendingQueue: import("@angular/core").WritableSignal<{
        id: string;
        label: string;
    }[]>;
    /** Libellés restant à placer — pour le bandeau d'aide. */
    protected readonly remainingSampleLabels: import("@angular/core").Signal<string[]>;
    protected readonly hasAutosave: import("@angular/core").WritableSignal<boolean>;
    protected readonly autosaveTime: import("@angular/core").WritableSignal<string | null>;
    private autosaveInterval;
    private projectChangeTimer;
    protected readonly floors: import("@angular/core").WritableSignal<{
        id: string;
        name: string;
        order: number;
    }[]>;
    protected readonly currentFloorId: import("@angular/core").WritableSignal<string>;
    private floorObjects;
    /** ID du niveau source dont on propose de copier les murs extérieurs. */
    protected readonly copyWallsSourceId: import("@angular/core").WritableSignal<string | null>;
    protected readonly showCopyWallsOffer: import("@angular/core").Signal<boolean>;
    /** Modal d'ajout d'un niveau */
    protected readonly showAddFloorModal: import("@angular/core").WritableSignal<boolean>;
    protected readonly newFloorDirection: import("@angular/core").WritableSignal<"above" | "below">;
    protected readonly newFloorName: import("@angular/core").WritableSignal<string>;
    /** Dropdown "copier depuis" (rétroactif) */
    protected readonly showCopyFromMenu: import("@angular/core").WritableSignal<boolean>;
    /** Dropdowns header */
    protected readonly showFondMenu: import("@angular/core").WritableSignal<boolean>;
    protected readonly showFichierMenu: import("@angular/core").WritableSignal<boolean>;
    /** Étages triés du plus bas (SS) au plus haut (Combles) */
    protected readonly sortedFloors: import("@angular/core").Signal<{
        id: string;
        name: string;
        order: number;
    }[]>;
    protected readonly roomsByFloor: import("@angular/core").WritableSignal<{
        floorId: string;
        floorName: string;
        rooms: Array<{
            label: string;
            areaM2: number;
        }>;
        totalArea: number;
    }[]>;
    protected readonly showRoomList: import("@angular/core").WritableSignal<boolean>;
    /** Surface totale cumulée sur tous les niveaux. */
    protected readonly globalAreaM2: import("@angular/core").Signal<number>;
    /** Entrées de linéaire triées par type pour l'affichage. */
    protected readonly pipeEntries: import("@angular/core").Signal<{
        label: string;
        lengthM: number;
    }[]>;
    protected toggleRoomList(): void;
    /** Sélectionne une pièce depuis la liste (les DetectedRoom étant non-sélectionnables
     *  par clic canvas, on ouvre l'inspecteur directement sans passer par setActiveObject). */
    protected selectRoomFromList(floorId: string, label: string, areaM2: number): void;
    private updateRoomList;
    protected readonly currentFloorName: import("@angular/core").Signal<string>;
    /** Ordre calculé selon la direction choisie dans la modal */
    protected readonly newFloorOrder: import("@angular/core").Signal<number>;
    protected readonly toolGroups: ToolGroup[];
    protected readonly ROOM_NAMES: string[];
    /** Version de la librairie (synchronisée depuis package.json au build). */
    protected readonly version = "1.8.0";
    /** État du drawer latéral sur mobile (slide-in). Géré par les media queries CSS,
     *  ce signal pilote uniquement l'overlay/transform sous le breakpoint. */
    protected readonly mobileSidebarOpen: import("@angular/core").WritableSignal<boolean>;
    protected toggleMobileSidebar(): void;
    protected closeMobileSidebar(): void;
    constructor();
    protected readonly workModeDefs: import("g-plan").WorkModeDefinition[];
    protected readonly activeWorkModes: import("@angular/core").WritableSignal<Set<WorkMode>>;
    /** Filtre les groupes/outils selon les modes actifs (union d'outils, sans doublon). */
    protected readonly visibleToolGroups: import("@angular/core").Signal<ToolGroup[]>;
    protected isWorkModeActive(id: WorkMode): boolean;
    protected toggleWorkMode(id: WorkMode): void;
    private loadInitialWorkModes;
    private persistWorkModes;
    /** Si l'outil courant n'est plus dans les modes actifs, retombe en sélection. */
    private resetToolIfHidden;
    private readonly fabricSvc;
    protected readonly historySvc: HistoryService;
    private readonly exportSvc;
    private readonly osmSvc;
    private readonly geometrySvc;
    private readonly analysisSvc;
    protected readonly config: import("g-plan").FloorplanConfig;
    private readonly destroyRef;
    private readonly zone;
    private canvas;
    /** Mur actuellement mis en surbrillance (sélection) — pour restaurer sa couleur. */
    private highlightedWall;
    /** Dernier mur/cloison sélectionné — conservé même après deselection (pour applyCalibration). */
    private calibrationTarget;
    /** Dernier projet émis par CE composant — utilisé pour éviter les rechargements inutiles. */
    private _lastEmittedProject;
    /** Libellé lisible de l'outil actif (résolu depuis TOOL_GROUPS) — utilisé
     *  par le badge contextuel du header pour éviter l'affichage du mode brut
     *  type "ac-regard-eu". */
    protected readonly currentToolLabel: import("@angular/core").Signal<string>;
    /** Vrai dès qu'un outil de tracé polyligne est actif (mur/cloison/pipe).
     *  Volontairement indépendant de l'état "tracé en cours" : ce dernier bascule
     *  dans un handler Fabric hors zone Angular et ne déclencherait pas de
     *  détection de changements fiable — le bouton "Terminer le tracé" ne
     *  s'afficherait jamais pour les pipes. `currentMode` est mis à jour par un
     *  clic in-zone, donc le binding réagit toujours. */
    protected readonly isPolylineMode: import("@angular/core").Signal<boolean>;
    /** Vrai s'il y a des pièces détectées (≥ 1). Les compteurs pcs/m² et le badge
     *  de surface n'ont de sens que dans ce cas (un plan SPANC/AC à base de
     *  réseaux n'a aucune pièce → "0 pcs / 0,0 m²" est du bruit). */
    protected readonly hasRooms: import("@angular/core").Signal<boolean>;
    /** Vrai si le panneau latéral droit a quelque chose à afficher : au moins une
     *  pièce détectée OU au moins un linéaire de réseau. Sinon il ne montrerait
     *  que « Aucune pièce détectée » — inutile, on le masque (cf. plan en cours de
     *  tracé sans pièce). */
    protected readonly hasRoomListContent: import("@angular/core").Signal<boolean>;
    /** Le badge de stats du header est masqué quand il n'y a ni pièce ni mur. */
    protected readonly showStatsBadge: import("@angular/core").Signal<boolean>;
    /** Le badge de niveau (RDC…) n'a de sens que s'il y a des pièces ou plusieurs
     *  niveaux à distinguer. Pour un plan réseau SPANC/AC (1 niveau, 0 pièce) il
     *  n'est que du bruit → masqué. (En 3D le badge est de toute façon recouvert
     *  par l'overlay ; c'est le watermark interne du viewer 3D qui prend le relais,
     *  gating identique côté viewer-3d.) */
    protected readonly showFloorBadge: import("@angular/core").Signal<boolean>;
    protected get canUndo(): import("@angular/core").Signal<boolean>;
    protected get canRedo(): import("@angular/core").Signal<boolean>;
    ngAfterViewInit(): void;
    private checkAutosave;
    private scheduleProjectChange;
    /** Synthèse structurée du plan, à la demande (ex : au clic « Valider le plan »).
     *  Synchrone et à jour : `buildProjectWithFloors()` snapshote le niveau courant
     *  et renvoie tous les niveaux. */
    getPlanSummary(): PlanSummary;
    /** Recharge le canvas depuis un projet externe (autre onglet éditeur). */
    private performAutosave;
    restoreAutosave(): void;
    dismissAutosave(): void;
    openAddFloorModal(): void;
    setAddFloorDirection(dir: 'above' | 'below'): void;
    confirmAddFloor(): void;
    cancelAddFloor(): void;
    /** Nom par défaut selon l'ordre relatif du niveau */
    protected nameForOrder(order: number): string;
    /** Nom d'un niveau par son id */
    protected getFloorName(id: string | null): string;
    /** Ouvre/ferme le menu rétroactif "copier depuis" */
    openCopyFromMenu(): void;
    toggleFondMenu(): void;
    toggleFichierMenu(): void;
    /** Déclenche la proposition de copie depuis un étage donné (rétroactif) */
    copyWallsFromFloor(sourceId: string): void;
    switchFloor(floorId: string): void;
    copyExteriorWalls(): void;
    dismissCopyWallsOffer(): void;
    private updateInspector;
    private setupKeyboardShortcuts;
    setMode(mode: EditorMode): void;
    /** Bascule entre la vue 2D (canvas Fabric) et la vue 3D (Three.js). À chaque
     *  entrée en 3D, on resérialise le projet courant pour refléter les dernières
     *  modifications. Non destructif : le canvas 2D est simplement masqué. */
    toggle3D(): void;
    undo(): void;
    redo(): void;
    /** Termine le tracé en cours et repasse en mode Sélection (l'outil de
     *  dessin est désélectionné — pratique sur tactile pour clôturer nettement). */
    finishPolyline(): void;
    /** Convertit les RoomBox du croquis en murs porteurs et cloisons. */
    generateEnvelope(): void;
    /**
     * Snape les extrémités de tous les murs sur une grille dédupliquée à ±SNAP px.
     * Garantit que deux coordonnées quasi-identiques (ex: 199.7 et 200.0) convergent
     * vers la même valeur — condition nécessaire pour la détection des T-jonctions.
     */
    private normalizeWallCoordinates;
    /** Bascule le mur/cloison sélectionné entre porteur et cloison. */
    toggleSelectedWallType(): void;
    /**
     * 1ère calibration → ajuste le PPM pour que ce mur = realLengthM.
     * Calibrations suivantes → redimensionne CE mur en pixels (PPM inchangé).
     * Dans les deux cas, verrouille la longueur et affiche un indicateur visuel.
     */
    applyCalibration(): void;
    /** Définit les dimensions réelles (m) d'une pièce RoomBox et redimensionne en pixels. */
    applyRoomBoxDimensions(): void;
    /** Retourne les coordonnées absolues canvas des deux extrémités d'un mur (fabric.Line). */
    private getAbsWallEndpoints;
    /**
     * Solveur de contraintes de layout orthogonal global.
     *
     * Principe :
     *  1. Construire un modèle colonnes (X uniques) / lignes (Y uniques) depuis tous les murs.
     *  2. Chaque mur verrouillé impose une distance fixe entre deux colonnes ou deux lignes.
     *  3. Résoudre les positions 1D en respectant ces contraintes, les spans libres
     *     se compressant/dilatant proportionnellement.
     *  4. Repositionner tous les murs selon les nouvelles positions colonnes/lignes.
     *
     * Avantage vs BFS impératif : toutes les contraintes sont résolues simultanément,
     * sans accumulation d'erreurs entre calibrations successives.
     */
    private applyLayoutConstraints;
    /**
     * Solveur 1D : repositionne N positions ordonnées selon des contraintes de distance.
     *
     * L'ancre est la première position (index 0), fixe.
     * Les contraintes (ci, cj, d) imposent : positions[cj] - positions[ci] = d px.
     * Traitées de gauche à droite : chaque contrainte décale les positions ≥ cj,
     * puis redistribue les positions intermédiaires proportionnellement.
     * Les spans libres s'ajustent naturellement.
     */
    private solve1D;
    /**
     * Mappe une coordonnée de l'ancien espace grille vers le nouveau.
     * Snap exact sur les lignes de grille, interpolation linéaire entre.
     */
    private snapRemap;
    /**
     * Redimensionne les RoomBoxes avec cotes réelles verrouillées selon le PPM courant.
     * Les murs verrouillés sont gérés par applyLayoutConstraints().
     */
    private updateLockedObjects;
    /**
     * Crée les labels visuels "⊛ X.XX m" sur les murs avec longueur verrouillée.
     * Non persistés (recréés à chaque recalculateRooms).
     */
    private refreshLockedLabels;
    /** Met le mur sélectionné en orange vif et sauvegarde sa couleur d'origine. */
    private highlightSelectedWall;
    /** Restaure la couleur d'origine du mur précédemment mis en surbrillance. */
    private restoreHighlightedWall;
    deleteActive(): void;
    importWallsFromScanner(payload: WallsImportPayload): void;
    /** Identifiant unique (UUID si dispo, sinon fallback). Utilisé pour les ids
     *  stables de pièces (data.roomId). */
    private genId;
    recalculateRooms(): void;
    /** Affiche les identifiants (P1, P2…) des zones à risque sur le plan 2D. */
    private refreshHazardLabels;
    /** Supprime et recrée les labels de pièces nommées sur le canvas (non sélectionnables). */
    private refreshRoomLabels;
    saveProject(): void;
    private buildProjectWithFloors;
    loadProject(event: Event): void;
    /** Applique les modes métier portés par un projet chargé (override localStorage si présents). */
    private applyProjectWorkModes;
    exportJPG(): void;
    exportPNG(): void;
    exportSVG(): void;
    /** Recharge le canvas depuis un projet externe (appelable par le parent au changement d'onglet). */
    reloadFromProject(proj: FloorplanProject): void;
    onScaleInput(event: Event): void;
    commitScaleChange(event: Event): void;
    toggleMeasurements(): void;
    openOsmModal(): void;
    closeOsmModal(): void;
    openTemplateModal(): void;
    closeTemplateModal(): void;
    loadTemplate(tpl: ApartmentTemplate): void;
    onOsmImport(data: {
        dataUrl: string;
        geo: GeoLocation;
        scaleVal: number;
    }): void;
    /** Charge un fond de carte depuis l'input `geoPoint` (coordonnées fournies par
     *  l'app hôte) si présent et qu'aucun fond n'existe déjà. Zoom max par défaut.
     *  Idempotent — le garde `hasBackdrop` évite le double chargement. */
    private loadGeoBackdropIfNeeded;
    private applyBackdrop;
    /** Recentre la vue sur le fond de carte / backdrop dès son ajout : viewport
     *  remis à l'identité et zone de canvas scrollée sur le centre (le backdrop
     *  est placé au centre du canvas). */
    private centerViewOnBackdrop;
    /** Mode visualisation : verrouille la motion de tous les objets non-backdrop.
     *  Les objets restent sélectionnables (inspection panneau latéral) mais
     *  immobiles. Backdrop conserve ses propres verrous (syncBackdropState).
     *  Porte/fenêtre conservent leur lock de scaling en sortie de readOnly. */
    private applyReadOnlyToObjects;
    /** Synchronise l'état du fond de carte après chargement d'un projet : le
     *  backdrop est verrouillé (non sélectionnable) par défaut — sinon il se
     *  déplace par mégarde au doigt. */
    private syncBackdropState;
    removeBackdrop(): void;
    loadBackgroundImage(event: Event): void;
    toggleBackgroundLock(): void;
    updateBackgroundRotation(event: Event): void;
    showGridOverlay(): void;
    hideGridOverlay(): void;
    onInspectorChange(data: InspectorData): void;
    /**
     * Assigne les lettres A, B, C… à chaque mur d'une pièce, dans le sens horaire
     * en partant de la porte principale (la porte avec isPrimary=true, ou la première).
     * Crée des labels 'RoomWallLabel' sur le canvas et annote les fenêtres (ex : B-F1).
     * Seules les pièces avec au moins une porte sont numérotées.
     */
    private refreshWallLetters;
    /** Vérifie si un point est à moins de `tol` pixels d'une arête du polygone. */
    private rwlNearEdge;
    /** Renvoie l'index de l'arête du polygone la plus proche du point (tolérance 60px). */
    private rwlNearestEdge;
    /** Renvoie les extrémités absolues d'un mur Fabric (même formule que geometry.service). */
    private rwlLineEnds;
    /** Trouve le mur Fabric dont le segment est colinéaire à l'arête (p1, p2). */
    private rwlFindWall;
    /** Distance d'un point à un segment. */
    private rwlDist;
    /** Crée un label de lettre sur le canvas, décalé vers l'intérieur de la pièce. */
    private rwlAddLabel;
    /**
     * Trie les fenêtres d'un mur le long de son axe et leur attribue un label
     * de type "B-F1", "B-F2", etc. stocké dans `window.data.wallLabel`.
     */
    private rwlLabelWindows;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlanEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PlanEditorComponent, "ng-gplan-plan-editor", never, { "initialWalls": { "alias": "initialWalls"; "required": false; "isSignal": true; }; "project": { "alias": "project"; "required": false; "isSignal": true; }; "showSidebar": { "alias": "showSidebar"; "required": false; "isSignal": true; }; "showHeader": { "alias": "showHeader"; "required": false; "isSignal": true; }; "canvasHeight": { "alias": "canvasHeight"; "required": false; "isSignal": true; }; "canvasWidth": { "alias": "canvasWidth"; "required": false; "isSignal": true; }; "autoGeoLayer": { "alias": "autoGeoLayer"; "required": false; "isSignal": true; }; "geoPoint": { "alias": "geoPoint"; "required": false; "isSignal": true; }; "compactMode": { "alias": "compactMode"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; "criRooms": { "alias": "criRooms"; "required": false; "isSignal": true; }; "pendingSamples": { "alias": "pendingSamples"; "required": false; "isSignal": true; }; }, { "projectSaved": "projectSaved"; "projectChange": "projectChange"; "statsChanged": "statsChanged"; "roomsChanged": "roomsChanged"; "jpgExported": "jpgExported"; "pngExported": "pngExported"; "svgExported": "svgExported"; "canvasReady": "canvasReady"; "loadingState": "loadingState"; "summaryChange": "summaryChange"; "roomLinked": "roomLinked"; "samplePlaced": "samplePlaced"; }, never, never, true, never>;
}
