import { ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { FloorplanProject } from '../../models/project.model';
import * as i0 from "@angular/core";
export declare class Viewer3DComponent implements AfterViewInit, OnDestroy {
    project: import("@angular/core").InputSignal<FloorplanProject | null>;
    protected readonly canvasRef: import("@angular/core").Signal<ElementRef<HTMLCanvasElement>>;
    /** Vrai s'il y a quelque chose d'affiché : murs, réseau ou pictogrammes SPANC/AC.
     *  Signal (et non getter) : le rebuild de la scène est déclenché hors cycle de
     *  détection Angular — un signal garantit que l'overlay « rien à afficher »
     *  se met bien à jour après le rendu. */
    protected readonly hasContent: import("@angular/core").WritableSignal<boolean>;
    protected readonly selectedFloorId: import("@angular/core").WritableSignal<string | null>;
    /** Tous les niveaux triés bas → haut */
    protected readonly allFloors: import("@angular/core").Signal<(import("g-plan").FloorLevel | {
        id: string;
        name: string;
        order: number;
    })[]>;
    /** Vrai si au moins une pièce (DetectedRoom) existe dans le projet. Le
     *  watermark de niveau (« RDC »…) n'a de sens qu'avec des pièces ou plusieurs
     *  niveaux — un plan réseau SPANC/AC sans pièce n'en a pas besoin. */
    protected readonly hasAnyRoom: import("@angular/core").Signal<boolean>;
    /** Niveaux affichés dans le watermark (filtrés selon la sélection). Vide si
     *  aucune pièce et un seul niveau (plan réseau pur) → pas de watermark. */
    protected readonly watermarkFloors: import("@angular/core").Signal<(import("g-plan").FloorLevel | {
        id: string;
        name: string;
        order: number;
    })[]>;
    protected selectFloor(id: string | null): void;
    protected readonly showSlabs: import("@angular/core").WritableSignal<boolean>;
    protected toggleSlabs(): void;
    /** Rotation auto « démo » : la caméra orbite en continu autour du plan. */
    protected readonly autoRotate: import("@angular/core").WritableSignal<boolean>;
    protected toggleAutoRotate(): void;
    private scene;
    private camera;
    private renderer;
    private controls;
    private animId;
    private wallCount;
    private pipeCount;
    private pictoCount;
    private resizeObserver?;
    /** Textures chargées à disposer lors du prochain rebuild */
    private loadedTextures;
    private readonly zone;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private initThree;
    private rebuildScene;
    /** Recadre la caméra autour du bâtiment courant. Exposée pour le bouton
     *  "Recadrer" et pour le rebuild initial. */
    resetCamera(): void;
    private lastBuildingSpan;
    private lastFloorCount;
    private addBackdrop;
    private extractWalls;
    private extractOpenings;
    private extractHazardZones;
    /** Ajoute une boîte de mur (segment) orientée selon le mur. */
    private addWallSegment;
    /** Rend un mur en découpant les ouvertures (portes/fenêtres). */
    private renderWall;
    /** Rendu des vantaux de porte (simples ou doubles), ouverts à ~70°. */
    private addDoorLeaves;
    /** Rendu des zones à risque (amiante, plomb/crep, humidité) en 3D. */
    private renderHazardZones;
    private extractHazardSamples;
    /** Rendu des prélèvements amiante en 3D : sphère positionnée selon la surface. Rouge si positif amiante, ambre sinon. */
    private renderHazardSamples;
    private addHazardOutline;
    private getAbsoluteEnds;
    /** Bornes (en pixels canvas) de toute la géométrie : murs, canalisations,
     *  pictogrammes et fond de carte. `null` si la scène est strictement vide. */
    private computeSceneBounds;
    private extractPipes;
    /** Rend chaque canalisation en cylindre coloré, légèrement surélevé au-dessus
     *  du fond de plan, avec une sphère de jonction à chaque extrémité. */
    private renderPipes;
    private extractPictograms;
    /** Rend les pictogrammes : regards en cuves cylindriques colorées selon le
     *  type d'eau, autres pictogrammes en marqueurs cubiques. Tous étiquetés. */
    private renderPictograms;
    /** Crée une étiquette texte flottante (sprite face-caméra) via un canvas. */
    private makeLabelSprite;
    /** Rendu du sol de chaque pièce DetectedRoom (polygone Fabric.js) */
    private renderRoomFloors;
    /** Génère une texture procédurale parquet bois pour le sol intérieur */
    private createParquetTexture;
    /** Génère une texture procédurale type pelouse/terrain pour le sol RDC */
    private createGroundTexture;
    private boundingBox;
    private animate;
    private onResize;
    static ɵfac: i0.ɵɵFactoryDeclaration<Viewer3DComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Viewer3DComponent, "ng-gplan-viewer-3d", never, { "project": { "alias": "project"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
