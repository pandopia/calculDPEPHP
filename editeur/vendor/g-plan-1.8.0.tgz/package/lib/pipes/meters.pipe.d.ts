import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Convertit une valeur en pixels en mètres formatés.
 * Usage: `{{ pixels | meters:pixelsPerMeter:2 }}`
 */
export declare class MetersPipe implements PipeTransform {
    transform(pixels: number, pixelsPerMeter?: number, decimals?: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetersPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MetersPipe, "meters", true>;
}
