import { InjectionToken } from '@angular/core';
import { FloorplanConfig } from '../models/config.model';
export declare const FLOORPLAN_CONFIG: InjectionToken<FloorplanConfig>;
/**
 * Fournit la configuration G-Plan au niveau de l'application.
 * À utiliser dans `bootstrapApplication` ou `ApplicationConfig`.
 */
export declare function provideGPlan(config: Partial<FloorplanConfig>): {
    provide: InjectionToken<FloorplanConfig>;
    useValue: {
        opencvUrl: string;
        pixelsPerMeter: number;
        tileServerUrl: string;
        tileStyle: string;
        defaultGridSize: number;
        defaultSnapDistance: number;
        backdropCaptureWidth?: number;
        backdropCaptureHeight?: number;
        detection?: Partial<import("g-plan").DetectionParams>;
    };
}[];
