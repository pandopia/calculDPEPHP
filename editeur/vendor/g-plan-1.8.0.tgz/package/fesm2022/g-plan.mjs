import * as i0 from '@angular/core';
import { InjectionToken, Pipe, output, HostListener, Directive, inject, signal, Injectable, computed, input, viewChild, DestroyRef, effect, ChangeDetectionStrategy, Component, NgZone, model } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { DecimalPipe, DatePipe } from '@angular/common';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

const defaultConfig = {
    opencvUrl: 'https://docs.opencv.org/4.8.0/opencv.js',
    pixelsPerMeter: 50,
    tileServerUrl: '',
    tileStyle: 'styles/osm-bright',
    defaultGridSize: 20,
    defaultSnapDistance: 15,
    // Capture du fond de carte : ~2× l'ancien défaut (800×600) pour englober plus
    // de terrain autour du point. Surchargeable via provideGPlan({ ... }).
    backdropCaptureWidth: 1280,
    backdropCaptureHeight: 960,
};
const FLOORPLAN_CONFIG = new InjectionToken('FLOORPLAN_CONFIG', {
    providedIn: 'root',
    factory: () => ({ ...defaultConfig })
});
/**
 * Fournit la configuration G-Plan au niveau de l'application.
 * À utiliser dans `bootstrapApplication` ou `ApplicationConfig`.
 */
function provideGPlan(config) {
    return [
        { provide: FLOORPLAN_CONFIG, useValue: { ...defaultConfig, ...config } }
    ];
}

/**
 * Convertit une valeur en pixels en mètres formatés.
 * Usage: `{{ pixels | meters:pixelsPerMeter:2 }}`
 */
class MetersPipe {
    transform(pixels, pixelsPerMeter = 50, decimals = 2) {
        const meters = pixels / pixelsPerMeter;
        return `${meters.toFixed(decimals)} m`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: MetersPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.25", ngImport: i0, type: MetersPipe, isStandalone: true, name: "meters" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: MetersPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'meters',
                    standalone: true,
                    pure: true
                }]
        }] });

/**
 * Directive de drag & drop pour le canvas de l'éditeur de plan.
 * Émet un événement `fileDrop` lorsqu'un fichier image est déposé sur l'élément hôte.
 *
 * Usage:
 * ```html
 * <canvas ngGplanCanvasDrop (fileDrop)="onFileDrop($event)"></canvas>
 * ```
 */
class CanvasDropDirective {
    /** Émis lorsqu'un fichier image valide est déposé */
    fileDrop = output();
    onDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = 'copy';
        }
    }
    onDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        const files = event.dataTransfer?.files;
        if (!files || files.length === 0) {
            return;
        }
        const file = files[0];
        if (file.type.startsWith('image/')) {
            this.fileDrop.emit(file);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CanvasDropDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.25", type: CanvasDropDirective, isStandalone: true, selector: "[ngGplanCanvasDrop]", outputs: { fileDrop: "fileDrop" }, host: { listeners: { "dragover": "onDragOver($event)", "drop": "onDrop($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CanvasDropDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngGplanCanvasDrop]',
                    standalone: true
                }]
        }], propDecorators: { onDragOver: [{
                type: HostListener,
                args: ['dragover', ['$event']]
            }], onDrop: [{
                type: HostListener,
                args: ['drop', ['$event']]
            }] } });

class OpenCvService {
    config = inject(FLOORPLAN_CONFIG);
    loadPromise = null;
    _isReady = signal(false);
    isReady = this._isReady.asReadonly();
    load() {
        if (this.loadPromise)
            return this.loadPromise;
        this.loadPromise = new Promise((resolve, reject) => {
            if (typeof window === 'undefined') {
                resolve();
                return;
            }
            if (window['cv']?.Mat) {
                this._isReady.set(true);
                resolve();
                return;
            }
            const script = document.createElement('script');
            script.async = true;
            script.src = this.config.opencvUrl;
            script.onload = () => {
                const timeout = setTimeout(() => reject(new Error('Timeout: OpenCV.js non initialisé après 30s')), 30000);
                const check = setInterval(() => {
                    if (window['cv']?.Mat) {
                        clearInterval(check);
                        clearTimeout(timeout);
                        this._isReady.set(true);
                        resolve();
                    }
                }, 100);
            };
            script.onerror = () => reject(new Error('Impossible de charger OpenCV.js depuis: ' + this.config.opencvUrl));
            document.head.appendChild(script);
        });
        return this.loadPromise;
    }
    get cv() {
        return typeof window !== 'undefined' ? window['cv'] : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: OpenCvService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: OpenCvService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: OpenCvService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class GeometryService {
    performClustering(segments, clusterDist) {
        const result = [];
        const processGroup = (list, isH) => {
            if (list.length === 0)
                return;
            list.sort((a, b) => (isH ? a.y1 - b.y1 : a.x1 - b.x1));
            const groups = [];
            let current = [list[0]];
            for (let i = 1; i < list.length; i++) {
                const delta = isH ? Math.abs(list[i].y1 - current[0].y1) : Math.abs(list[i].x1 - current[0].x1);
                if (delta <= clusterDist)
                    current.push(list[i]);
                else {
                    groups.push(current);
                    current = [list[i]];
                }
            }
            groups.push(current);
            groups.forEach(group => {
                const avgPos = group.reduce((s, x) => s + (isH ? x.y1 : x.x1), 0) / group.length;
                const intervals = group.map(x => isH ? { s: x.x1, e: x.x2 } : { s: x.y1, e: x.y2 }).sort((a, b) => a.s - b.s);
                const merged = [intervals[0]];
                for (let i = 1; i < intervals.length; i++) {
                    const last = merged[merged.length - 1];
                    if (intervals[i].s < last.e + 20)
                        last.e = Math.max(last.e, intervals[i].e);
                    else
                        merged.push(intervals[i]);
                }
                merged.forEach(v => {
                    result.push(isH
                        ? { id: crypto.randomUUID(), x1: v.s, y1: avgPos, x2: v.e, y2: avgPos, type: 'H', ignored: false }
                        : { id: crypto.randomUUID(), x1: avgPos, y1: v.s, x2: avgPos, y2: v.e, type: 'V', ignored: false });
                });
            });
        };
        processGroup(segments.filter(s => s.type === 'H'), true);
        processGroup(segments.filter(s => s.type === 'V'), false);
        return result;
    }
    extendToIntersections(walls, extDist) {
        if (extDist === 0)
            return walls;
        const H = walls.filter(w => w.type === 'H');
        const V = walls.filter(w => w.type === 'V');
        H.forEach(h => {
            const vl = V.find(v => Math.abs(v.x1 - h.x1) < extDist && h.y1 >= v.y1 && h.y1 <= v.y2);
            if (vl)
                h.x1 = vl.x1;
            const vr = V.find(v => Math.abs(v.x1 - h.x2) < extDist && h.y1 >= v.y1 && h.y1 <= v.y2);
            if (vr)
                h.x2 = vr.x1;
        });
        V.forEach(v => {
            const ht = H.find(h => Math.abs(h.y1 - v.y1) < extDist && v.x1 >= h.x1 && v.x1 <= h.x2);
            if (ht)
                v.y1 = ht.y1;
            const hb = H.find(h => Math.abs(h.y1 - v.y2) < extDist && v.x1 >= h.x1 && v.x1 <= h.x2);
            if (hb)
                v.y2 = hb.y1;
        });
        return walls;
    }
    snapCorners(walls, snapDist) {
        const H = walls.filter(w => w.type === 'H');
        const V = walls.filter(w => w.type === 'V');
        H.forEach(h => {
            V.forEach(v => {
                const ix = v.x1, iy = h.y1;
                if (Math.abs(h.x1 - ix) < snapDist && (Math.abs(v.y1 - iy) < snapDist || Math.abs(v.y2 - iy) < snapDist))
                    h.x1 = ix;
                if (Math.abs(h.x2 - ix) < snapDist && (Math.abs(v.y1 - iy) < snapDist || Math.abs(v.y2 - iy) < snapDist))
                    h.x2 = ix;
                if (Math.abs(v.y1 - iy) < snapDist && (Math.abs(h.x1 - ix) < snapDist || Math.abs(h.x2 - ix) < snapDist))
                    v.y1 = iy;
                if (Math.abs(v.y2 - iy) < snapDist && (Math.abs(h.x1 - ix) < snapDist || Math.abs(h.x2 - ix) < snapDist))
                    v.y2 = iy;
            });
        });
        return [...H, ...V];
    }
    fragmentWalls(walls) {
        const result = [];
        walls.forEach(w => {
            const cutPoints = [];
            cutPoints.push(w.type === 'H' ? w.x1 : w.y1);
            cutPoints.push(w.type === 'H' ? w.x2 : w.y2);
            walls.forEach(other => {
                if (w === other || w.type === other.type)
                    return;
                if (w.type === 'H') {
                    const inRangeX = other.x1 >= Math.min(w.x1, w.x2) - 2 && other.x1 <= Math.max(w.x1, w.x2) + 2;
                    const inRangeY = w.y1 >= Math.min(other.y1, other.y2) - 2 && w.y1 <= Math.max(other.y1, other.y2) + 2;
                    if (inRangeX && inRangeY)
                        cutPoints.push(other.x1);
                }
                else {
                    const inRangeX = w.x1 >= Math.min(other.x1, other.x2) - 2 && w.x1 <= Math.max(other.x1, other.x2) + 2;
                    const inRangeY = other.y1 >= Math.min(w.y1, w.y2) - 2 && other.y1 <= Math.max(w.y1, w.y2) + 2;
                    if (inRangeX && inRangeY)
                        cutPoints.push(other.y1);
                }
            });
            cutPoints.sort((a, b) => a - b);
            const unique = [cutPoints[0]];
            for (let i = 1; i < cutPoints.length; i++) {
                if (cutPoints[i] - unique[unique.length - 1] > 5)
                    unique.push(cutPoints[i]);
            }
            for (let i = 0; i < unique.length - 1; i++) {
                result.push(w.type === 'H'
                    ? { id: crypto.randomUUID(), x1: unique[i], y1: w.y1, x2: unique[i + 1], y2: w.y1, type: 'H', ignored: w.ignored }
                    : { id: crypto.randomUUID(), x1: w.x1, y1: unique[i], x2: w.x1, y2: unique[i + 1], type: 'V', ignored: w.ignored });
            }
        });
        return result;
    }
    getConnectivity(x, y, walls, scopeBox) {
        let count = 0;
        walls.forEach(w => {
            if (w.ignored)
                return;
            if (scopeBox?.active && Math.abs(scopeBox.w) > 5) {
                const cx = (w.x1 + w.x2) / 2, cy = (w.y1 + w.y2) / 2;
                const rx = Math.min(scopeBox.x, scopeBox.x + scopeBox.w);
                const ry = Math.min(scopeBox.y, scopeBox.y + scopeBox.h);
                if (cx < rx || cx > rx + Math.abs(scopeBox.w) || cy < ry || cy > ry + Math.abs(scopeBox.h))
                    return;
            }
            if (Math.abs(w.x1 - x) < 3 && Math.abs(w.y1 - y) < 3)
                count++;
            if (Math.abs(w.x2 - x) < 3 && Math.abs(w.y2 - y) < 3)
                count++;
        });
        return count;
    }
    mergeCollinearSegments(walls, indices) {
        const hInds = indices.filter(i => walls[i].type === 'H');
        const vInds = indices.filter(i => walls[i].type === 'V');
        const result = [...walls];
        const processMerge = (inds, isH) => {
            if (inds.length < 2)
                return;
            const group = inds.map(i => ({ ...walls[i] }));
            group.sort((a, b) => {
                const pA = isH ? a.y1 : a.x1;
                const pB = isH ? b.y1 : b.x1;
                if (Math.abs(pA - pB) > 5)
                    return pA - pB;
                return isH ? a.x1 - b.x1 : a.y1 - b.y1;
            });
            inds.forEach(i => result[i] = { ...result[i], ignored: true });
            let current = group[0];
            for (let i = 1; i < group.length; i++) {
                const next = group[i];
                const posCurr = isH ? current.y1 : current.x1;
                const posNext = isH ? next.y1 : next.x1;
                if (Math.abs(posCurr - posNext) < 10) {
                    const endCurr = isH ? current.x2 : current.y2;
                    const startNext = isH ? next.x1 : next.y1;
                    if (startNext < endCurr + 20) {
                        const minStart = isH ? Math.min(current.x1, next.x1) : Math.min(current.y1, next.y1);
                        const maxEnd = isH ? Math.max(current.x2, next.x2) : Math.max(current.y2, next.y2);
                        const avgPos = (posCurr + posNext) / 2;
                        current = isH
                            ? { id: crypto.randomUUID(), x1: minStart, y1: avgPos, x2: maxEnd, y2: avgPos, type: 'H', ignored: false }
                            : { id: crypto.randomUUID(), x1: avgPos, y1: minStart, x2: avgPos, y2: maxEnd, type: 'V', ignored: false };
                    }
                    else {
                        result.push({ ...current, id: crypto.randomUUID(), ignored: false });
                        current = next;
                    }
                }
                else {
                    result.push({ ...current, id: crypto.randomUUID(), ignored: false });
                    current = next;
                }
            }
            result.push({ ...current, id: crypto.randomUUID(), ignored: false });
        };
        processMerge(hInds, true);
        processMerge(vInds, false);
        return result;
    }
    buildGraph(segments, snapPx = 5) {
        const graph = {};
        // Cluster-based node merging : évite les artefacts de bord de cellule du hash-grid.
        // Pour chaque extrémité, recherche un nœud existant à moins de snapPx pixels,
        // ou crée un nouveau nœud. Fusionne correctement les nœuds proches quelle que
        // soit leur position par rapport aux frontières d'une grille.
        const nodeKeys = [];
        const nodePoints = [];
        const findOrCreate = (x, y) => {
            for (let i = 0; i < nodeKeys.length; i++) {
                if (Math.hypot(nodePoints[i].x - x, nodePoints[i].y - y) <= snapPx) {
                    return nodeKeys[i];
                }
            }
            const k = `${Math.round(x)}_${Math.round(y)}_${nodeKeys.length}`;
            nodeKeys.push(k);
            nodePoints.push({ x, y });
            graph[k] = { p: { x, y }, neighbors: [] };
            return k;
        };
        segments.forEach(l => {
            const k1 = findOrCreate(l.x1, l.y1);
            const k2 = findOrCreate(l.x2, l.y2);
            if (k1 === k2)
                return; // segment dégénéré
            if (!graph[k1].neighbors.find(n => n.id === k2))
                graph[k1].neighbors.push({ id: k2, p: graph[k2].p, angle: Math.atan2(l.y2 - l.y1, l.x2 - l.x1) });
            if (!graph[k2].neighbors.find(n => n.id === k1))
                graph[k2].neighbors.push({ id: k1, p: graph[k1].p, angle: Math.atan2(l.y1 - l.y2, l.x1 - l.x2) });
        });
        Object.values(graph).forEach(node => node.neighbors.sort((a, b) => a.angle - b.angle));
        return graph;
    }
    findMinimalCycles(graph) {
        const cycles = [];
        const visited = new Set();
        Object.keys(graph).forEach(startId => {
            const startNode = graph[startId];
            startNode.neighbors.forEach(nb => {
                const edgeKey = `${startId}->${nb.id}`;
                if (visited.has(edgeKey))
                    return;
                const path = [startNode.p];
                let currentId = nb.id;
                let prevId = startId;
                visited.add(edgeKey);
                while (currentId !== startId) {
                    path.push(graph[currentId].p);
                    const cn = graph[currentId];
                    if (!cn)
                        break;
                    const idx = cn.neighbors.findIndex(x => x.id === prevId);
                    const nidx = (idx - 1 + cn.neighbors.length) % cn.neighbors.length;
                    const nn = cn.neighbors[nidx];
                    const nek = `${currentId}->${nn.id}`;
                    if (visited.has(nek))
                        return;
                    visited.add(nek);
                    prevId = currentId;
                    currentId = nn.id;
                    // Limite augmentée à 100 pour supporter les pièces complexes (alcôves, niches)
                    if (path.length > 100)
                        break;
                }
                if (currentId === startId)
                    cycles.push(path);
            });
        });
        return cycles;
    }
    getSignedArea(points) {
        let area = 0;
        for (let i = 0; i < points.length; i++) {
            const j = (i + 1) % points.length;
            area += (points[i].x * points[j].y) - (points[j].x * points[i].y);
        }
        return area / 2;
    }
    getCentroid(points) {
        return {
            x: points.reduce((s, p) => s + p.x, 0) / points.length,
            y: points.reduce((s, p) => s + p.y, 0) / points.length
        };
    }
    /**
     * Test point-dans-polygone (ray casting).
     * Utilisé pour détecter les cycles imbriqués (ex : placard dans une chambre).
     */
    isPointInPolygon(point, polygon) {
        let inside = false;
        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            const xi = polygon[i].x, yi = polygon[i].y;
            const xj = polygon[j].x, yj = polygon[j].y;
            const intersect = ((yi > point.y) !== (yj > point.y))
                && (point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi);
            if (intersect)
                inside = !inside;
        }
        return inside;
    }
    distanceToSegment(p, v, w) {
        const l2 = (v.x - w.x) ** 2 + (v.y - w.y) ** 2;
        if (l2 === 0)
            return Math.hypot(p.x - v.x, p.y - v.y);
        let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
        t = Math.max(0, Math.min(1, t));
        return Math.hypot(p.x - (v.x + t * (w.x - v.x)), p.y - (v.y + t * (w.y - v.y)));
    }
    recalculateRooms(canvas, pixelsPerMeter, showMeasurements) {
        const fabric = window['fabric'];
        const toRemove = canvas.getObjects().filter((o) => ['DetectedRoom', 'WallLabel', 'WallMeasurement', 'PipeMeasurement', 'RoomLabel'].includes(o.myType));
        toRemove.forEach((o) => canvas.remove(o));
        const walls = canvas.getObjects().filter((o) => ['Mur', 'Cloison'].includes(o.myType));
        if (walls.length === 0) {
            return { stats: { roomCount: 0, totalArea: 0, wallCount: 0, wallLength: 0, roomAreas: [] } };
        }
        const segments = walls.map((l) => {
            const ends = this.getAbsoluteLineEnds(l);
            return { x1: ends.p1.x, y1: ends.p1.y, x2: ends.p2.x, y2: ends.p2.y };
        });
        // Snapping des T-jonctions : colle les extrémités proches (≤ 20px) sur la surface
        // du mur le plus proche afin de garantir des jonctions exactes avant la fragmentation.
        this.snapEndpointsToWalls(segments, 20);
        const fragmented = this.splitIntersectingFabricLines(segments);
        // Tolérance proportionnelle à l'échelle : ~0.3m en pixels, bornée entre 5 et 30px
        const snapPx = Math.min(30, Math.max(5, Math.round(pixelsPerMeter * 0.3)));
        const graph = this.buildGraph(fragmented, snapPx);
        const cycles = this.findMinimalCycles(graph);
        // Calcule aire et centroïde pour chaque cycle
        const cycleData = cycles.map(cycle => ({
            cycle,
            area: Math.abs(this.getSignedArea(cycle)),
            centroid: this.getCentroid(cycle),
        }));
        // Tri par aire décroissante (les plus grandes pièces d'abord)
        cycleData.sort((a, b) => b.area - a.area);
        // Pré-calcul des aires (absolue et signée) pour chaque cycle.
        // Aires signées : faces intérieures > 0, face extérieure (infinie) < 0.
        // L'aire signée permet d'exclure la face extérieure sans seuil arbitraire de surface.
        const areasM2 = cycleData.map(item => item.area / (pixelsPerMeter * pixelsPerMeter));
        const signedAreasM2 = cycleData.map(item => this.getSignedArea(item.cycle) / (pixelsPerMeter * pixelsPerMeter));
        // Seules les faces intérieures (aire signée > 0) dans la plage 0.3–5000 m² sont candidates.
        const validMask = cycleData.map((_, i) => signedAreasM2[i] > 0 && areasM2[i] >= 0.3 && areasM2[i] <= 5000);
        // Un cycle est une "enveloppe" (limite extérieure du bâtiment) s'il contient d'autres cycles
        // valides en son sein. Les vraies pièces atomiques ne contiennent pas d'autre pièce valide.
        const isEnvelope = cycleData.map((item, i) => {
            if (!validMask[i])
                return false;
            for (let j = 0; j < cycleData.length; j++) {
                if (j === i || !validMask[j])
                    continue;
                if (this.isPointInPolygon(cycleData[j].centroid, item.cycle))
                    return true;
            }
            return false;
        });
        let totalArea = 0;
        let validRooms = 0;
        const roomAreas = [];
        cycleData.forEach((item, idx) => {
            const areaM2 = areasM2[idx];
            if (!validMask[idx])
                return;
            // Les enveloppes (périmètre global du bâtiment contenant les pièces) ne sont pas comptées
            // comme pièces individuelles pour éviter le double-comptage.
            const isEnv = isEnvelope[idx];
            if (!isEnv) {
                totalArea += areaM2;
                validRooms++;
            }
            roomAreas.push({ areaM2, isNested: isEnv, centroid: item.centroid });
            // Enveloppe : fond translucide neutre ; pièce atomique : couleur pastel
            const color = isEnv
                ? 'rgba(148, 163, 184, 0.08)'
                : this.generateStablePastelColor(item.centroid.x, item.centroid.y);
            if (fabric) {
                const poly = new fabric.Polygon(item.cycle, {
                    fill: color, stroke: 'transparent', strokeWidth: 0,
                    selectable: false, evented: false, objectCaching: false,
                    myType: 'DetectedRoom', originX: 'left', originY: 'top',
                    data: { areaM2, isNested: isEnv, _cx: Math.round(item.centroid.x), _cy: Math.round(item.centroid.y) }
                });
                canvas.add(poly);
                canvas.sendToBack(poly);
                if (showMeasurements && !isEnv) {
                    const label = new fabric.Text(`${areaM2.toFixed(2)} m²`, {
                        left: item.centroid.x, top: item.centroid.y, originX: 'center', originY: 'center',
                        fontSize: 14, fontFamily: 'Arial', fill: '#333',
                        backgroundColor: 'rgba(255,255,255,0.8)',
                        myType: 'WallMeasurement', selectable: false
                    });
                    canvas.add(label);
                }
            }
        });
        if (showMeasurements && fabric) {
            walls.forEach((wall) => {
                const ends = this.getAbsoluteLineEnds(wall);
                const len = Math.hypot(ends.p2.x - ends.p1.x, ends.p2.y - ends.p1.y);
                const lenM = (len / pixelsPerMeter).toFixed(2);
                const mx = (ends.p1.x + ends.p2.x) / 2;
                const my = (ends.p1.y + ends.p2.y) / 2;
                const label = new fabric.Text(`${lenM}m`, {
                    left: mx, top: my - 12, originX: 'center', originY: 'bottom',
                    fontSize: 11, fontFamily: 'Arial', fill: '#555',
                    myType: 'WallLabel', selectable: false
                });
                canvas.add(label);
            });
        }
        if (showMeasurements && fabric) {
            const PIPE_COLORS = {
                PipeAEP: '#2563eb', PipeEU: '#7c3aed', PipeEM: '#a16207', PipeEV: '#78350f',
                PipeVent: '#6b7280', PipeEP: '#22d3ee', PipeGaz: '#f59e0b',
                PipeElec: '#eab308', PipeFibre: '#06b6d4'
            };
            const pipes = canvas.getObjects().filter((o) => Object.keys(PIPE_COLORS).includes(o.myType));
            pipes.forEach((pipe) => {
                const ends = this.getAbsoluteLineEnds(pipe);
                const len = Math.hypot(ends.p2.x - ends.p1.x, ends.p2.y - ends.p1.y);
                const lenM = (len / pixelsPerMeter).toFixed(2);
                const mx = (ends.p1.x + ends.p2.x) / 2;
                const my = (ends.p1.y + ends.p2.y) / 2;
                const color = PIPE_COLORS[pipe.myType] ?? '#555';
                const label = new fabric.Text(`${lenM}m`, {
                    left: mx, top: my - 10, originX: 'center', originY: 'bottom',
                    fontSize: 10, fontFamily: 'Arial', fill: color,
                    backgroundColor: 'rgba(255,255,255,0.85)',
                    myType: 'PipeMeasurement', selectable: false
                });
                canvas.add(label);
            });
        }
        const wallLengthTotal = walls.reduce((sum, wall) => {
            const ends = this.getAbsoluteLineEnds(wall);
            return sum + Math.hypot(ends.p2.x - ends.p1.x, ends.p2.y - ends.p1.y);
        }, 0);
        // Linéaires par type de réseau
        const PIPE_TYPES = [
            'PipeAEP', 'PipeEU', 'PipeEM', 'PipeEV', 'PipeVent',
            'PipeEP', 'PipeGaz', 'PipeElec', 'PipeFibre',
        ];
        const pipeLengths = {};
        const pipes = canvas.getObjects().filter((o) => PIPE_TYPES.includes(o.myType));
        pipes.forEach((pipe) => {
            const ends = this.getAbsoluteLineEnds(pipe);
            const lenM = Math.hypot(ends.p2.x - ends.p1.x, ends.p2.y - ends.p1.y) / pixelsPerMeter;
            pipeLengths[pipe.myType] = parseFloat(((pipeLengths[pipe.myType] ?? 0) + lenM).toFixed(2));
        });
        return {
            stats: {
                roomCount: validRooms,
                totalArea: parseFloat(totalArea.toFixed(2)),
                wallCount: walls.length,
                wallLength: parseFloat((wallLengthTotal / pixelsPerMeter).toFixed(1)),
                roomAreas,
                pipeLengths: Object.keys(pipeLengths).length > 0 ? pipeLengths : undefined,
            }
        };
    }
    getAbsoluteLineEnds(line) {
        // Lecture directe des coordonnées absolues (même approche que fabric-canvas.service).
        // line.x1/y1/x2/y2 = coords de construction ; line.left/top = coin sup-gauche de la bbox.
        // Après un drag Fabric natif, line.left ≠ min(x1,x2) : l'offset capture le déplacement.
        const dx = (line.left ?? 0) - Math.min(line.x1 ?? 0, line.x2 ?? 0);
        const dy = (line.top ?? 0) - Math.min(line.y1 ?? 0, line.y2 ?? 0);
        return {
            p1: { x: (line.x1 ?? 0) + dx, y: (line.y1 ?? 0) + dy },
            p2: { x: (line.x2 ?? 0) + dx, y: (line.y2 ?? 0) + dy },
        };
    }
    /**
     * Pour chaque extrémité de segment qui se trouve à moins de `snapDist` px de l'intérieur
     * d'un autre segment, déplace cette extrémité sur la surface du mur (snap exact).
     * Garantit des T-jonctions précises avant la fragmentation, même si les murs sont légèrement
     * désalignés (tracé manuel, croquis).
     */
    snapEndpointsToWalls(segments, snapDist) {
        for (const s of segments) {
            for (const wall of segments) {
                if (wall === s)
                    continue;
                const wLen2 = (wall.x2 - wall.x1) ** 2 + (wall.y2 - wall.y1) ** 2;
                if (wLen2 < 1)
                    continue;
                // Test chaque extrémité de s contre l'intérieur de wall
                for (const side of ['1', '2']) {
                    const ex = side === '1' ? s.x1 : s.x2;
                    const ey = side === '1' ? s.y1 : s.y2;
                    const t = ((ex - wall.x1) * (wall.x2 - wall.x1) + (ey - wall.y1) * (wall.y2 - wall.y1)) / wLen2;
                    if (t < 0.02 || t > 0.98)
                        continue; // seulement l'intérieur du mur
                    const nearX = wall.x1 + (wall.x2 - wall.x1) * t;
                    const nearY = wall.y1 + (wall.y2 - wall.y1) * t;
                    if (Math.hypot(ex - nearX, ey - nearY) <= snapDist) {
                        if (side === '1') {
                            s.x1 = nearX;
                            s.y1 = nearY;
                        }
                        else {
                            s.x2 = nearX;
                            s.y2 = nearY;
                        }
                    }
                }
            }
        }
    }
    splitIntersectingFabricLines(segments) {
        const result = [];
        segments.forEach(s => {
            const cuts = [{ t: 0 }, { t: 1 }];
            segments.forEach(other => {
                if (s === other)
                    return;
                const pt = this.lineIntersect(s, other);
                if (pt && this.pointOnSegment(pt.x, pt.y, s)) {
                    const t = Math.hypot(pt.x - s.x1, pt.y - s.y1) / Math.hypot(s.x2 - s.x1, s.y2 - s.y1);
                    cuts.push({ t });
                }
            });
            cuts.sort((a, b) => a.t - b.t);
            const unique = [cuts[0]];
            for (let i = 1; i < cuts.length; i++) {
                if (cuts[i].t - unique[unique.length - 1].t > 0.001)
                    unique.push(cuts[i]);
            }
            for (let i = 0; i < unique.length - 1; i++) {
                result.push({
                    x1: s.x1 + (s.x2 - s.x1) * unique[i].t,
                    y1: s.y1 + (s.y2 - s.y1) * unique[i].t,
                    x2: s.x1 + (s.x2 - s.x1) * unique[i + 1].t,
                    y2: s.y1 + (s.y2 - s.y1) * unique[i + 1].t
                });
            }
        });
        return result;
    }
    lineIntersect(a, b) {
        const d1x = a.x2 - a.x1, d1y = a.y2 - a.y1;
        const d2x = b.x2 - b.x1, d2y = b.y2 - b.y1;
        const cross = d1x * d2y - d1y * d2x;
        if (Math.abs(cross) < 1e-10)
            return null;
        const t = ((b.x1 - a.x1) * d2y - (b.y1 - a.y1) * d2x) / cross;
        const u = ((b.x1 - a.x1) * d1y - (b.y1 - a.y1) * d1x) / cross;
        // Petite tolérance flottante pour les T-jonctions exactes (u = ±1e-15)
        const eps = 1e-9;
        if (t < -eps || t > 1 + eps || u < -eps || u > 1 + eps)
            return null;
        return { x: a.x1 + t * d1x, y: a.y1 + t * d1y };
    }
    /**
     * Vérifie qu'un point est à l'intérieur d'un segment (hors extrémités).
     * Utilise la distance perpendiculaire normalisée par la longueur du segment
     * pour être robuste sur les murs diagonaux (contrairement à un EPS absolu).
     */
    pointOnSegment(px, py, s) {
        const dx = s.x2 - s.x1, dy = s.y2 - s.y1;
        const len2 = dx * dx + dy * dy;
        if (len2 < 1e-10)
            return false;
        // Paramètre de projection [0..1]
        const t = ((px - s.x1) * dx + (py - s.y1) * dy) / len2;
        // Exclure les extrémités (tolérance 2px / longueur)
        const endEps = 2 / Math.sqrt(len2);
        if (t < endEps || t > 1 - endEps)
            return false;
        // Distance perpendiculaire (en pixels) doit être < 2px
        const cross = (py - s.y1) * dx - (px - s.x1) * dy;
        return (cross * cross) / len2 < 4; // 4 = 2² px²
    }
    generateStablePastelColor(x, y) {
        const seed = Math.round(x) * Math.round(y) + Math.round(x);
        return `hsla(${(seed * 137.508) % 360}, 70%, 85%, 0.25)`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: GeometryService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: GeometryService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: GeometryService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class WallDetectionService {
    opencvSvc = inject(OpenCvService);
    geometrySvc = inject(GeometryService);
    detect(srcCanvas, binCanvas, params) {
        const cv = this.opencvSvc.cv;
        let src = cv.imread(srcCanvas);
        let mat = new cv.Mat();
        let tmp = new cv.Mat();
        const k = cv.Mat.ones(1, 1, cv.CV_8U);
        const lines = new cv.Mat();
        try {
            cv.cvtColor(src, mat, cv.COLOR_RGBA2GRAY);
            cv.bilateralFilter(mat, tmp, 9, 75, 75);
            mat.delete();
            mat = tmp;
            let bs = params.threshold;
            if (bs % 2 === 0)
                bs++;
            cv.adaptiveThreshold(mat, mat, 255, cv.ADAPTIVE_THRESH_GAUSSIAN_C, cv.THRESH_BINARY_INV, bs, 2);
            cv.morphologyEx(mat, mat, cv.MORPH_OPEN, k);
            cv.imshow(binCanvas, mat);
            cv.HoughLinesP(mat, lines, 1, Math.PI / 180, 50, params.minLineLength, params.maxLineGap);
            const rawSegments = [];
            for (let i = 0; i < lines.rows; ++i) {
                const x1 = lines.data32S[i * 4], y1 = lines.data32S[i * 4 + 1];
                const x2 = lines.data32S[i * 4 + 2], y2 = lines.data32S[i * 4 + 3];
                const dx = Math.abs(x2 - x1), dy = Math.abs(y2 - y1);
                const len = Math.hypot(dx, dy);
                if (len < params.minLineLength)
                    continue;
                if (dx > dy * 3) {
                    rawSegments.push({ x1: Math.min(x1, x2), y1, x2: Math.max(x1, x2), y2: y1, type: 'H' });
                }
                else if (dy > dx * 3) {
                    rawSegments.push({ x1, y1: Math.min(y1, y2), x2: x1, y2: Math.max(y1, y2), type: 'V' });
                }
            }
            let walls = this.geometrySvc.performClustering(rawSegments, params.clusterDistance);
            walls = this.geometrySvc.extendToIntersections(walls, params.extensionDistance);
            walls = this.geometrySvc.snapCorners(walls, 30);
            walls = this.geometrySvc.fragmentWalls(walls);
            return { walls, imageWidth: srcCanvas.width, imageHeight: srcCanvas.height, params, timestamp: new Date() };
        }
        finally {
            src.delete();
            mat.delete();
            k.delete();
            lines.delete();
        }
    }
    async detectAsync(srcCanvas, binCanvas, params) {
        // TODO: Déléguer à un Web Worker quand disponible
        return this.detect(srcCanvas, binCanvas, params);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: WallDetectionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: WallDetectionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: WallDetectionService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class HistoryService {
    canvas;
    history = [];
    step = -1;
    isRestoring = false;
    savePaused = false;
    _step = signal(-1);
    _historyLength = signal(0);
    canUndo = computed(() => this._step() > 0);
    canRedo = computed(() => this._step() < this._historyLength() - 1);
    init(canvas) {
        this.canvas = canvas;
        this.canvas.on('object:added', () => { if (!this.isRestoring && !this.savePaused)
            this.save(); });
        this.canvas.on('object:removed', () => { if (!this.isRestoring && !this.savePaused)
            this.save(); });
        this.canvas.on('object:modified', () => { if (!this.isRestoring && !this.savePaused)
            this.save(); });
        this.save();
    }
    /** Bloque temporairement les sauvegardes automatiques (undo/redo + recalcul). */
    pauseSaving() { this.savePaused = true; }
    resumeSaving() { this.savePaused = false; }
    save() {
        if (this.isRestoring || this.savePaused)
            return;
        const json = JSON.stringify(this.canvas.toJSON(['myType', 'data', 'roomName', 'isPrimary']));
        this.history = this.history.slice(0, this.step + 1);
        this.history.push(json);
        if (this.history.length > 50)
            this.history.shift();
        else
            this.step++;
        this._step.set(this.step);
        this._historyLength.set(this.history.length);
    }
    undo() {
        if (this.step <= 0)
            return Promise.resolve();
        this.step--;
        this._step.set(this.step);
        return this.restore(this.history[this.step]);
    }
    redo() {
        if (this.step >= this.history.length - 1)
            return Promise.resolve();
        this.step++;
        this._step.set(this.step);
        return this.restore(this.history[this.step]);
    }
    restore(json) {
        this.isRestoring = true;
        return new Promise(resolve => {
            this.canvas.loadFromJSON(json, () => {
                this.isRestoring = false;
                this.canvas.renderAll();
                resolve();
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: HistoryService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: HistoryService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: HistoryService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Types d'objets Fabric.js persistés lors de la sauvegarde */
const FABRIC_SAVED_TYPES = [
    'Mur', 'Cloison',
    'PipeAEP', 'PipeEU', 'PipeEM', 'PipeEV', 'PipeVent', 'PipeEP', 'PipeGaz', 'PipeElec', 'PipeFibre',
    'Door', 'Window',
    'Stair', 'RoomBox', 'Equipment', 'SpancPictogram', 'AcPictogram', 'HazardZone', 'HazardSample', 'NorthArrow',
    'PTag', 'ETag', 'STag', 'WallLabel', 'WallMeasurement',
    'PipeMeasurement', 'RoomLabel', 'Backdrop', 'DetectedRoom'
];
const ALL = ['diag', 'aep', 'eu', 'spanc', 'ac', 'vrd'];
/** Groupes d'outils de la barre d'outils de l'éditeur */
const TOOL_GROUPS = [
    {
        label: 'Structure',
        modes: ALL,
        tools: [
            { mode: 'select', icon: '↖', label: 'Sélection', shortcut: 'V' },
            { mode: 'pan', icon: '✋', label: 'Déplacer la vue', shortcut: 'H' },
            { mode: 'node-edit', icon: '◎', label: 'Nœuds', shortcut: 'N' },
            { mode: 'wall', icon: '▬', label: 'Mur porteur', shortcut: 'W' },
            { mode: 'cloison', icon: '╌', label: 'Cloison', shortcut: 'C' },
            { mode: 'room', icon: '⬜', label: 'Pièce rect.', shortcut: 'R' },
            { mode: 'room-sketch', icon: '⊡', label: 'Croquis pièces', shortcut: 'K' },
            { mode: 'stair', icon: '↕', label: 'Escalier' },
        ]
    },
    {
        label: 'Ouvertures',
        modes: ['diag'],
        tools: [
            { mode: 'door', icon: '🚪', label: 'Porte', shortcut: 'D' },
            { mode: 'window', icon: '🪟', label: 'Fenêtre', shortcut: 'F' },
        ]
    },
    {
        label: 'Réseaux',
        tools: [
            { mode: 'pipe-aep', icon: '💧', label: 'AEP', borderColor: '#3b82f6', modes: ['aep', 'vrd'] },
            { mode: 'pipe-eu', icon: '🟣', label: 'Eaux usées', borderColor: '#8b5cf6', modes: ['eu', 'spanc', 'ac', 'vrd'] },
            { mode: 'pipe-em', icon: '🟤', label: 'Eaux ménagères', borderColor: '#a16207', modes: ['spanc', 'ac'] },
            { mode: 'pipe-ev', icon: '⬛', label: 'Eaux vannes', borderColor: '#78350f', modes: ['spanc', 'ac'] },
            { mode: 'pipe-ep', icon: '🌧', label: 'EP', borderColor: '#22d3ee', modes: ['eu', 'spanc', 'ac', 'vrd'] },
            { mode: 'pipe-vent', icon: '↥', label: 'Ventilation', borderColor: '#6b7280', modes: ['spanc', 'ac'] },
            { mode: 'pipe-gaz', icon: '🟡', label: 'Gaz', borderColor: '#f59e0b', modes: ['vrd'] },
            { mode: 'pipe-elec', icon: '⚡', label: 'Élec', borderColor: '#eab308', modes: ['vrd'] },
            { mode: 'pipe-fibre', icon: '🔶', label: 'Fibre', borderColor: '#06b6d4', modes: ['vrd'] },
        ]
    },
    {
        label: 'Équipements techniques',
        modes: ['diag'],
        tools: [
            { mode: 'equip-elec', icon: '⚡', label: 'Tableau électrique' },
            { mode: 'equip-boiler', icon: '🔥', label: 'Chaudière / PAC' },
            { mode: 'equip-vmc', icon: '💨', label: 'VMC' },
            { mode: 'equip-daaf', icon: '🔔', label: 'DAAF' },
            { mode: 'equip-gas', icon: '⛽', label: 'Compteur gaz' },
            { mode: 'equip-hwt', icon: '♨', label: 'Cumulus / ECS' },
        ]
    },
    {
        label: 'Repérage diagnostic',
        modes: ['diag'],
        tools: [
            { mode: 'hazard-amiante', icon: '⚠', label: 'Zone amiante', borderColor: '#f59e0b' },
            { mode: 'hazard-plomb', icon: '⚠', label: 'Zone plomb', borderColor: '#ef4444' },
            { mode: 'hazard-humidite', icon: '💦', label: 'Zone humidité', borderColor: '#3b82f6' },
            { mode: 'prelevement', icon: '⊕', label: 'Prélèvement amiante', borderColor: '#d97706' },
            { mode: 'north-arrow', icon: '↑', label: 'Flèche Nord' },
        ]
    },
    {
        label: 'Points SPANC',
        modes: ['spanc'],
        tools: [
            { mode: 'tag-eau', icon: '🔵', label: 'Eau (E..)' },
            { mode: 'tag-spanc', icon: '⬤', label: 'SPANC (S..)' },
        ]
    },
    {
        label: 'Schéma SPANC — Prétraitement',
        modes: ['spanc'],
        tools: [
            { mode: 'spanc-bac-graisses', icon: '▭', label: 'Bac à graisses' },
            { mode: 'spanc-fosse-septique', icon: '▭', label: 'Fosse septique' },
            { mode: 'spanc-fosse-toutes-eaux', icon: '▭', label: 'Fosse toutes eaux' },
            { mode: 'spanc-fosse-toutes-eaux-prefiltre', icon: '▭', label: 'Fosse + préfiltre' },
            { mode: 'spanc-prefiltre', icon: '▭', label: 'Préfiltre séparé' },
            { mode: 'spanc-fosse-etanche', icon: '▭', label: 'Fosse étanche' },
        ]
    },
    {
        label: 'Schéma SPANC — Traitement',
        modes: ['spanc'],
        tools: [
            { mode: 'spanc-tranchees-epandage', icon: '☷', label: 'Tranchées d\'épandage' },
            { mode: 'spanc-filtre-sable', icon: '▦', label: 'Filtre à sable' },
            { mode: 'spanc-filtre-compact', icon: '▦', label: 'Filtre compact' },
            { mode: 'spanc-microstation', icon: '▣', label: 'Micro-station' },
            { mode: 'spanc-filtre-plante', icon: '🌿', label: 'Filtre planté' },
            { mode: 'spanc-toilettes-seches', icon: '🚽', label: 'Toilettes sèches' },
            { mode: 'spanc-compost', icon: '♺', label: 'Compost' },
            { mode: 'spanc-lit-epandage', icon: '☵', label: 'Lit d\'épandage' },
        ]
    },
    {
        label: 'Schéma SPANC — Rejet',
        modes: ['spanc'],
        tools: [
            { mode: 'spanc-puits-infiltration', icon: '◯', label: 'Puits d\'infiltration' },
            { mode: 'spanc-puits-perdu', icon: '◉', label: 'Puits perdu' },
            { mode: 'spanc-evacuation', icon: '➤', label: 'Évacuation' },
            { mode: 'spanc-tranchee-infiltration', icon: '☷', label: 'Tranchée d\'infiltration' },
        ]
    },
    {
        label: 'Schéma SPANC — Regards',
        modes: ['spanc'],
        tools: [
            { mode: 'spanc-regard', icon: '◻', label: 'Regard' },
            { mode: 'spanc-pompe-relevage', icon: '◍', label: 'Pompe de relevage' },
        ]
    },
    {
        label: 'Schéma SPANC — Ventilation',
        modes: ['spanc'],
        tools: [
            { mode: 'spanc-ventilation-secondaire', icon: '↥', label: 'Ventilation secondaire' },
        ]
    },
    {
        label: 'AC — Regards',
        modes: ['ac'],
        tools: [
            { mode: 'ac-regard-eu', icon: '⬤', label: 'Regard EU', borderColor: '#7c3aed' },
            { mode: 'ac-regard-em', icon: '⬤', label: 'Regard EM', borderColor: '#a16207' },
            { mode: 'ac-regard-ev', icon: '⬤', label: 'Regard EV', borderColor: '#78350f' },
            { mode: 'ac-regard-ep', icon: '⬤', label: 'Regard EP', borderColor: '#22d3ee' },
        ]
    },
    {
        label: 'AC — Repères réseau',
        modes: ['ac'],
        tools: [
            { mode: 'ac-noeud', icon: '➤', label: 'Nœud / branchement' },
            { mode: 'ac-pied', icon: '▢', label: 'Pied de descente' },
            { mode: 'ac-boite-branchement', icon: '⬛', label: 'Boîte de branchement' },
        ]
    },
    {
        label: 'AC — Étiquettes type d\'eau',
        modes: ['ac'],
        tools: [
            { mode: 'ac-label-eu', icon: '🏷', label: 'Étiquette EU', borderColor: '#7c3aed' },
            { mode: 'ac-label-em', icon: '🏷', label: 'Étiquette EM', borderColor: '#a16207' },
            { mode: 'ac-label-ev', icon: '🏷', label: 'Étiquette EV', borderColor: '#78350f' },
            { mode: 'ac-label-ep', icon: '🏷', label: 'Étiquette EP', borderColor: '#22d3ee' },
        ]
    },
    {
        label: 'Annotations',
        modes: ALL,
        tools: [
            { mode: 'draw-red', icon: '🔴', label: 'Stylo rouge' },
            { mode: 'draw-blue', icon: '🔵', label: 'Stylo bleu' },
        ]
    }
];

/**
 * Légende des éléments dessinés — intégrée aux exports image (PNG/JPEG).
 *
 * Principe : la couleur de chaque entrée est **dérivée de l'objet Fabric
 * réellement dessiné** (`stroke`/`fill`, en descendant dans les groupes), de
 * sorte que la légende reprenne toujours exactement les couleurs du plan — y
 * compris pour les repères color-codés par type d'eau (AC : EU violet, EP
 * cyan…). Les couleurs ci-dessous ne servent que de repli quand l'objet ne
 * porte pas de couleur exploitable (ex. forme sérialisée sans enfants).
 *
 * Les types non « physiques » (labels, mesures, nœuds, fond de carte, repères
 * de cote) ne sont pas mappés et sont donc ignorés par `collectLegendItems`.
 */
/** Mapping direct `myType` → libellé/forme + couleur de **repli**. */
const STATIC_LEGEND = {
    Mur: { label: 'Mur porteur', color: '#18181b', swatch: 'line' },
    Cloison: { label: 'Cloison', color: '#52525b', swatch: 'dashed' },
    PipeAEP: { label: 'AEP — eau potable', color: '#2563eb', swatch: 'line' },
    PipeEU: { label: 'Eaux usées', color: '#7c3aed', swatch: 'line' },
    PipeEM: { label: 'Eaux ménagères', color: '#a16207', swatch: 'line' },
    PipeEV: { label: 'Eaux vannes', color: '#78350f', swatch: 'line' },
    PipeEP: { label: 'Eaux pluviales', color: '#22d3ee', swatch: 'dashed' },
    PipeVent: { label: 'Ventilation', color: '#6b7280', swatch: 'dashed' },
    PipeGaz: { label: 'Gaz', color: '#f59e0b', swatch: 'dashed' },
    PipeElec: { label: 'Électricité', color: '#eab308', swatch: 'dashed' },
    PipeFibre: { label: 'Fibre', color: '#06b6d4', swatch: 'dashed' },
    Door: { label: 'Porte', color: '#d97706', swatch: 'box' },
    Window: { label: 'Fenêtre', color: '#0284c7', swatch: 'box' },
    Stair: { label: 'Escalier', color: '#374151', swatch: 'box' },
    RoomBox: { label: 'Pièce', color: '#3b82f6', swatch: 'box' },
    NorthArrow: { label: 'Nord', color: '#18181b', swatch: 'marker' },
};
/** Zones de risque — libellé par `data.hazardType` (couleur dérivée du tracé). */
const HAZARD_LEGEND = {
    amiante: { label: 'Zone amiante', color: '#f59e0b', swatch: 'box' },
    plomb: { label: 'Zone plomb', color: '#ef4444', swatch: 'box' },
    humidite: { label: 'Zone humidité', color: '#3b82f6', swatch: 'box' },
};
/** Équipements techniques — libellé par `data.subtype` (couleur dérivée du tracé). */
const EQUIPMENT_LEGEND = {
    'elec-panel': { label: 'Tableau élec.', color: '#d97706', swatch: 'marker' },
    'boiler': { label: 'Chaudière', color: '#ea580c', swatch: 'marker' },
    'vmc': { label: 'VMC', color: '#0284c7', swatch: 'marker' },
    'daaf': { label: 'DAAF', color: '#dc2626', swatch: 'marker' },
    'gas-meter': { label: 'Compteur gaz', color: '#16a34a', swatch: 'marker' },
    'water-heater': { label: 'Cumulus / ECS', color: '#ea580c', swatch: 'marker' },
};
/** Couleur de tracé des pictogrammes SPANC (contour sombre, non color-codés). */
const SPANC_OUTLINE = '#1f2937';
/** Ordre d'affichage des entrées (par `myType`/famille). Les clés absentes
 *  passent en fin de liste. */
const LEGEND_ORDER = [
    'Mur', 'Cloison', 'RoomBox', 'Door', 'Window', 'Stair',
    'PipeAEP', 'PipeEU', 'PipeEM', 'PipeEV', 'PipeEP', 'PipeVent', 'PipeGaz', 'PipeElec', 'PipeFibre',
    'Equipment', 'HazardZone', 'HazardSample', 'SpancPictogram', 'AcPictogram', 'NorthArrow',
];
function orderIndex(myType) {
    const i = LEGEND_ORDER.indexOf(myType);
    return i === -1 ? LEGEND_ORDER.length : i;
}
function parseColor(c) {
    if (typeof c !== 'string')
        return null;
    const s = c.trim();
    let m = /^#([0-9a-f]{3})$/i.exec(s);
    if (m) {
        const h = m[1];
        return { r: parseInt(h[0] + h[0], 16), g: parseInt(h[1] + h[1], 16), b: parseInt(h[2] + h[2], 16), a: 1 };
    }
    m = /^#([0-9a-f]{6})$/i.exec(s);
    if (m) {
        const n = parseInt(m[1], 16);
        return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255, a: 1 };
    }
    m = /^rgba?\(([^)]+)\)$/i.exec(s);
    if (m) {
        const p = m[1].split(',').map(x => parseFloat(x.trim()));
        if (p.length < 3 || p.some(isNaN))
            return null;
        return { r: p[0], g: p[1], b: p[2], a: p[3] === undefined ? 1 : p[3] };
    }
    return null; // couleurs nommées non gérées → repli
}
function toHex({ r, g, b }) {
    const h = (1 << 24) | (Math.round(r) << 16) | (Math.round(g) << 8) | Math.round(b);
    return '#' + h.toString(16).slice(1);
}
/** Score « identifiant » d'une couleur : pénalise blanc/transparent et les gris
 *  neutres (contours, textes), favorise les teintes vives (réseaux color-codés). */
function colorScore(p) {
    if (!p || p.a === 0)
        return -1;
    const r = p.r / 255, g = p.g / 255, b = p.b / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2, chroma = max - min;
    if (l > 0.93)
        return 0.1; // quasi blanc (remplissages, textes)
    if (chroma < 0.12)
        return 0.35; // gris / noir neutre (contours, murs)
    return 1 + chroma; // teinte vive
}
/** Couleur la plus représentative d'un objet (descend dans les groupes Fabric,
 *  vivants `_objects` ou sérialisés `objects`). `stroke` est légèrement
 *  privilégié à `fill` (le contour porte la couleur d'identité). */
function dominantColor(obj) {
    let best = null;
    let bestScore = 0;
    const consider = (c, bias) => {
        const p = parseColor(c);
        const s = colorScore(p) + (p ? bias : 0);
        if (p && s > bestScore) {
            bestScore = s;
            best = p;
        }
    };
    const walk = (o) => {
        if (!o || typeof o !== 'object')
            return;
        consider(o.stroke, 0.05);
        consider(o.fill, 0);
        const kids = o._objects ?? o.objects;
        if (Array.isArray(kids))
            kids.forEach(walk);
    };
    walk(obj);
    return best ? toHex(best) : null;
}
/**
 * Construit la liste dédoublonnée des entrées de légende à partir des objets
 * Fabric (vivants ou sérialisés). La couleur est dérivée de l'objet dessiné
 * (cf. `dominantColor`) et retombe sur la couleur de repli si indisponible.
 * L'ordre suit `LEGEND_ORDER`, puis le libellé.
 */
function collectLegendItems(objects) {
    const found = new Map();
    for (const o of objects ?? []) {
        const type = o?.myType;
        if (!type)
            continue;
        let base = null;
        let key = type;
        let extractColor = true;
        if (STATIC_LEGEND[type]) {
            base = STATIC_LEGEND[type];
        }
        else if (type === 'HazardZone') {
            base = HAZARD_LEGEND[o?.data?.hazardType];
            key = `haz-${o?.data?.hazardType}`;
        }
        else if (type === 'Equipment') {
            base = EQUIPMENT_LEGEND[o?.data?.subtype];
            key = `eq-${o?.data?.subtype}`;
        }
        else if (type === 'HazardSample') {
            base = { label: 'Prélèvement', color: '#f59e0b', swatch: 'marker' };
            key = 'sample';
        }
        else if (type === 'AcPictogram') {
            const label = o?.data?.label || 'Ouvrage AC';
            base = { label, color: '#0891b2', swatch: 'marker' };
            key = `ac-${label}`;
        }
        else if (type === 'SpancPictogram') {
            // Pictogrammes SPANC : dessinés en contour sombre, non color-codés →
            // couleur fixe (le contour), pas d'extraction des accents internes.
            const label = o?.data?.label || 'Dispositif SPANC';
            base = { label, color: SPANC_OUTLINE, swatch: 'marker' };
            key = `spanc-${label}`;
            extractColor = false;
        }
        if (!base)
            continue;
        const color = (extractColor && dominantColor(o)) || base.color;
        if (!found.has(key))
            found.set(key, { item: { key, label: base.label, color, swatch: base.swatch, ref: o }, type });
    }
    return [...found.values()]
        .sort((a, b) => orderIndex(a.type) - orderIndex(b.type) || a.item.label.localeCompare(b.item.label))
        .map(e => e.item);
}

/**
 * Disclaimer légal affiché sur tout export de surface.
 * La surface calculée est brute (axe des murs, sans gestion HSP) — pas une surface Carrez/Boutin.
 */
const SURFACE_DISCLAIMER = 'Surface brute calculée à partir de l\'axe des murs. ' +
    'Ne constitue pas une mesure Carrez (décret 97-532) ou Boutin (loi 89-462). ' +
    'La hauteur sous plafond n\'est pas prise en compte.';
class ExportService {
    toProject(canvas, pixelsPerMeter) {
        const json = canvas.toJSON(['myType', 'data', 'roomName', 'isPrimary']);
        const filteredObjects = json.objects.filter(o => FABRIC_SAVED_TYPES.includes(o.myType));
        return {
            version: '5.3.0',
            pixelsPerMeter,
            objects: filteredObjects,
            meta: { createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
        };
    }
    fromFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const project = JSON.parse(e.target.result);
                    if (!project.version || !Array.isArray(project.objects)) {
                        reject(new Error('Format de projet invalide'));
                        return;
                    }
                    if (project.version !== '5.3.0') {
                        console.warn(`[G-Plan] Version de projet ${project.version} différente de 5.3.0 — compatibilité non garantie.`);
                    }
                    resolve(project);
                }
                catch {
                    reject(new Error('Fichier JSON invalide'));
                }
            };
            reader.readAsText(file);
        });
    }
    /** Export JPEG — qualité 90%, multiplicateur x2 pour l'impression.
     *  Le JPEG ne gère pas la transparence : on force un fond blanc le temps de
     *  l'export (sinon les zones transparentes du canvas ressortent en noir),
     *  puis on restaure l'état précédent. */
    toJpg(canvas) {
        const prevBg = canvas.backgroundColor;
        if (!prevBg || prevBg === 'transparent') {
            canvas.backgroundColor = '#ffffff';
            canvas.renderAll();
        }
        const dataUrl = canvas.toDataURL({ format: 'jpeg', quality: 0.9, multiplier: 2 });
        if (canvas.backgroundColor !== prevBg) {
            canvas.backgroundColor = prevBg;
            canvas.renderAll();
        }
        return this.dataUrlToBlob(dataUrl);
    }
    /** Export PNG haute résolution (300 dpi équivalent, multiplicateur x3) */
    toPng(canvas, multiplier = 3) {
        const dataUrl = canvas.toDataURL({ format: 'png', multiplier });
        return this.dataUrlToBlob(dataUrl);
    }
    toSvg(canvas) {
        return canvas.toSVG();
    }
    // ── EXPORTS IMAGE AVEC LÉGENDE ──────────────────────────────────────────────
    // Le plan est rendu via Fabric (toDataURL), puis recomposé sur un canvas natif
    // 2D avec un panneau « Légende » des éléments réellement présents. Asynchrone
    // car le rendu de l'image source passe par `HTMLImageElement.onload`.
    /** JPEG (qualité 90%, x2) avec légende automatique des éléments dessinés. */
    async toJpgWithLegend(canvas, multiplier = 2) {
        const items = collectLegendItems(canvas.getObjects());
        const planUrl = this.planDataUrl(canvas, 'jpeg', multiplier);
        return this.composeWithLegend(planUrl, items, 'image/jpeg', 0.9);
    }
    /** PNG haute résolution (x3) avec légende automatique des éléments dessinés. */
    async toPngWithLegend(canvas, multiplier = 3) {
        const items = collectLegendItems(canvas.getObjects());
        const planUrl = this.planDataUrl(canvas, 'png', multiplier);
        return this.composeWithLegend(planUrl, items, 'image/png');
    }
    async downloadJpgWithLegend(canvas, filename = 'plan.jpg', multiplier = 2) {
        const blob = await this.toJpgWithLegend(canvas, multiplier);
        this.triggerDownload(blob, filename);
        return blob;
    }
    async downloadPngWithLegend(canvas, filename = 'plan.png', multiplier = 3) {
        const blob = await this.toPngWithLegend(canvas, multiplier);
        this.triggerDownload(blob, filename);
        return blob;
    }
    /** Rend le plan en dataURL. Le JPEG ne gère pas la transparence : on force un
     *  fond blanc le temps de l'export puis on restaure l'état précédent. */
    planDataUrl(canvas, format, multiplier) {
        if (format === 'png') {
            return canvas.toDataURL({ format: 'png', multiplier });
        }
        const prevBg = canvas.backgroundColor;
        const needsBg = !prevBg || prevBg === 'transparent';
        if (needsBg) {
            canvas.backgroundColor = '#ffffff';
            canvas.renderAll();
        }
        const dataUrl = canvas.toDataURL({ format: 'jpeg', quality: 0.9, multiplier });
        if (needsBg) {
            canvas.backgroundColor = prevBg;
            canvas.renderAll();
        }
        return dataUrl;
    }
    /**
     * Recompose l'image du plan avec un panneau de légende. Placement automatique :
     * à droite si l'image est en paysage, en bas si elle est en portrait.
     * S'il n'y a aucun élément à légender, renvoie l'image telle quelle.
     */
    async composeWithLegend(planDataUrl, items, mime, quality) {
        const img = await this.loadImage(planDataUrl);
        const W = img.naturalWidth, H = img.naturalHeight;
        if (items.length === 0) {
            return this.dataUrlToBlob(planDataUrl);
        }
        // Unité d'échelle relative à la taille de l'image exportée (déjà × multiplier),
        // pour que la légende reste lisible quelle que soit la résolution.
        const u = Math.max(1, Math.min(W, H) / 1000);
        const font = Math.round(15 * u);
        const titleFont = Math.round(17 * u);
        const rowH = Math.round(28 * u);
        const pad = Math.round(18 * u);
        const swatchW = Math.round(34 * u);
        const gap = Math.round(12 * u);
        // Mesure du libellé le plus long pour dimensionner les colonnes.
        const meas = document.createElement('canvas').getContext('2d');
        meas.font = `${font}px Arial, sans-serif`;
        const maxLabelW = items.reduce((m, it) => Math.max(m, meas.measureText(it.label).width), 0);
        const colW = pad + swatchW + gap + Math.ceil(maxLabelW) + pad;
        const titleH = Math.round(titleFont * 1.6);
        const side = W >= H ? 'right' : 'bottom';
        let canvasW, canvasH, panelX, panelY, panelW, panelH, cols;
        if (side === 'right') {
            // Empilement vertical, multi-colonnes si la hauteur disponible est dépassée.
            const usableH = H - titleH - pad * 2;
            const perCol = Math.max(1, Math.floor(usableH / rowH));
            cols = Math.max(1, Math.ceil(items.length / perCol));
            panelW = colW * cols;
            canvasW = W + panelW;
            canvasH = H;
            panelX = W;
            panelY = 0;
            panelH = H;
        }
        else {
            // Bande horizontale sous le plan : autant de colonnes que la largeur permet.
            cols = Math.max(1, Math.min(items.length, Math.floor((W - pad) / colW)));
            const rows = Math.ceil(items.length / cols);
            panelH = titleH + pad * 2 + rows * rowH;
            panelW = W;
            canvasW = W;
            canvasH = H + panelH;
            panelX = 0;
            panelY = H;
        }
        const out = document.createElement('canvas');
        out.width = canvasW;
        out.height = canvasH;
        const ctx = out.getContext('2d');
        // Fond blanc global puis plan. La zone légende reste sur ce blanc franc —
        // sans cadre, sans trait, sans fondu : bande blanche nette et lisible.
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvasW, canvasH);
        ctx.drawImage(img, 0, 0, W, H);
        // Titre.
        ctx.fillStyle = '#0f172a';
        ctx.textBaseline = 'middle';
        ctx.font = `bold ${titleFont}px Arial, sans-serif`;
        ctx.fillText('Légende', panelX + pad, panelY + pad + titleFont * 0.6);
        // Vignettes des symboles ponctuels (regards, labels, équipements…) :
        // rendues depuis le vrai objet Fabric pour reproduire le pictogramme dessiné.
        const thumbs = await this.renderSymbolThumbnails(items);
        // Items, colonne par colonne.
        const itemsTop = panelY + pad + titleH;
        const perCol = side === 'right'
            ? Math.max(1, Math.floor((panelH - titleH - pad * 2) / rowH))
            : Math.ceil(items.length / cols);
        const swatchH = Math.round(20 * u);
        items.forEach((it, i) => {
            const col = Math.floor(i / perCol);
            const row = i % perCol;
            const x = panelX + col * colW + pad;
            const cy = itemsTop + row * rowH + rowH / 2;
            this.drawSwatch(ctx, it, x, cy, swatchW, swatchH, u, thumbs.get(it.key));
            ctx.fillStyle = '#1e293b';
            ctx.font = `${font}px Arial, sans-serif`;
            ctx.fillText(it.label, x + swatchW + gap, cy);
        });
        return this.canvasToBlob(out, mime, quality);
    }
    /**
     * Pré-rend une vignette PNG du vrai symbole dessiné pour chaque entrée
     * « marker » (pictogrammes AC/SPANC, équipements, prélèvements, Nord…), via
     * `fabricObject.toDataURL()`. Les traits et zones gardent leur pastille de
     * synthèse. Échecs silencieux → repli sur la pastille générique.
     */
    async renderSymbolThumbnails(items) {
        const thumbs = new Map();
        await Promise.all(items.map(async (it) => {
            if (it.swatch !== 'marker' || !it.ref || typeof it.ref.toDataURL !== 'function')
                return;
            try {
                const url = it.ref.toDataURL({ format: 'png', multiplier: 4, enableRetinaScaling: false });
                thumbs.set(it.key, await this.loadImage(url));
            }
            catch { /* repli pastille */ }
        }));
        return thumbs;
    }
    /** Dessine la pastille d'un item : vignette du symbole réel si fournie, sinon
     *  pastille de synthèse (trait, trait pointillé, rectangle ou point). */
    drawSwatch(ctx, item, x, cy, w, h, u, thumb) {
        if (thumb && thumb.width > 0 && thumb.height > 0) {
            const s = Math.min(w / thumb.width, h / thumb.height);
            const tw = thumb.width * s, th = thumb.height * s;
            ctx.drawImage(thumb, x + (w - tw) / 2, cy - th / 2, tw, th);
            return;
        }
        const swatch = item.swatch;
        ctx.save();
        if (swatch === 'line' || swatch === 'dashed') {
            ctx.strokeStyle = item.color;
            ctx.lineWidth = Math.max(2, Math.round(4 * u));
            ctx.lineCap = 'round';
            ctx.setLineDash(swatch === 'dashed' ? [Math.round(7 * u), Math.round(5 * u)] : []);
            ctx.beginPath();
            ctx.moveTo(x, cy);
            ctx.lineTo(x + w, cy);
            ctx.stroke();
        }
        else if (swatch === 'box') {
            const bh = Math.round(16 * u);
            ctx.fillStyle = this.withAlpha(item.color, 0.18);
            ctx.strokeStyle = item.color;
            ctx.lineWidth = Math.max(1, Math.round(2 * u));
            ctx.fillRect(x, cy - bh / 2, w, bh);
            ctx.strokeRect(x + 0.5, cy - bh / 2 + 0.5, w - 1, bh - 1);
        }
        else { // marker
            const r = Math.round(8 * u);
            ctx.fillStyle = item.color;
            ctx.beginPath();
            ctx.arc(x + w / 2, cy, r, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.85)';
            ctx.lineWidth = Math.max(1, Math.round(u));
            ctx.stroke();
        }
        ctx.restore();
    }
    /** `#rrggbb` → `rgba(r,g,b,a)`. Renvoie la couleur telle quelle si non hex. */
    withAlpha(hex, alpha) {
        const m = /^#([0-9a-f]{6})$/i.exec(hex);
        if (!m)
            return hex;
        const n = parseInt(m[1], 16);
        return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alpha})`;
    }
    loadImage(src) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = () => reject(new Error('Échec du chargement de l\'image du plan'));
            img.src = src;
        });
    }
    canvasToBlob(canvas, mime, quality) {
        return new Promise((resolve, reject) => {
            canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('Échec de la génération de l\'image')), mime, quality);
        });
    }
    downloadJson(project, filename = 'plan.json') {
        const blob = new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' });
        this.triggerDownload(blob, filename);
    }
    downloadJpg(canvas, filename = 'plan.jpg') {
        this.triggerDownload(this.toJpg(canvas), filename);
    }
    /** Télécharge un PNG haute résolution (x3 = ~300 dpi pour A4) */
    downloadPng(canvas, filename = 'plan.png', multiplier = 3) {
        this.triggerDownload(this.toPng(canvas, multiplier), filename);
    }
    downloadSvg(canvas, filename = 'plan.svg') {
        const blob = new Blob([this.toSvg(canvas)], { type: 'image/svg+xml' });
        this.triggerDownload(blob, filename);
    }
    /**
     * Export JSON structuré métier (distinct du JSON Fabric.js interne).
     * Inclut le disclaimer légal et les surfaces par pièce si disponibles.
     */
    toStructuredJson(canvas, pixelsPerMeter, stats, meta) {
        const project = this.toProject(canvas, pixelsPerMeter);
        return {
            exportedAt: new Date().toISOString(),
            disclaimer: SURFACE_DISCLAIMER,
            address: meta?.address ?? '',
            diagnostician: meta?.diagnostician ?? '',
            missionId: meta?.missionId ?? '',
            pixelsPerMeter,
            totalAreaM2: stats?.totalArea ?? 0,
            wallCount: stats?.wallCount ?? 0,
            wallLengthM: stats?.wallLength ?? 0,
            roomAreas: (stats?.roomAreas ?? []).filter(r => !r.isNested).map((r, i) => ({
                index: i + 1,
                areaM2: parseFloat(r.areaM2.toFixed(2)),
            })),
            fabricObjects: project.objects,
        };
    }
    downloadStructuredJson(canvas, pixelsPerMeter, stats, meta, filename = 'plan-metier.json') {
        const data = this.toStructuredJson(canvas, pixelsPerMeter, stats, meta);
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        this.triggerDownload(blob, filename);
    }
    dataUrlToBlob(dataUrl) {
        const arr = dataUrl.split(',');
        const mime = arr[0].match(/:(.*?);/)[1];
        const bstr = atob(arr[1]);
        const u8arr = new Uint8Array(bstr.length);
        for (let i = 0; i < bstr.length; i++)
            u8arr[i] = bstr.charCodeAt(i);
        return new Blob([u8arr], { type: mime });
    }
    triggerDownload(blob, filename) {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        a.click();
        URL.revokeObjectURL(a.href);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ExportService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ExportService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ExportService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const STROKE = '#1f2937';
const FILL_LIGHT = 'rgba(255,255,255,0.95)';
const PIPE_BLUE = '#3b82f6';
/** Rectangle de base d'une cuve : contour + remplissage clair */
function tankRect(fabric, w, h) {
    return new fabric.Rect({
        left: -w / 2, top: -h / 2, width: w, height: h,
        fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5,
    });
}
function txt(fabric, label, x, y, size = 9) {
    return new fabric.Text(label, {
        left: x, top: y, originX: 'center', originY: 'center',
        fontSize: size, fontFamily: 'Arial', fontWeight: 'bold', fill: STROKE,
    });
}
/** Petite ligne (pour cloisonnements internes, déflecteurs en T) */
function ln(fabric, x1, y1, x2, y2, w = 1) {
    return new fabric.Line([x1, y1, x2, y2], { stroke: STROKE, strokeWidth: w });
}
const W = 90;
const H = 50;
const SPANC_PICTOGRAMS = {
    // ── Prétraitement ────────────────────────────────────────────────────────
    'spanc-bac-graisses': {
        mode: 'spanc-bac-graisses', label: 'Bac à graisses', width: 60, height: 40,
        build: (fabric) => {
            const w = 60, h = 40;
            return [
                new fabric.Rect({ left: -w / 2, top: -h / 2, width: w, height: h,
                    fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5 }),
                // ligne horizontale haute (niveau graisses)
                ln(fabric, -w / 2 + 4, -h / 2 + 10, w / 2 - 4, -h / 2 + 10),
                txt(fabric, 'BG', 0, 6, 11),
            ];
        },
    },
    'spanc-fosse-septique': {
        mode: 'spanc-fosse-septique', label: 'Fosse septique', width: W, height: H,
        build: (fabric) => [
            tankRect(fabric, W, H),
            // déflecteur en T à gauche
            ln(fabric, -W / 2 + 18, -H / 2 + 4, -W / 2 + 18, H / 2 - 4),
            ln(fabric, -W / 2 + 14, -H / 2 + 8, -W / 2 + 22, -H / 2 + 8),
            // déflecteur en T à droite
            ln(fabric, W / 2 - 18, -H / 2 + 4, W / 2 - 18, H / 2 - 4),
            ln(fabric, W / 2 - 22, -H / 2 + 8, W / 2 - 14, -H / 2 + 8),
            txt(fabric, 'FS', 0, 0, 10),
        ],
    },
    'spanc-fosse-toutes-eaux': {
        mode: 'spanc-fosse-toutes-eaux', label: 'Fosse toutes eaux', width: W, height: H,
        build: (fabric) => [
            tankRect(fabric, W, H),
            // cloison verticale 2/3 - 1/3
            ln(fabric, W / 2 - W / 3, -H / 2 + 4, W / 2 - W / 3, H / 2 - 4, 1.5),
            // déflecteur dans la grande chambre
            ln(fabric, -W / 2 + 18, -H / 2 + 6, -W / 2 + 18, H / 2 - 6),
            txt(fabric, 'FTE', 0, 0, 10),
        ],
    },
    'spanc-fosse-toutes-eaux-prefiltre': {
        mode: 'spanc-fosse-toutes-eaux-prefiltre', label: 'Fosse toutes eaux + préfiltre',
        width: W + 25, height: H,
        build: (fabric) => {
            const w = W + 25;
            return [
                new fabric.Rect({ left: -w / 2, top: -H / 2, width: w, height: H,
                    fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5 }),
                // cloison fosse principale
                ln(fabric, w / 2 - 30, -H / 2 + 4, w / 2 - 30, H / 2 - 4, 1.5),
                // cloison compartiment préfiltre
                ln(fabric, w / 2 - 18, -H / 2 + 4, w / 2 - 18, H / 2 - 4),
                // points = média filtrant
                ...[0, 1, 2, 3].flatMap(i => [0, 1].map(j => new fabric.Circle({ left: w / 2 - 27 + i * 2.5, top: -H / 2 + 14 + j * 10, radius: 1, fill: STROKE }))),
                txt(fabric, 'FTE', -8, 0, 10),
            ];
        },
    },
    'spanc-prefiltre': {
        mode: 'spanc-prefiltre', label: 'Préfiltre séparé', width: 50, height: 40,
        build: (fabric) => {
            const w = 50, h = 40;
            return [
                new fabric.Rect({ left: -w / 2, top: -h / 2, width: w, height: h,
                    fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5 }),
                // points = média
                ...[0, 1, 2, 3].flatMap(i => [0, 1, 2].map(j => new fabric.Circle({ left: -w / 2 + 8 + i * 8, top: -h / 2 + 10 + j * 8, radius: 1.5, fill: STROKE }))),
                txt(fabric, 'P', 0, h / 2 - 6, 8),
            ];
        },
    },
    'spanc-fosse-etanche': {
        mode: 'spanc-fosse-etanche', label: 'Fosse étanche', width: W, height: H,
        build: (fabric) => {
            const r = tankRect(fabric, W, H);
            r.set({ fill: 'rgba(31,41,55,0.08)', strokeWidth: 2.5 });
            // double contour pour symboliser l'étanchéité
            const inner = new fabric.Rect({
                left: -W / 2 + 3, top: -H / 2 + 3, width: W - 6, height: H - 6,
                fill: '', stroke: STROKE, strokeWidth: 1, strokeDashArray: [3, 2],
            });
            return [r, inner, txt(fabric, 'FE', 0, 0, 10)];
        },
    },
    // ── Traitement ────────────────────────────────────────────────────────────
    'spanc-tranchees-epandage': {
        mode: 'spanc-tranchees-epandage', label: 'Tranchées d\'épandage', width: 100, height: 60,
        build: (fabric) => {
            const w = 100, h = 60;
            const lines = [];
            for (let i = 0; i < 4; i++) {
                const y = -h / 2 + 10 + i * 12;
                lines.push(new fabric.Line([-w / 2 + 4, y, w / 2 - 4, y], {
                    stroke: STROKE, strokeWidth: 1.5, strokeDashArray: [4, 3]
                }));
            }
            // collecteur à gauche
            lines.push(ln(fabric, -w / 2 + 4, -h / 2 + 10, -w / 2 + 4, -h / 2 + 10 + 3 * 12, 2));
            return [...lines, txt(fabric, 'épandage', 0, h / 2 - 4, 7)];
        },
    },
    'spanc-filtre-sable': {
        mode: 'spanc-filtre-sable', label: 'Filtre à sable', width: W, height: H,
        build: (fabric) => {
            const r = tankRect(fabric, W, H);
            const hatch = [];
            for (let i = -W / 2 + 4; i < W / 2 - 4; i += 6) {
                hatch.push(new fabric.Line([i, -H / 2 + 2, i + 10, H / 2 - 2], {
                    stroke: STROKE, strokeWidth: 0.8,
                }));
            }
            return [r, ...hatch, txt(fabric, 'FS', 0, 0, 9)];
        },
    },
    'spanc-filtre-compact': {
        mode: 'spanc-filtre-compact', label: 'Filtre compact', width: W, height: H,
        build: (fabric) => {
            const r = tankRect(fabric, W, H);
            // motif damier petit
            const cells = [];
            const cs = 6;
            for (let i = 0; i < W / cs - 1; i++) {
                for (let j = 0; j < H / cs - 1; j++) {
                    if ((i + j) % 2 === 0) {
                        cells.push(new fabric.Rect({
                            left: -W / 2 + 2 + i * cs, top: -H / 2 + 2 + j * cs, width: cs, height: cs,
                            fill: 'rgba(31,41,55,0.18)', stroke: '', strokeWidth: 0
                        }));
                    }
                }
            }
            return [r, ...cells, txt(fabric, 'FC', 0, 0, 9)];
        },
    },
    'spanc-microstation': {
        mode: 'spanc-microstation', label: 'Micro-station', width: W + 10, height: H,
        build: (fabric) => {
            const w = W + 10;
            return [
                new fabric.Rect({ left: -w / 2, top: -H / 2, width: w, height: H,
                    fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5 }),
                ln(fabric, -w / 2 + w / 3, -H / 2 + 4, -w / 2 + w / 3, H / 2 - 4, 1.5),
                ln(fabric, -w / 2 + 2 * w / 3, -H / 2 + 4, -w / 2 + 2 * w / 3, H / 2 - 4, 1.5),
                txt(fabric, 'µ-station', 0, 0, 8),
            ];
        },
    },
    'spanc-filtre-plante': {
        mode: 'spanc-filtre-plante', label: 'Filtre planté', width: W, height: H,
        build: (fabric) => {
            const r = tankRect(fabric, W, H);
            r.set({ fill: 'rgba(34,197,94,0.10)', strokeDashArray: [4, 2] });
            const plants = [];
            for (let i = -W / 2 + 10; i < W / 2 - 4; i += 12) {
                plants.push(txt(fabric, '⚘', i + 4, -2, 14));
            }
            return [r, ...plants];
        },
    },
    'spanc-toilettes-seches': {
        mode: 'spanc-toilettes-seches', label: 'Toilettes sèches', width: W, height: H,
        build: (fabric) => {
            const r = tankRect(fabric, W, H);
            r.set({ strokeDashArray: [4, 2] });
            return [r, txt(fabric, 'TLS', 0, 0, 11)];
        },
    },
    'spanc-compost': {
        mode: 'spanc-compost', label: 'Compost', width: W, height: H,
        build: (fabric) => {
            const r = tankRect(fabric, W, H);
            r.set({ fill: 'rgba(120,53,15,0.12)', strokeDashArray: [4, 2] });
            return [r, txt(fabric, 'COMPOST', 0, 0, 9)];
        },
    },
    'spanc-lit-epandage': {
        mode: 'spanc-lit-epandage', label: 'Lit d\'épandage', width: 100, height: 60,
        build: (fabric) => {
            const w = 100, h = 60;
            const r = new fabric.Rect({
                left: -w / 2, top: -h / 2, width: w, height: h,
                fill: 'rgba(217,119,6,0.10)', stroke: STROKE, strokeWidth: 1.5,
            });
            // lignes drainantes
            const lines = [];
            for (let i = 0; i < 5; i++) {
                const y = -h / 2 + 8 + i * 11;
                lines.push(new fabric.Line([-w / 2 + 4, y, w / 2 - 4, y], {
                    stroke: STROKE, strokeWidth: 1
                }));
            }
            return [r, ...lines, txt(fabric, 'lit', 0, h / 2 - 5, 7)];
        },
    },
    // ── Rejet ─────────────────────────────────────────────────────────────────
    'spanc-puits-infiltration': {
        mode: 'spanc-puits-infiltration', label: 'Puits d\'infiltration', width: 50, height: 50,
        build: (fabric) => [
            new fabric.Circle({ left: -25, top: -25, radius: 25,
                fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5 }),
            // flèche vers le bas
            new fabric.Line([0, -10, 0, 10], { stroke: STROKE, strokeWidth: 1.5 }),
            new fabric.Line([0, 10, -4, 4], { stroke: STROKE, strokeWidth: 1.5 }),
            new fabric.Line([0, 10, 4, 4], { stroke: STROKE, strokeWidth: 1.5 }),
            txt(fabric, 'PI', 12, 12, 8),
        ],
    },
    'spanc-puits-perdu': {
        mode: 'spanc-puits-perdu', label: 'Puits perdu', width: 50, height: 50,
        build: (fabric) => [
            new fabric.Circle({ left: -25, top: -25, radius: 25,
                fill: 'rgba(31,41,55,0.20)', stroke: STROKE, strokeWidth: 1.5 }),
            new fabric.Circle({ left: -10, top: -10, radius: 10,
                fill: STROKE, stroke: STROKE, strokeWidth: 1 }),
        ],
    },
    'spanc-evacuation': {
        mode: 'spanc-evacuation', label: 'Évacuation', width: 70, height: 30,
        build: (fabric) => [
            // grosse flèche
            new fabric.Line([-30, 0, 25, 0], { stroke: STROKE, strokeWidth: 3 }),
            new fabric.Line([25, 0, 14, -8], { stroke: STROKE, strokeWidth: 3 }),
            new fabric.Line([25, 0, 14, 8], { stroke: STROKE, strokeWidth: 3 }),
            txt(fabric, 'évac.', -10, -12, 8),
        ],
    },
    'spanc-tranchee-infiltration': {
        mode: 'spanc-tranchee-infiltration', label: 'Tranchée d\'infiltration',
        width: 100, height: 60,
        build: (fabric) => {
            const w = 100, h = 60;
            const lines = [];
            for (let i = 0; i < 4; i++) {
                const y = -h / 2 + 10 + i * 12;
                lines.push(new fabric.Line([-w / 2 + 4, y, w / 2 - 4, y], {
                    stroke: STROKE, strokeWidth: 1.5, strokeDashArray: [4, 3]
                }));
            }
            lines.push(ln(fabric, -w / 2 + 4, -h / 2 + 10, -w / 2 + 4, -h / 2 + 10 + 3 * 12, 2));
            return [...lines, txt(fabric, 'T.I.', 0, h / 2 - 4, 7)];
        },
    },
    // ── Regards / Pompes ──────────────────────────────────────────────────────
    'spanc-regard': {
        mode: 'spanc-regard', label: 'Regard', width: 30, height: 30,
        build: (fabric) => [
            new fabric.Rect({ left: -15, top: -15, width: 30, height: 30,
                fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5 }),
            ln(fabric, -10, -10, 10, 10),
            ln(fabric, -10, 10, 10, -10),
            txt(fabric, 'R', 0, 0, 8),
        ],
    },
    'spanc-pompe-relevage': {
        mode: 'spanc-pompe-relevage', label: 'Pompe de relevage', width: 50, height: 40,
        build: (fabric) => [
            new fabric.Rect({ left: -25, top: -20, width: 50, height: 40,
                fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5 }),
            new fabric.Circle({ left: -10, top: -10, radius: 10,
                fill: 'rgba(59,130,246,0.20)', stroke: PIPE_BLUE, strokeWidth: 1.5 }),
            txt(fabric, 'P', 0, 0, 11),
            // flèche montante
            new fabric.Line([12, 8, 12, -10], { stroke: STROKE, strokeWidth: 1.5 }),
            new fabric.Line([12, -10, 9, -6], { stroke: STROKE, strokeWidth: 1.5 }),
            new fabric.Line([12, -10, 15, -6], { stroke: STROKE, strokeWidth: 1.5 }),
        ],
    },
    // ── Ventilation ───────────────────────────────────────────────────────────
    'spanc-ventilation-secondaire': {
        mode: 'spanc-ventilation-secondaire', label: 'Ventilation secondaire',
        width: 24, height: 70,
        build: (fabric) => [
            // tube vertical
            new fabric.Rect({ left: -4, top: -25, width: 8, height: 50,
                fill: FILL_LIGHT, stroke: STROKE, strokeWidth: 1.5 }),
            // chapeau
            new fabric.Line([-10, -25, 10, -25], { stroke: STROKE, strokeWidth: 1.5 }),
            new fabric.Line([-10, -28, 10, -28], { stroke: STROKE, strokeWidth: 1.5 }),
            // flèche d'air montante
            new fabric.Line([0, 25, 0, -32], { stroke: '#6b7280', strokeWidth: 1, strokeDashArray: [3, 2] }),
            new fabric.Line([0, -32, -3, -28], { stroke: '#6b7280', strokeWidth: 1 }),
            new fabric.Line([0, -32, 3, -28], { stroke: '#6b7280', strokeWidth: 1 }),
            txt(fabric, 'V2', 12, 0, 8),
        ],
    },
};
/** Vrai si le mode correspond à un pictogramme SPANC */
function isSpancPictogramMode(mode) {
    return mode in SPANC_PICTOGRAMS;
}
/** Type d'objet Fabric persisté pour tous les pictogrammes SPANC */
const SPANC_PICTOGRAM_TYPE = 'SpancPictogram';

// Couleurs des types d'eau — alignées avec PIPE_COLORS dans geometry.service.ts
const COLORS = {
    eu: '#7c3aed', // Eaux usées (violet)
    em: '#a16207', // Eaux ménagères (brun)
    ev: '#78350f', // Eaux vannes (brun foncé)
    ep: '#22d3ee', // Eaux pluviales (cyan)
};
const STROKE_DARK = '#1f2937';
/** Pictogramme « Regard » coloré : cercle creux teinté + petit carré central plein.
 *  Reprend image 2 du xlsx (cercle brun + carré plein) mais décliné par couleur. */
function buildRegard(fabric, color) {
    return [
        new fabric.Circle({
            left: 0, top: 0, originX: 'center', originY: 'center',
            radius: 14,
            fill: 'rgba(255,255,255,0.95)',
            stroke: color, strokeWidth: 2,
        }),
        new fabric.Rect({
            left: 0, top: 0, originX: 'center', originY: 'center',
            width: 10, height: 10,
            fill: color, stroke: color, strokeWidth: 1,
        }),
    ];
}
/** Badge texte (EU/EM/EV/EP) — fond coloré, texte blanc, conforme aux images 15-17 du xlsx. */
function buildLabel(fabric, text, color) {
    const w = 30, h = 16;
    return [
        new fabric.Rect({
            left: 0, top: 0, originX: 'center', originY: 'center',
            width: w, height: h,
            fill: color, stroke: '#0f172a', strokeWidth: 1,
            rx: 2, ry: 2,
        }),
        new fabric.Text(text, {
            left: 0, top: 0, originX: 'center', originY: 'center',
            fontSize: 11, fontFamily: 'Arial', fontWeight: 'bold',
            fill: '#ffffff',
        }),
    ];
}
const AC_PICTOGRAMS = {
    // ── Regards (manholes) — un par type d'eau ────────────────────────────────
    'ac-regard-eu': {
        mode: 'ac-regard-eu', label: 'Regard EU', width: 28, height: 28,
        build: (fabric) => buildRegard(fabric, COLORS.eu),
    },
    'ac-regard-em': {
        mode: 'ac-regard-em', label: 'Regard EM', width: 28, height: 28,
        build: (fabric) => buildRegard(fabric, COLORS.em),
    },
    'ac-regard-ev': {
        mode: 'ac-regard-ev', label: 'Regard EV', width: 28, height: 28,
        build: (fabric) => buildRegard(fabric, COLORS.ev),
    },
    'ac-regard-ep': {
        mode: 'ac-regard-ep', label: 'Regard EP', width: 28, height: 28,
        build: (fabric) => buildRegard(fabric, COLORS.ep),
    },
    // ── Badges de type d'eau (à poser le long d'un tracé) ─────────────────────
    'ac-label-eu': {
        mode: 'ac-label-eu', label: 'Label EU', width: 30, height: 16,
        build: (fabric) => buildLabel(fabric, 'EU', COLORS.eu),
    },
    'ac-label-em': {
        mode: 'ac-label-em', label: 'Label EM', width: 30, height: 16,
        build: (fabric) => buildLabel(fabric, 'EM', COLORS.em),
    },
    'ac-label-ev': {
        mode: 'ac-label-ev', label: 'Label EV', width: 30, height: 16,
        build: (fabric) => buildLabel(fabric, 'EV', COLORS.ev),
    },
    'ac-label-ep': {
        mode: 'ac-label-ep', label: 'Label EP', width: 30, height: 16,
        build: (fabric) => buildLabel(fabric, 'EP', COLORS.ep),
    },
    // ── Nœud de connexion (image 13 du xlsx : disque plein + flèche) ──────────
    'ac-noeud': {
        mode: 'ac-noeud', label: 'Nœud / branchement', width: 30, height: 14,
        build: (fabric) => [
            new fabric.Circle({
                left: -8, top: 0, originX: 'center', originY: 'center',
                radius: 6, fill: STROKE_DARK,
            }),
            // Flèche pointant vers la droite
            new fabric.Line([-2, 0, 10, 0], { stroke: STROKE_DARK, strokeWidth: 2 }),
            new fabric.Polygon([{ x: 10, y: -4 }, { x: 14, y: 0 }, { x: 10, y: 4 }], { fill: STROKE_DARK, stroke: STROKE_DARK, strokeWidth: 1,
                originX: 'left', originY: 'center' }),
        ],
    },
    // ── Boîte de branchement (carré) ─────────────────────────────────────────
    'ac-boite-branchement': {
        mode: 'ac-boite-branchement', label: 'Boîte de branchement', width: 22, height: 22,
        build: (fabric) => [
            new fabric.Rect({
                left: 0, top: 0, originX: 'center', originY: 'center',
                width: 22, height: 22,
                fill: 'rgba(255,255,255,0.95)', stroke: STROKE_DARK, strokeWidth: 2,
            }),
        ],
    },
    // ── Pied de descente / collecteur terminus (image 14 : cadre + bas vert) ──
    'ac-pied': {
        mode: 'ac-pied', label: 'Pied de descente', width: 22, height: 26,
        build: (fabric) => {
            const w = 22, h = 26;
            return [
                new fabric.Rect({
                    left: 0, top: 0, originX: 'center', originY: 'center',
                    width: w, height: h,
                    fill: 'rgba(255,255,255,0.95)', stroke: STROKE_DARK, strokeWidth: 1.5,
                }),
                // Bande verte en bas (sortie / sol)
                new fabric.Rect({
                    left: 0, top: h / 2 - 3, originX: 'center', originY: 'center',
                    width: w, height: 4,
                    fill: '#16a34a', stroke: '#16a34a', strokeWidth: 1,
                }),
            ];
        },
    },
};
/** Vrai si le mode correspond à un pictogramme AC */
function isAcPictogramMode(mode) {
    return mode in AC_PICTOGRAMS;
}
/** Type d'objet Fabric persisté pour tous les pictogrammes AC */
const AC_PICTOGRAM_TYPE = 'AcPictogram';

const POLYLINE_MODES$1 = [
    'wall', 'cloison',
    'pipe-aep', 'pipe-eu', 'pipe-em', 'pipe-ev', 'pipe-vent',
    'pipe-ep', 'pipe-gaz', 'pipe-elec', 'pipe-fibre',
];
/** Types qui NE peuvent PAS être déplacés au clic en cours de dessin réseau :
 *  fond de carte, nœuds, murs (drag connecté dédié), labels/cotes auto-générés. */
const NON_MOVABLE_IN_DRAW = new Set([
    'Backdrop', 'GhostFloor', 'WallNode', 'Mur', 'Cloison',
    'WallLabel', 'WallMeasurement', 'PipeMeasurement', 'RoomLabel', 'RoomWallLabel', 'LockedLabel',
]);
const EQUIPMENT_CONFIG = {
    'equip-elec': { label: 'Tableau élec.', subtype: 'elec-panel', symbol: 'TGBT', color: '#d97706' },
    'equip-boiler': { label: 'Chaudière', subtype: 'boiler', symbol: 'CH', color: '#ea580c' },
    'equip-vmc': { label: 'VMC', subtype: 'vmc', symbol: 'VMC', color: '#0284c7' },
    'equip-daaf': { label: 'DAAF', subtype: 'daaf', symbol: 'DAAF', color: '#dc2626' },
    'equip-gas': { label: 'Compteur gaz', subtype: 'gas-meter', symbol: 'GAZ', color: '#16a34a' },
    'equip-hwt': { label: 'Cumulus / ECS', subtype: 'water-heater', symbol: 'ECS', color: '#ea580c' },
};
const HAZARD_CONFIG = {
    'hazard-amiante': { label: 'Zone amiante', hazardType: 'amiante', fill: 'rgba(245,158,11,0.15)', stroke: '#f59e0b' },
    'hazard-plomb': { label: 'Zone plomb', hazardType: 'plomb', fill: 'rgba(239,68,68,0.15)', stroke: '#ef4444' },
    'hazard-humidite': { label: 'Zone humidité', hazardType: 'humidite', fill: 'rgba(59,130,246,0.15)', stroke: '#3b82f6' },
};
class FabricCanvasService {
    canvas;
    _isPolylineDrawing = signal(false);
    activePolylineLines = [];
    lastPoint = null;
    previewLine = null;
    _currentMode = signal('select');
    // Pan
    isDragging = false;
    lastPosX = 0;
    lastPosY = 0;
    // Rect drawing (room, stair, hazard zones)
    isDrawingRect = false;
    rectStart = null;
    previewRect = null;
    // Node editing
    activeNodes = [];
    // Connected-wall drag state
    WALL_CONN_SNAP = 20; // px — doit correspondre à snapLineEndpoints
    /** Callback déclenché après chaque ajout/modification — utilisé pour recalculateRooms. */
    onWallsChanged;
    /** Prochain prélèvement CRI à poser au clic (pose guidée). null = pose libre (P{n+1}). */
    _nextSample = null;
    setNextSample(s) { this._nextSample = s; }
    /** Callback déclenché quand un prélèvement de la file guidée vient d'être posé. */
    onSamplePlaced;
    isPolylineDrawing = this._isPolylineDrawing.asReadonly();
    currentMode = this._currentMode.asReadonly();
    // ── Init ────────────────────────────────────────────────────────────────────
    init(canvas) {
        this.canvas = canvas;
        // Fabric n'émet pas `mouse:down`/`up` pour les boutons droit et milieu par
        // défaut : on les active pour permettre le pan au clic DROIT maintenu (et au
        // clic molette), ainsi que le clic droit pour clôturer un tracé réseau.
        // `stopContextMenu` neutralise en plus le menu contextuel côté Fabric.
        this.canvas.fireRightClick = true;
        this.canvas.fireMiddleClick = true;
        this.canvas.stopContextMenu = true;
        this.canvas.on('mouse:down', (o) => this.onMouseDown(o));
        this.canvas.on('mouse:move', (o) => this.onMouseMove(o));
        this.canvas.on('mouse:up', (o) => this.onMouseUp(o));
        this.canvas.on('mouse:dblclick', (o) => this.onDoubleClick(o));
        // Menu contextuel du navigateur : on le neutralise sur toute la zone de
        // dessin. Sur le clic droit (utilisé pour clôturer un tracé, cf. onMouseDown)
        // comme sur l'appui long PWA/tactile, il interrompait le déplacement d'un
        // objet. On l'attache au conteneur Fabric (.canvas-container) qui enveloppe
        // les deux canvases, avec repli sur l'upper-canvas.
        // On ne pose l'écouteur que si l'on tient réellement un nœud DOM : sous
        // Karma le canvas est un mock sans conteneur, et un `wrapper` non-élément
        // faisait échouer l'initialisation complète du service.
        const noCtx = (e) => e.preventDefault();
        const wrapper = (this.canvas.wrapperEl ?? this.canvas.upperCanvasEl);
        if (typeof wrapper?.addEventListener === 'function') {
            wrapper.addEventListener('contextmenu', noCtx);
        }
        // Déplacement en temps réel
        this.canvas.on('object:moving', (e) => {
            const obj = e.target;
            if (obj?.myType === 'WallNode') {
                this.onNodeMoving(obj);
                return;
            }
            if (obj?.myType === 'Mur' || obj?.myType === 'Cloison') {
                this.onWallMoving(obj);
                return;
            }
            if (obj?.myType === 'Door' || obj?.myType === 'Window') {
                this.constrainOpeningToWall(obj);
            }
        });
        // Fin de déplacement (drop)
        this.canvas.on('object:modified', (e) => {
            const obj = e.target;
            if (obj?.myType === 'WallNode') {
                this.refreshNodeHandles();
                this.onWallsChanged?.();
                return;
            }
            if (obj?.myType === 'Mur' || obj?.myType === 'Cloison') {
                delete obj._moveInit; // clean up drag state
                const snapped = this.snapLineEndpoints(obj);
                if (snapped)
                    this.canvas.renderAll();
                this.refreshNodeHandles();
                this.onWallsChanged?.();
            }
        });
        // Réapplique le mode courant : si setMode() a été appelé avant init()
        // (canvas pas prêt), l'état du canvas est maintenant synchronisé.
        this.setMode(this._currentMode());
    }
    setMode(mode) {
        this._currentMode.set(mode);
        // Garde défensive : le mode est mémorisé même si le canvas n'est pas
        // encore initialisé — init() réapplique le mode au démarrage.
        if (!this.canvas)
            return;
        const isSelectMode = mode === 'select' || mode === 'node-edit';
        // Sélection-rectangle (lasso) désactivée : par choix produit, un glisser sur
        // le vide en mode sélection déplace la vue (pan) au lieu de faire un lasso.
        // La laisser active empêchait le pan : Fabric démarre son group-selector au
        // mousedown, AVANT le handler onMouseDown, donc y remettre selection=false
        // arrivait trop tard. La sélection d'un objet unique reste possible.
        this.canvas.selection = false;
        if (mode === 'draw-red' || mode === 'draw-blue') {
            this.canvas.isDrawingMode = true;
            this.canvas.freeDrawingBrush.color = mode === 'draw-red' ? '#dc2626' : '#2563eb';
            this.canvas.freeDrawingBrush.width = 2;
        }
        else {
            this.canvas.isDrawingMode = false;
        }
        this.canvas.defaultCursor =
            mode === 'pan' || mode === 'select' ? 'grab'
                : [...POLYLINE_MODES$1, 'room', 'room-sketch', 'stair', 'door', 'window',
                    ...Object.keys(HAZARD_CONFIG)].includes(mode)
                    ? 'crosshair'
                    : 'default';
        this.applyModeSelectability(mode);
    }
    /**
     * En mode sélection : tous les objets sont sélectionnables/évènementiels.
     * Dans les autres modes : seuls les WallNodes restent évènementiels (drag de nœud possible),
     * le reste est verrouillé pour ne pas interférer avec le dessin.
     * En lecture seule : aucun objet n'est sélectionnable — masque le cadre de
     * sélection et les poignées qui laissaient croire à une modification possible.
     */
    applyModeSelectability(mode) {
        const isSelectMode = mode === 'select' || mode === 'node-edit';
        const ro = this._readOnly;
        this.canvas.getObjects().forEach((obj) => {
            // Backdrop verrouillé : reste inerte quel que soit le mode courant
            // (sinon le passage en mode "select" le rendait à nouveau déplaçable).
            if (obj.myType === 'Backdrop' && obj.data?.locked === true) {
                obj.selectable = false;
                obj.evented = false;
                return;
            }
            if (ro) {
                // Lecture seule : aucun objet ne reçoit d'événement → pas de cadre,
                // pas de poignées, pas d'inspecteur peuplé.
                obj.selectable = false;
                obj.evented = false;
                return;
            }
            // En mode croquis, les RoomBoxes restent sélectionnables pour déplacer/sélectionner
            const keepForSketch = mode === 'room-sketch' && obj.myType === 'RoomBox';
            // En mode dessin réseau, les dessins existants (fosses, boîtes, tuyaux…)
            // restent déplaçables au clic sans quitter l'outil courant.
            const movableInNetwork = this.isPipeMode(mode) && this.isUserMovable(obj);
            obj.selectable = isSelectMode || keepForSketch || movableInNetwork;
            obj.evented = isSelectMode || keepForSketch || movableInNetwork;
        });
        if (!isSelectMode || ro)
            this.canvas.discardActiveObject();
        this.canvas.requestRenderAll();
    }
    // ── Mode lecture seule ────────────────────────────────────────────────────────
    _readOnly = false;
    /** Active/désactive le mode lecture seule au niveau du service Fabric.
     *  À jour dès l'appel — re-applique la sélectabilité de tous les objets. */
    setReadOnly(ro) {
        this._readOnly = ro;
        if (this.canvas) {
            this.applyModeSelectability(this._currentMode());
        }
    }
    isReadOnly() { return this._readOnly; }
    // ── Node editing ─────────────────────────────────────────────────────────────
    /**
     * Recrée tous les nœuds visibles sur les extrémités de murs/cloisons.
     * Appelé après chaque ajout/modification de mur.
     */
    refreshNodeHandles() {
        const fabric = window['fabric'];
        // Supprimer les cercles existants
        const existing = this.canvas.getObjects().filter((o) => o.myType === 'WallNode');
        existing.forEach((o) => this.canvas.remove(o));
        this.activeNodes = [];
        const walls = this.canvas.getObjects().filter((o) => ['Mur', 'Cloison'].includes(o.myType));
        if (walls.length === 0)
            return;
        // Regrouper les extrémités par position (arrondi à 5px pour tolérance)
        const nodeMap = new Map();
        walls.forEach((line) => {
            const ends = this.getAbsoluteLineEnds(line);
            for (const pos of [ends.p1, ends.p2]) {
                const key = `${Math.round(pos.x / 5) * 5}_${Math.round(pos.y / 5) * 5}`;
                if (!nodeMap.has(key))
                    nodeMap.set(key, { x: pos.x, y: pos.y });
            }
        });
        nodeMap.forEach(({ x, y }) => {
            // Compter les connexions (extrémités qui tombent sur ce nœud)
            let connCount = 0;
            walls.forEach((line) => {
                const ends = this.getAbsoluteLineEnds(line);
                if (Math.hypot(ends.p1.x - x, ends.p1.y - y) < 8)
                    connCount++;
                if (Math.hypot(ends.p2.x - x, ends.p2.y - y) < 8)
                    connCount++;
            });
            const isJunction = connCount > 2;
            const circle = new fabric.Circle({
                left: x, top: y,
                radius: isJunction ? 7 : 5,
                originX: 'center', originY: 'center',
                fill: isJunction ? '#f59e0b' : '#ffffff',
                stroke: '#6366f1',
                strokeWidth: 2,
                selectable: true,
                hasControls: false,
                hasBorders: false,
                myType: 'WallNode',
                evented: true,
                hoverCursor: 'grab',
                moveCursor: 'grabbing',
            });
            circle._initialPos = { x, y };
            this.canvas.add(circle);
            this.canvas.bringToFront(circle);
            this.activeNodes.push({ circle, connections: [] });
        });
        // Appliquer la sélectabilité selon le mode courant
        this.applyModeSelectability(this._currentMode());
    }
    onNodeMoving(circle) {
        let snapX = circle.left; // originX: 'center' → left = centre
        let snapY = circle.top;
        const initPos = circle._initialPos;
        if (!initPos)
            return;
        // Snap vers un nœud voisin (fusion automatique)
        const MERGE_DIST = 20;
        const otherNodes = this.canvas.getObjects().filter((o) => o.myType === 'WallNode' && o !== circle);
        for (const other of otherNodes) {
            if (Math.hypot(other.left - snapX, other.top - snapY) <= MERGE_DIST) {
                snapX = other.left;
                snapY = other.top;
                circle.set({ left: snapX, top: snapY });
                break;
            }
        }
        // Mettre à jour toutes les extrémités de murs qui étaient à initPos
        const TOLERANCE = 10;
        const walls = this.canvas.getObjects().filter((o) => ['Mur', 'Cloison'].includes(o.myType));
        walls.forEach((line) => {
            const ends = this.getAbsoluteLineEnds(line);
            let nx1 = ends.p1.x, ny1 = ends.p1.y;
            let nx2 = ends.p2.x, ny2 = ends.p2.y;
            let changed = false;
            if (Math.hypot(ends.p1.x - initPos.x, ends.p1.y - initPos.y) < TOLERANCE) {
                nx1 = snapX;
                ny1 = snapY;
                changed = true;
            }
            if (Math.hypot(ends.p2.x - initPos.x, ends.p2.y - initPos.y) < TOLERANCE) {
                nx2 = snapX;
                ny2 = snapY;
                changed = true;
            }
            if (changed) {
                // Mise à jour explicite de toutes les propriétés pour éviter le cache Fabric périmé
                line.set({
                    x1: nx1, y1: ny1, x2: nx2, y2: ny2,
                    left: Math.min(nx1, nx2),
                    top: Math.min(ny1, ny2),
                    width: Math.abs(nx2 - nx1),
                    height: Math.abs(ny2 - ny1),
                });
                line.ownMatrixCache = null;
                line.dirty = true;
                line.setCoords();
                // Faire suivre les portes/fenêtres accrochées à ce mur
                this.updateOpeningsOnWall(line, nx1, ny1, nx2, ny2);
            }
        });
        // Mettre à jour la position initiale pour le prochain appel (position snappée)
        circle._initialPos = { x: snapX, y: snapY };
        this.canvas.requestRenderAll();
    }
    /**
     * Enregistre les positions initiales et les connexions d'un mur/cloison
     * AVANT tout déplacement (appelé depuis mouse:down pour avoir les bonnes coords).
     *
     * Deux types de connexions détectées :
     *  - endpoint-to-endpoint : extrémité d'un autre mur coïncide avec P1 ou P2
     *  - endpoint-to-body : extrémité d'une cloison posée sur le CORPS du mur (milieu)
     */
    initWallMoveState(line) {
        if (!line || !['Mur', 'Cloison'].includes(line.myType))
            return;
        const SNAP = this.WALL_CONN_SNAP;
        const ends = this.getAbsoluteLineEnds(line);
        const walls = this.canvas.getObjects().filter((o) => ['Mur', 'Cloison'].includes(o.myType) && o !== line);
        // ── Connexions extrémité→extrémité ──────────────────────────────────────
        const findEndpointConns = (pt) => {
            const conns = [];
            for (const w of walls) {
                const we = this.getAbsoluteLineEnds(w);
                if (Math.hypot(we.p1.x - pt.x, we.p1.y - pt.y) < SNAP) {
                    conns.push({ wall: w, endpoint: 'p1', staticPt: { x: we.p2.x, y: we.p2.y } });
                }
                if (Math.hypot(we.p2.x - pt.x, we.p2.y - pt.y) < SNAP) {
                    conns.push({ wall: w, endpoint: 'p2', staticPt: { x: we.p1.x, y: we.p1.y } });
                }
            }
            return conns;
        };
        const p1Conns = findEndpointConns(ends.p1);
        const p2Conns = findEndpointConns(ends.p2);
        // Vérification par référence objet (ne pas utiliser toString qui donne [object Object])
        const isEndpointConn = (w, ep) => [...p1Conns, ...p2Conns].some(c => c.wall === w && c.endpoint === ep);
        // ── Connexions extrémité→corps (cloison attachée au milieu du mur) ──────
        const dx = ends.p2.x - ends.p1.x;
        const dy = ends.p2.y - ends.p1.y;
        const len2 = dx * dx + dy * dy;
        const bodyConns = [];
        if (len2 > 0) {
            for (const w of walls) {
                const we = this.getAbsoluteLineEnds(w);
                for (const { pt, ep, sp } of [
                    { pt: we.p1, ep: 'p1', sp: we.p2 },
                    { pt: we.p2, ep: 'p2', sp: we.p1 },
                ]) {
                    // Ignorer si déjà comptabilisé en connexion extrémité-extrémité
                    if (isEndpointConn(w, ep))
                        continue;
                    // Projection sur le segment du mur déplacé
                    const t = ((pt.x - ends.p1.x) * dx + (pt.y - ends.p1.y) * dy) / len2;
                    if (t <= 0.01 || t >= 0.99)
                        continue; // exclure les extrémités (déjà gérées)
                    const projX = ends.p1.x + t * dx;
                    const projY = ends.p1.y + t * dy;
                    const perp = Math.hypot(pt.x - projX, pt.y - projY);
                    if (perp < SNAP) {
                        bodyConns.push({
                            wall: w, endpoint: ep,
                            staticPt: { x: sp.x, y: sp.y },
                            initConnPt: { x: pt.x, y: pt.y },
                        });
                    }
                }
            }
        }
        line._moveInit = {
            p1: { x: ends.p1.x, y: ends.p1.y },
            p2: { x: ends.p2.x, y: ends.p2.y },
            p1Conns,
            p2Conns,
            bodyConns,
        };
    }
    /**
     * Déplacement d'un mur/cloison en temps réel avec maintien des connexions.
     * L'état (_moveInit) doit être initialisé dans mouse:down pour des positions correctes.
     */
    onWallMoving(line) {
        // Fallback si l'état n'est pas pré-initialisé (ex : sélection clavier)
        // Dans ce cas les positions sont déjà décalées → peu de connexions trouvées, mais ça ne casse pas
        if (!line._moveInit) {
            this.initWallMoveState(line);
        }
        const init = line._moveInit;
        const current = this.getAbsoluteLineEnds(line);
        const updateConns = (conns, newPt) => {
            for (const { wall, endpoint, staticPt } of conns) {
                const nx1 = endpoint === 'p1' ? newPt.x : staticPt.x;
                const ny1 = endpoint === 'p1' ? newPt.y : staticPt.y;
                const nx2 = endpoint === 'p2' ? newPt.x : staticPt.x;
                const ny2 = endpoint === 'p2' ? newPt.y : staticPt.y;
                wall.set({
                    x1: nx1, y1: ny1, x2: nx2, y2: ny2,
                    left: Math.min(nx1, nx2),
                    top: Math.min(ny1, ny2),
                    width: Math.abs(nx2 - nx1),
                    height: Math.abs(ny2 - ny1),
                });
                wall.ownMatrixCache = null;
                wall.dirty = true;
                wall.setCoords();
                this.updateOpeningsOnWall(wall, nx1, ny1, nx2, ny2);
            }
        };
        updateConns(init.p1Conns, current.p1);
        updateConns(init.p2Conns, current.p2);
        // ── Connexions extrémité→corps (translation uniforme) ──────────────────
        const delta = { x: current.p1.x - init.p1.x, y: current.p1.y - init.p1.y };
        for (const { wall, endpoint, staticPt, initConnPt } of (init.bodyConns ?? [])) {
            const newPt = { x: initConnPt.x + delta.x, y: initConnPt.y + delta.y };
            const nx1 = endpoint === 'p1' ? newPt.x : staticPt.x;
            const ny1 = endpoint === 'p1' ? newPt.y : staticPt.y;
            const nx2 = endpoint === 'p2' ? newPt.x : staticPt.x;
            const ny2 = endpoint === 'p2' ? newPt.y : staticPt.y;
            wall.set({
                x1: nx1, y1: ny1, x2: nx2, y2: ny2,
                left: Math.min(nx1, nx2), top: Math.min(ny1, ny2),
                width: Math.abs(nx2 - nx1), height: Math.abs(ny2 - ny1),
            });
            wall.ownMatrixCache = null;
            wall.dirty = true;
            wall.setCoords();
            this.updateOpeningsOnWall(wall, nx1, ny1, nx2, ny2);
        }
        this.canvas.requestRenderAll();
    }
    // ── Grid snap ───────────────────────────────────────────────────────────────
    /**
     * Calcule les coordonnées canvas à partir d'un MouseEvent en utilisant
     * getBoundingClientRect() directement, évitant le bug de scroll traversal
     * de canvas.getPointer() dans les conteneurs scrollables.
     */
    /** Coordonnées écran d'un événement souris OU tactile (les TouchEvent
     *  n'exposent pas clientX/Y à la racine). */
    eventClient(evt) {
        const src = evt.touches?.[0]
            ?? evt.changedTouches?.[0]
            ?? evt;
        return { x: src.clientX ?? 0, y: src.clientY ?? 0 };
    }
    getCanvasPointer(evt) {
        const el = this.canvas.upperCanvasEl;
        const rect = el.getBoundingClientRect();
        // Les TouchEvent n'exposent pas clientX/Y à la racine : lire le 1er point
        // (touches[0] sur touchstart/move, changedTouches[0] sur touchend).
        const src = evt.touches?.[0]
            ?? evt.changedTouches?.[0]
            ?? evt;
        const cssX = src.clientX - rect.left;
        const cssY = src.clientY - rect.top;
        const [a, , , d, e, f] = this.canvas.viewportTransform;
        return { x: (cssX - e) / a, y: (cssY - f) / d };
    }
    /** Pas de grille effectif — élargi sur tactile pour viser plus facilement au doigt. */
    get effectiveGrid() {
        const isTouch = typeof window !== 'undefined'
            && window.matchMedia?.('(pointer: coarse)').matches;
        return isTouch ? 30 : 20;
    }
    snapToGrid(ptr, grid) {
        const g = grid ?? this.effectiveGrid;
        return {
            x: Math.round(ptr.x / g) * g,
            y: Math.round(ptr.y / g) * g,
        };
    }
    /**
     * Snap intelligent pour le dessin de murs/cloisons.
     * Priorité : 1) nœud existant (extrémité de mur), 2) projection sur un mur, 3) grille.
     */
    snapPolylinePoint(pt, nodeSnapDist = 20, wallSnapDist = 15) {
        // 1. Nœuds existants (WallNode)
        const nodes = this.canvas.getObjects().filter((o) => o.myType === 'WallNode');
        let bestDist = nodeSnapDist;
        let best = null;
        for (const node of nodes) {
            const d = Math.hypot(node.left - pt.x, node.top - pt.y);
            if (d < bestDist) {
                bestDist = d;
                best = { x: node.left, y: node.top };
            }
        }
        if (best)
            return best;
        // 2. Projection sur un mur/cloison existant
        const walls = this.canvas.getObjects().filter((o) => ['Mur', 'Cloison'].includes(o.myType));
        bestDist = wallSnapDist;
        for (const wall of walls) {
            const { p1, p2 } = this.getAbsoluteLineEnds(wall);
            const dx = p2.x - p1.x, dy = p2.y - p1.y;
            const len2 = dx * dx + dy * dy;
            if (len2 === 0)
                continue;
            const t = Math.max(0, Math.min(1, ((pt.x - p1.x) * dx + (pt.y - p1.y) * dy) / len2));
            const projX = p1.x + t * dx, projY = p1.y + t * dy;
            const d = Math.hypot(pt.x - projX, pt.y - projY);
            if (d < bestDist) {
                bestDist = d;
                best = { x: projX, y: projY };
            }
        }
        if (best)
            return best;
        // 3. Grille
        return this.snapToGrid(pt);
    }
    // ── Mouse events ────────────────────────────────────────────────────────────
    onMouseDown(o) {
        const evt = o.e;
        const fabric = window['fabric'];
        // Réinitialise l'état de drag sur tous les murs
        this.canvas.getObjects()
            .filter((ob) => ['Mur', 'Cloison'].includes(ob.myType))
            .forEach((ob) => { delete ob._moveInit; });
        // Pré-initialise AVANT tout déplacement (positions correctes à ce stade)
        const clickedTarget = o.target;
        if (this._currentMode() === 'select' &&
            clickedTarget && ['Mur', 'Cloison'].includes(clickedTarget.myType)) {
            this.initWallMoveState(clickedTarget);
        }
        // Déplacement de la vue (pan) :
        //  - clic DROIT maintenu + glisser : pan universel, quel que soit le mode
        //    (sauf en plein tracé réseau, où le clic droit termine le tracé). Le
        //    bouton droit n'est pas capté par une éventuelle modale draggable
        //    (cdkDrag n'écoute que le bouton principal), donc il fonctionne partout ;
        //  - Alt+glisser, clic molette, ou outil « Déplacer la vue » (mode pan) ;
        //  - en mode sélection, glisser gauche sur le « fond » (zone vide OU fond de
        //    carte / calque fantôme, inertes) pan aussi ; sur un dessin réel il le
        //    déplace via Fabric.
        const dragTarget = o.target;
        const onBackground = !dragTarget
            || dragTarget.myType === 'Backdrop'
            || dragTarget.myType === 'GhostFloor';
        const panRight = evt.button === 2 && !this._isPolylineDrawing();
        const panOnEmpty = this._currentMode() === 'select' && onBackground;
        if (evt.altKey || evt.button === 1 || panRight || this._currentMode() === 'pan' || panOnEmpty) {
            this.isDragging = true;
            this.canvas.selection = false;
            const c = this.eventClient(evt);
            this.lastPosX = c.x;
            this.lastPosY = c.y;
            return;
        }
        const mode = this._currentMode();
        // Clic gauche sur un dessin existant pendant un tracé réseau → déplacement :
        // l'objet (fosse, boîte de branchement, tuyau…) se repositionne sans quitter
        // l'outil. Un tracé en cours est d'abord clôturé, puis Fabric gère le drag.
        const target = o.target;
        if (this.isPipeMode(mode) && target && this.isUserMovable(target)) {
            if (this._isPolylineDrawing())
                this.finishPolyline();
            return;
        }
        // En mode dessin, un clic sur un nœud laisse passer (le snap positionne l'extrémité sur ce nœud).
        // En mode sélection, on bloque pour ne pas démarrer accidentellement un dessin.
        if (o.target?.myType === 'WallNode' && !POLYLINE_MODES$1.includes(mode))
            return;
        const ptr = this.getCanvasPointer(evt);
        const snapped = this.snapToGrid(new fabric.Point(ptr.x, ptr.y));
        // Polyline modes (wall, cloison, pipes)
        if (POLYLINE_MODES$1.includes(mode)) {
            if (evt.button === 2) {
                this.finishPolyline();
                return;
            }
            // Murs/cloisons : snap intelligent (nœud → mur → grille).
            // Réseaux : AUCUN magnétisme — angles et positions libres.
            const point = ['wall', 'cloison'].includes(mode)
                ? this.snapPolylinePoint(ptr)
                : { x: ptr.x, y: ptr.y };
            this.handlePolylineClick(point, mode);
            return;
        }
        // Rect drawing modes (room, room-sketch, stair, hazard zones)
        if (mode === 'room' || mode === 'room-sketch' || mode === 'stair' || mode in HAZARD_CONFIG) {
            // En mode croquis : si le clic touche un RoomBox existant, laisser Fabric gérer
            // la sélection/déplacement sans démarrer un nouveau dessin
            if (mode === 'room-sketch' && o.target?.myType === 'RoomBox')
                return;
            this.isDrawingRect = true;
            this.rectStart = mode === 'room-sketch' ? this.snapForRoomSketch(ptr) : snapped;
            return;
        }
        switch (mode) {
            case 'door':
            case 'window':
                this.handleDoorWindow(snapped, mode);
                break;
            case 'north-arrow':
                this.handleNorthArrow(snapped);
                break;
            case 'prelevement':
                this.handleClickPrelevement(snapped);
                break;
            default:
                if (mode in EQUIPMENT_CONFIG) {
                    this.handleClickEquipment(snapped, mode);
                }
                else if (['tag', 'tag-eau', 'tag-spanc'].includes(mode)) {
                    this.handleClickSymbol(snapped, mode);
                }
                else if (isSpancPictogramMode(mode)) {
                    this.handleClickSpancPictogram(snapped, mode);
                }
                else if (isAcPictogramMode(mode)) {
                    this.handleClickAcPictogram(snapped, mode);
                }
                break;
        }
    }
    onMouseMove(o) {
        const evt = o.e;
        const fabric = window['fabric'];
        if (this.isDragging) {
            const vpt = this.canvas.viewportTransform;
            const c = this.eventClient(evt);
            vpt[4] += c.x - this.lastPosX;
            vpt[5] += c.y - this.lastPosY;
            this.canvas.requestRenderAll();
            this.lastPosX = c.x;
            this.lastPosY = c.y;
            return;
        }
        const ptr = this.getCanvasPointer(evt);
        const snapped = this.snapToGrid(new fabric.Point(ptr.x, ptr.y));
        // Preview polyligne
        if (this._isPolylineDrawing() && this.lastPoint) {
            const mode = this._currentMode();
            const previewEnd = ['wall', 'cloison'].includes(mode)
                ? this.snapPolylinePoint(ptr)
                : { x: ptr.x, y: ptr.y }; // réseaux : aperçu sans magnétisme
            if (this.previewLine)
                this.canvas.remove(this.previewLine);
            this.previewLine = new fabric.Line([this.lastPoint.x, this.lastPoint.y, previewEnd.x, previewEnd.y], { stroke: '#94a3b8', strokeWidth: 2, strokeDashArray: [6, 4], selectable: false, evented: false });
            this.canvas.add(this.previewLine);
            this.canvas.renderAll();
        }
        // Preview rect (room, room-sketch, stair, hazard zones)
        if (this.isDrawingRect && this.rectStart) {
            if (this.previewRect)
                this.canvas.remove(this.previewRect);
            const mode = this._currentMode();
            const snapEnd = mode === 'room-sketch' ? this.snapForRoomSketch(ptr) : snapped;
            const x = Math.min(this.rectStart.x, snapEnd.x);
            const y = Math.min(this.rectStart.y, snapEnd.y);
            const w = Math.abs(snapEnd.x - this.rectStart.x);
            const h = Math.abs(snapEnd.y - this.rectStart.y);
            const hazardCfg = HAZARD_CONFIG[mode];
            this.previewRect = new fabric.Rect({
                left: x, top: y, width: w, height: h,
                fill: mode === 'room-sketch' ? 'rgba(59,130,246,0.08)' :
                    hazardCfg ? hazardCfg.fill : 'rgba(99,102,241,0.06)',
                stroke: mode === 'room-sketch' ? '#3b82f6' :
                    hazardCfg ? hazardCfg.stroke : '#6366f1',
                strokeWidth: 1, strokeDashArray: [6, 3],
                selectable: false, evented: false,
            });
            this.canvas.add(this.previewRect);
            this.canvas.renderAll();
        }
    }
    onMouseUp(o) {
        const evt = o.e;
        if (this.isDragging) {
            this.isDragging = false;
            // Sélection-rectangle toujours désactivée (cf. setMode) pour préserver le
            // pan au glisser en mode sélection.
            this.canvas.selection = false;
            this.canvas.setViewportTransform(this.canvas.viewportTransform);
            return;
        }
        if (this.isDrawingRect && this.rectStart) {
            const fabric = window['fabric'];
            const ptr = this.getCanvasPointer(evt);
            const snapped = this.snapToGrid(new fabric.Point(ptr.x, ptr.y));
            if (this.previewRect) {
                this.canvas.remove(this.previewRect);
                this.previewRect = null;
            }
            const mode = this._currentMode();
            const snapEnd = mode === 'room-sketch' ? this.snapForRoomSketch(ptr) : snapped;
            const x = Math.min(this.rectStart.x, snapEnd.x);
            const y = Math.min(this.rectStart.y, snapEnd.y);
            const w = Math.abs(snapEnd.x - this.rectStart.x);
            const h = Math.abs(snapEnd.y - this.rectStart.y);
            if (w >= 20 && h >= 20) {
                if (mode === 'room') {
                    // Crée 4 murs réels (fabric.Line) formant le rectangle
                    const corners = [
                        [x, y, x + w, y],
                        [x + w, y, x + w, y + h],
                        [x, y + h, x + w, y + h],
                        [x, y, x, y + h],
                    ];
                    corners.forEach(([x1, y1, x2, y2]) => {
                        this.canvas.add(this.createWallLine(x1, y1, x2, y2));
                    });
                    this.refreshNodeHandles();
                    this.onWallsChanged?.();
                }
                else if (mode === 'room-sketch') {
                    // Post-création snap : coller le nouveau box sur les bords proches des boxes existants
                    const EDGE_SNAP = 20;
                    const existingBoxes = this.canvas.getObjects().filter((o) => o.myType === 'RoomBox');
                    let nx = x, ny = y, nw = w, nh = h;
                    for (const box of existingBoxes) {
                        const bx = box.left, by = box.top;
                        const bw = box.width * (box.scaleX ?? 1);
                        const bh = box.height * (box.scaleY ?? 1);
                        if (Math.abs(nx - (bx + bw)) <= EDGE_SNAP)
                            nx = bx + bw;
                        else if (Math.abs(nx - bx) <= EDGE_SNAP)
                            nx = bx;
                        if (Math.abs((nx + nw) - bx) <= EDGE_SNAP)
                            nw = bx - nx;
                        else if (Math.abs((nx + nw) - (bx + bw)) <= EDGE_SNAP)
                            nw = (bx + bw) - nx;
                        if (Math.abs(ny - (by + bh)) <= EDGE_SNAP)
                            ny = by + bh;
                        else if (Math.abs(ny - by) <= EDGE_SNAP)
                            ny = by;
                        if (Math.abs((ny + nh) - by) <= EDGE_SNAP)
                            nh = by - ny;
                        else if (Math.abs((ny + nh) - (by + bh)) <= EDGE_SNAP)
                            nh = (by + bh) - ny;
                    }
                    this.canvas.add(nw > 10 && nh > 10 ? this.createRoomBox(nx, ny, nw, nh) : this.createRoomBox(x, y, w, h));
                    // Garder le nouveau RoomBox sélectionnable en mode room-sketch
                    this.applyModeSelectability(this._currentMode());
                    this.canvas.renderAll();
                }
                else if (mode === 'stair') {
                    this.canvas.add(this.createStairObject(x, y, w, h));
                }
                else if (mode in HAZARD_CONFIG) {
                    const cfg = HAZARD_CONFIG[mode];
                    this.canvas.add(this.createHazardZone(x, y, w, h, cfg));
                    this.onWallsChanged?.();
                }
                this.canvas.renderAll();
            }
            this.isDrawingRect = false;
            this.rectStart = null;
        }
    }
    // ── Polyligne ────────────────────────────────────────────────────────────────
    handlePolylineClick(pt, mode) {
        const fabric = window['fabric'];
        if (!this._isPolylineDrawing()) {
            this._isPolylineDrawing.set(true);
            this.lastPoint = new fabric.Point(pt.x, pt.y);
            return;
        }
        if (!this.lastPoint)
            return;
        let segment;
        if (mode === 'wall') {
            segment = this.createWallLine(this.lastPoint.x, this.lastPoint.y, pt.x, pt.y);
        }
        else if (mode === 'cloison') {
            segment = this.createCloisonLine(this.lastPoint.x, this.lastPoint.y, pt.x, pt.y);
        }
        else {
            segment = this.createPipeLine(this.lastPoint, new fabric.Point(pt.x, pt.y), mode);
        }
        this.canvas.add(segment);
        // Les traits de réseau passent SOUS les autres dessins (fosses, boîtes de
        // branchement, pictogrammes…) : on les renvoie au fond, juste au-dessus du
        // fond de carte / étage fantôme.
        if (this.isPipeMode(mode))
            this.sendNetworkToBack(segment);
        this.activePolylineLines.push(segment);
        this.lastPoint = new fabric.Point(pt.x, pt.y);
        if (this.previewLine) {
            this.canvas.remove(this.previewLine);
            this.previewLine = null;
        }
        this.canvas.renderAll();
        if (['wall', 'cloison'].includes(mode))
            this.refreshNodeHandles();
        this.onWallsChanged?.();
    }
    /**
     * Crée un mur porteur (fabric.Line) avec un wallId unique pour le cascade delete.
     * Utilise des coords relatives au centre pour être compatible avec calcLinePoints().
     */
    createWallLine(x1, y1, x2, y2) {
        const fabric = window['fabric'];
        const line = new fabric.Line([x1, y1, x2, y2], {
            strokeWidth: 5, stroke: '#18181b',
            selectable: true,
            myType: 'Mur',
            data: { material: 'Agglo', wallId: crypto.randomUUID() },
        });
        return line;
    }
    /**
     * Crée une cloison (non porteur) — trait plus fin et tirets.
     */
    createCloisonLine(x1, y1, x2, y2) {
        const fabric = window['fabric'];
        return new fabric.Line([x1, y1, x2, y2], {
            strokeWidth: 3, stroke: '#52525b',
            strokeDashArray: [8, 4],
            selectable: true,
            myType: 'Cloison',
            data: { material: 'Plâtre', wallId: crypto.randomUUID() },
        });
    }
    createPipeLine(p1, p2, mode) {
        const fabric = window['fabric'];
        const styles = {
            'pipe-aep': { stroke: '#2563eb', strokeWidth: 3, myType: 'PipeAEP' },
            'pipe-eu': { stroke: '#7c3aed', strokeWidth: 3, myType: 'PipeEU' },
            'pipe-em': { stroke: '#a16207', strokeWidth: 3, myType: 'PipeEM' },
            'pipe-ev': { stroke: '#78350f', strokeWidth: 3, myType: 'PipeEV' },
            'pipe-vent': { stroke: '#6b7280', strokeWidth: 2, myType: 'PipeVent', strokeDashArray: [3, 3] },
            'pipe-ep': { stroke: '#22d3ee', strokeWidth: 3, myType: 'PipeEP', strokeDashArray: [8, 4] },
            'pipe-gaz': { stroke: '#f59e0b', strokeWidth: 3, myType: 'PipeGaz', strokeDashArray: [10, 4] },
            'pipe-elec': { stroke: '#eab308', strokeWidth: 3, myType: 'PipeElec', strokeDashArray: [6, 3] },
            'pipe-fibre': { stroke: '#06b6d4', strokeWidth: 2, myType: 'PipeFibre', strokeDashArray: [4, 4] },
        };
        const s = styles[mode] || styles['pipe-aep'];
        return new fabric.Line([p1.x, p1.y, p2.x, p2.y], {
            selectable: true, data: {}, ...s,
        });
    }
    finishPolyline() {
        this._isPolylineDrawing.set(false);
        this.lastPoint = null;
        this.activePolylineLines = [];
        if (this.previewLine) {
            this.canvas.remove(this.previewLine);
            this.previewLine = null;
        }
        this.canvas.renderAll();
    }
    /** Double-clic : termine le tracé en cours. Le 2ᵉ clic du double-clic a créé
     *  un segment quasi nul (le curseur n'a pas bougé) — on le retire avant de
     *  clôturer pour ne pas laisser de point parasite. */
    onDoubleClick(o) {
        if (!this._isPolylineDrawing())
            return;
        const last = this.activePolylineLines[this.activePolylineLines.length - 1];
        if (last && this.lineLength(last) < 6) {
            this.canvas.remove(last);
            this.activePolylineLines.pop();
            if (['wall', 'cloison'].includes(this._currentMode()))
                this.refreshNodeHandles();
            this.onWallsChanged?.();
        }
        this.finishPolyline();
    }
    /** Longueur (px) d'un segment fabric.Line, indépendante du recentrage. */
    lineLength(line) {
        return Math.hypot((line.x2 - line.x1), (line.y2 - line.y1));
    }
    /** Vrai si le mode courant est un tracé de réseau (canalisation). */
    isPipeMode(mode) {
        return typeof mode === 'string' && mode.startsWith('pipe-');
    }
    /** Vrai si l'objet peut être déplacé au clic pendant un tracé réseau. */
    isUserMovable(obj) {
        return !!obj && !NON_MOVABLE_IN_DRAW.has(obj.myType);
    }
    /** Renvoie un objet réseau au fond, juste au-dessus du fond de carte et des
     *  étages fantômes (qui doivent rester tout en bas). */
    sendNetworkToBack(obj) {
        this.canvas.sendToBack(obj);
        const base = this.canvas.getObjects()
            .filter(o => o.myType === 'Backdrop' || o.myType === 'GhostFloor').length;
        if (base > 0)
            this.canvas.moveTo(obj, base);
    }
    /** Reclasse tous les traits de réseau sous les autres dessins (appelé au
     *  chargement d'un projet pour garantir l'ordre même sur les plans anciens). */
    restackNetworksBelow() {
        const isPipe = (o) => typeof o.myType === 'string'
            && o.myType.startsWith('Pipe') && o.myType !== 'PipeMeasurement';
        this.canvas.getObjects().filter(isPipe).forEach(o => this.sendNetworkToBack(o));
    }
    // ── Escalier ─────────────────────────────────────────────────────────────────
    createStairObject(x, y, w, h) {
        const fabric = window['fabric'];
        const stepCount = Math.max(3, Math.round(h / 25));
        const lines = [];
        // Contour du rectangle
        lines.push(new fabric.Line([0, 0, w, 0], { stroke: '#374151', strokeWidth: 2 }));
        lines.push(new fabric.Line([w, 0, w, h], { stroke: '#374151', strokeWidth: 2 }));
        lines.push(new fabric.Line([0, h, w, h], { stroke: '#374151', strokeWidth: 2 }));
        lines.push(new fabric.Line([0, 0, 0, h], { stroke: '#374151', strokeWidth: 2 }));
        // Marches horizontales
        for (let i = 1; i < stepCount; i++) {
            const y0 = (h / stepCount) * i;
            lines.push(new fabric.Line([0, y0, w, y0], { stroke: '#374151', strokeWidth: 1 }));
        }
        // Flèche montante
        lines.push(new fabric.Line([w / 2, h * 0.8, w / 2, h * 0.2], {
            stroke: '#374151', strokeWidth: 2,
        }));
        const group = new fabric.Group(lines, {
            left: x, top: y,
            selectable: true,
            myType: 'Stair',
            data: { label: 'Escalier' },
        });
        return group;
    }
    // ── Zone à risque ────────────────────────────────────────────────────────────
    createHazardZone(x, y, w, h, cfg) {
        const fabric = window['fabric'];
        const rect = new fabric.Rect({
            left: x, top: y, width: w, height: h,
            fill: cfg.fill,
            stroke: cfg.stroke, strokeWidth: 2, strokeDashArray: [8, 4],
            selectable: true,
            lockScalingX: true, lockScalingY: true,
            myType: 'HazardZone',
            data: { hazardType: cfg.hazardType, label: cfg.label, hazardSurface: 'sol', linkedSampleId: null },
        });
        return rect;
    }
    // ── Croquis pièces ──────────────────────────────────────────────────────────
    createRoomBox(x, y, w, h) {
        const fabric = window['fabric'];
        return new fabric.Rect({
            left: x, top: y, width: w, height: h,
            fill: 'rgba(59,130,246,0.08)',
            stroke: '#3b82f6', strokeWidth: 1.5, strokeDashArray: [8, 4],
            selectable: true,
            myType: 'RoomBox',
            data: { label: 'Pièce' },
        });
    }
    /**
     * Snap d'un point sur les bords (X et Y) des RoomBox existantes.
     * Utilise la grille (20px) comme fallback si aucune boîte n'est assez proche.
     */
    snapForRoomSketch(ptr, snapDist = 25) {
        const boxes = this.canvas.getObjects().filter((o) => o.myType === 'RoomBox');
        let snapX = Math.round(ptr.x / 20) * 20;
        let snapY = Math.round(ptr.y / 20) * 20;
        let bestX = snapDist;
        let bestY = snapDist;
        for (const box of boxes) {
            const bx = box.left, by = box.top;
            const bw = box.width * (box.scaleX ?? 1);
            const bh = box.height * (box.scaleY ?? 1);
            for (const ex of [bx, bx + bw]) {
                const d = Math.abs(ptr.x - ex);
                if (d < bestX) {
                    bestX = d;
                    snapX = ex;
                }
            }
            for (const ey of [by, by + bh]) {
                const d = Math.abs(ptr.y - ey);
                if (d < bestY) {
                    bestY = d;
                    snapY = ey;
                }
            }
        }
        return { x: snapX, y: snapY };
    }
    /**
     * Génère l'enveloppe de l'appartement à partir des RoomBox présentes sur le canvas.
     * - Les segments partagés par ≥ 2 pièces → Cloison
     * - Les segments extérieurs (1 seule pièce) → Mur porteur
     * Supprime ensuite tous les RoomBox.
     */
    generateEnvelope() {
        const roomBoxes = this.canvas.getObjects().filter((o) => o.myType === 'RoomBox');
        if (roomBoxes.length === 0)
            return;
        const rects = roomBoxes.map((box) => ({
            x: box.left,
            y: box.top,
            w: box.width * (box.scaleX ?? 1),
            h: box.height * (box.scaleY ?? 1),
        }));
        // Pré-snap : supprimer les petits espaces entre pièces adjacentes (≤ 20px)
        const GAP_SNAP = 20;
        for (let i = 0; i < rects.length; i++) {
            for (let j = i + 1; j < rects.length; j++) {
                const a = rects[i], b = rects[j];
                const gapR = b.x - (a.x + a.w);
                if (gapR > 0 && gapR <= GAP_SNAP) {
                    const mid = (a.x + a.w + b.x) / 2;
                    a.w = mid - a.x;
                    const oldBR = b.x + b.w;
                    b.x = mid;
                    b.w = oldBR - mid;
                }
                const gapL = a.x - (b.x + b.w);
                if (gapL > 0 && gapL <= GAP_SNAP) {
                    const mid = (b.x + b.w + a.x) / 2;
                    b.w = mid - b.x;
                    const oldAR = a.x + a.w;
                    a.x = mid;
                    a.w = oldAR - mid;
                }
                const gapB = b.y - (a.y + a.h);
                if (gapB > 0 && gapB <= GAP_SNAP) {
                    const mid = (a.y + a.h + b.y) / 2;
                    a.h = mid - a.y;
                    const oldBB = b.y + b.h;
                    b.y = mid;
                    b.h = oldBB - mid;
                }
                const gapT = a.y - (b.y + b.h);
                if (gapT > 0 && gapT <= GAP_SNAP) {
                    const mid = (b.y + b.h + a.y) / 2;
                    b.h = mid - b.y;
                    const oldAB = a.y + a.h;
                    a.y = mid;
                    a.h = oldAB - mid;
                }
            }
        }
        const TOLERANCE = 5;
        const segs = [];
        for (const r of rects) {
            segs.push({ axis: 'H', fixed: r.y, from: r.x, to: r.x + r.w }); // top
            segs.push({ axis: 'H', fixed: r.y + r.h, from: r.x, to: r.x + r.w }); // bottom
            segs.push({ axis: 'V', fixed: r.x, from: r.y, to: r.y + r.h }); // left
            segs.push({ axis: 'V', fixed: r.x + r.w, from: r.y, to: r.y + r.h }); // right
        }
        const groupBy = (axis) => {
            const axisSt = segs.filter(s => s.axis === axis);
            const groups = new Map();
            for (const seg of axisSt) {
                let placed = false;
                for (const [key, arr] of groups) {
                    if (Math.abs(key - seg.fixed) <= TOLERANCE) {
                        arr.push(seg);
                        placed = true;
                        break;
                    }
                }
                if (!placed)
                    groups.set(seg.fixed, [seg]);
            }
            return groups;
        };
        const processGroups = (groups, axis) => {
            for (const [fixed, arr] of groups) {
                const pts = new Set();
                arr.forEach(s => { pts.add(Math.round(s.from)); pts.add(Math.round(s.to)); });
                const sorted = [...pts].sort((a, b) => a - b);
                for (let i = 0; i < sorted.length - 1; i++) {
                    const from = sorted[i], to = sorted[i + 1];
                    if (to - from < 2)
                        continue;
                    const mid = (from + to) / 2;
                    const coverage = arr.filter(s => s.from <= mid && s.to >= mid).length;
                    if (coverage === 0)
                        continue;
                    const x1 = axis === 'H' ? from : fixed;
                    const y1 = axis === 'H' ? fixed : from;
                    const x2 = axis === 'H' ? to : fixed;
                    const y2 = axis === 'H' ? fixed : to;
                    this.canvas.add(coverage >= 2
                        ? this.createCloisonLine(x1, y1, x2, y2)
                        : this.createWallLine(x1, y1, x2, y2));
                }
            }
        };
        processGroups(groupBy('H'), 'H');
        processGroups(groupBy('V'), 'V');
        roomBoxes.forEach((box) => this.canvas.remove(box));
        this.refreshNodeHandles();
        this.onWallsChanged?.();
        this.canvas.renderAll();
    }
    /**
     * Bascule un mur porteur en cloison ou vice-versa.
     */
    toggleWallType(obj) {
        if (!obj)
            return;
        if (obj.myType === 'Mur') {
            obj.set({ myType: 'Cloison', strokeWidth: 3, stroke: '#52525b', strokeDashArray: [8, 4] });
            obj.data = { ...(obj.data || {}), material: obj.data?.material || 'Plâtre' };
        }
        else if (obj.myType === 'Cloison') {
            obj.set({ myType: 'Mur', strokeWidth: 5, stroke: '#18181b', strokeDashArray: null });
            obj.data = { ...(obj.data || {}), material: obj.data?.material || 'Agglo' };
        }
        this.canvas.renderAll();
        this.onWallsChanged?.();
    }
    // ── Porte / Fenêtre ─────────────────────────────────────────────────────────
    handleDoorWindow(pt, mode) {
        const fabric = window['fabric'];
        const snap = this.findNearestWallSnap(pt, 80);
        // Refuser le placement si aucun mur ou cloison n'est à portée
        if (!snap)
            return;
        const isDoor = mode === 'door';
        const openingWidth = isDoor ? 80 : 60;
        const openingHeight = isDoor ? 8 : 6;
        const left = snap.projPt.x;
        const top = snap.projPt.y;
        const angle = snap.angle;
        const rect = new fabric.Rect({
            left, top,
            width: openingWidth, height: openingHeight,
            originX: 'center', originY: 'center',
            fill: isDoor ? 'rgba(251,191,36,0.6)' : 'rgba(125,211,252,0.6)',
            stroke: isDoor ? '#d97706' : '#0284c7',
            strokeWidth: 2,
            angle,
            selectable: true,
            lockScalingX: true, lockScalingY: true,
            myType: isDoor ? 'Door' : 'Window',
            data: {
                label: isDoor ? 'Porte' : 'Fenêtre',
                parentWallId: snap.wallId,
            },
        });
        this.canvas.add(rect);
        this.canvas.renderAll();
    }
    // ── Équipements techniques ───────────────────────────────────────────────────
    handleClickEquipment(pt, mode) {
        const fabric = window['fabric'];
        const cfg = EQUIPMENT_CONFIG[mode];
        if (!cfg)
            return;
        const r = 8;
        const dot = new fabric.Circle({
            radius: r, fill: cfg.color,
            stroke: 'rgba(255,255,255,0.6)', strokeWidth: 1,
        });
        const txt = new fabric.Text(cfg.symbol, {
            left: r * 2 + 3, top: 0,
            originX: 'left', originY: 'center',
            fontSize: 12, fontFamily: 'Arial', fontWeight: 'bold', fill: '#18181b',
        });
        const group = new fabric.Group([dot, txt], {
            left: pt.x, top: pt.y,
            originX: 'center', originY: 'center',
            myType: 'Equipment', selectable: true, evented: true,
            data: { subtype: cfg.subtype, label: cfg.label },
        });
        this.canvas.add(group);
        this.canvas.renderAll();
    }
    // ── Flèche Nord ──────────────────────────────────────────────────────────────
    handleNorthArrow(pt) {
        const fabric = window['fabric'];
        const text = new fabric.Text('↑N', {
            left: pt.x, top: pt.y,
            originX: 'center', originY: 'center',
            fontSize: 20, fontFamily: 'Arial', fontWeight: 'bold', fill: '#18181b',
            backgroundColor: 'rgba(255,255,255,0.85)', padding: 6,
            myType: 'NorthArrow', selectable: true,
            data: { label: 'Nord' },
        });
        this.canvas.add(text);
        this.canvas.renderAll();
    }
    // ── Tags SPANC / repères ─────────────────────────────────────────────────────
    handleClickSymbol(pt, mode) {
        const fabric = window['fabric'];
        const prefixes = { 'tag': 'P', 'tag-eau': 'E', 'tag-spanc': 'S' };
        const myTypes = { 'tag': 'PTag', 'tag-eau': 'ETag', 'tag-spanc': 'STag' };
        const colors = { 'tag': '#6366f1', 'tag-eau': '#0284c7', 'tag-spanc': '#f59e0b' };
        const myType = myTypes[mode] || 'PTag';
        const prefix = prefixes[mode] || 'P';
        const color = colors[mode] || '#6366f1';
        // Auto-incrément : compte les tags existants du même type pour numéroter P1, P2...
        const existingCount = this.canvas.getObjects()
            .filter(o => o.myType === myType)
            .length;
        const label = `${prefix}${existingCount + 1}`;
        const r = 8;
        const dot = new fabric.Circle({
            radius: r, fill: color,
            stroke: 'rgba(255,255,255,0.6)', strokeWidth: 1,
        });
        const txt = new fabric.Text(label, {
            left: r * 2 + 3, top: 0,
            originX: 'left', originY: 'center',
            fontSize: 12, fontFamily: 'Arial', fontWeight: 'bold', fill: '#18181b',
        });
        const group = new fabric.Group([dot, txt], {
            left: pt.x, top: pt.y,
            originX: 'center', originY: 'center',
            myType, selectable: true, evented: true,
        });
        this.canvas.add(group);
        this.canvas.renderAll();
    }
    // ── Pictogrammes SPANC (vectoriels) ──────────────────────────────────────────
    handleClickSpancPictogram(pt, mode) {
        const fabric = window['fabric'];
        const def = SPANC_PICTOGRAMS[mode];
        if (!def)
            return;
        const primitives = def.build(fabric);
        const group = new fabric.Group(primitives, {
            left: pt.x, top: pt.y,
            originX: 'center', originY: 'center',
            myType: SPANC_PICTOGRAM_TYPE, selectable: true, evented: true,
            data: { spancKind: mode, label: def.label },
        });
        this.canvas.add(group);
        this.canvas.renderAll();
    }
    // ── Pictogrammes AC (vectoriels) ─────────────────────────────────────────────
    handleClickAcPictogram(pt, mode) {
        const fabric = window['fabric'];
        const def = AC_PICTOGRAMS[mode];
        if (!def)
            return;
        const primitives = def.build(fabric);
        const group = new fabric.Group(primitives, {
            left: pt.x, top: pt.y,
            originX: 'center', originY: 'center',
            myType: AC_PICTOGRAM_TYPE, selectable: true, evented: true,
            data: { acKind: mode, label: def.label },
        });
        this.canvas.add(group);
        this.canvas.renderAll();
    }
    // ── Prélèvements amiante ─────────────────────────────────────────────────────
    handleClickPrelevement(pt) {
        const fabric = window['fabric'];
        const existingCount = this.canvas.getObjects()
            .filter(o => o.myType === 'HazardSample').length;
        // Pose guidée : si un prélèvement CRI est en attente, on utilise son label
        // comme identifiant affiché ; sinon pose libre auto-incrémentée (P{n+1}).
        const guided = this._nextSample;
        const sampleId = guided ? guided.label : `P${existingCount + 1}`;
        // Auto-detect surface: if placed near a wall/cloison, default to 'mur'
        const WALL_PROX = 40;
        const walls = this.canvas.getObjects()
            .filter(o => o.myType === 'Mur' || o.myType === 'Cloison');
        const nearWall = walls.some(wall => {
            const { p1, p2 } = this.getAbsoluteLineEnds(wall);
            return this.ptSegDist(pt, p1, p2) <= WALL_PROX;
        });
        const hazardSurface = nearWall ? 'mur' : 'sol';
        const r = 11;
        // Cercle ambre avec bord
        const dot = new fabric.Circle({
            radius: r,
            fill: '#f59e0b', stroke: '#92400e', strokeWidth: 2,
            originX: 'center', originY: 'center',
        });
        // Texte centré
        const txt = new fabric.Text(sampleId, {
            fontSize: 10, fontFamily: 'Arial', fontWeight: 'bold', fill: '#fff',
            originX: 'center', originY: 'center',
        });
        const group = new fabric.Group([dot, txt], {
            left: pt.x, top: pt.y,
            originX: 'center', originY: 'center',
            selectable: true, evented: true,
            lockScalingX: true, lockScalingY: true,
            myType: 'HazardSample',
            data: { sampleId, hazardSurface, label: sampleId, criSampleId: guided?.id },
        });
        this.canvas.add(group);
        if (guided) {
            this._nextSample = null;
            this.onSamplePlaced?.({ criSampleId: guided.id, label: guided.label, position: { x: pt.x, y: pt.y } });
        }
        this.onWallsChanged?.();
        this.canvas.renderAll();
    }
    /** Distance from point p to segment (a, b) */
    ptSegDist(p, a, b) {
        const dx = b.x - a.x, dy = b.y - a.y;
        const lenSq = dx * dx + dy * dy;
        if (lenSq === 0)
            return Math.hypot(p.x - a.x, p.y - a.y);
        const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq));
        return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
    }
    // ── Portes / Fenêtres contraintes ───────────────────────────────────────────
    /**
     * Contraint une porte/fenêtre à glisser sur son mur parent pendant le drag.
     * Si le mur n'est pas trouvé, on laisse libre.
     */
    constrainOpeningToWall(opening) {
        const wallId = opening.data?.parentWallId;
        const wall = this.canvas.getObjects().find((o) => ['Mur', 'Cloison'].includes(o.myType) && o.data?.wallId === wallId);
        if (!wall)
            return;
        const { p1, p2 } = this.getAbsoluteLineEnds(wall);
        this.projectOpeningOntoWall(opening, p1, p2);
    }
    /**
     * Remet toutes les portes/fenêtres d'un mur sur sa nouvelle géométrie
     * (appelé pendant le drag d'un nœud).
     */
    updateOpeningsOnWall(wall, x1, y1, x2, y2) {
        const wallId = wall.data?.wallId;
        if (!wallId)
            return;
        const openings = this.canvas.getObjects().filter((o) => ['Door', 'Window'].includes(o.myType) && o.data?.parentWallId === wallId);
        if (openings.length === 0)
            return;
        const p1 = { x: x1, y: y1 }, p2 = { x: x2, y: y2 };
        openings.forEach((op) => this.projectOpeningOntoWall(op, p1, p2));
    }
    /** Projette le centre d'une ouverture sur le segment [p1,p2] et met à jour angle. */
    projectOpeningOntoWall(opening, p1, p2) {
        const dx = p2.x - p1.x, dy = p2.y - p1.y;
        const len2 = dx * dx + dy * dy;
        if (len2 === 0)
            return;
        const t = Math.max(0.05, Math.min(0.95, ((opening.left - p1.x) * dx + (opening.top - p1.y) * dy) / len2));
        opening.set({
            left: p1.x + t * dx,
            top: p1.y + t * dy,
            angle: Math.atan2(dy, dx) * 180 / Math.PI,
        });
        opening.setCoords?.();
    }
    // ── Snap endpoint au drop ────────────────────────────────────────────────────
    /**
     * Après déplacement d'un mur, recolle ses extrémités aux extrémités voisines
     * des autres murs (tolérance 20px) et aligne sur la grille sinon.
     * Retourne true si un snap a eu lieu.
     */
    snapLineEndpoints(line, snapDist = 20) {
        const others = this.canvas.getObjects().filter((o) => ['Mur', 'Cloison'].includes(o.myType) && o !== line);
        const moved = this.getAbsoluteLineEnds(line);
        let x1 = moved.p1.x, y1 = moved.p1.y;
        let x2 = moved.p2.x, y2 = moved.p2.y;
        let didSnap = false;
        // Pour chaque extrémité du mur déplacé, chercher le nœud le plus proche
        for (const other of others) {
            const ends = this.getAbsoluteLineEnds(other);
            for (const pt of [ends.p1, ends.p2]) {
                if (Math.hypot(x1 - pt.x, y1 - pt.y) <= snapDist) {
                    x1 = pt.x;
                    y1 = pt.y;
                    didSnap = true;
                }
                if (Math.hypot(x2 - pt.x, y2 - pt.y) <= snapDist) {
                    x2 = pt.x;
                    y2 = pt.y;
                    didSnap = true;
                }
            }
        }
        // Snap sur la grille si aucun voisin trouvé
        const g = 20;
        if (!didSnap) {
            x1 = Math.round(x1 / g) * g;
            y1 = Math.round(y1 / g) * g;
            x2 = Math.round(x2 / g) * g;
            y2 = Math.round(y2 / g) * g;
            didSnap = true;
        }
        line.set({ x1, y1, x2, y2 });
        if (typeof line._setWidthHeight === 'function')
            line._setWidthHeight();
        line.setCoords();
        return didSnap;
    }
    // ── Snap mur le plus proche ──────────────────────────────────────────────────
    findNearestWallSnap(pt, maxDist) {
        const walls = this.canvas.getObjects().filter((o) => ['Mur', 'Cloison'].includes(o.myType));
        let minDist = maxDist;
        let best = null;
        for (const wall of walls) {
            const { p1, p2 } = this.getAbsoluteLineEnds(wall);
            const dx = p2.x - p1.x;
            const dy = p2.y - p1.y;
            const len2 = dx * dx + dy * dy;
            if (len2 === 0)
                continue;
            const t = Math.max(0, Math.min(1, ((pt.x - p1.x) * dx + (pt.y - p1.y) * dy) / len2));
            const projX = p1.x + t * dx;
            const projY = p1.y + t * dy;
            const dist = Math.hypot(pt.x - projX, pt.y - projY);
            if (dist < minDist) {
                minDist = dist;
                best = {
                    projPt: { x: projX, y: projY },
                    angle: Math.atan2(dy, dx) * 180 / Math.PI,
                    wallId: wall.data?.wallId ?? null,
                };
            }
        }
        return best;
    }
    getAbsoluteLineEnds(line) {
        // Calcul robuste sans passer par getCenterPoint() ni calcLinePoints() :
        // line.x1/y1/x2/y2 sont les coords absolues de construction.
        // Si le mur a été glissé sans mise à jour (drag Fabric natif), line.left ≠ min(x1,x2).
        // L'offset de glissement est line.left - min(x1,x2).
        const dx = (line.left ?? 0) - Math.min(line.x1 ?? 0, line.x2 ?? 0);
        const dy = (line.top ?? 0) - Math.min(line.y1 ?? 0, line.y2 ?? 0);
        return {
            p1: { x: (line.x1 ?? 0) + dx, y: (line.y1 ?? 0) + dy },
            p2: { x: (line.x2 ?? 0) + dx, y: (line.y2 ?? 0) + dy },
        };
    }
    // ── Cascade delete ──────────────────────────────────────────────────────────
    cascadeDeleteOpenings(deletedWallIds) {
        if (deletedWallIds.length === 0)
            return;
        const idSet = new Set(deletedWallIds);
        const toRemove = this.canvas.getObjects().filter((o) => ['Door', 'Window'].includes(o.myType) && idSet.has(o.data?.parentWallId));
        toRemove.forEach((o) => this.canvas.remove(o));
        if (toRemove.length > 0)
            this.canvas.renderAll();
    }
    // ── Étage fantôme (ghost floor) ─────────────────────────────────────────────
    /** Affiche les objets d'un étage précédent en très atténué (8% opacité). */
    showGhostFloor(rawObjects) {
        this.clearGhostFloor();
        if (!rawObjects?.length)
            return;
        const fabric = window['fabric'];
        fabric.util.enlivenObjects(rawObjects, (objects) => {
            objects.forEach((obj) => {
                obj.set({ opacity: 0.08, selectable: false, evented: false, hasControls: false, hasBorders: false });
                obj.myType = 'GhostFloor';
                this.canvas.add(obj);
                this.canvas.sendToBack(obj);
            });
            this.canvas.requestRenderAll();
        }, 'fabric');
    }
    /** Supprime tous les objets fantôme du canvas. */
    clearGhostFloor() {
        const ghosts = this.canvas.getObjects().filter(o => o.myType === 'GhostFloor');
        ghosts.forEach(g => this.canvas.remove(g));
    }
    /**
     * Copie les murs extérieurs (Mur) d'un étage sur le canvas courant.
     * Utilisé pour repartir des murs de l'étage inférieur sur un nouvel étage.
     */
    copyObjectsFromFloor(rawObjects) {
        if (!rawObjects?.length)
            return;
        const fabric = window['fabric'];
        const wallObjects = rawObjects.filter(o => o.myType === 'Mur');
        fabric.util.enlivenObjects(wallObjects, (objects) => {
            objects.forEach((obj) => this.canvas.add(obj));
            this.refreshNodeHandles();
            this.onWallsChanged?.();
            this.canvas.requestRenderAll();
        }, 'fabric');
    }
    // ── Projet ──────────────────────────────────────────────────────────────────
    loadFromProject(project) {
        return new Promise(resolve => {
            this.clearGhostFloor();
            this.canvas.loadFromJSON(JSON.stringify({ objects: project.objects }), () => {
                // loadFromJSON réinitialise le fond du canvas (le JSON ne contient pas de
                // clé `background`) → il devient transparent. À l'export JPEG (pas d'alpha)
                // ces zones virent au noir. On restaure le fond blanc systématiquement.
                this.canvas.backgroundColor = '#ffffff';
                this.restackNetworksBelow();
                this.canvas.renderAll();
                this.refreshNodeHandles();
                resolve();
            });
        });
    }
    destroy() {
        this.canvas?.off();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: FabricCanvasService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: FabricCanvasService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: FabricCanvasService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const CADASTRE_TILES = [
    'https://data.geopf.fr/wmts?REQUEST=GetTile&SERVICE=WMTS&VERSION=1.0.0' +
        '&TILEMATRIXSET=PM&LAYER=CADASTRALPARCELS.PARCELLAIRE_EXPRESS' +
        '&STYLE=bdparcellaire&FORMAT=image%2Fpng&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}',
];
const FALLBACK_OSM_STYLE = {
    version: 8,
    sources: {
        osm: {
            type: 'raster',
            tiles: [
                'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
                'https://b.tile.openstreetmap.org/{z}/{x}/{y}.png',
                'https://c.tile.openstreetmap.org/{z}/{x}/{y}.png',
            ],
            tileSize: 256,
            attribution: '© OpenStreetMap contributors',
            maxzoom: 19,
        },
    },
    layers: [{ id: 'osm', type: 'raster', source: 'osm' }],
};
class OsmService {
    map = null;
    /**
     * Résout la classe Map quelle que soit la forme de distribution de maplibre-gl :
     * - ESM natif → `mod.Map`
     * - UMD/CJS empaqueté comme ESM par certains bundlers → `mod.default.Map`
     *   (le package.json upstream déclare `"type": "module"` alors que le main
     *   est un UMD sans `export` nommé, ce qui peut faire que `mod.Map` est
     *   undefined dans certains contextes esbuild/webpack et plante avec
     *   « r is not a constructor »).
     */
    async loadMapClass() {
        const mod = await import('maplibre-gl');
        return mod.Map ?? mod.default?.Map ?? mod.default;
    }
    initMap(container, config) {
        this.loadMapClass().then((Map) => {
            this.map = new Map({
                container,
                style: this.getBaseStyle(config),
                center: [1.888334, 46.603354],
                zoom: 6,
                maxZoom: 19,
                attributionControl: false,
                canvasContextAttributes: { preserveDrawingBuffer: true },
            });
        });
    }
    /**
     * Bascule la couche affichée :
     * - 'osm'       → style vecteur du tileserver (ou raster OSM en fallback)
     * - 'satellite' → imagerie satellite raster
     * - 'cadastre'  → ajoute le cadastre en overlay par-dessus le fond courant
     * - 'custom'    → style alternatif du tileserver (config.tileStyle)
     */
    setLayer(type, config) {
        if (!this.map)
            return;
        if (type === 'cadastre') {
            this.addCadastreOverlay();
            return;
        }
        this.removeCadastreOverlay();
        const center = this.map.getCenter();
        const zoom = this.map.getZoom();
        const style = type === 'satellite' ? this.getSatelliteStyle()
            : type === 'custom' ? this.getCustomStyle(config)
                : this.getBaseStyle(config);
        this.map.setStyle(style);
        this.map.once('style.load', () => this.map.jumpTo({ center, zoom }));
    }
    /** Géocode une adresse via Nominatim et retourne les résultats. */
    async geocode(query) {
        const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=6&addressdetails=0`;
        const res = await fetch(url, { headers: { 'Accept-Language': 'fr,en' } });
        const data = await res.json();
        return data.map(r => ({
            lat: parseFloat(r.lat),
            lng: parseFloat(r.lon),
            label: r.display_name,
        }));
    }
    /** Déplace la carte vers les coordonnées données, zoom minimum 18. */
    flyTo(lat, lng, zoom = 18) {
        this.map?.flyTo({ center: [lng, lat], zoom: Math.min(Math.max(zoom, 18), 19), duration: 1200 });
    }
    getCenter() {
        if (!this.map)
            return null;
        const c = this.map.getCenter();
        return { lat: c.lat, lng: c.lng, zoom: this.map.getZoom() };
    }
    /** Résolution en mètres/px CSS à la position courante (formule MapLibre 512px). */
    getMetersPerPixel() {
        if (!this.map)
            return null;
        const c = this.map.getCenter();
        const zoom = this.map.getZoom();
        return 78271.515 * Math.cos(c.lat * Math.PI / 180) / Math.pow(2, zoom);
    }
    async captureCurrentView() {
        if (!this.map)
            return 'data:image/png;base64,';
        this.map.triggerRepaint();
        await new Promise(r => setTimeout(r, 100));
        return this.map.getCanvas().toDataURL('image/png');
    }
    destroy() {
        this.map?.remove();
        this.map = null;
    }
    /**
     * Capture une vue cartographique en offscreen à la position `geo` donnée.
     * Crée un div temporaire hors-écran, initialise une carte MapLibre, attend le chargement
     * des tuiles (idle), capture le canvas et retourne le dataUrl + l'échelle px/m.
     */
    async captureAt(geo, layer, config, width, height) {
        // Priorité : argument explicite > config > défaut. Taille en px CSS ;
        // l'image réelle sera ×devicePixelRatio.
        const w = width ?? config.backdropCaptureWidth ?? 1280;
        const h = height ?? config.backdropCaptureHeight ?? 960;
        const Map = await this.loadMapClass();
        const container = document.createElement('div');
        container.style.cssText =
            `position:absolute;left:-9999px;top:-9999px;width:${w}px;height:${h}px;overflow:hidden`;
        document.body.appendChild(container);
        const style = layer === 'satellite' ? this.getSatelliteStyle() : this.getBaseStyle(config);
        const map = new Map({
            container,
            style,
            center: [geo.lng, geo.lat],
            zoom: geo.zoom,
            maxZoom: 19,
            attributionControl: false,
            canvasContextAttributes: { preserveDrawingBuffer: true },
        });
        // Attendre style chargé + idle (tuiles rendues)
        await new Promise(resolve => map.once('style.load', resolve));
        await new Promise(resolve => map.once('idle', resolve));
        // Petit délai supplémentaire pour garantir le rendu des tuiles de bordure
        await new Promise(r => setTimeout(r, 300));
        map.triggerRepaint();
        await new Promise(r => setTimeout(r, 100));
        const dataUrl = map.getCanvas().toDataURL('image/png');
        const center = map.getCenter();
        const zoom = map.getZoom();
        const dpr = window.devicePixelRatio || 1;
        const metersPerPx = 78271.515 * Math.cos(center.lat * Math.PI / 180) / Math.pow(2, zoom);
        const scaleVal = dpr / metersPerPx;
        map.remove();
        document.body.removeChild(container);
        return { dataUrl, scaleVal };
    }
    getBaseStyle(config) {
        return config.tileServerUrl
            ? `${config.tileServerUrl}/styles/osm-bright/style.json`
            : FALLBACK_OSM_STYLE;
    }
    getCustomStyle(config) {
        return config.tileServerUrl
            ? `${config.tileServerUrl}/${config.tileStyle}/style.json`
            : FALLBACK_OSM_STYLE;
    }
    getSatelliteStyle() {
        return {
            version: 8,
            sources: {
                satellite: {
                    type: 'raster',
                    tiles: ['https://tiles.g-ordon.io/v1/imagery/{z}/{x}/{y}.webp'],
                    tileSize: 256,
                    // maxzoom = zoom natif estimé des tuiles (analyse entropie par zone).
                    // Hossegor/rural : natif z=18, grandes villes : natif z=19-20.
                    // En déclarant 19, MapLibre fait un oversampling client (meilleure qualité
                    // que le PMTiles serveur) au-delà. La formule d'échelle reste correcte
                    // quel que soit le zoom visuel (camera zoom = scale géographique réelle).
                    maxzoom: 19,
                },
            },
            layers: [{ id: 'satellite', type: 'raster', source: 'satellite' }],
        };
    }
    /** Ajoute le cadastre comme couche raster par-dessus le style vectoriel courant. */
    addCadastreOverlay() {
        const apply = () => {
            if (!this.map.getSource('g-cadastre')) {
                this.map.addSource('g-cadastre', { type: 'raster', tiles: CADASTRE_TILES, tileSize: 256 });
                this.map.addLayer({ id: 'g-cadastre', type: 'raster', source: 'g-cadastre',
                    paint: { 'raster-opacity': 0.65 } });
            }
            else {
                this.map.setLayoutProperty('g-cadastre', 'visibility', 'visible');
            }
        };
        this.map.isStyleLoaded() ? apply() : this.map.once('style.load', apply);
    }
    removeCadastreOverlay() {
        if (this.map?.getLayer('g-cadastre')) {
            this.map.setLayoutProperty('g-cadastre', 'visibility', 'none');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: OsmService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: OsmService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: OsmService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Libellés courts des canalisations par `myType` Fabric. */
const PIPE_LABELS = {
    PipeAEP: 'AEP', PipeEU: 'EU', PipeEM: 'EM (ménagères)', PipeEV: 'EV (vannes)',
    PipeVent: 'Vent.', PipeEP: 'EP', PipeGaz: 'Gaz', PipeElec: 'Élec', PipeFibre: 'Fibre',
};
/** Ordre d'affichage des linéaires de réseaux. */
const PIPE_ORDER = [
    'PipeAEP', 'PipeEU', 'PipeEM', 'PipeEV', 'PipeEP', 'PipeVent',
    'PipeGaz', 'PipeElec', 'PipeFibre',
];

const PIPE_TYPES = new Set(PIPE_ORDER);
const EMPTY_FINISH = {};
/**
 * Analyseur pur : produit une synthèse structurée (`PlanSummary`) à partir d'un
 * `FloorplanProject` sérialisé. Ne dépend PAS d'un canvas Fabric vivant — toutes
 * les associations (pièce↔murs↔ouvertures) sont reconstruites depuis les champs
 * `data` persistés (wallLetters, parentWallId…). Couvre donc tous les niveaux.
 */
class PlanAnalysisService {
    analyze(project, opts) {
        const ppm = project.pixelsPerMeter || 50;
        const criRooms = opts?.criRooms ?? [];
        const floorsInput = (project.floors?.length
            ? project.floors.map(f => ({ meta: { id: f.id, name: f.name, order: f.order ?? 0 }, objects: (f.objects ?? []) }))
            : [{ meta: { id: 'rdc', name: 'RDC', order: 0 }, objects: (project.objects ?? []) }]).sort((a, b) => a.meta.order - b.meta.order);
        const floors = [];
        const allRooms = [];
        const network = { pipes: [], totalLengthM: 0, elements: [] };
        const hazards = { samples: [], zones: [] };
        const pipeTotals = {};
        let wallCountTotal = 0;
        let wallLengthTotal = 0;
        for (const { meta, objects } of floorsInput) {
            const rooms = objects.filter(o => o?.myType === 'DetectedRoom');
            const walls = objects.filter(o => o?.myType === 'Mur' || o?.myType === 'Cloison');
            const doors = objects.filter(o => o?.myType === 'Door');
            const windows = objects.filter(o => o?.myType === 'Window');
            const pipes = objects.filter(o => PIPE_TYPES.has(o?.myType));
            const spanc = objects.filter(o => o?.myType === 'SpancPictogram');
            const ac = objects.filter(o => o?.myType === 'AcPictogram');
            const hSamples = objects.filter(o => o?.myType === 'HazardSample');
            const hZones = objects.filter(o => o?.myType === 'HazardZone');
            // Longueur de chaque mur, indexée par wallId.
            const wallLenById = new Map();
            for (const w of walls) {
                const { p1, p2 } = this.absEnds(w);
                const lenM = Math.hypot(p2.x - p1.x, p2.y - p1.y) / ppm;
                wallLengthTotal += lenM;
                const id = w.data?.wallId;
                if (id)
                    wallLenById.set(id, lenM);
            }
            wallCountTotal += walls.length;
            // Pièces du niveau.
            const roomSummaries = rooms.map(room => {
                const d = room.data ?? {};
                const letters = d.wallLetters ?? {};
                const desc = d.roomDescription ?? {};
                const roomWalls = Object.entries(letters)
                    .map(([wallId, letter]) => ({ letter: letter, wallId, lengthM: round1(wallLenById.get(wallId) ?? 0) }))
                    .sort((a, b) => a.letter.localeCompare(b.letter));
                const roomDoors = doors
                    .filter(dr => dr.data?.parentWallId && letters[dr.data.parentWallId] !== undefined)
                    .map(dr => ({
                    wall: dr.data.parentWallId,
                    letter: letters[dr.data.parentWallId] ?? '',
                    type: (dr.data?.doorType ?? 'simple'),
                    isPrimary: !!dr.data?.isPrimary,
                }));
                const roomWindows = windows
                    .filter(wd => wd.data?.parentWallId && letters[wd.data.parentWallId] !== undefined)
                    .map(wd => ({
                    wall: wd.data.parentWallId,
                    letter: letters[wd.data.parentWallId] ?? '',
                    glazing: (wd.data?.glazingType ?? 'simple'),
                }));
                const criId = d.criRoomId ?? null;
                const cri = criId ? criRooms.find(c => c.id === criId) : undefined;
                return {
                    id: d.roomId ?? null,
                    name: d.label || null,
                    areaM2: d.areaM2 ?? 0,
                    isNested: !!d.isNested,
                    floor: { ...meta },
                    centroid: { x: d._cx ?? 0, y: d._cy ?? 0 },
                    materials: {
                        sol: (desc.sol ?? EMPTY_FINISH),
                        mur: (desc.mur ?? EMPTY_FINISH),
                        plafond: (desc.plafond ?? EMPTY_FINISH),
                    },
                    notes: desc.notes ?? d.notes ?? null,
                    walls: roomWalls,
                    openings: {
                        doors: roomDoors,
                        windows: roomWindows,
                        doorCount: roomDoors.length,
                        windowCount: roomWindows.length,
                    },
                    linkedCri: criId ? { id: criId, name: cri?.name ?? (d.label || '') } : null,
                };
            });
            const totalAreaM2 = round2(roomSummaries.filter(r => !r.isNested).reduce((s, r) => s + r.areaM2, 0));
            floors.push({ ...meta, rooms: roomSummaries, totalAreaM2 });
            allRooms.push(...roomSummaries);
            // Réseaux.
            for (const pipe of pipes) {
                const { p1, p2 } = this.absEnds(pipe);
                const lenM = Math.hypot(p2.x - p1.x, p2.y - p1.y) / ppm;
                pipeTotals[pipe.myType] = (pipeTotals[pipe.myType] ?? 0) + lenM;
            }
            for (const p of spanc) {
                network.elements.push({ family: 'spanc', kind: p.data?.spancKind ?? '', label: p.data?.label ?? '', position: { x: p.left ?? 0, y: p.top ?? 0 }, floorId: meta.id });
            }
            for (const p of ac) {
                network.elements.push({ family: 'ac', kind: p.data?.acKind ?? '', label: p.data?.label ?? '', position: { x: p.left ?? 0, y: p.top ?? 0 }, floorId: meta.id });
            }
            // Repérage diagnostic.
            for (const s of hSamples) {
                hazards.samples.push({
                    id: s.data?.sampleId ?? s.data?.label ?? '',
                    label: s.data?.label ?? s.data?.sampleId ?? '',
                    surface: (s.data?.hazardSurface ?? 'mur'),
                    result: s.data?.amianteResult,
                    position: { x: s.left ?? 0, y: s.top ?? 0 },
                    floorId: meta.id,
                    linkedCriId: s.data?.criSampleId,
                });
            }
            for (const z of hZones) {
                hazards.zones.push({
                    hazardType: z.data?.hazardType ?? '',
                    label: z.data?.label ?? '',
                    surface: (z.data?.hazardSurface ?? 'sol'),
                    linkedSampleId: z.data?.linkedSampleId ?? undefined,
                    position: { x: z.left ?? 0, y: z.top ?? 0 },
                    floorId: meta.id,
                });
            }
        }
        network.pipes = PIPE_ORDER
            .filter(k => pipeTotals[k] !== undefined)
            .map(k => ({ type: k, label: PIPE_LABELS[k] ?? k, lengthM: round2(pipeTotals[k]) }));
        network.totalLengthM = round2(Object.values(pipeTotals).reduce((s, v) => s + v, 0));
        return {
            generatedAt: new Date().toISOString(),
            pixelsPerMeter: ppm,
            floors,
            rooms: allRooms,
            network,
            hazards,
            stats: {
                roomCount: allRooms.filter(r => !r.isNested).length,
                totalAreaM2: round2(floors.reduce((s, f) => s + f.totalAreaM2, 0)),
                wallCount: wallCountTotal,
                wallLengthM: round1(wallLengthTotal),
            },
        };
    }
    /** Endpoints absolus d'une ligne Fabric (mur ou pipe) — gère l'offset de drag.
     *  Même formule que GeometryService.getAbsoluteLineEnds / fabric-canvas.service. */
    absEnds(line) {
        const dx = (line.left ?? 0) - Math.min(line.x1 ?? 0, line.x2 ?? 0);
        const dy = (line.top ?? 0) - Math.min(line.y1 ?? 0, line.y2 ?? 0);
        return {
            p1: { x: (line.x1 ?? 0) + dx, y: (line.y1 ?? 0) + dy },
            p2: { x: (line.x2 ?? 0) + dx, y: (line.y2 ?? 0) + dy },
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: PlanAnalysisService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: PlanAnalysisService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: PlanAnalysisService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
function round1(n) { return parseFloat(n.toFixed(1)); }
function round2(n) { return parseFloat(n.toFixed(2)); }

/** Paramètres de détection par défaut utilisés par le scanner */
const DEFAULT_DETECTION_PARAMS = {
    threshold: 3,
    minLineLength: 40,
    maxLineGap: 25,
    clusterDistance: 45,
    extensionDistance: 60,
    rotation: 0
};

class ScannerComponent {
    // ── INPUTS ──────────────────────────────────────────────
    initialParams = input({});
    showControls = input(true);
    showTabs = input(true);
    // ── OUTPUTS ─────────────────────────────────────────────
    wallsDetected = output();
    paramsChanged = output();
    opencvReady = output();
    // ── CANVAS REFS ──────────────────────────────────────────
    canvasSrcRef = viewChild.required('canvasSrc');
    canvasBinRef = viewChild.required('canvasBin');
    canvasResRef = viewChild.required('canvasRes');
    canvasWrapperRef = viewChild.required('canvasWrapper');
    // ── ÉTAT INTERNE (Signals) ───────────────────────────────
    isOpenCvReady = signal(false);
    isProcessing = signal(false);
    activeTab = signal('res');
    currentMode = signal(null);
    wallCount = signal(0);
    params = signal({ ...DEFAULT_DETECTION_PARAMS });
    walls = signal([]);
    selectionBox = signal({ x: 0, y: 0, w: 0, h: 0, active: false });
    hasImage = signal(false);
    includeBg = true;
    // ── SERVICES ────────────────────────────────────────────
    opencvSvc = inject(OpenCvService);
    wallDetectionSvc = inject(WallDetectionService);
    geometrySvc = inject(GeometryService);
    destroyRef = inject(DestroyRef);
    // ── COMPUTED ────────────────────────────────────────────
    activeWalls = computed(() => this.walls().filter(w => !w.ignored));
    canExport = computed(() => this.activeWalls().length > 0);
    // ── PRIVÉ ────────────────────────────────────────────────
    sourceImage = null;
    isDragging = false;
    drawingStart = null;
    constructor() {
        // Charger OpenCV au démarrage
        this.opencvSvc.load().then(() => {
            this.isOpenCvReady.set(true);
            this.opencvReady.emit();
        });
        // Synchroniser les params initiaux
        effect(() => {
            const initial = this.initialParams();
            if (Object.keys(initial).length > 0) {
                this.params.update(p => ({ ...p, ...initial }));
            }
        });
    }
    setTab(tab) {
        this.activeTab.set(tab);
    }
    onFileSelected(event) {
        const input = event.target;
        const file = input.files?.[0];
        if (!file)
            return;
        const img = new Image();
        img.onload = () => {
            this.sourceImage = img;
            this.hasImage.set(true);
            this.params.update(p => ({ ...p, rotation: 0 }));
            this.process();
        };
        img.src = URL.createObjectURL(file);
    }
    onParamChange(key, event) {
        const value = parseFloat(event.target.value);
        this.params.update(p => ({ ...p, [key]: value }));
        this.paramsChanged.emit(this.params());
    }
    triggerProcess() {
        if (this.sourceImage && this.isOpenCvReady()) {
            this.process();
        }
    }
    process() {
        if (!this.sourceImage || !this.isOpenCvReady())
            return;
        this.isProcessing.set(true);
        this.drawRotated();
        try {
            const result = this.wallDetectionSvc.detect(this.canvasSrcRef().nativeElement, this.canvasBinRef().nativeElement, this.params());
            this.walls.set(result.walls);
            this.wallCount.set(result.walls.filter((w) => !w.ignored).length);
            this.renderFinal();
        }
        catch (e) {
            console.error('Erreur lors de la détection:', e);
        }
        finally {
            this.isProcessing.set(false);
        }
    }
    drawRotated() {
        if (!this.sourceImage)
            return;
        const r = this.params().rotation * Math.PI / 180;
        const nw = Math.floor(this.sourceImage.width * Math.abs(Math.cos(r)) + this.sourceImage.height * Math.abs(Math.sin(r)));
        const nh = Math.floor(this.sourceImage.width * Math.abs(Math.sin(r)) + this.sourceImage.height * Math.abs(Math.cos(r)));
        const canvases = [
            this.canvasSrcRef().nativeElement,
            this.canvasBinRef().nativeElement,
            this.canvasResRef().nativeElement
        ];
        canvases.forEach(c => { c.width = nw; c.height = nh; });
        const wrapper = this.canvasWrapperRef().nativeElement;
        wrapper.style.width = `${nw}px`;
        wrapper.style.height = `${nh}px`;
        const ctx = this.canvasSrcRef().nativeElement.getContext('2d');
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, nw, nh);
        ctx.save();
        ctx.translate(nw / 2, nh / 2);
        ctx.rotate(r);
        ctx.drawImage(this.sourceImage, -this.sourceImage.width / 2, -this.sourceImage.height / 2);
        ctx.restore();
    }
    setMode(mode) {
        this.currentMode.set(this.currentMode() === mode ? null : mode);
    }
    onCanvasMouseDown(event) {
        const mode = this.currentMode();
        if (!mode)
            return;
        const { x, y } = this.getCanvasCoords(event);
        switch (mode) {
            case 'select':
                this.isDragging = true;
                this.selectionBox.set({ x, y, w: 0, h: 0, active: true });
                break;
            case 'erase':
                this.handleErase(x, y);
                break;
            case 'draw':
                this.isDragging = true;
                this.drawingStart = { x, y };
                break;
        }
    }
    onCanvasMouseMove(event) {
        if (!this.isDragging)
            return;
        const { x, y } = this.getCanvasCoords(event);
        if (this.currentMode() === 'select') {
            this.selectionBox.update(s => ({ ...s, w: x - s.x, h: y - s.y }));
            this.renderFinal();
        }
        else if (this.currentMode() === 'draw' && this.drawingStart) {
            this.renderFinal();
            const ctx = this.canvasResRef().nativeElement.getContext('2d');
            ctx.beginPath();
            ctx.moveTo(this.drawingStart.x, this.drawingStart.y);
            ctx.lineTo(x, y);
            ctx.lineWidth = 4;
            ctx.strokeStyle = '#3498db';
            ctx.stroke();
        }
    }
    onCanvasMouseUp(event) {
        if (this.currentMode() === 'draw' && this.isDragging && this.drawingStart) {
            const { x, y } = this.getCanvasCoords(event);
            this.finishDraw(x, y);
        }
        this.isDragging = false;
    }
    getCanvasCoords(event) {
        const canvas = this.canvasResRef().nativeElement;
        const rect = canvas.getBoundingClientRect();
        return {
            x: (event.clientX - rect.left) * (canvas.width / rect.width),
            y: (event.clientY - rect.top) * (canvas.height / rect.height)
        };
    }
    finishDraw(endX, endY) {
        if (!this.drawingStart)
            return;
        const dx = Math.abs(endX - this.drawingStart.x);
        const dy = Math.abs(endY - this.drawingStart.y);
        const newWall = dx > dy
            ? { id: crypto.randomUUID(), x1: Math.min(this.drawingStart.x, endX), y1: this.drawingStart.y, x2: Math.max(this.drawingStart.x, endX), y2: this.drawingStart.y, type: 'H', ignored: false }
            : { id: crypto.randomUUID(), x1: this.drawingStart.x, y1: Math.min(this.drawingStart.y, endY), x2: this.drawingStart.x, y2: Math.max(this.drawingStart.y, endY), type: 'V', ignored: false };
        const updated = this.geometrySvc.fragmentWalls([...this.walls(), newWall]);
        this.walls.set(updated);
        this.drawingStart = null;
        this.renderFinal();
    }
    handleErase(x, y) {
        this.walls.update(walls => {
            let minDist = 20;
            let closestIdx = -1;
            walls.forEach((w, i) => {
                if (w.ignored)
                    return;
                const mid = { x: (w.x1 + w.x2) / 2, y: (w.y1 + w.y2) / 2 };
                const d = this.geometrySvc.distanceToSegment({ x, y }, { x: w.x1, y: w.y1 }, { x: w.x2, y: w.y2 });
                if (d < minDist) {
                    minDist = d;
                    closestIdx = i;
                }
            });
            if (closestIdx >= 0) {
                return walls.map((w, i) => i === closestIdx ? { ...w, ignored: !w.ignored } : w);
            }
            return walls;
        });
        this.renderFinal();
    }
    mergeInSelection() {
        const sel = this.selectionBox();
        if (!sel.active || Math.abs(sel.w) <= 5)
            return;
        const walls = this.walls();
        const rx = Math.min(sel.x, sel.x + sel.w);
        const ry = Math.min(sel.y, sel.y + sel.h);
        const indices = [];
        walls.forEach((w, i) => {
            if (w.ignored)
                return;
            const cx = (w.x1 + w.x2) / 2;
            const cy = (w.y1 + w.y2) / 2;
            if (cx >= rx && cx <= rx + Math.abs(sel.w) && cy >= ry && cy <= ry + Math.abs(sel.h)) {
                indices.push(i);
            }
        });
        if (indices.length >= 2) {
            const merged = this.geometrySvc.mergeCollinearSegments(walls, indices);
            this.walls.set(merged);
            this.renderFinal();
        }
    }
    cleanIsolatedSegments() {
        let count = 0;
        this.walls.update(walls => walls.map(w => {
            if (!w.ignored) {
                const c1 = this.geometrySvc.getConnectivity(w.x1, w.y1, walls);
                const c2 = this.geometrySvc.getConnectivity(w.x2, w.y2, walls);
                if (c1 <= 1 && c2 <= 1) {
                    count++;
                    return { ...w, ignored: true };
                }
            }
            return w;
        }));
        this.renderFinal();
    }
    cleanDanglingSegments() {
        let count = 0;
        this.walls.update(walls => walls.map(w => {
            if (!w.ignored) {
                const c1 = this.geometrySvc.getConnectivity(w.x1, w.y1, walls);
                const c2 = this.geometrySvc.getConnectivity(w.x2, w.y2, walls);
                if ((c1 <= 1 && c2 > 1) || (c1 > 1 && c2 <= 1)) {
                    count++;
                    return { ...w, ignored: true };
                }
            }
            return w;
        }));
        this.renderFinal();
    }
    renderFinal() {
        const canvas = this.canvasResRef().nativeElement;
        const srcCanvas = this.canvasSrcRef().nativeElement;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, srcCanvas.width, srcCanvas.height);
        ctx.globalAlpha = 0.3;
        ctx.drawImage(srcCanvas, 0, 0);
        ctx.globalAlpha = 1.0;
        const sel = this.selectionBox();
        this.walls().forEach(w => {
            const active = this.isWallInScope(w, sel);
            ctx.beginPath();
            ctx.moveTo(w.x1, w.y1);
            ctx.lineTo(w.x2, w.y2);
            if (w.ignored) {
                ctx.strokeStyle = 'rgba(0,0,0,0.1)';
                ctx.lineWidth = 2;
                ctx.setLineDash([5, 5]);
            }
            else if (!active) {
                ctx.strokeStyle = 'rgba(0,0,0,0.2)';
                ctx.lineWidth = 2;
                ctx.setLineDash([]);
            }
            else {
                ctx.strokeStyle = '#2c3e50';
                ctx.lineWidth = 4;
                ctx.setLineDash([]);
            }
            ctx.stroke();
        });
        ctx.setLineDash([]);
        this.walls().forEach(w => {
            if (this.isWallInScope(w, sel)) {
                this.drawConnectionDot(ctx, w.x1, w.y1);
                this.drawConnectionDot(ctx, w.x2, w.y2);
            }
        });
        if (sel.active) {
            ctx.strokeStyle = '#f39c12';
            ctx.lineWidth = 2;
            ctx.setLineDash([6, 4]);
            ctx.strokeRect(sel.x, sel.y, sel.w, sel.h);
            ctx.setLineDash([]);
        }
        const exportCount = this.walls().filter(w => this.isWallInScope(w, sel)).length;
        this.wallCount.set(exportCount);
    }
    drawConnectionDot(ctx, x, y) {
        const count = this.geometrySvc.getConnectivity(x, y, this.walls());
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fillStyle = count > 1 ? '#27ae60' : '#e74c3c';
        ctx.fill();
    }
    isWallInScope(w, sel) {
        if (w.ignored)
            return false;
        if (!sel.active || Math.abs(sel.w) <= 5)
            return true;
        const cx = (w.x1 + w.x2) / 2;
        const cy = (w.y1 + w.y2) / 2;
        const rx = Math.min(sel.x, sel.x + sel.w);
        const ry = Math.min(sel.y, sel.y + sel.h);
        return cx >= rx && cx <= rx + Math.abs(sel.w) && cy >= ry && cy <= ry + Math.abs(sel.h);
    }
    exportWalls() {
        const sel = this.selectionBox();
        const bounds = sel.active && Math.abs(sel.w) > 5
            ? { x: Math.min(sel.x, sel.x + sel.w), y: Math.min(sel.y, sel.y + sel.h), w: Math.abs(sel.w), h: Math.abs(sel.h) }
            : { x: 0, y: 0, w: this.canvasResRef().nativeElement.width, h: this.canvasResRef().nativeElement.height };
        const finalWalls = this.walls().filter(w => this.isWallInScope(w, this.selectionBox()));
        let backgroundImageDataUrl;
        if (this.includeBg && this.hasImage()) {
            const tmp = document.createElement('canvas');
            tmp.width = bounds.w;
            tmp.height = bounds.h;
            tmp.getContext('2d').drawImage(this.canvasSrcRef().nativeElement, bounds.x, bounds.y, bounds.w, bounds.h, 0, 0, bounds.w, bounds.h);
            backgroundImageDataUrl = tmp.toDataURL('image/jpeg', 0.8);
        }
        const payload = {
            walls: finalWalls,
            bounds,
            backgroundImageDataUrl,
            pixelsPerMeter: this.params().clusterDistance > 0 ? 50 : 50
        };
        this.wallsDetected.emit(payload);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ScannerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ScannerComponent, isStandalone: true, selector: "ng-gplan-scanner", inputs: { initialParams: { classPropertyName: "initialParams", publicName: "initialParams", isSignal: true, isRequired: false, transformFunction: null }, showControls: { classPropertyName: "showControls", publicName: "showControls", isSignal: true, isRequired: false, transformFunction: null }, showTabs: { classPropertyName: "showTabs", publicName: "showTabs", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { wallsDetected: "wallsDetected", paramsChanged: "paramsChanged", opencvReady: "opencvReady" }, viewQueries: [{ propertyName: "canvasSrcRef", first: true, predicate: ["canvasSrc"], descendants: true, isSignal: true }, { propertyName: "canvasBinRef", first: true, predicate: ["canvasBin"], descendants: true, isSignal: true }, { propertyName: "canvasResRef", first: true, predicate: ["canvasRes"], descendants: true, isSignal: true }, { propertyName: "canvasWrapperRef", first: true, predicate: ["canvasWrapper"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"ngf-scanner\" [class.ngf-scanner--loading]=\"!isOpenCvReady()\">\n\n  @if (!isOpenCvReady()) {\n    <div class=\"ngf-scanner__loading\">\n      <span class=\"ngf-spinner\"></span>\n      Chargement OpenCV.js\u2026\n    </div>\n  }\n\n  <div class=\"ngf-scanner__layout\" [class.ngf-scanner__layout--no-sidebar]=\"!showControls()\">\n\n    @if (showControls()) {\n      <aside class=\"ngf-scanner__sidebar\">\n\n        <section class=\"ngf-section\">\n          <h3 class=\"ngf-section__title\">Source</h3>\n          <input type=\"file\" accept=\"image/*\" (change)=\"onFileSelected($event)\" class=\"ngf-file-input\" />\n          <label class=\"ngf-param-label\">\n            <span>Rotation</span>\n            <span class=\"ngf-param-value\">{{ params().rotation }}\u00B0</span>\n          </label>\n          <input type=\"range\" min=\"-10\" max=\"10\" step=\"0.1\"\n            [value]=\"params().rotation\"\n            (input)=\"onParamChange('rotation', $event)\"\n            (change)=\"triggerProcess()\"\n            class=\"ngf-range\" />\n        </section>\n\n        <section class=\"ngf-section\">\n          <h3 class=\"ngf-section__title\">D\u00E9tection</h3>\n\n          <label class=\"ngf-param-label\">\n            <span>Seuil lumi\u00E8re</span>\n            <span class=\"ngf-param-value\">{{ params().threshold }}</span>\n          </label>\n          <input type=\"range\" min=\"3\" max=\"99\" step=\"2\"\n            [value]=\"params().threshold\"\n            (input)=\"onParamChange('threshold', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n\n          <label class=\"ngf-param-label\">\n            <span>Longueur min.</span>\n            <span class=\"ngf-param-value\">{{ params().minLineLength }}px</span>\n          </label>\n          <input type=\"range\" min=\"10\" max=\"150\"\n            [value]=\"params().minLineLength\"\n            (input)=\"onParamChange('minLineLength', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n\n          <label class=\"ngf-param-label\">\n            <span>Boucher les trous</span>\n            <span class=\"ngf-param-value\">{{ params().maxLineGap }}px</span>\n          </label>\n          <input type=\"range\" min=\"1\" max=\"50\"\n            [value]=\"params().maxLineGap\"\n            (input)=\"onParamChange('maxLineGap', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n        </section>\n\n        <section class=\"ngf-section\">\n          <h3 class=\"ngf-section__title\">G\u00E9om\u00E9trie</h3>\n\n          <label class=\"ngf-param-label\">\n            <span>\u00C9paisseur mur</span>\n            <span class=\"ngf-param-value\">{{ params().clusterDistance }}px</span>\n          </label>\n          <input type=\"range\" min=\"1\" max=\"60\"\n            [value]=\"params().clusterDistance\"\n            (input)=\"onParamChange('clusterDistance', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n\n          <label class=\"ngf-param-label\">\n            <span>Extension (T)</span>\n            <span class=\"ngf-param-value\">{{ params().extensionDistance }}px</span>\n          </label>\n          <input type=\"range\" min=\"0\" max=\"150\"\n            [value]=\"params().extensionDistance\"\n            (input)=\"onParamChange('extensionDistance', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n        </section>\n\n        <section class=\"ngf-section ngf-section--tools\">\n          <h3 class=\"ngf-section__title\">Correction manuelle</h3>\n\n          <div class=\"ngf-tools-grid\">\n            <button class=\"ngf-tool-btn ngf-tool-btn--select\"\n              [class.ngf-tool-btn--active]=\"currentMode() === 'select'\"\n              (click)=\"setMode('select')\" title=\"S\u00E9lectionner une zone\">\n              <span class=\"tool-emoji\">\u2B1A</span>\n              Zone\n            </button>\n            <button class=\"ngf-tool-btn ngf-tool-btn--draw\"\n              [class.ngf-tool-btn--active]=\"currentMode() === 'draw'\"\n              (click)=\"setMode('draw')\" title=\"Dessiner un mur manuellement\">\n              <span class=\"tool-emoji\">\u270F\uFE0F</span>\n              Crayon\n            </button>\n            <button class=\"ngf-tool-btn ngf-tool-btn--erase\"\n              [class.ngf-tool-btn--active]=\"currentMode() === 'erase'\"\n              (click)=\"setMode('erase')\" title=\"Effacer un segment\">\n              <span class=\"tool-emoji\">\u232B</span>\n              Gomme\n            </button>\n          </div>\n\n          <button class=\"ngf-btn ngf-btn--blue\" (click)=\"mergeInSelection()\" [disabled]=\"!selectionBox().active\">\n            Fusionner la s\u00E9lection\n          </button>\n          <button class=\"ngf-btn ngf-btn--red\" (click)=\"cleanIsolatedSegments()\">\n            Supprimer isol\u00E9s\n          </button>\n          <button class=\"ngf-btn ngf-btn--orange\" (click)=\"cleanDanglingSegments()\">\n            Supprimer impasses\n          </button>\n\n          <div class=\"ngf-legend\">\n            <span class=\"ngf-legend__item\"><span class=\"ngf-dot ngf-dot--green\"></span> Connect\u00E9</span>\n            <span class=\"ngf-legend__item\"><span class=\"ngf-dot ngf-dot--red\"></span> Libre</span>\n          </div>\n        </section>\n\n        <section class=\"ngf-section\">\n          <h3 class=\"ngf-section__title\">Export</h3>\n          <label class=\"ngf-checkbox-label\">\n            <input type=\"checkbox\" [(ngModel)]=\"includeBg\" />\n            Inclure l'image de fond\n          </label>\n        </section>\n\n        <div class=\"ngf-scanner__footer\">\n          <div class=\"ngf-count\">\n            Segments actifs : <strong>{{ wallCount() }}</strong>\n          </div>\n          <button class=\"ngf-btn ngf-btn--export\" [disabled]=\"!canExport()\" (click)=\"exportWalls()\">\n            Envoyer \u00E0 l'\u00E9diteur \u2192\n          </button>\n        </div>\n\n      </aside>\n    }\n\n    <div class=\"ngf-scanner__viewer\">\n\n      @if (showTabs()) {\n        <div class=\"ngf-tabs\">\n          <button class=\"ngf-tab\" [class.ngf-tab--active]=\"activeTab() === 'src'\" (click)=\"setTab('src')\">\n            Alignement\n          </button>\n          <button class=\"ngf-tab\" [class.ngf-tab--active]=\"activeTab() === 'bin'\" (click)=\"setTab('bin')\">\n            Vue machine\n          </button>\n          <button class=\"ngf-tab\" [class.ngf-tab--active]=\"activeTab() === 'res'\" (click)=\"setTab('res')\">\n            R\u00E9sultat \u2726\n          </button>\n        </div>\n      }\n\n      <div class=\"ngf-canvas-area\">\n        <div #canvasWrapper class=\"ngf-canvas-wrapper\">\n          <canvas #canvasSrc [class.ngf-canvas--active]=\"activeTab() === 'src'\"></canvas>\n          <canvas #canvasBin [class.ngf-canvas--active]=\"activeTab() === 'bin'\"></canvas>\n          <canvas #canvasRes\n            class=\"ngf-canvas--interactive\"\n            [class.ngf-canvas--active]=\"activeTab() === 'res'\"\n            (mousedown)=\"onCanvasMouseDown($event)\"\n            (mousemove)=\"onCanvasMouseMove($event)\"\n            (mouseup)=\"onCanvasMouseUp($event)\">\n          </canvas>\n        </div>\n      </div>\n\n      @if (currentMode()) {\n        <div class=\"ngf-info-bar\">\n          @switch (currentMode()) {\n            @case ('select') { \u2B1A Glissez pour d\u00E9limiter une zone d'export }\n            @case ('erase') { \u232B Cliquez sur un segment pour le masquer }\n            @case ('draw') { \u270F\uFE0F Glissez pour tracer un mur H ou V }\n          }\n        </div>\n      }\n\n    </div>\n  </div>\n</div>\n", styles: [":host{--z-50: #fafafa;--z-100: #f5f5f5;--z-200: #e5e5e5;--z-300: #d4d4d4;--z-400: #a3a3a3;--z-500: #737373;--z-600: #525252;--z-700: #404040;--z-800: #262626;--z-900: #171717;--primary: #f97316;--primary-hover: #ea580c;--primary-light: #fff7ed;--primary-border: #fed7aa;--primary-text: #9a3412;--success: #16a34a;--success-light: #f0fdf4;--danger: #dc2626;--danger-light: #fef2f2;--warn: #d97706;--warn-light: #fffbeb;--info: #0284c7;--info-light: #f0f9ff;--radius-sm: 4px;--radius: 8px;--radius-lg: 12px;--shadow-sm: 0 1px 3px rgba(0,0,0,.07), 0 0 0 1px rgba(0,0,0,.04);--shadow: 0 4px 12px rgba(0,0,0,.08), 0 0 0 1px rgba(0,0,0,.04);--font: \"Poppins\", ui-sans-serif, system-ui, sans-serif;--font-mono: \"DM Mono\", ui-monospace, monospace;display:block;height:100%;font-family:var(--font)}.ngf-scanner{background:#f5f4f2;height:100%;display:flex;flex-direction:column;box-sizing:border-box;padding:12px;gap:12px}.ngf-scanner__loading{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;color:var(--z-500);font-size:13px}.ngf-scanner__layout{display:flex;gap:12px;flex:1;min-height:0}.ngf-scanner__sidebar{flex:0 0 268px;background:#fff;border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);border:1px solid var(--z-200);overflow-y:auto;display:flex;flex-direction:column}.ngf-scanner__sidebar::-webkit-scrollbar{width:3px}.ngf-scanner__sidebar::-webkit-scrollbar-thumb{background:var(--z-200);border-radius:2px}.ngf-scanner__viewer{flex:1;background:#fff;border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);border:1px solid var(--z-200);display:flex;flex-direction:column;overflow:hidden;position:relative}.ngf-scanner__footer{padding:12px 14px;border-top:1px solid var(--z-100);display:flex;flex-direction:column;gap:8px;background:var(--z-50);border-radius:0 0 var(--radius-lg) var(--radius-lg);margin-top:auto}.ngf-spinner{width:26px;height:26px;border:3px solid var(--primary-border);border-top-color:var(--primary);border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}.ngf-section{padding:14px;border-bottom:1px solid var(--z-100)}.ngf-section:last-child{border-bottom:none}.ngf-section__title{margin:0 0 10px;font-size:9px;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:var(--z-400);display:flex;align-items:center;gap:6px}.ngf-section__title:before{content:\"\";display:inline-block;width:3px;height:10px;background:var(--primary);border-radius:2px}.ngf-section--tools{background:var(--primary-light);border:none;border-top:1px solid var(--primary-border);border-bottom:1px solid var(--primary-border)}.ngf-param-label{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--z-600);margin-bottom:5px}.ngf-param-value{font-family:var(--font-mono);font-size:11px;font-weight:700;color:var(--primary);background:var(--primary-light);border:1px solid var(--primary-border);padding:1px 7px;border-radius:100px;min-width:36px;text-align:right}.ngf-range{width:100%;margin-bottom:10px;accent-color:var(--primary);cursor:pointer;height:4px}.ngf-range:last-child{margin-bottom:0}.ngf-file-input{width:100%;font-size:11px;font-family:var(--font);color:var(--z-600);margin-bottom:10px;cursor:pointer}.ngf-file-input::file-selector-button{background:var(--primary);color:#fff;border:none;padding:5px 12px;border-radius:var(--radius);font-size:11px;font-family:var(--font);font-weight:700;cursor:pointer;margin-right:8px;transition:filter .1s}.ngf-file-input::file-selector-button:hover{filter:brightness(.92)}.ngf-tools-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:10px}.ngf-tool-btn{border:1px solid var(--z-200);background:#fff;padding:9px 6px;border-radius:var(--radius);cursor:pointer;font-size:11px;font-weight:600;font-family:var(--font);color:var(--z-600);display:flex;flex-direction:column;align-items:center;gap:4px;transition:background .1s,border-color .1s,color .1s,box-shadow .1s}.ngf-tool-btn .tool-emoji{font-size:16px;line-height:1}.ngf-tool-btn:hover:not(.ngf-tool-btn--active){background:var(--primary-light);border-color:var(--primary-border);color:var(--primary)}.ngf-tool-btn--active{background:var(--primary)!important;color:#fff!important;border-color:var(--primary)!important;box-shadow:0 2px 8px #f973164d}.ngf-tool-btn--erase.ngf-tool-btn--active{background:var(--danger)!important;border-color:var(--danger)!important;box-shadow:0 2px 8px #dc262640}.ngf-tool-btn--draw.ngf-tool-btn--active{background:var(--info)!important;border-color:var(--info)!important;box-shadow:0 2px 8px #0284c740}.ngf-btn{border:none;padding:7px 10px;width:100%;border-radius:var(--radius);font-weight:600;font-family:var(--font);cursor:pointer;font-size:11px;display:flex;align-items:center;justify-content:center;gap:5px;transition:filter .1s,opacity .1s;margin-top:5px}.ngf-btn:first-child{margin-top:0}.ngf-btn:disabled{opacity:.4;cursor:not-allowed}.ngf-btn--red{background:var(--danger-light);color:var(--danger);border:1px solid #fecaca}.ngf-btn--red:not(:disabled):hover{filter:brightness(.96)}.ngf-btn--orange{background:var(--primary-light);color:var(--primary);border:1px solid var(--primary-border)}.ngf-btn--orange:not(:disabled):hover{filter:brightness(.96)}.ngf-btn--blue{background:var(--info-light);color:var(--info);border:1px solid #bae6fd}.ngf-btn--blue:not(:disabled):hover{filter:brightness(.96)}.ngf-btn--export{background:var(--primary);color:#fff;padding:10px;font-size:12px;font-weight:700;border-radius:var(--radius);letter-spacing:.02em;margin-top:4px;box-shadow:0 2px #c2410c66}.ngf-btn--export:not(:disabled):hover{background:var(--primary-hover)}.ngf-btn--export:not(:disabled):active{transform:translateY(1px);box-shadow:none}.ngf-checkbox-label{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--z-600);cursor:pointer;-webkit-user-select:none;user-select:none}.ngf-checkbox-label input[type=checkbox]{accent-color:var(--primary);width:14px;height:14px;cursor:pointer}.ngf-checkbox-label:hover{color:var(--primary)}.ngf-count{font-size:11px;color:var(--z-500);text-align:center;font-family:var(--font-mono)}.ngf-count strong{color:var(--primary);font-weight:700}.ngf-legend{display:flex;gap:12px;margin-top:8px;padding:8px 10px;background:var(--primary-light);border:1px solid var(--primary-border);border-radius:var(--radius)}.ngf-legend__item{display:flex;align-items:center;gap:5px;font-size:11px;color:var(--z-600)}.ngf-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}.ngf-dot--green{background:var(--success)}.ngf-dot--red{background:var(--danger)}.ngf-tabs{display:flex;border-bottom:1px solid var(--z-200);padding:0 4px;gap:0;flex-shrink:0}.ngf-tab{padding:10px 14px;font-size:11px;font-weight:600;font-family:var(--font);color:var(--z-400);cursor:pointer;border:none;background:none;transition:color .1s;position:relative;white-space:nowrap}.ngf-tab:after{content:\"\";position:absolute;bottom:-1px;left:0;right:0;height:2px;background:var(--primary);border-radius:2px 2px 0 0;transform:scaleX(0);transition:transform .15s}.ngf-tab:hover{color:var(--primary)}.ngf-tab--active{color:var(--primary);font-weight:700}.ngf-tab--active:after{transform:scaleX(1)}.ngf-canvas-area{flex:1;overflow:auto;position:relative;display:flex;justify-content:center;align-items:flex-start;padding:20px;background-image:radial-gradient(circle,#d6d2cc 1px,transparent 1px);background-size:20px 20px;background-position:10px 10px;background-color:#f0ede8;cursor:default}.ngf-canvas-area::-webkit-scrollbar{width:8px;height:8px}.ngf-canvas-area::-webkit-scrollbar-thumb{background:var(--z-300);border-radius:4px;border:2px solid #f0ede8}.ngf-canvas-wrapper{position:relative;display:inline-block}canvas{background:#fff;box-shadow:var(--shadow);display:none}canvas.ngf-canvas--active{display:block}canvas.ngf-canvas--interactive{cursor:crosshair}.ngf-info-bar{position:absolute;bottom:12px;left:50%;transform:translate(-50%);background:var(--z-900);color:#ffffffe6;padding:6px 16px;border-radius:100px;font-size:11px;font-weight:500;pointer-events:none;z-index:100;white-space:nowrap;box-shadow:0 4px 16px #0003}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ScannerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-gplan-scanner', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [FormsModule], template: "<div class=\"ngf-scanner\" [class.ngf-scanner--loading]=\"!isOpenCvReady()\">\n\n  @if (!isOpenCvReady()) {\n    <div class=\"ngf-scanner__loading\">\n      <span class=\"ngf-spinner\"></span>\n      Chargement OpenCV.js\u2026\n    </div>\n  }\n\n  <div class=\"ngf-scanner__layout\" [class.ngf-scanner__layout--no-sidebar]=\"!showControls()\">\n\n    @if (showControls()) {\n      <aside class=\"ngf-scanner__sidebar\">\n\n        <section class=\"ngf-section\">\n          <h3 class=\"ngf-section__title\">Source</h3>\n          <input type=\"file\" accept=\"image/*\" (change)=\"onFileSelected($event)\" class=\"ngf-file-input\" />\n          <label class=\"ngf-param-label\">\n            <span>Rotation</span>\n            <span class=\"ngf-param-value\">{{ params().rotation }}\u00B0</span>\n          </label>\n          <input type=\"range\" min=\"-10\" max=\"10\" step=\"0.1\"\n            [value]=\"params().rotation\"\n            (input)=\"onParamChange('rotation', $event)\"\n            (change)=\"triggerProcess()\"\n            class=\"ngf-range\" />\n        </section>\n\n        <section class=\"ngf-section\">\n          <h3 class=\"ngf-section__title\">D\u00E9tection</h3>\n\n          <label class=\"ngf-param-label\">\n            <span>Seuil lumi\u00E8re</span>\n            <span class=\"ngf-param-value\">{{ params().threshold }}</span>\n          </label>\n          <input type=\"range\" min=\"3\" max=\"99\" step=\"2\"\n            [value]=\"params().threshold\"\n            (input)=\"onParamChange('threshold', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n\n          <label class=\"ngf-param-label\">\n            <span>Longueur min.</span>\n            <span class=\"ngf-param-value\">{{ params().minLineLength }}px</span>\n          </label>\n          <input type=\"range\" min=\"10\" max=\"150\"\n            [value]=\"params().minLineLength\"\n            (input)=\"onParamChange('minLineLength', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n\n          <label class=\"ngf-param-label\">\n            <span>Boucher les trous</span>\n            <span class=\"ngf-param-value\">{{ params().maxLineGap }}px</span>\n          </label>\n          <input type=\"range\" min=\"1\" max=\"50\"\n            [value]=\"params().maxLineGap\"\n            (input)=\"onParamChange('maxLineGap', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n        </section>\n\n        <section class=\"ngf-section\">\n          <h3 class=\"ngf-section__title\">G\u00E9om\u00E9trie</h3>\n\n          <label class=\"ngf-param-label\">\n            <span>\u00C9paisseur mur</span>\n            <span class=\"ngf-param-value\">{{ params().clusterDistance }}px</span>\n          </label>\n          <input type=\"range\" min=\"1\" max=\"60\"\n            [value]=\"params().clusterDistance\"\n            (input)=\"onParamChange('clusterDistance', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n\n          <label class=\"ngf-param-label\">\n            <span>Extension (T)</span>\n            <span class=\"ngf-param-value\">{{ params().extensionDistance }}px</span>\n          </label>\n          <input type=\"range\" min=\"0\" max=\"150\"\n            [value]=\"params().extensionDistance\"\n            (input)=\"onParamChange('extensionDistance', $event); triggerProcess()\"\n            class=\"ngf-range\" />\n        </section>\n\n        <section class=\"ngf-section ngf-section--tools\">\n          <h3 class=\"ngf-section__title\">Correction manuelle</h3>\n\n          <div class=\"ngf-tools-grid\">\n            <button class=\"ngf-tool-btn ngf-tool-btn--select\"\n              [class.ngf-tool-btn--active]=\"currentMode() === 'select'\"\n              (click)=\"setMode('select')\" title=\"S\u00E9lectionner une zone\">\n              <span class=\"tool-emoji\">\u2B1A</span>\n              Zone\n            </button>\n            <button class=\"ngf-tool-btn ngf-tool-btn--draw\"\n              [class.ngf-tool-btn--active]=\"currentMode() === 'draw'\"\n              (click)=\"setMode('draw')\" title=\"Dessiner un mur manuellement\">\n              <span class=\"tool-emoji\">\u270F\uFE0F</span>\n              Crayon\n            </button>\n            <button class=\"ngf-tool-btn ngf-tool-btn--erase\"\n              [class.ngf-tool-btn--active]=\"currentMode() === 'erase'\"\n              (click)=\"setMode('erase')\" title=\"Effacer un segment\">\n              <span class=\"tool-emoji\">\u232B</span>\n              Gomme\n            </button>\n          </div>\n\n          <button class=\"ngf-btn ngf-btn--blue\" (click)=\"mergeInSelection()\" [disabled]=\"!selectionBox().active\">\n            Fusionner la s\u00E9lection\n          </button>\n          <button class=\"ngf-btn ngf-btn--red\" (click)=\"cleanIsolatedSegments()\">\n            Supprimer isol\u00E9s\n          </button>\n          <button class=\"ngf-btn ngf-btn--orange\" (click)=\"cleanDanglingSegments()\">\n            Supprimer impasses\n          </button>\n\n          <div class=\"ngf-legend\">\n            <span class=\"ngf-legend__item\"><span class=\"ngf-dot ngf-dot--green\"></span> Connect\u00E9</span>\n            <span class=\"ngf-legend__item\"><span class=\"ngf-dot ngf-dot--red\"></span> Libre</span>\n          </div>\n        </section>\n\n        <section class=\"ngf-section\">\n          <h3 class=\"ngf-section__title\">Export</h3>\n          <label class=\"ngf-checkbox-label\">\n            <input type=\"checkbox\" [(ngModel)]=\"includeBg\" />\n            Inclure l'image de fond\n          </label>\n        </section>\n\n        <div class=\"ngf-scanner__footer\">\n          <div class=\"ngf-count\">\n            Segments actifs : <strong>{{ wallCount() }}</strong>\n          </div>\n          <button class=\"ngf-btn ngf-btn--export\" [disabled]=\"!canExport()\" (click)=\"exportWalls()\">\n            Envoyer \u00E0 l'\u00E9diteur \u2192\n          </button>\n        </div>\n\n      </aside>\n    }\n\n    <div class=\"ngf-scanner__viewer\">\n\n      @if (showTabs()) {\n        <div class=\"ngf-tabs\">\n          <button class=\"ngf-tab\" [class.ngf-tab--active]=\"activeTab() === 'src'\" (click)=\"setTab('src')\">\n            Alignement\n          </button>\n          <button class=\"ngf-tab\" [class.ngf-tab--active]=\"activeTab() === 'bin'\" (click)=\"setTab('bin')\">\n            Vue machine\n          </button>\n          <button class=\"ngf-tab\" [class.ngf-tab--active]=\"activeTab() === 'res'\" (click)=\"setTab('res')\">\n            R\u00E9sultat \u2726\n          </button>\n        </div>\n      }\n\n      <div class=\"ngf-canvas-area\">\n        <div #canvasWrapper class=\"ngf-canvas-wrapper\">\n          <canvas #canvasSrc [class.ngf-canvas--active]=\"activeTab() === 'src'\"></canvas>\n          <canvas #canvasBin [class.ngf-canvas--active]=\"activeTab() === 'bin'\"></canvas>\n          <canvas #canvasRes\n            class=\"ngf-canvas--interactive\"\n            [class.ngf-canvas--active]=\"activeTab() === 'res'\"\n            (mousedown)=\"onCanvasMouseDown($event)\"\n            (mousemove)=\"onCanvasMouseMove($event)\"\n            (mouseup)=\"onCanvasMouseUp($event)\">\n          </canvas>\n        </div>\n      </div>\n\n      @if (currentMode()) {\n        <div class=\"ngf-info-bar\">\n          @switch (currentMode()) {\n            @case ('select') { \u2B1A Glissez pour d\u00E9limiter une zone d'export }\n            @case ('erase') { \u232B Cliquez sur un segment pour le masquer }\n            @case ('draw') { \u270F\uFE0F Glissez pour tracer un mur H ou V }\n          }\n        </div>\n      }\n\n    </div>\n  </div>\n</div>\n", styles: [":host{--z-50: #fafafa;--z-100: #f5f5f5;--z-200: #e5e5e5;--z-300: #d4d4d4;--z-400: #a3a3a3;--z-500: #737373;--z-600: #525252;--z-700: #404040;--z-800: #262626;--z-900: #171717;--primary: #f97316;--primary-hover: #ea580c;--primary-light: #fff7ed;--primary-border: #fed7aa;--primary-text: #9a3412;--success: #16a34a;--success-light: #f0fdf4;--danger: #dc2626;--danger-light: #fef2f2;--warn: #d97706;--warn-light: #fffbeb;--info: #0284c7;--info-light: #f0f9ff;--radius-sm: 4px;--radius: 8px;--radius-lg: 12px;--shadow-sm: 0 1px 3px rgba(0,0,0,.07), 0 0 0 1px rgba(0,0,0,.04);--shadow: 0 4px 12px rgba(0,0,0,.08), 0 0 0 1px rgba(0,0,0,.04);--font: \"Poppins\", ui-sans-serif, system-ui, sans-serif;--font-mono: \"DM Mono\", ui-monospace, monospace;display:block;height:100%;font-family:var(--font)}.ngf-scanner{background:#f5f4f2;height:100%;display:flex;flex-direction:column;box-sizing:border-box;padding:12px;gap:12px}.ngf-scanner__loading{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;color:var(--z-500);font-size:13px}.ngf-scanner__layout{display:flex;gap:12px;flex:1;min-height:0}.ngf-scanner__sidebar{flex:0 0 268px;background:#fff;border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);border:1px solid var(--z-200);overflow-y:auto;display:flex;flex-direction:column}.ngf-scanner__sidebar::-webkit-scrollbar{width:3px}.ngf-scanner__sidebar::-webkit-scrollbar-thumb{background:var(--z-200);border-radius:2px}.ngf-scanner__viewer{flex:1;background:#fff;border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);border:1px solid var(--z-200);display:flex;flex-direction:column;overflow:hidden;position:relative}.ngf-scanner__footer{padding:12px 14px;border-top:1px solid var(--z-100);display:flex;flex-direction:column;gap:8px;background:var(--z-50);border-radius:0 0 var(--radius-lg) var(--radius-lg);margin-top:auto}.ngf-spinner{width:26px;height:26px;border:3px solid var(--primary-border);border-top-color:var(--primary);border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}.ngf-section{padding:14px;border-bottom:1px solid var(--z-100)}.ngf-section:last-child{border-bottom:none}.ngf-section__title{margin:0 0 10px;font-size:9px;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:var(--z-400);display:flex;align-items:center;gap:6px}.ngf-section__title:before{content:\"\";display:inline-block;width:3px;height:10px;background:var(--primary);border-radius:2px}.ngf-section--tools{background:var(--primary-light);border:none;border-top:1px solid var(--primary-border);border-bottom:1px solid var(--primary-border)}.ngf-param-label{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--z-600);margin-bottom:5px}.ngf-param-value{font-family:var(--font-mono);font-size:11px;font-weight:700;color:var(--primary);background:var(--primary-light);border:1px solid var(--primary-border);padding:1px 7px;border-radius:100px;min-width:36px;text-align:right}.ngf-range{width:100%;margin-bottom:10px;accent-color:var(--primary);cursor:pointer;height:4px}.ngf-range:last-child{margin-bottom:0}.ngf-file-input{width:100%;font-size:11px;font-family:var(--font);color:var(--z-600);margin-bottom:10px;cursor:pointer}.ngf-file-input::file-selector-button{background:var(--primary);color:#fff;border:none;padding:5px 12px;border-radius:var(--radius);font-size:11px;font-family:var(--font);font-weight:700;cursor:pointer;margin-right:8px;transition:filter .1s}.ngf-file-input::file-selector-button:hover{filter:brightness(.92)}.ngf-tools-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:10px}.ngf-tool-btn{border:1px solid var(--z-200);background:#fff;padding:9px 6px;border-radius:var(--radius);cursor:pointer;font-size:11px;font-weight:600;font-family:var(--font);color:var(--z-600);display:flex;flex-direction:column;align-items:center;gap:4px;transition:background .1s,border-color .1s,color .1s,box-shadow .1s}.ngf-tool-btn .tool-emoji{font-size:16px;line-height:1}.ngf-tool-btn:hover:not(.ngf-tool-btn--active){background:var(--primary-light);border-color:var(--primary-border);color:var(--primary)}.ngf-tool-btn--active{background:var(--primary)!important;color:#fff!important;border-color:var(--primary)!important;box-shadow:0 2px 8px #f973164d}.ngf-tool-btn--erase.ngf-tool-btn--active{background:var(--danger)!important;border-color:var(--danger)!important;box-shadow:0 2px 8px #dc262640}.ngf-tool-btn--draw.ngf-tool-btn--active{background:var(--info)!important;border-color:var(--info)!important;box-shadow:0 2px 8px #0284c740}.ngf-btn{border:none;padding:7px 10px;width:100%;border-radius:var(--radius);font-weight:600;font-family:var(--font);cursor:pointer;font-size:11px;display:flex;align-items:center;justify-content:center;gap:5px;transition:filter .1s,opacity .1s;margin-top:5px}.ngf-btn:first-child{margin-top:0}.ngf-btn:disabled{opacity:.4;cursor:not-allowed}.ngf-btn--red{background:var(--danger-light);color:var(--danger);border:1px solid #fecaca}.ngf-btn--red:not(:disabled):hover{filter:brightness(.96)}.ngf-btn--orange{background:var(--primary-light);color:var(--primary);border:1px solid var(--primary-border)}.ngf-btn--orange:not(:disabled):hover{filter:brightness(.96)}.ngf-btn--blue{background:var(--info-light);color:var(--info);border:1px solid #bae6fd}.ngf-btn--blue:not(:disabled):hover{filter:brightness(.96)}.ngf-btn--export{background:var(--primary);color:#fff;padding:10px;font-size:12px;font-weight:700;border-radius:var(--radius);letter-spacing:.02em;margin-top:4px;box-shadow:0 2px #c2410c66}.ngf-btn--export:not(:disabled):hover{background:var(--primary-hover)}.ngf-btn--export:not(:disabled):active{transform:translateY(1px);box-shadow:none}.ngf-checkbox-label{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--z-600);cursor:pointer;-webkit-user-select:none;user-select:none}.ngf-checkbox-label input[type=checkbox]{accent-color:var(--primary);width:14px;height:14px;cursor:pointer}.ngf-checkbox-label:hover{color:var(--primary)}.ngf-count{font-size:11px;color:var(--z-500);text-align:center;font-family:var(--font-mono)}.ngf-count strong{color:var(--primary);font-weight:700}.ngf-legend{display:flex;gap:12px;margin-top:8px;padding:8px 10px;background:var(--primary-light);border:1px solid var(--primary-border);border-radius:var(--radius)}.ngf-legend__item{display:flex;align-items:center;gap:5px;font-size:11px;color:var(--z-600)}.ngf-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}.ngf-dot--green{background:var(--success)}.ngf-dot--red{background:var(--danger)}.ngf-tabs{display:flex;border-bottom:1px solid var(--z-200);padding:0 4px;gap:0;flex-shrink:0}.ngf-tab{padding:10px 14px;font-size:11px;font-weight:600;font-family:var(--font);color:var(--z-400);cursor:pointer;border:none;background:none;transition:color .1s;position:relative;white-space:nowrap}.ngf-tab:after{content:\"\";position:absolute;bottom:-1px;left:0;right:0;height:2px;background:var(--primary);border-radius:2px 2px 0 0;transform:scaleX(0);transition:transform .15s}.ngf-tab:hover{color:var(--primary)}.ngf-tab--active{color:var(--primary);font-weight:700}.ngf-tab--active:after{transform:scaleX(1)}.ngf-canvas-area{flex:1;overflow:auto;position:relative;display:flex;justify-content:center;align-items:flex-start;padding:20px;background-image:radial-gradient(circle,#d6d2cc 1px,transparent 1px);background-size:20px 20px;background-position:10px 10px;background-color:#f0ede8;cursor:default}.ngf-canvas-area::-webkit-scrollbar{width:8px;height:8px}.ngf-canvas-area::-webkit-scrollbar-thumb{background:var(--z-300);border-radius:4px;border:2px solid #f0ede8}.ngf-canvas-wrapper{position:relative;display:inline-block}canvas{background:#fff;box-shadow:var(--shadow);display:none}canvas.ngf-canvas--active{display:block}canvas.ngf-canvas--interactive{cursor:crosshair}.ngf-info-bar{position:absolute;bottom:12px;left:50%;transform:translate(-50%);background:var(--z-900);color:#ffffffe6;padding:6px 16px;border-radius:100px;font-size:11px;font-weight:500;pointer-events:none;z-index:100;white-space:nowrap;box-shadow:0 4px 16px #0003}\n"] }]
        }], ctorParameters: () => [] });

/** Matériaux de sol */
const SOL_MATERIALS = [
    'Parquet massif',
    'Parquet stratifié',
    'Carrelage',
    'Tomettes',
    'Terre cuite',
    'Marbre',
    'Pierre naturelle',
    'Moquette',
    'Vinyle / PVC',
    'Linoleum',
    'Béton ciré',
    'Résine époxy',
    'Dalle béton brut',
];
/** Matériaux / finitions de mur */
const MUR_FINISHES = [
    'Peinture',
    'Papier peint',
    'Enduit à la chaux',
    'Crépi',
    'Carrelage',
    'Faïence',
    'Pierre apparente',
    'Brique apparente',
    'Lambris bois',
    'Bardage PVC',
    'Panneau composite',
    'Béton brut',
    'Mortier',
];
/** Matériaux / finitions de plafond */
const PLAFOND_FINISHES = [
    'Peinture',
    'Plâtre lisse',
    'Enduit',
    'Faux plafond (dalles)',
    'Faux plafond (plâtre)',
    'Lambris bois',
    'Béton apparent',
    'Plafond tendu',
    'Voûte',
    'Solives apparentes',
];
/** États génériques (sol, mur, plafond) */
const ETAT_OPTIONS = [
    'Bon état',
    'État correct',
    'Usure normale',
    'Dégradé',
    'À rénover',
    'Hors service',
];

class InspectorPanelComponent {
    data = input(null);
    /** Mode visualisation : tous les champs deviennent en lecture seule. */
    readOnly = input(false);
    dataChange = output();
    materials = ['Agglo', 'Béton', 'Brique', 'Plâtre', 'Bois', 'Métal'];
    solMaterials = SOL_MATERIALS;
    murFinishes = MUR_FINISHES;
    plafondFinishes = PLAFOND_FINISHES;
    etatOptions = ETAT_OPTIONS;
    glazingOptions = [
        { value: 'simple', label: '1 ouvrant (simple)' },
        { value: 'double', label: '2 ouvrants (double)' },
        { value: 'triple', label: '3 ouvrants (triple)' },
        { value: 'quadruple', label: '4 ouvrants (quadruple)' },
    ];
    doorTypeOptions = [
        { value: 'simple', label: 'Simple vantail' },
        { value: 'double', label: 'Double vantail' },
    ];
    hazardSurfaceOptions = [
        { value: 'sol', label: 'Sol' },
        { value: 'mur', label: 'Mur' },
        { value: 'plafond', label: 'Plafond' },
    ];
    onLabelChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, label: value });
    }
    onMaterialChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, material: value });
    }
    onIsPrimaryChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, isPrimary: value });
    }
    onGlazingTypeChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, glazingType: value });
    }
    onDoorTypeChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, doorType: value });
    }
    onHazardSurfaceChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, hazardSurface: value });
    }
    onRoomDescChange(surface, field, value) {
        const d = this.data();
        if (!d)
            return;
        const desc = { ...d.roomDescription };
        desc[surface] = { ...desc[surface], [field]: value };
        this.dataChange.emit({ ...d, roomDescription: desc });
    }
    onAmianteResultChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, amianteResult: value });
    }
    onLinkedSampleChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, linkedSampleId: value || null });
    }
    onNotesChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, notes: value });
    }
    onRoomNotesChange(value) {
        const d = this.data();
        if (!d)
            return;
        this.dataChange.emit({ ...d, roomDescription: { ...d.roomDescription, notes: value } });
    }
    onCriRoomChange(value) {
        const d = this.data();
        if (d)
            this.dataChange.emit({ ...d, criRoomId: value || null });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: InspectorPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: InspectorPanelComponent, isStandalone: true, selector: "ng-gplan-inspector-panel", inputs: { data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, readOnly: { classPropertyName: "readOnly", publicName: "readOnly", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dataChange: "dataChange" }, ngImport: i0, template: "<div class=\"ngf-inspector-panel\">\n  @if (!data()) {\n    <div class=\"ngf-inspector-panel__empty\">\n      <span>Selectionnez un objet</span>\n    </div>\n  } @else {\n    <fieldset class=\"ngf-inspector-panel__content\" [disabled]=\"readOnly()\"\n      [class.ngf-inspector-panel__content--readonly]=\"readOnly()\">\n      <h4 class=\"ngf-inspector-panel__type\">{{ data()!.objectType }}</h4>\n\n      @switch (data()!.objectType) {\n        @case ('DetectedRoom') {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Nom de la pi\u00E8ce</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" placeholder=\"ex : Salon, Chambre 1\u2026\" />\n          </div>\n          @if (data()!.availableCriRooms?.length) {\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Pi\u00E8ce CRI li\u00E9e</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.criRoomId || ''\"\n                (change)=\"onCriRoomChange($any($event.target).value)\">\n                <option value=\"\">\u2014 Aucune \u2014</option>\n                @for (c of data()!.availableCriRooms!; track c.id) {\n                  <option [value]=\"c.id\">{{ c.name }}</option>\n                }\n              </select>\n            </div>\n          }\n          @if (data()!.area !== undefined) {\n            <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n              <label>Surface</label>\n              <span>{{ data()!.area!.toFixed(2) }} m\u00B2</span>\n            </div>\n          }\n\n          <!-- Sol -->\n          <div class=\"ngf-room-surface-section\">\n            <div class=\"ngf-room-surface-section__title\">Sol</div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Mat\u00E9riau</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.sol?.material || ''\"\n                (change)=\"onRoomDescChange('sol', 'material', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (m of solMaterials; track m) {\n                  <option [value]=\"m\">{{ m }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>\u00C9tat</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.sol?.etat || ''\"\n                (change)=\"onRoomDescChange('sol', 'etat', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (e of etatOptions; track e) {\n                  <option [value]=\"e\">{{ e }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Notes</label>\n              <input type=\"text\" class=\"ngf-input\"\n                [value]=\"data()!.roomDescription?.sol?.notes || ''\"\n                (input)=\"onRoomDescChange('sol', 'notes', $any($event.target).value)\"\n                placeholder=\"Observations\u2026\" />\n            </div>\n          </div>\n\n          <!-- Mur -->\n          <div class=\"ngf-room-surface-section\">\n            <div class=\"ngf-room-surface-section__title\">Murs</div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Finition</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.mur?.material || ''\"\n                (change)=\"onRoomDescChange('mur', 'material', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (m of murFinishes; track m) {\n                  <option [value]=\"m\">{{ m }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>\u00C9tat</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.mur?.etat || ''\"\n                (change)=\"onRoomDescChange('mur', 'etat', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (e of etatOptions; track e) {\n                  <option [value]=\"e\">{{ e }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Notes</label>\n              <input type=\"text\" class=\"ngf-input\"\n                [value]=\"data()!.roomDescription?.mur?.notes || ''\"\n                (input)=\"onRoomDescChange('mur', 'notes', $any($event.target).value)\"\n                placeholder=\"Observations\u2026\" />\n            </div>\n          </div>\n\n          <!-- Plafond -->\n          <div class=\"ngf-room-surface-section\">\n            <div class=\"ngf-room-surface-section__title\">Plafond</div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Finition</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.plafond?.material || ''\"\n                (change)=\"onRoomDescChange('plafond', 'material', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (m of plafondFinishes; track m) {\n                  <option [value]=\"m\">{{ m }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>\u00C9tat</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.plafond?.etat || ''\"\n                (change)=\"onRoomDescChange('plafond', 'etat', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (e of etatOptions; track e) {\n                  <option [value]=\"e\">{{ e }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Notes</label>\n              <input type=\"text\" class=\"ngf-input\"\n                [value]=\"data()!.roomDescription?.plafond?.notes || ''\"\n                (input)=\"onRoomDescChange('plafond', 'notes', $any($event.target).value)\"\n                placeholder=\"Observations\u2026\" />\n            </div>\n          </div>\n\n          <!-- Notes g\u00E9n\u00E9rales pi\u00E8ce -->\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Notes g\u00E9n\u00E9rales</label>\n            <textarea class=\"ngf-input ngf-textarea\" rows=\"3\"\n              [value]=\"data()!.roomDescription?.notes || ''\"\n              (input)=\"onRoomNotesChange($any($event.target).value)\"\n              placeholder=\"Observations g\u00E9n\u00E9rales sur la pi\u00E8ce\u2026\"></textarea>\n          </div>\n        }\n        @case ('Mur') {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Mat\u00E9riau</label>\n            <select [value]=\"data()!.material || 'Agglo'\"\n              (change)=\"onMaterialChange($any($event.target).value)\" class=\"ngf-select\">\n              @for (m of materials; track m) {\n                <option [value]=\"m\">{{ m }}</option>\n              }\n            </select>\n          </div>\n          @if (data()!.length !== undefined) {\n            <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n              <label>Longueur</label>\n              <span>{{ data()!.length!.toFixed(2) }} m</span>\n            </div>\n          }\n        }\n        @case ('Cloison') {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          @if (data()!.length !== undefined) {\n            <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n              <label>Longueur</label>\n              <span>{{ data()!.length!.toFixed(2) }} m</span>\n            </div>\n          }\n        }\n        @case ('Door') {\n          @if (data()!.wallRef) {\n            <div class=\"ngf-inspector-panel__wall-ref\">\n              <span class=\"ngf-wall-letter\">{{ data()!.wallRef!.split(' ')[0] }}</span>\n              <span class=\"ngf-wall-ref-text\">{{ data()!.wallRef!.substring(data()!.wallRef!.indexOf(' ') + 1) }}</span>\n            </div>\n          }\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Type</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.doorType || 'simple'\"\n              (change)=\"onDoorTypeChange($any($event.target).value)\">\n              @for (opt of doorTypeOptions; track opt.value) {\n                <option [value]=\"opt.value\">{{ opt.label }}</option>\n              }\n            </select>\n          </div>\n          <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--primary\">\n            <label>Porte principale</label>\n            <button class=\"ngf-primary-btn\"\n              [class.ngf-primary-btn--active]=\"data()!.isPrimary\"\n              (click)=\"onIsPrimaryChange(!data()!.isPrimary)\">\n              {{ data()!.isPrimary ? 'Principale' : 'Secondaire' }}\n            </button>\n          </div>\n        }\n        @case ('Window') {\n          @if (data()!.wallRef) {\n            <div class=\"ngf-inspector-panel__wall-ref\">\n              <span class=\"ngf-wall-letter\">{{ data()!.wallRef!.split('-')[0] }}</span>\n              <span class=\"ngf-wall-ref-text\">{{ data()!.wallRef }}</span>\n            </div>\n          }\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Type de fen\u00EAtre</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.glazingType || 'simple'\"\n              (change)=\"onGlazingTypeChange($any($event.target).value)\">\n              @for (opt of glazingOptions; track opt.value) {\n                <option [value]=\"opt.value\">{{ opt.label }}</option>\n              }\n            </select>\n          </div>\n        }\n        @case ('HazardSample') {\n          <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n            <label>R\u00E9f\u00E9rence</label>\n            <span class=\"ngf-hazard-sample-id\">{{ data()!.label }}</span>\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Localisation</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.hazardSurface || 'sol'\"\n              (change)=\"onHazardSurfaceChange($any($event.target).value)\">\n              @for (opt of hazardSurfaceOptions; track opt.value) {\n                <option [value]=\"opt.value\">{{ opt.label }}</option>\n              }\n            </select>\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>R\u00E9sultat amiante</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.amianteResult || 'unknown'\"\n              (change)=\"onAmianteResultChange($any($event.target).value)\">\n              <option value=\"unknown\">\u2014 Non renseign\u00E9 \u2014</option>\n              <option value=\"positive\">Positif (oui)</option>\n              <option value=\"negative\">N\u00E9gatif (non)</option>\n            </select>\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Notes</label>\n            <textarea class=\"ngf-input ngf-textarea\" rows=\"2\"\n              [value]=\"data()!.notes || ''\"\n              (input)=\"onNotesChange($any($event.target).value)\"\n              placeholder=\"Observations\u2026\"></textarea>\n          </div>\n        }\n        @case ('HazardZone') {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Localisation</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.hazardSurface || 'sol'\"\n              (change)=\"onHazardSurfaceChange($any($event.target).value)\">\n              @for (opt of hazardSurfaceOptions; track opt.value) {\n                <option [value]=\"opt.value\">{{ opt.label }}</option>\n              }\n            </select>\n          </div>\n          @if (data()!.hazardType === 'amiante' && data()!.availableSamples?.length) {\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Pr\u00E9l\u00E8vement li\u00E9</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.linkedSampleId || ''\"\n                (change)=\"onLinkedSampleChange($any($event.target).value)\">\n                <option value=\"\">\u2014 Aucun \u2014</option>\n                @for (s of data()!.availableSamples!; track s.sampleId) {\n                  <option [value]=\"s.sampleId\">{{ s.sampleId }}</option>\n                }\n              </select>\n            </div>\n          }\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Notes</label>\n            <textarea class=\"ngf-input ngf-textarea\" rows=\"2\"\n              [value]=\"data()!.notes || ''\"\n              (input)=\"onNotesChange($any($event.target).value)\"\n              placeholder=\"Observations\u2026\"></textarea>\n          </div>\n        }\n        @default {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          @if (data()!.area !== undefined) {\n            <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n              <label>Surface</label>\n              <span>{{ data()!.area!.toFixed(2) }} m\u00B2</span>\n            </div>\n          }\n        }\n      }\n    </fieldset>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{--z-100: #f5f5f5;--z-200: #e5e5e5;--z-400: #a3a3a3;--z-500: #737373;--z-700: #404040;--z-900: #171717;--primary: #f97316;--primary-light: #fff7ed;--primary-border: #fed7aa;--font: \"Poppins\", ui-sans-serif, system-ui, sans-serif;--font-mono: \"DM Mono\", ui-monospace, monospace;display:block;font-family:var(--font)}.ngf-inspector-panel__empty{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px 16px;gap:8px;color:var(--z-400);font-size:12px;text-align:center}.ngf-inspector-panel__empty:before{content:\"\\2196\";font-size:24px;opacity:.3}.ngf-inspector-panel__content{display:flex;flex-direction:column;gap:14px}.ngf-inspector-panel__type{margin:0;font-size:9px;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:var(--primary);padding-bottom:10px;border-bottom:2px solid var(--primary-border)}.ngf-inspector-panel__field{display:flex;flex-direction:column;gap:5px}.ngf-inspector-panel__field label{font-size:9px;color:var(--z-400);text-transform:uppercase;letter-spacing:.1em;font-weight:700}.ngf-inspector-panel__field--readonly{padding:8px 10px;background:var(--primary-light);border:1px solid var(--primary-border);border-radius:8px}.ngf-inspector-panel__field--readonly span{font-family:var(--font-mono);font-size:15px;font-weight:700;color:var(--primary)}.ngf-inspector-panel__wall-ref{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;margin-bottom:4px}.ngf-wall-letter{display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:24px;background:#6366f1;color:#fff;border-radius:5px;font-size:12px;font-weight:700;font-family:var(--font-mono);flex-shrink:0}.ngf-wall-ref-text{font-size:11px;color:#4338ca;font-weight:500;line-height:1.3}.ngf-inspector-panel__field--primary{align-items:center}.ngf-primary-btn{padding:5px 12px;border-radius:20px;border:1.5px solid #e5e7eb;background:#f9fafb;color:#6b7280;font-size:11px;font-weight:600;cursor:pointer;font-family:var(--font);transition:all .12s}.ngf-primary-btn:hover{border-color:#f97316;color:#f97316}.ngf-primary-btn--active{background:#f97316;border-color:#f97316;color:#fff}.ngf-primary-btn--active:hover{background:#ea580c;border-color:#ea580c}.ngf-input,.ngf-select{width:100%;padding:7px 10px;border:1px solid var(--z-200);border-radius:8px;font-size:12px;font-family:var(--font);color:var(--z-900);background:#fff;box-sizing:border-box;transition:border-color .1s,box-shadow .1s}.ngf-input:focus,.ngf-select:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px #f973161f}.ngf-textarea{resize:vertical;min-height:60px;line-height:1.4}.ngf-room-surface-section{display:flex;flex-direction:column;gap:10px;padding:12px;background:#fafafa;border:1px solid var(--z-200);border-radius:10px}.ngf-room-surface-section__title{font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:var(--z-500);padding-bottom:8px;border-bottom:1px solid var(--z-200)}fieldset.ngf-inspector-panel__content{border:0;padding:0;margin:0;min-width:0}fieldset.ngf-inspector-panel__content--readonly{opacity:.85}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: InspectorPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-gplan-inspector-panel', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [FormsModule], template: "<div class=\"ngf-inspector-panel\">\n  @if (!data()) {\n    <div class=\"ngf-inspector-panel__empty\">\n      <span>Selectionnez un objet</span>\n    </div>\n  } @else {\n    <fieldset class=\"ngf-inspector-panel__content\" [disabled]=\"readOnly()\"\n      [class.ngf-inspector-panel__content--readonly]=\"readOnly()\">\n      <h4 class=\"ngf-inspector-panel__type\">{{ data()!.objectType }}</h4>\n\n      @switch (data()!.objectType) {\n        @case ('DetectedRoom') {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Nom de la pi\u00E8ce</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" placeholder=\"ex : Salon, Chambre 1\u2026\" />\n          </div>\n          @if (data()!.availableCriRooms?.length) {\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Pi\u00E8ce CRI li\u00E9e</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.criRoomId || ''\"\n                (change)=\"onCriRoomChange($any($event.target).value)\">\n                <option value=\"\">\u2014 Aucune \u2014</option>\n                @for (c of data()!.availableCriRooms!; track c.id) {\n                  <option [value]=\"c.id\">{{ c.name }}</option>\n                }\n              </select>\n            </div>\n          }\n          @if (data()!.area !== undefined) {\n            <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n              <label>Surface</label>\n              <span>{{ data()!.area!.toFixed(2) }} m\u00B2</span>\n            </div>\n          }\n\n          <!-- Sol -->\n          <div class=\"ngf-room-surface-section\">\n            <div class=\"ngf-room-surface-section__title\">Sol</div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Mat\u00E9riau</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.sol?.material || ''\"\n                (change)=\"onRoomDescChange('sol', 'material', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (m of solMaterials; track m) {\n                  <option [value]=\"m\">{{ m }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>\u00C9tat</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.sol?.etat || ''\"\n                (change)=\"onRoomDescChange('sol', 'etat', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (e of etatOptions; track e) {\n                  <option [value]=\"e\">{{ e }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Notes</label>\n              <input type=\"text\" class=\"ngf-input\"\n                [value]=\"data()!.roomDescription?.sol?.notes || ''\"\n                (input)=\"onRoomDescChange('sol', 'notes', $any($event.target).value)\"\n                placeholder=\"Observations\u2026\" />\n            </div>\n          </div>\n\n          <!-- Mur -->\n          <div class=\"ngf-room-surface-section\">\n            <div class=\"ngf-room-surface-section__title\">Murs</div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Finition</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.mur?.material || ''\"\n                (change)=\"onRoomDescChange('mur', 'material', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (m of murFinishes; track m) {\n                  <option [value]=\"m\">{{ m }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>\u00C9tat</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.mur?.etat || ''\"\n                (change)=\"onRoomDescChange('mur', 'etat', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (e of etatOptions; track e) {\n                  <option [value]=\"e\">{{ e }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Notes</label>\n              <input type=\"text\" class=\"ngf-input\"\n                [value]=\"data()!.roomDescription?.mur?.notes || ''\"\n                (input)=\"onRoomDescChange('mur', 'notes', $any($event.target).value)\"\n                placeholder=\"Observations\u2026\" />\n            </div>\n          </div>\n\n          <!-- Plafond -->\n          <div class=\"ngf-room-surface-section\">\n            <div class=\"ngf-room-surface-section__title\">Plafond</div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Finition</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.plafond?.material || ''\"\n                (change)=\"onRoomDescChange('plafond', 'material', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (m of plafondFinishes; track m) {\n                  <option [value]=\"m\">{{ m }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>\u00C9tat</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.roomDescription?.plafond?.etat || ''\"\n                (change)=\"onRoomDescChange('plafond', 'etat', $any($event.target).value)\">\n                <option value=\"\">\u2014 Non renseign\u00E9 \u2014</option>\n                @for (e of etatOptions; track e) {\n                  <option [value]=\"e\">{{ e }}</option>\n                }\n              </select>\n            </div>\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Notes</label>\n              <input type=\"text\" class=\"ngf-input\"\n                [value]=\"data()!.roomDescription?.plafond?.notes || ''\"\n                (input)=\"onRoomDescChange('plafond', 'notes', $any($event.target).value)\"\n                placeholder=\"Observations\u2026\" />\n            </div>\n          </div>\n\n          <!-- Notes g\u00E9n\u00E9rales pi\u00E8ce -->\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Notes g\u00E9n\u00E9rales</label>\n            <textarea class=\"ngf-input ngf-textarea\" rows=\"3\"\n              [value]=\"data()!.roomDescription?.notes || ''\"\n              (input)=\"onRoomNotesChange($any($event.target).value)\"\n              placeholder=\"Observations g\u00E9n\u00E9rales sur la pi\u00E8ce\u2026\"></textarea>\n          </div>\n        }\n        @case ('Mur') {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Mat\u00E9riau</label>\n            <select [value]=\"data()!.material || 'Agglo'\"\n              (change)=\"onMaterialChange($any($event.target).value)\" class=\"ngf-select\">\n              @for (m of materials; track m) {\n                <option [value]=\"m\">{{ m }}</option>\n              }\n            </select>\n          </div>\n          @if (data()!.length !== undefined) {\n            <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n              <label>Longueur</label>\n              <span>{{ data()!.length!.toFixed(2) }} m</span>\n            </div>\n          }\n        }\n        @case ('Cloison') {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          @if (data()!.length !== undefined) {\n            <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n              <label>Longueur</label>\n              <span>{{ data()!.length!.toFixed(2) }} m</span>\n            </div>\n          }\n        }\n        @case ('Door') {\n          @if (data()!.wallRef) {\n            <div class=\"ngf-inspector-panel__wall-ref\">\n              <span class=\"ngf-wall-letter\">{{ data()!.wallRef!.split(' ')[0] }}</span>\n              <span class=\"ngf-wall-ref-text\">{{ data()!.wallRef!.substring(data()!.wallRef!.indexOf(' ') + 1) }}</span>\n            </div>\n          }\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Type</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.doorType || 'simple'\"\n              (change)=\"onDoorTypeChange($any($event.target).value)\">\n              @for (opt of doorTypeOptions; track opt.value) {\n                <option [value]=\"opt.value\">{{ opt.label }}</option>\n              }\n            </select>\n          </div>\n          <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--primary\">\n            <label>Porte principale</label>\n            <button class=\"ngf-primary-btn\"\n              [class.ngf-primary-btn--active]=\"data()!.isPrimary\"\n              (click)=\"onIsPrimaryChange(!data()!.isPrimary)\">\n              {{ data()!.isPrimary ? 'Principale' : 'Secondaire' }}\n            </button>\n          </div>\n        }\n        @case ('Window') {\n          @if (data()!.wallRef) {\n            <div class=\"ngf-inspector-panel__wall-ref\">\n              <span class=\"ngf-wall-letter\">{{ data()!.wallRef!.split('-')[0] }}</span>\n              <span class=\"ngf-wall-ref-text\">{{ data()!.wallRef }}</span>\n            </div>\n          }\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Type de fen\u00EAtre</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.glazingType || 'simple'\"\n              (change)=\"onGlazingTypeChange($any($event.target).value)\">\n              @for (opt of glazingOptions; track opt.value) {\n                <option [value]=\"opt.value\">{{ opt.label }}</option>\n              }\n            </select>\n          </div>\n        }\n        @case ('HazardSample') {\n          <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n            <label>R\u00E9f\u00E9rence</label>\n            <span class=\"ngf-hazard-sample-id\">{{ data()!.label }}</span>\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Localisation</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.hazardSurface || 'sol'\"\n              (change)=\"onHazardSurfaceChange($any($event.target).value)\">\n              @for (opt of hazardSurfaceOptions; track opt.value) {\n                <option [value]=\"opt.value\">{{ opt.label }}</option>\n              }\n            </select>\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>R\u00E9sultat amiante</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.amianteResult || 'unknown'\"\n              (change)=\"onAmianteResultChange($any($event.target).value)\">\n              <option value=\"unknown\">\u2014 Non renseign\u00E9 \u2014</option>\n              <option value=\"positive\">Positif (oui)</option>\n              <option value=\"negative\">N\u00E9gatif (non)</option>\n            </select>\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Notes</label>\n            <textarea class=\"ngf-input ngf-textarea\" rows=\"2\"\n              [value]=\"data()!.notes || ''\"\n              (input)=\"onNotesChange($any($event.target).value)\"\n              placeholder=\"Observations\u2026\"></textarea>\n          </div>\n        }\n        @case ('HazardZone') {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Localisation</label>\n            <select class=\"ngf-select\"\n              [value]=\"data()!.hazardSurface || 'sol'\"\n              (change)=\"onHazardSurfaceChange($any($event.target).value)\">\n              @for (opt of hazardSurfaceOptions; track opt.value) {\n                <option [value]=\"opt.value\">{{ opt.label }}</option>\n              }\n            </select>\n          </div>\n          @if (data()!.hazardType === 'amiante' && data()!.availableSamples?.length) {\n            <div class=\"ngf-inspector-panel__field\">\n              <label>Pr\u00E9l\u00E8vement li\u00E9</label>\n              <select class=\"ngf-select\"\n                [value]=\"data()!.linkedSampleId || ''\"\n                (change)=\"onLinkedSampleChange($any($event.target).value)\">\n                <option value=\"\">\u2014 Aucun \u2014</option>\n                @for (s of data()!.availableSamples!; track s.sampleId) {\n                  <option [value]=\"s.sampleId\">{{ s.sampleId }}</option>\n                }\n              </select>\n            </div>\n          }\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Notes</label>\n            <textarea class=\"ngf-input ngf-textarea\" rows=\"2\"\n              [value]=\"data()!.notes || ''\"\n              (input)=\"onNotesChange($any($event.target).value)\"\n              placeholder=\"Observations\u2026\"></textarea>\n          </div>\n        }\n        @default {\n          <div class=\"ngf-inspector-panel__field\">\n            <label>Label</label>\n            <input type=\"text\" [value]=\"data()!.label || ''\"\n              (input)=\"onLabelChange($any($event.target).value)\" class=\"ngf-input\" />\n          </div>\n          @if (data()!.area !== undefined) {\n            <div class=\"ngf-inspector-panel__field ngf-inspector-panel__field--readonly\">\n              <label>Surface</label>\n              <span>{{ data()!.area!.toFixed(2) }} m\u00B2</span>\n            </div>\n          }\n        }\n      }\n    </fieldset>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{--z-100: #f5f5f5;--z-200: #e5e5e5;--z-400: #a3a3a3;--z-500: #737373;--z-700: #404040;--z-900: #171717;--primary: #f97316;--primary-light: #fff7ed;--primary-border: #fed7aa;--font: \"Poppins\", ui-sans-serif, system-ui, sans-serif;--font-mono: \"DM Mono\", ui-monospace, monospace;display:block;font-family:var(--font)}.ngf-inspector-panel__empty{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px 16px;gap:8px;color:var(--z-400);font-size:12px;text-align:center}.ngf-inspector-panel__empty:before{content:\"\\2196\";font-size:24px;opacity:.3}.ngf-inspector-panel__content{display:flex;flex-direction:column;gap:14px}.ngf-inspector-panel__type{margin:0;font-size:9px;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:var(--primary);padding-bottom:10px;border-bottom:2px solid var(--primary-border)}.ngf-inspector-panel__field{display:flex;flex-direction:column;gap:5px}.ngf-inspector-panel__field label{font-size:9px;color:var(--z-400);text-transform:uppercase;letter-spacing:.1em;font-weight:700}.ngf-inspector-panel__field--readonly{padding:8px 10px;background:var(--primary-light);border:1px solid var(--primary-border);border-radius:8px}.ngf-inspector-panel__field--readonly span{font-family:var(--font-mono);font-size:15px;font-weight:700;color:var(--primary)}.ngf-inspector-panel__wall-ref{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;margin-bottom:4px}.ngf-wall-letter{display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:24px;background:#6366f1;color:#fff;border-radius:5px;font-size:12px;font-weight:700;font-family:var(--font-mono);flex-shrink:0}.ngf-wall-ref-text{font-size:11px;color:#4338ca;font-weight:500;line-height:1.3}.ngf-inspector-panel__field--primary{align-items:center}.ngf-primary-btn{padding:5px 12px;border-radius:20px;border:1.5px solid #e5e7eb;background:#f9fafb;color:#6b7280;font-size:11px;font-weight:600;cursor:pointer;font-family:var(--font);transition:all .12s}.ngf-primary-btn:hover{border-color:#f97316;color:#f97316}.ngf-primary-btn--active{background:#f97316;border-color:#f97316;color:#fff}.ngf-primary-btn--active:hover{background:#ea580c;border-color:#ea580c}.ngf-input,.ngf-select{width:100%;padding:7px 10px;border:1px solid var(--z-200);border-radius:8px;font-size:12px;font-family:var(--font);color:var(--z-900);background:#fff;box-sizing:border-box;transition:border-color .1s,box-shadow .1s}.ngf-input:focus,.ngf-select:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px #f973161f}.ngf-textarea{resize:vertical;min-height:60px;line-height:1.4}.ngf-room-surface-section{display:flex;flex-direction:column;gap:10px;padding:12px;background:#fafafa;border:1px solid var(--z-200);border-radius:10px}.ngf-room-surface-section__title{font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:var(--z-500);padding-bottom:8px;border-bottom:1px solid var(--z-200)}fieldset.ngf-inspector-panel__content{border:0;padding:0;margin:0;min-width:0}fieldset.ngf-inspector-panel__content--readonly{opacity:.85}\n"] }]
        }] });

class OsmModalComponent {
    config = input.required();
    import = output();
    close = output();
    mapContainerRef = viewChild.required('osmMapContainer');
    osmSvc = inject(OsmService);
    searchQuery = signal('');
    searchResults = signal([]);
    isSearching = signal(false);
    showResults = signal(false);
    activeLayer = signal('osm');
    ngAfterViewInit() {
        this.osmSvc.initMap(this.mapContainerRef().nativeElement, this.config());
    }
    async onSearch() {
        const q = this.searchQuery().trim();
        if (!q)
            return;
        this.isSearching.set(true);
        this.showResults.set(false);
        try {
            const results = await this.osmSvc.geocode(q);
            this.searchResults.set(results);
            this.showResults.set(results.length > 0);
        }
        finally {
            this.isSearching.set(false);
        }
    }
    onSearchKeydown(event) {
        if (event.key === 'Enter')
            this.onSearch();
        if (event.key === 'Escape')
            this.showResults.set(false);
    }
    selectResult(result) {
        this.osmSvc.flyTo(result.lat, result.lng);
        this.showResults.set(false);
    }
    setLayer(layer) {
        this.activeLayer.set(layer);
        this.osmSvc.setLayer(layer, this.config());
    }
    async onImport() {
        const dataUrl = await this.osmSvc.captureCurrentView();
        const center = this.osmSvc.getCenter();
        if (!center)
            return;
        // MapLibre GL utilise un renderer 512px natif → constante 78271.515
        // metersPerPx en pixels CSS ; MapLibre rend à devicePixelRatio donc
        // chaque pixel image = 1 px CSS / dpr → correction par dpr
        const metersPerPx = 78271.515 * Math.cos(center.lat * Math.PI / 180) / Math.pow(2, center.zoom);
        const dpr = window.devicePixelRatio || 1;
        const scaleVal = dpr / metersPerPx; // pixels Fabric (physiques) par mètre réel
        const geo = { lat: center.lat, lng: center.lng, zoom: center.zoom, valid: true };
        this.import.emit({ dataUrl, geo, scaleVal });
    }
    onClose() {
        this.close.emit();
    }
    ngOnDestroy() {
        this.osmSvc.destroy();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: OsmModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: OsmModalComponent, isStandalone: true, selector: "ng-gplan-osm-modal", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { import: "import", close: "close" }, viewQueries: [{ propertyName: "mapContainerRef", first: true, predicate: ["osmMapContainer"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"ngf-osm-overlay\" (click)=\"onClose()\">\n  <div class=\"ngf-osm-modal\" (click)=\"$event.stopPropagation()\">\n\n    <!-- En-t\u00EAte -->\n    <div class=\"ngf-osm-modal__header\">\n      <h3>Importer depuis la carte</h3>\n      <button class=\"ngf-osm-modal__close\" (click)=\"onClose()\">\u2715</button>\n    </div>\n\n    <!-- Barre de recherche + switcher de couches -->\n    <div class=\"ngf-osm-modal__toolbar\">\n\n      <div class=\"ngf-osm-search\">\n        <input class=\"ngf-osm-search__input\"\n               type=\"text\"\n               placeholder=\"Rechercher une adresse\u2026\"\n               [ngModel]=\"searchQuery()\"\n               (ngModelChange)=\"searchQuery.set($event)\"\n               (keydown)=\"onSearchKeydown($event)\" />\n        <button class=\"ngf-osm-search__btn\"\n                (click)=\"onSearch()\"\n                [disabled]=\"isSearching()\"\n                title=\"Rechercher\">\n          @if (isSearching()) { \u2026 } @else { \u2315 }\n        </button>\n\n        <!-- R\u00E9sultats -->\n        @if (showResults()) {\n          <div class=\"ngf-osm-results\">\n            @for (r of searchResults(); track r.label) {\n              <button class=\"ngf-osm-results__item\" (click)=\"selectResult(r)\">\n                {{ r.label }}\n              </button>\n            }\n          </div>\n        }\n      </div>\n\n      <!-- Switcher de couches -->\n      <div class=\"ngf-osm-layers\">\n        <button class=\"ngf-osm-layer-btn\"\n                [class.ngf-osm-layer-btn--active]=\"activeLayer() === 'osm'\"\n                (click)=\"setLayer('osm')\" title=\"Carte OSM\">\n          \uD83D\uDDFA OSM\n        </button>\n        <button class=\"ngf-osm-layer-btn\"\n                [class.ngf-osm-layer-btn--active]=\"activeLayer() === 'satellite'\"\n                (click)=\"setLayer('satellite')\" title=\"Satellite\">\n          \uD83D\uDEF0 Satellite\n        </button>\n        <button class=\"ngf-osm-layer-btn\"\n                [class.ngf-osm-layer-btn--active]=\"activeLayer() === 'cadastre'\"\n                (click)=\"setLayer('cadastre')\" title=\"Cadastre (overlay)\">\n          \uD83C\uDFD8 Cadastre\n        </button>\n      </div>\n    </div>\n\n    <!-- Carte -->\n    <div #osmMapContainer class=\"ngf-osm-modal__map\"></div>\n\n    <!-- Avertissement satellite overzooom -->\n    @if (activeLayer() === 'satellite') {\n      <div class=\"ngf-osm-modal__sat-warn\">\n        \u26A0 Satellite : couverture native jusqu'au zoom 18. Au-del\u00E0, l'image est floue et l'\u00E9chelle peut \u00EAtre approximative \u2014 ajustez le curseur <strong>\u00C9chelle</strong> apr\u00E8s l'import si n\u00E9cessaire.\n      </div>\n    }\n\n    <!-- Pied de page -->\n    <div class=\"ngf-osm-modal__footer\">\n      <span class=\"ngf-osm-modal__hint\">Centrez et zoomez sur la zone \u00E0 importer</span>\n      <button class=\"ngf-btn-primary\" (click)=\"onImport()\">Importer cette vue</button>\n    </div>\n\n  </div>\n</div>\n", styles: [".ngf-osm-overlay{position:fixed;inset:0;background:#00000080;display:flex;align-items:center;justify-content:center;z-index:9000;backdrop-filter:blur(2px)}.ngf-osm-modal{background:#fff;border-radius:16px;width:82vw;max-width:960px;height:76vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 64px #0003,0 0 0 1px #0000000a;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;animation:modalIn .18s cubic-bezier(.34,1.56,.64,1)}.ngf-osm-modal__header{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;background:#f97316;flex-shrink:0}.ngf-osm-modal__header h3{margin:0;font-size:14px;font-weight:700;color:#fff;letter-spacing:.01em}.ngf-osm-modal__close{background:#ffffff26;border:none;font-size:14px;cursor:pointer;color:#fff;width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;transition:background .1s}.ngf-osm-modal__close:hover{background:#ffffff47}.ngf-osm-modal__map{flex:1;min-height:0}.ngf-osm-modal__sat-warn{padding:7px 16px;background:#fef3c7;border-top:1px solid #fbbf24;font-size:11px;color:#92400e;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;flex-shrink:0;line-height:1.5}.ngf-osm-modal__footer{padding:10px 16px;border-top:1px solid #e5e5e5;background:#fff7ed;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:12px}.ngf-osm-modal__hint{font-size:11px;color:#9a3412;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:500}@keyframes modalIn{0%{opacity:0;transform:scale(.97) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}.ngf-osm-modal__toolbar{display:flex;align-items:center;gap:10px;padding:8px 12px;background:#f5f5f5;border-bottom:1px solid #e5e5e5;flex-shrink:0}.ngf-osm-search{position:relative;flex:1;display:flex}.ngf-osm-search__input{flex:1;padding:7px 12px;border:1px solid #e5e5e5;border-right:none;border-radius:8px 0 0 8px;font-size:12px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:500;outline:none;background:#fff;color:#171717;transition:border-color .1s,box-shadow .1s}.ngf-osm-search__input:focus{border-color:#f97316;box-shadow:0 0 0 2px #f973161f}.ngf-osm-search__input::placeholder{color:#a3a3a3}.ngf-osm-search__btn{padding:7px 14px;background:#f97316;color:#fff;border:1px solid #f97316;border-radius:0 8px 8px 0;cursor:pointer;font-size:15px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;line-height:1;transition:background .1s}.ngf-osm-search__btn:hover:not(:disabled){background:#ea580c;border-color:#ea580c}.ngf-osm-search__btn:disabled{opacity:.5;cursor:default}.ngf-osm-results{position:absolute;top:calc(100% + 4px);left:0;right:0;background:#fff;border:1px solid #fed7aa;border-radius:10px;box-shadow:0 8px 24px #f973161f,0 2px 8px #00000014;z-index:100;max-height:240px;overflow-y:auto}.ngf-osm-results__item{display:block;width:100%;text-align:left;padding:9px 14px;background:none;border:none;border-bottom:1px solid #f5f5f5;font-size:12px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:500;color:#525252;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:background .1s,color .1s}.ngf-osm-results__item:first-child{border-radius:10px 10px 0 0}.ngf-osm-results__item:last-child{border-bottom:none;border-radius:0 0 10px 10px}.ngf-osm-results__item:hover{background:#fff7ed;color:#f97316}.ngf-osm-layers{display:flex;gap:4px;flex-shrink:0}.ngf-osm-layer-btn{padding:6px 12px;background:#fff;border:1px solid #e5e5e5;border-radius:100px;font-size:11px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:600;cursor:pointer;color:#525252;white-space:nowrap;transition:background .1s,border-color .1s,color .1s}.ngf-osm-layer-btn:hover{background:#fff7ed;border-color:#fed7aa;color:#f97316}.ngf-osm-layer-btn--active{background:#f97316;border-color:#f97316;color:#fff;box-shadow:0 2px 6px #f973164d}.ngf-btn-primary{background:#f97316;color:#fff;border:none;padding:8px 20px;border-radius:100px;cursor:pointer;font-size:12px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:700;flex-shrink:0;box-shadow:0 2px 6px #f9731659;transition:background .1s,box-shadow .1s}.ngf-btn-primary:hover{background:#ea580c;box-shadow:0 4px 12px #f9731666}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: OsmModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-gplan-osm-modal', standalone: true, imports: [FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"ngf-osm-overlay\" (click)=\"onClose()\">\n  <div class=\"ngf-osm-modal\" (click)=\"$event.stopPropagation()\">\n\n    <!-- En-t\u00EAte -->\n    <div class=\"ngf-osm-modal__header\">\n      <h3>Importer depuis la carte</h3>\n      <button class=\"ngf-osm-modal__close\" (click)=\"onClose()\">\u2715</button>\n    </div>\n\n    <!-- Barre de recherche + switcher de couches -->\n    <div class=\"ngf-osm-modal__toolbar\">\n\n      <div class=\"ngf-osm-search\">\n        <input class=\"ngf-osm-search__input\"\n               type=\"text\"\n               placeholder=\"Rechercher une adresse\u2026\"\n               [ngModel]=\"searchQuery()\"\n               (ngModelChange)=\"searchQuery.set($event)\"\n               (keydown)=\"onSearchKeydown($event)\" />\n        <button class=\"ngf-osm-search__btn\"\n                (click)=\"onSearch()\"\n                [disabled]=\"isSearching()\"\n                title=\"Rechercher\">\n          @if (isSearching()) { \u2026 } @else { \u2315 }\n        </button>\n\n        <!-- R\u00E9sultats -->\n        @if (showResults()) {\n          <div class=\"ngf-osm-results\">\n            @for (r of searchResults(); track r.label) {\n              <button class=\"ngf-osm-results__item\" (click)=\"selectResult(r)\">\n                {{ r.label }}\n              </button>\n            }\n          </div>\n        }\n      </div>\n\n      <!-- Switcher de couches -->\n      <div class=\"ngf-osm-layers\">\n        <button class=\"ngf-osm-layer-btn\"\n                [class.ngf-osm-layer-btn--active]=\"activeLayer() === 'osm'\"\n                (click)=\"setLayer('osm')\" title=\"Carte OSM\">\n          \uD83D\uDDFA OSM\n        </button>\n        <button class=\"ngf-osm-layer-btn\"\n                [class.ngf-osm-layer-btn--active]=\"activeLayer() === 'satellite'\"\n                (click)=\"setLayer('satellite')\" title=\"Satellite\">\n          \uD83D\uDEF0 Satellite\n        </button>\n        <button class=\"ngf-osm-layer-btn\"\n                [class.ngf-osm-layer-btn--active]=\"activeLayer() === 'cadastre'\"\n                (click)=\"setLayer('cadastre')\" title=\"Cadastre (overlay)\">\n          \uD83C\uDFD8 Cadastre\n        </button>\n      </div>\n    </div>\n\n    <!-- Carte -->\n    <div #osmMapContainer class=\"ngf-osm-modal__map\"></div>\n\n    <!-- Avertissement satellite overzooom -->\n    @if (activeLayer() === 'satellite') {\n      <div class=\"ngf-osm-modal__sat-warn\">\n        \u26A0 Satellite : couverture native jusqu'au zoom 18. Au-del\u00E0, l'image est floue et l'\u00E9chelle peut \u00EAtre approximative \u2014 ajustez le curseur <strong>\u00C9chelle</strong> apr\u00E8s l'import si n\u00E9cessaire.\n      </div>\n    }\n\n    <!-- Pied de page -->\n    <div class=\"ngf-osm-modal__footer\">\n      <span class=\"ngf-osm-modal__hint\">Centrez et zoomez sur la zone \u00E0 importer</span>\n      <button class=\"ngf-btn-primary\" (click)=\"onImport()\">Importer cette vue</button>\n    </div>\n\n  </div>\n</div>\n", styles: [".ngf-osm-overlay{position:fixed;inset:0;background:#00000080;display:flex;align-items:center;justify-content:center;z-index:9000;backdrop-filter:blur(2px)}.ngf-osm-modal{background:#fff;border-radius:16px;width:82vw;max-width:960px;height:76vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 64px #0003,0 0 0 1px #0000000a;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;animation:modalIn .18s cubic-bezier(.34,1.56,.64,1)}.ngf-osm-modal__header{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;background:#f97316;flex-shrink:0}.ngf-osm-modal__header h3{margin:0;font-size:14px;font-weight:700;color:#fff;letter-spacing:.01em}.ngf-osm-modal__close{background:#ffffff26;border:none;font-size:14px;cursor:pointer;color:#fff;width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;transition:background .1s}.ngf-osm-modal__close:hover{background:#ffffff47}.ngf-osm-modal__map{flex:1;min-height:0}.ngf-osm-modal__sat-warn{padding:7px 16px;background:#fef3c7;border-top:1px solid #fbbf24;font-size:11px;color:#92400e;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;flex-shrink:0;line-height:1.5}.ngf-osm-modal__footer{padding:10px 16px;border-top:1px solid #e5e5e5;background:#fff7ed;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:12px}.ngf-osm-modal__hint{font-size:11px;color:#9a3412;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:500}@keyframes modalIn{0%{opacity:0;transform:scale(.97) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}.ngf-osm-modal__toolbar{display:flex;align-items:center;gap:10px;padding:8px 12px;background:#f5f5f5;border-bottom:1px solid #e5e5e5;flex-shrink:0}.ngf-osm-search{position:relative;flex:1;display:flex}.ngf-osm-search__input{flex:1;padding:7px 12px;border:1px solid #e5e5e5;border-right:none;border-radius:8px 0 0 8px;font-size:12px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:500;outline:none;background:#fff;color:#171717;transition:border-color .1s,box-shadow .1s}.ngf-osm-search__input:focus{border-color:#f97316;box-shadow:0 0 0 2px #f973161f}.ngf-osm-search__input::placeholder{color:#a3a3a3}.ngf-osm-search__btn{padding:7px 14px;background:#f97316;color:#fff;border:1px solid #f97316;border-radius:0 8px 8px 0;cursor:pointer;font-size:15px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;line-height:1;transition:background .1s}.ngf-osm-search__btn:hover:not(:disabled){background:#ea580c;border-color:#ea580c}.ngf-osm-search__btn:disabled{opacity:.5;cursor:default}.ngf-osm-results{position:absolute;top:calc(100% + 4px);left:0;right:0;background:#fff;border:1px solid #fed7aa;border-radius:10px;box-shadow:0 8px 24px #f973161f,0 2px 8px #00000014;z-index:100;max-height:240px;overflow-y:auto}.ngf-osm-results__item{display:block;width:100%;text-align:left;padding:9px 14px;background:none;border:none;border-bottom:1px solid #f5f5f5;font-size:12px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:500;color:#525252;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:background .1s,color .1s}.ngf-osm-results__item:first-child{border-radius:10px 10px 0 0}.ngf-osm-results__item:last-child{border-bottom:none;border-radius:0 0 10px 10px}.ngf-osm-results__item:hover{background:#fff7ed;color:#f97316}.ngf-osm-layers{display:flex;gap:4px;flex-shrink:0}.ngf-osm-layer-btn{padding:6px 12px;background:#fff;border:1px solid #e5e5e5;border-radius:100px;font-size:11px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:600;cursor:pointer;color:#525252;white-space:nowrap;transition:background .1s,border-color .1s,color .1s}.ngf-osm-layer-btn:hover{background:#fff7ed;border-color:#fed7aa;color:#f97316}.ngf-osm-layer-btn--active{background:#f97316;border-color:#f97316;color:#fff;box-shadow:0 2px 6px #f973164d}.ngf-btn-primary{background:#f97316;color:#fff;border:none;padding:8px 20px;border-radius:100px;cursor:pointer;font-size:12px;font-family:Poppins,ui-sans-serif,system-ui,sans-serif;font-weight:700;flex-shrink:0;box-shadow:0 2px 6px #f9731659;transition:background .1s,box-shadow .1s}.ngf-btn-primary:hover{background:#ea580c;box-shadow:0 4px 12px #f9731666}\n"] }]
        }] });

/** Pixels per meter used in templates */
const PPM = 50;
/** Canvas offset so the plan isn't flush against the edge */
const OX = 120;
const OY = 120;
function mur(x1m, y1m, x2m, y2m, id) {
    const ax = OX + x1m * PPM, ay = OY + y1m * PPM;
    const bx = OX + x2m * PPM, by = OY + y2m * PPM;
    const w = Math.abs(bx - ax), h = Math.abs(by - ay);
    const xM = ax <= bx ? -1 : 1;
    const yM = ay <= by ? -1 : 1;
    return {
        type: 'line', version: '5.3.0',
        left: Math.min(ax, bx), top: Math.min(ay, by), width: w, height: h,
        originX: 'left', originY: 'top', angle: 0, scaleX: 1, scaleY: 1,
        opacity: 1, visible: true, stroke: '#18181b', strokeWidth: 5,
        fill: 'rgb(0,0,0)', selectable: true, evented: true, hasControls: true,
        myType: 'Mur', data: { material: 'Agglo', wallId: id },
        x1: xM * w / 2, y1: yM * h / 2, x2: -(xM * w / 2), y2: -(yM * h / 2),
    };
}
function cloison(x1m, y1m, x2m, y2m, id) {
    const ax = OX + x1m * PPM, ay = OY + y1m * PPM;
    const bx = OX + x2m * PPM, by = OY + y2m * PPM;
    const w = Math.abs(bx - ax), h = Math.abs(by - ay);
    const xM = ax <= bx ? -1 : 1;
    const yM = ay <= by ? -1 : 1;
    return {
        type: 'line', version: '5.3.0',
        left: Math.min(ax, bx), top: Math.min(ay, by), width: w, height: h,
        originX: 'left', originY: 'top', angle: 0, scaleX: 1, scaleY: 1,
        opacity: 1, visible: true, stroke: '#52525b', strokeWidth: 3,
        strokeDashArray: [8, 4], fill: 'rgb(0,0,0)', selectable: true, evented: true,
        hasControls: true, myType: 'Cloison', data: { material: 'Platre', wallId: id },
        x1: xM * w / 2, y1: yM * h / 2, x2: -(xM * w / 2), y2: -(yM * h / 2),
    };
}
/** Rectangle envelope: 4 walls (0,0)→(W,H) */
function envelope(W, H, prefix) {
    return [
        mur(0, 0, W, 0, `${prefix}-w1`),
        mur(W, 0, W, H, `${prefix}-w2`),
        mur(W, H, 0, H, `${prefix}-w3`),
        mur(0, H, 0, 0, `${prefix}-w4`),
    ];
}
/**
 * L-shape: full W×H bounding box minus top-right corner (W-cx)×cy.
 * Shape (clockwise from top-left):
 *  (0,0)──(cx,0)
 *    │       │
 *    │    (cx,cy)──(W,cy)
 *    │                │
 *  (0,H)─────────(W,H)
 */
function envelopeL(W, H, cx, cy, prefix) {
    return [
        mur(0, 0, cx, 0, `${prefix}-w1`), // top (short)
        mur(cx, 0, cx, cy, `${prefix}-w2`), // inner vertical
        mur(cx, cy, W, cy, `${prefix}-w3`), // inner horizontal
        mur(W, cy, W, H, `${prefix}-w4`), // right (lower)
        mur(W, H, 0, H, `${prefix}-w5`), // bottom
        mur(0, H, 0, 0, `${prefix}-w6`), // left
    ];
}
/**
 * U-shape: full W×H minus center-top cutout from cx1 to cx2, height cy.
 * Shape (clockwise):
 *  (0,0)─(cx1,0)  (cx2,0)─(W,0)
 *    │      │        │       │
 *    │   (cx1,cy)─(cx2,cy)  │
 *    │                       │
 *  (0,H)──────────────────(W,H)
 */
function envelopeU(W, H, cx1, cx2, cy, prefix) {
    return [
        mur(0, 0, cx1, 0, `${prefix}-w1`), // left top
        mur(cx1, 0, cx1, cy, `${prefix}-w2`), // left inner vertical
        mur(cx1, cy, cx2, cy, `${prefix}-w3`), // center horizontal
        mur(cx2, cy, cx2, 0, `${prefix}-w4`), // right inner vertical
        mur(cx2, 0, W, 0, `${prefix}-w5`), // right top
        mur(W, 0, W, H, `${prefix}-w6`), // right side
        mur(W, H, 0, H, `${prefix}-w7`), // bottom
        mur(0, H, 0, 0, `${prefix}-w8`), // left side
    ];
}
function project(objects) {
    return { version: '5.3.0', pixelsPerMeter: PPM, objects };
}
// ─────────────────────────────────────────────────────────────────────────────
// T1 — Studio rectangle (~28m²) — 5m × 5.5m
// ─────────────────────────────────────────────────────────────────────────────
const T1_RECT = project([
    ...envelope(5, 5.5, 't1'),
    cloison(0, 3.5, 5, 3.5, 't1-c1'), // H : séjour / service
    cloison(2, 3.5, 2, 5.5, 't1-c2'), // V : SdB | WC+Entrée
    cloison(3.5, 3.5, 3.5, 5.5, 't1-c3'), // V : WC | Entrée
]);
// ─────────────────────────────────────────────────────────────────────────────
// T1 — Studio carré (~28m²) — 5.3m × 5.3m
// ─────────────────────────────────────────────────────────────────────────────
const T1_SQ = project([
    ...envelope(5.3, 5.3, 't1sq'),
    cloison(0, 3.5, 5.3, 3.5, 't1sq-c1'), // H : séjour | zone service
    cloison(2.1, 3.5, 2.1, 5.3, 't1sq-c2'), // V : SdB | WC+Entrée
    cloison(3.8, 3.5, 3.8, 5.3, 't1sq-c3'), // V : WC | Entrée
]);
// ─────────────────────────────────────────────────────────────────────────────
// T2 — 2 pièces rectangle (~44m²) — 8m × 5.5m
// ─────────────────────────────────────────────────────────────────────────────
const T2_RECT = project([
    ...envelope(8, 5.5, 't2'),
    cloison(5, 0, 5, 3.5, 't2-c1'), // V : Séjour | Cuisine (haut)
    cloison(0, 3.5, 8, 3.5, 't2-c2'), // H : zone vie | zone nuit
    cloison(4.5, 3.5, 4.5, 5.5, 't2-c3'), // V : Ch.1 | SdB+WC
    cloison(6.5, 3.5, 6.5, 5.5, 't2-c4'), // V : SdB | WC
]);
// ─────────────────────────────────────────────────────────────────────────────
// T2 — 2 pièces en L (~42m²) — 9m × 6m, coupure top-right 4m × 3m
//  ┌─────────┐
//  │ Ch. SdB │  (5m large)
//  │       ──┤
//  │ Séj. Cui│  (9m large)
//  └─────────┘
// ─────────────────────────────────────────────────────────────────────────────
const T2_L = project([
    ...envelopeL(9, 6, 5, 3, 't2l'),
    cloison(3, 0, 3, 3, 't2l-c1'), // V : Chambre | SdB (aile haute)
    cloison(4.5, 3, 4.5, 6, 't2l-c2'), // V : Séjour | Cuisine (bande basse)
    cloison(7.5, 3, 7.5, 6, 't2l-c3'), // V : Cuisine | WC
]);
// ─────────────────────────────────────────────────────────────────────────────
// T3 — 3 pièces rectangle (~59m²) — 10m × 6.5m
// ─────────────────────────────────────────────────────────────────────────────
const T3_RECT = project([
    ...envelope(10, 6.5, 't3'),
    cloison(0, 4, 10, 4, 't3-c1'), // H : zone vie | zone nuit
    cloison(6, 0, 6, 4, 't3-c2'), // V : Séjour | Cuisine
    cloison(4.5, 4, 4.5, 6.5, 't3-c3'), // V : Ch.1 | Ch.2+SdB+WC
    cloison(7.5, 4, 7.5, 6.5, 't3-c4'), // V : Ch.2 | SdB+WC
    cloison(9, 4, 9, 6.5, 't3-c5'), // V : SdB | WC
]);
// ─────────────────────────────────────────────────────────────────────────────
// T3 — 3 pièces en L (~56m²) — 10m × 7m, coupure top-right 4m × 3.5m
// ─────────────────────────────────────────────────────────────────────────────
const T3_L = project([
    ...envelopeL(10, 7, 6, 3.5, 't3l'),
    cloison(3, 0, 3, 3.5, 't3l-c1'), // V : Ch.1 | Ch.2 (aile haute)
    cloison(4.5, 0, 4.5, 3.5, 't3l-c2'), // V : Ch.2 | SdB
    cloison(6, 3.5, 6, 7, 't3l-c3'), // V : Séjour | Cuisine (bande basse)
    cloison(9, 3.5, 9, 7, 't3l-c4'), // V : Cuisine | WC
]);
// ─────────────────────────────────────────────────────────────────────────────
// T3 — 3 pièces en U (~60m²) — 12m × 6m, coupure centre cx1=4, cx2=8, cy=3
// ─────────────────────────────────────────────────────────────────────────────
const T3_U = project([
    ...envelopeU(12, 6, 4, 8, 3, 't3u'),
    cloison(0, 3, 4, 3, 't3u-c1'), // H : Ch.1 (haut) | living (bas) — aile gauche
    cloison(8, 3, 12, 3, 't3u-c2'), // H : Ch.2 (haut) | service (bas) — aile droite
    cloison(6, 3, 6, 6, 't3u-c3'), // V : Séjour | Cuisine (bande basse)
    cloison(10, 3, 10, 6, 't3u-c4'), // V : Cuisine | SdB+WC
    cloison(10, 4.5, 12, 4.5, 't3u-c5'), // H : SdB | WC (aile droite basse)
]);
// ─────────────────────────────────────────────────────────────────────────────
// T4 — 4 pièces rectangle (~72m²) — 11m × 7m
// ─────────────────────────────────────────────────────────────────────────────
const T4_RECT = project([
    ...envelope(11, 7, 't4'),
    cloison(0, 4.5, 11, 4.5, 't4-c1'), // H : zone vie | zone nuit
    cloison(6.5, 0, 6.5, 4.5, 't4-c2'), // V : Séjour | Cuisine
    cloison(3.5, 4.5, 3.5, 7, 't4-c3'), // V : Ch.1 | Ch.2
    cloison(7, 4.5, 7, 7, 't4-c4'), // V : Ch.2 | Ch.3
    cloison(9, 4.5, 9, 7, 't4-c5'), // V : Ch.3 | SdB+WC
    cloison(10, 4.5, 10, 7, 't4-c6'), // V : SdB | WC
]);
// ─────────────────────────────────────────────────────────────────────────────
// T4 — 4 pièces en L (~72m²) — 11m × 8m, coupure top-right 4m × 4m
// ─────────────────────────────────────────────────────────────────────────────
const T4_L = project([
    ...envelopeL(11, 8, 7, 4, 't4l'),
    cloison(2.5, 0, 2.5, 4, 't4l-c1'), // V : Ch.1 | Ch.2 (aile haute)
    cloison(5, 0, 5, 4, 't4l-c2'), // V : Ch.2 | SdB
    cloison(6.5, 0, 6.5, 4, 't4l-c3'), // V : SdB | WC
    cloison(5.5, 4, 5.5, 8, 't4l-c4'), // V : Séjour | Cuisine+Ch.3 (bande basse)
    cloison(8.5, 4, 8.5, 8, 't4l-c5'), // V : Cuisine | Ch.3
    cloison(9.5, 4, 9.5, 8, 't4l-c6'), // V : Ch.3 | Couloir
]);
// ─────────────────────────────────────────────────────────────────────────────
// T4 — 4 pièces en U (~74m²) — 13m × 7m, coupure cx1=4, cx2=9, cy=3.5
// ─────────────────────────────────────────────────────────────────────────────
const T4_U = project([
    ...envelopeU(13, 7, 4, 9, 3.5, 't4u'),
    cloison(2, 0, 2, 3.5, 't4u-c1'), // V : Ch.1 | Ch.2 (aile gauche haute)
    cloison(11, 0, 11, 3.5, 't4u-c2'), // V : Ch.3 | SdB (aile droite haute)
    cloison(0, 3.5, 4, 3.5, 't4u-c3'), // H : haut | bas (aile gauche)
    cloison(9, 3.5, 13, 3.5, 't4u-c4'), // H : haut | bas (aile droite)
    cloison(8, 3.5, 8, 7, 't4u-c5'), // V : Séjour | Cuisine (zone basse)
    cloison(11, 3.5, 11, 7, 't4u-c6'), // V : Cuisine | WC
]);
// ─────────────────────────────────────────────────────────────────────────────
// T5 — 5 pièces rectangle (~88m²) — 12m × 8m
// ─────────────────────────────────────────────────────────────────────────────
const T5_RECT = project([
    ...envelope(12, 8, 't5'),
    cloison(0, 4.5, 12, 4.5, 't5-c1'), // H : zone vie | zone nuit
    cloison(7, 0, 7, 4.5, 't5-c2'), // V : Séjour | Cuisine
    cloison(3, 4.5, 3, 8, 't5-c3'), // V : Ch.1 | Ch.2
    cloison(6, 4.5, 6, 8, 't5-c4'), // V : Ch.2 | Ch.3
    cloison(9, 4.5, 9, 8, 't5-c5'), // V : Ch.3 | Ch.4
    cloison(10.5, 4.5, 10.5, 8, 't5-c6'), // V : Ch.4 | SdB+WC
    cloison(11.5, 4.5, 11.5, 8, 't5-c7'), // V : SdB | WC
]);
// ─────────────────────────────────────────────────────────────────────────────
// T5 — 5 pièces en L (~88m²) — 12m × 9m, coupure top-right 4m × 5m
// ─────────────────────────────────────────────────────────────────────────────
const T5_L = project([
    ...envelopeL(12, 9, 8, 5, 't5l'),
    cloison(2.5, 0, 2.5, 5, 't5l-c1'), // V : Ch.1 | Ch.2 (aile haute)
    cloison(5, 0, 5, 5, 't5l-c2'), // V : Ch.2 | Ch.3
    cloison(6.5, 0, 6.5, 5, 't5l-c3'), // V : Ch.3 | SdB
    cloison(7.5, 0, 7.5, 5, 't5l-c4'), // V : SdB | WC
    cloison(6, 5, 6, 9, 't5l-c5'), // V : Séjour | Cuisine (bande basse)
    cloison(9, 5, 9, 9, 't5l-c6'), // V : Cuisine | Ch.4
    cloison(10.5, 5, 10.5, 9, 't5l-c7'), // V : Ch.4 | Couloir
]);
// ─────────────────────────────────────────────────────────────────────────────
// T6 — 6 pièces (~108m²) — 14m × 8.5m
// ─────────────────────────────────────────────────────────────────────────────
const T6_RECT = project([
    ...envelope(14, 8.5, 't6'),
    cloison(0, 5, 14, 5, 't6-c1'), // H : zone vie | zone nuit
    cloison(8.5, 0, 8.5, 5, 't6-c2'), // V : Séjour | Cuisine+Suite
    cloison(12, 0, 12, 5, 't6-c3'), // V : Cuisine | Suite parentale
    cloison(3, 5, 3, 8.5, 't6-c4'), // V : Ch.1 | Ch.2
    cloison(6, 5, 6, 8.5, 't6-c5'), // V : Ch.2 | Ch.3
    cloison(9, 5, 9, 8.5, 't6-c6'), // V : Ch.3 | Ch.4
    cloison(11.5, 5, 11.5, 8.5, 't6-c7'), // V : Ch.4 | SdB+WC
    cloison(12.5, 5, 12.5, 8.5, 't6-c8'), // V : SdB | WC
    cloison(13.5, 5, 13.5, 8.5, 't6-c9'), // V : WC | Couloir
]);
// ─────────────────────────────────────────────────────────────────────────────
// T7 — 7 pièces (~125m²) — 15m × 9m
// ─────────────────────────────────────────────────────────────────────────────
const T7_RECT = project([
    ...envelope(15, 9, 't7'),
    cloison(0, 5.5, 15, 5.5, 't7-c1'), // H : zone vie | zone nuit
    cloison(9, 0, 9, 5.5, 't7-c2'), // V : Séjour | Cuisine
    cloison(13, 0, 13, 5.5, 't7-c3'), // V : Cuisine | Suite
    cloison(13, 3.5, 15, 3.5, 't7-c4'), // H : suite chambre | SdB suite
    cloison(3, 5.5, 3, 9, 't7-c5'), // V : Ch.1 | Ch.2
    cloison(6, 5.5, 6, 9, 't7-c6'), // V : Ch.2 | Ch.3
    cloison(9, 5.5, 9, 9, 't7-c7'), // V : Ch.3 | Ch.4
    cloison(12, 5.5, 12, 9, 't7-c8'), // V : Ch.4 | SdB+WC
    cloison(13, 5.5, 13, 9, 't7-c9'), // V : SdB | WC
    cloison(14, 5.5, 14, 9, 't7-c10'), // V : WC | Couloir
]);
// ─────────────────────────────────────────────────────────────────────────────
// T8 — 8 pièces (~145m²) — 17m × 9.5m
// ─────────────────────────────────────────────────────────────────────────────
const T8_RECT = project([
    ...envelope(17, 9.5, 't8'),
    cloison(0, 5.5, 17, 5.5, 't8-c1'), // H : zone vie | zone nuit
    cloison(10, 0, 10, 5.5, 't8-c2'), // V : Séjour | Cuisine+Salle à manger
    cloison(14, 0, 14, 5.5, 't8-c3'), // V : Cuisine | Suite parentale
    cloison(14, 3.5, 17, 3.5, 't8-c4'), // H : suite chambre | SdB suite
    cloison(2.5, 5.5, 2.5, 9.5, 't8-c5'), // V : Ch.1 | Ch.2
    cloison(5, 5.5, 5, 9.5, 't8-c6'), // V : Ch.2 | Ch.3
    cloison(7.5, 5.5, 7.5, 9.5, 't8-c7'), // V : Ch.3 | Ch.4
    cloison(10, 5.5, 10, 9.5, 't8-c8'), // V : Ch.4 | Ch.5
    cloison(12, 5.5, 12, 9.5, 't8-c9'), // V : Ch.5 | SdB1
    cloison(13, 5.5, 13, 9.5, 't8-c10'), // V : SdB1 | WC1
    cloison(14, 5.5, 14, 9.5, 't8-c11'), // V : WC1 | SdB2+WC2
    cloison(15, 5.5, 15, 9.5, 't8-c12'), // V : SdB2 | WC2
    cloison(16, 5.5, 16, 9.5, 't8-c13'), // V : WC2 | Couloir
]);
const APARTMENT_TEMPLATES = [
    // ── T1 ──────────────────────────────────────────────────────────────────────
    {
        id: 't1',
        typology: 'T1',
        shape: 'rectangle',
        label: 'Studio',
        description: 'Espace de vie ouvert avec coin cuisine intégré, salle de bain et WC séparés.',
        areaSqm: 28,
        rooms: ['Séjour / Cuisine ouverte', 'Salle de bain', 'WC', 'Entrée'],
        project: T1_RECT,
    },
    {
        id: 't1-sq',
        typology: 'T1',
        shape: 'square',
        label: 'Studio carré',
        description: 'Studio compact aux proportions carrées, idéal pour optimiser chaque mètre carré.',
        areaSqm: 28,
        rooms: ['Séjour / Cuisine ouverte', 'Salle de bain', 'WC', 'Entrée'],
        project: T1_SQ,
    },
    // ── T2 ──────────────────────────────────────────────────────────────────────
    {
        id: 't2',
        typology: 'T2',
        shape: 'rectangle',
        label: '2 pièces',
        description: 'Séjour avec cuisine séparée, une chambre, salle de bain et WC.',
        areaSqm: 44,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Salle de bain', 'WC'],
        project: T2_RECT,
    },
    {
        id: 't2-l',
        typology: 'T2',
        shape: 'L',
        label: '2 pièces en L',
        description: 'Aile nuit en retrait avec une chambre et salle de bain, séjour et cuisine dans la bande basse.',
        areaSqm: 42,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Salle de bain', 'WC'],
        project: T2_L,
    },
    // ── T3 ──────────────────────────────────────────────────────────────────────
    {
        id: 't3',
        typology: 'T3',
        shape: 'rectangle',
        label: '3 pièces',
        description: 'Séjour, cuisine indépendante, deux chambres, salle de bain et WC.',
        areaSqm: 59,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Chambre 2', 'Salle de bain', 'WC'],
        project: T3_RECT,
    },
    {
        id: 't3-l',
        typology: 'T3',
        shape: 'L',
        label: '3 pièces en L',
        description: 'Aile nuit indépendante avec deux chambres et salle de bain, séjour-cuisine dans la bande principale.',
        areaSqm: 56,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Chambre 2', 'Salle de bain', 'WC'],
        project: T3_L,
    },
    {
        id: 't3-u',
        typology: 'T3',
        shape: 'U',
        label: '3 pièces en U',
        description: 'Deux ailes latérales pour les chambres encadrant un grand séjour-cuisine central.',
        areaSqm: 60,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Chambre 2', 'Salle de bain', 'WC'],
        project: T3_U,
    },
    // ── T4 ──────────────────────────────────────────────────────────────────────
    {
        id: 't4',
        typology: 'T4',
        shape: 'rectangle',
        label: '4 pièces',
        description: 'Grand séjour, cuisine, trois chambres dont une master, salle de bain et WC.',
        areaSqm: 72,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Salle de bain', 'WC'],
        project: T4_RECT,
    },
    {
        id: 't4-l',
        typology: 'T4',
        shape: 'L',
        label: '4 pièces en L',
        description: 'Aile nuit en L avec trois chambres et salle de bain, grande bande de vie en bas.',
        areaSqm: 72,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Salle de bain', 'WC'],
        project: T4_L,
    },
    {
        id: 't4-u',
        typology: 'T4',
        shape: 'U',
        label: '4 pièces en U',
        description: 'Deux ailes symétriques pour les chambres, grand séjour ouvert dans la bande centrale basse.',
        areaSqm: 74,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Salle de bain', 'WC'],
        project: T4_U,
    },
    // ── T5 ──────────────────────────────────────────────────────────────────────
    {
        id: 't5',
        typology: 'T5',
        shape: 'rectangle',
        label: '5 pièces',
        description: 'Appartement familial avec séjour généreux, cuisine, quatre chambres, salle de bain et WC.',
        areaSqm: 88,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Chambre 4', 'Salle de bain', 'WC'],
        project: T5_RECT,
    },
    {
        id: 't5-l',
        typology: 'T5',
        shape: 'L',
        label: '5 pièces en L',
        description: 'Grande aile nuit avec trois chambres et services, séjour-cuisine sur la bande basse.',
        areaSqm: 88,
        rooms: ['Séjour', 'Cuisine', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Chambre 4', 'Salle de bain', 'WC'],
        project: T5_L,
    },
    // ── T6 ──────────────────────────────────────────────────────────────────────
    {
        id: 't6',
        typology: 'T6',
        shape: 'rectangle',
        label: '6 pièces',
        description: 'Grand appartement avec séjour, cuisine, suite parentale et quatre chambres.',
        areaSqm: 108,
        rooms: ['Séjour', 'Cuisine', 'Suite parentale', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Chambre 4', 'Salle de bain', 'WC'],
        project: T6_RECT,
    },
    // ── T7 ──────────────────────────────────────────────────────────────────────
    {
        id: 't7',
        typology: 'T7',
        shape: 'rectangle',
        label: '7 pièces',
        description: 'Vaste appartement avec séjour, cuisine, suite parentale avec salle de bain privée et cinq chambres.',
        areaSqm: 125,
        rooms: ['Séjour', 'Cuisine', 'Suite parentale + SdB', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Chambre 4', 'Salle de bain', 'WC'],
        project: T7_RECT,
    },
    // ── T8 ──────────────────────────────────────────────────────────────────────
    {
        id: 't8',
        typology: 'T8',
        shape: 'rectangle',
        label: '8 pièces',
        description: 'Appartement de prestige : séjour double, cuisine, suite parentale et six chambres avec deux salles de bain.',
        areaSqm: 145,
        rooms: ['Séjour', 'Cuisine', 'Suite parentale + SdB', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Chambre 4', 'Chambre 5', 'SdB 1', 'WC 1', 'SdB 2', 'WC 2'],
        project: T8_RECT,
    },
];

class TemplateModalComponent {
    close = output();
    templateSelected = output();
    selectedShape = signal('all');
    shapeOptions = [
        {
            value: 'all',
            label: 'Tous',
            // 4 small squares icon
            svgPath: 'M1 1h8v6H1zM13 1h8v6H13zM1 9h8v6H1zM13 9h8v6H13z',
        },
        {
            value: 'rectangle',
            label: 'Rectangle',
            // wide rectangle
            svgPath: 'M1 4h20v8H1z',
        },
        {
            value: 'square',
            label: 'Carré',
            // square shape
            svgPath: 'M4 1h14v14H4z',
        },
        {
            value: 'L',
            label: 'En L',
            // L-shape: top-right corner cut
            svgPath: 'M2 1h8v7h8v7H2z',
        },
        {
            value: 'U',
            label: 'En U',
            // U-shape: center-top cut
            svgPath: 'M1 1h6v9h8V1h6v14H1z',
        },
    ];
    filteredTemplates = computed(() => {
        const shape = this.selectedShape();
        if (shape === 'all')
            return APARTMENT_TEMPLATES;
        return APARTMENT_TEMPLATES.filter(t => t.shape === shape);
    });
    select(tpl) {
        this.templateSelected.emit(tpl);
        this.close.emit();
    }
    isMur(obj) { return obj?.myType === 'Mur'; }
    isCloison(obj) { return obj?.myType === 'Cloison'; }
    shapeLabel(shape) {
        const labels = {
            rectangle: 'RECT',
            square: 'CARRÉ',
            L: 'EN L',
            U: 'EN U',
            T: 'EN T',
        };
        return labels[shape];
    }
    shapeColor(shape) {
        const colors = {
            rectangle: '#64748b',
            square: '#3b82f6',
            L: '#6366f1',
            U: '#8b5cf6',
            T: '#ec4899',
        };
        return colors[shape];
    }
    /** Reconstruct absolute X1 from Fabric.js line JSON */
    svgX(obj) { return (obj.left ?? 0) + (obj.width ?? 0) / 2 + (obj.x1 ?? 0); }
    svgY(obj) { return (obj.top ?? 0) + (obj.height ?? 0) / 2 + (obj.y1 ?? 0); }
    svgX2(obj) { return (obj.left ?? 0) + (obj.width ?? 0) / 2 + (obj.x2 ?? 0); }
    svgY2(obj) { return (obj.top ?? 0) + (obj.height ?? 0) / 2 + (obj.y2 ?? 0); }
    svgViewBox(tpl) {
        const objs = tpl.project.objects;
        if (!objs.length)
            return '0 0 100 100';
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (const o of objs) {
            const x1 = this.svgX(o), y1 = this.svgY(o);
            const x2 = this.svgX2(o), y2 = this.svgY2(o);
            minX = Math.min(minX, x1, x2);
            minY = Math.min(minY, y1, y2);
            maxX = Math.max(maxX, x1, x2);
            maxY = Math.max(maxY, y1, y2);
        }
        const pad = 10;
        return `${minX - pad} ${minY - pad} ${maxX - minX + pad * 2} ${maxY - minY + pad * 2}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: TemplateModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: TemplateModalComponent, isStandalone: true, selector: "ng-gplan-template-modal", outputs: { close: "close", templateSelected: "templateSelected" }, ngImport: i0, template: `
    <div class="tpl-overlay" (click)="close.emit()">
      <div class="tpl-modal" (click)="$event.stopPropagation()">

        <div class="tpl-modal__header">
          <h2 class="tpl-modal__title">Choisir un modèle d'appartement</h2>
          <p class="tpl-modal__sub">Sélectionnez d'abord la forme puis la typologie. Les murs peuvent être déplacés, supprimés ou complétés.</p>
          <button class="tpl-modal__close" (click)="close.emit()">&#x2715;</button>
        </div>

        <!-- Shape filter -->
        <div class="tpl-shapes">
          @for (s of shapeOptions; track s.value) {
            <button
              class="tpl-shape-btn"
              [class.tpl-shape-btn--active]="selectedShape() === s.value"
              (click)="selectedShape.set(s.value)">
              <svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path [attr.d]="s.svgPath" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>
              </svg>
              {{ s.label }}
            </button>
          }
        </div>

        <!-- Template grid -->
        <div class="tpl-modal__grid">
          @if (filteredTemplates().length === 0) {
            <div class="tpl-empty">Aucun modèle disponible pour cette forme.</div>
          }
          @for (tpl of filteredTemplates(); track tpl.id) {
            <div class="tpl-card" (click)="select(tpl)">
              <div class="tpl-card__badges">
                <span class="tpl-card__badge tpl-card__badge--shape" [style.background]="shapeColor(tpl.shape)">
                  {{ shapeLabel(tpl.shape) }}
                </span>
                <span class="tpl-card__badge tpl-card__badge--typo">{{ tpl.typology }}</span>
              </div>
              <div class="tpl-card__preview">
                <svg [attr.viewBox]="svgViewBox(tpl)" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                  @for (obj of tpl.project.objects; track $index) {
                    @if (isMur(obj)) {
                      <line
                        [attr.x1]="svgX(obj)"
                        [attr.y1]="svgY(obj)"
                        [attr.x2]="svgX2(obj)"
                        [attr.y2]="svgY2(obj)"
                        stroke="#18181b" stroke-width="3" stroke-linecap="square" />
                    }
                    @if (isCloison(obj)) {
                      <line
                        [attr.x1]="svgX(obj)"
                        [attr.y1]="svgY(obj)"
                        [attr.x2]="svgX2(obj)"
                        [attr.y2]="svgY2(obj)"
                        stroke="#64748b" stroke-width="1.5" stroke-dasharray="4 2" stroke-linecap="square" />
                    }
                  }
                </svg>
              </div>
              <div class="tpl-card__body">
                <strong class="tpl-card__name">{{ tpl.label }}</strong>
                <span class="tpl-card__area">{{ tpl.areaSqm }} m²</span>
              </div>
              <p class="tpl-card__desc">{{ tpl.description }}</p>
              <ul class="tpl-card__rooms">
                @for (room of tpl.rooms; track room) {
                  <li>{{ room }}</li>
                }
              </ul>
              <button class="tpl-card__btn">Charger ce plan</button>
            </div>
          }
        </div>

      </div>
    </div>
  `, isInline: true, styles: [".tpl-overlay{position:fixed;inset:0;background:#00000080;display:flex;align-items:center;justify-content:center;z-index:9000;backdrop-filter:blur(2px);animation:tpl-fade .15s ease}.tpl-modal{background:#fff;border-radius:14px;width:min(980px,96vw);max-height:90vh;display:flex;flex-direction:column;box-shadow:0 24px 64px #00000038;animation:tpl-slide .18s ease;overflow:hidden}.tpl-modal__header{padding:20px 24px 16px;border-bottom:1px solid #e4e4e7;flex-shrink:0;position:relative}.tpl-modal__title{margin:0 0 4px;font-size:16px;font-weight:700;color:#18181b}.tpl-modal__sub{margin:0;font-size:12px;color:#71717a;padding-right:32px}.tpl-modal__close{position:absolute;top:16px;right:16px;background:none;border:none;cursor:pointer;font-size:18px;color:#71717a;padding:4px 8px;border-radius:6px;line-height:1;&:hover{background:#f4f4f5;color:#18181b}}.tpl-shapes{display:flex;gap:6px;padding:12px 16px;border-bottom:1px solid #e4e4e7;flex-shrink:0;overflow-x:auto;scrollbar-width:none;&::-webkit-scrollbar{display:none}}.tpl-shape-btn{display:flex;align-items:center;gap:6px;padding:6px 14px;border-radius:100px;border:1.5px solid #e4e4e7;background:#fff;color:#52525b;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;transition:border-color .12s,background .12s,color .12s;&:hover{border-color:#f97316;color:#f97316}}.tpl-shape-btn--active{background:#f97316;border-color:#f97316;color:#fff}.tpl-modal__grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;padding:16px;overflow-y:auto}.tpl-empty{grid-column:1 / -1;text-align:center;padding:40px;color:#94a3b8;font-size:13px}.tpl-card{border:1.5px solid #e4e4e7;border-radius:10px;padding:12px;cursor:pointer;display:flex;flex-direction:column;gap:8px;transition:border-color .15s,box-shadow .15s;position:relative;&:hover{border-color:#f97316;box-shadow:0 0 0 3px #f973161f}}.tpl-card__badges{display:flex;gap:4px;flex-wrap:wrap}.tpl-card__badge{font-size:10px;font-weight:700;padding:2px 7px;border-radius:100px;letter-spacing:.04em;color:#fff}.tpl-card__badge--typo{background:#f97316}.tpl-card__preview{width:100%;aspect-ratio:4/3;background:#f8fafc;border-radius:6px;overflow:hidden;border:1px solid #e4e4e7;padding:8px;box-sizing:border-box}.tpl-card__body{display:flex;align-items:baseline;justify-content:space-between}.tpl-card__name{font-size:13px;font-weight:700;color:#18181b}.tpl-card__area{font-size:11px;color:#71717a}.tpl-card__desc{margin:0;font-size:11px;color:#52525b;line-height:1.4}.tpl-card__rooms{margin:0;padding-left:14px;list-style:disc;& li{font-size:10px;color:#71717a;line-height:1.5}}.tpl-card__btn{margin-top:auto;padding:7px 0;background:#f97316;color:#fff;border:none;border-radius:7px;cursor:pointer;font-size:12px;font-weight:600;width:100%;transition:background .12s;&:hover{background:#ea580c}}@keyframes tpl-fade{0%{opacity:0}to{opacity:1}}@keyframes tpl-slide{0%{transform:translateY(16px);opacity:0}to{transform:translateY(0);opacity:1}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: TemplateModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-gplan-template-modal', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="tpl-overlay" (click)="close.emit()">
      <div class="tpl-modal" (click)="$event.stopPropagation()">

        <div class="tpl-modal__header">
          <h2 class="tpl-modal__title">Choisir un modèle d'appartement</h2>
          <p class="tpl-modal__sub">Sélectionnez d'abord la forme puis la typologie. Les murs peuvent être déplacés, supprimés ou complétés.</p>
          <button class="tpl-modal__close" (click)="close.emit()">&#x2715;</button>
        </div>

        <!-- Shape filter -->
        <div class="tpl-shapes">
          @for (s of shapeOptions; track s.value) {
            <button
              class="tpl-shape-btn"
              [class.tpl-shape-btn--active]="selectedShape() === s.value"
              (click)="selectedShape.set(s.value)">
              <svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path [attr.d]="s.svgPath" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>
              </svg>
              {{ s.label }}
            </button>
          }
        </div>

        <!-- Template grid -->
        <div class="tpl-modal__grid">
          @if (filteredTemplates().length === 0) {
            <div class="tpl-empty">Aucun modèle disponible pour cette forme.</div>
          }
          @for (tpl of filteredTemplates(); track tpl.id) {
            <div class="tpl-card" (click)="select(tpl)">
              <div class="tpl-card__badges">
                <span class="tpl-card__badge tpl-card__badge--shape" [style.background]="shapeColor(tpl.shape)">
                  {{ shapeLabel(tpl.shape) }}
                </span>
                <span class="tpl-card__badge tpl-card__badge--typo">{{ tpl.typology }}</span>
              </div>
              <div class="tpl-card__preview">
                <svg [attr.viewBox]="svgViewBox(tpl)" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                  @for (obj of tpl.project.objects; track $index) {
                    @if (isMur(obj)) {
                      <line
                        [attr.x1]="svgX(obj)"
                        [attr.y1]="svgY(obj)"
                        [attr.x2]="svgX2(obj)"
                        [attr.y2]="svgY2(obj)"
                        stroke="#18181b" stroke-width="3" stroke-linecap="square" />
                    }
                    @if (isCloison(obj)) {
                      <line
                        [attr.x1]="svgX(obj)"
                        [attr.y1]="svgY(obj)"
                        [attr.x2]="svgX2(obj)"
                        [attr.y2]="svgY2(obj)"
                        stroke="#64748b" stroke-width="1.5" stroke-dasharray="4 2" stroke-linecap="square" />
                    }
                  }
                </svg>
              </div>
              <div class="tpl-card__body">
                <strong class="tpl-card__name">{{ tpl.label }}</strong>
                <span class="tpl-card__area">{{ tpl.areaSqm }} m²</span>
              </div>
              <p class="tpl-card__desc">{{ tpl.description }}</p>
              <ul class="tpl-card__rooms">
                @for (room of tpl.rooms; track room) {
                  <li>{{ room }}</li>
                }
              </ul>
              <button class="tpl-card__btn">Charger ce plan</button>
            </div>
          }
        </div>

      </div>
    </div>
  `, styles: [".tpl-overlay{position:fixed;inset:0;background:#00000080;display:flex;align-items:center;justify-content:center;z-index:9000;backdrop-filter:blur(2px);animation:tpl-fade .15s ease}.tpl-modal{background:#fff;border-radius:14px;width:min(980px,96vw);max-height:90vh;display:flex;flex-direction:column;box-shadow:0 24px 64px #00000038;animation:tpl-slide .18s ease;overflow:hidden}.tpl-modal__header{padding:20px 24px 16px;border-bottom:1px solid #e4e4e7;flex-shrink:0;position:relative}.tpl-modal__title{margin:0 0 4px;font-size:16px;font-weight:700;color:#18181b}.tpl-modal__sub{margin:0;font-size:12px;color:#71717a;padding-right:32px}.tpl-modal__close{position:absolute;top:16px;right:16px;background:none;border:none;cursor:pointer;font-size:18px;color:#71717a;padding:4px 8px;border-radius:6px;line-height:1;&:hover{background:#f4f4f5;color:#18181b}}.tpl-shapes{display:flex;gap:6px;padding:12px 16px;border-bottom:1px solid #e4e4e7;flex-shrink:0;overflow-x:auto;scrollbar-width:none;&::-webkit-scrollbar{display:none}}.tpl-shape-btn{display:flex;align-items:center;gap:6px;padding:6px 14px;border-radius:100px;border:1.5px solid #e4e4e7;background:#fff;color:#52525b;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;transition:border-color .12s,background .12s,color .12s;&:hover{border-color:#f97316;color:#f97316}}.tpl-shape-btn--active{background:#f97316;border-color:#f97316;color:#fff}.tpl-modal__grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;padding:16px;overflow-y:auto}.tpl-empty{grid-column:1 / -1;text-align:center;padding:40px;color:#94a3b8;font-size:13px}.tpl-card{border:1.5px solid #e4e4e7;border-radius:10px;padding:12px;cursor:pointer;display:flex;flex-direction:column;gap:8px;transition:border-color .15s,box-shadow .15s;position:relative;&:hover{border-color:#f97316;box-shadow:0 0 0 3px #f973161f}}.tpl-card__badges{display:flex;gap:4px;flex-wrap:wrap}.tpl-card__badge{font-size:10px;font-weight:700;padding:2px 7px;border-radius:100px;letter-spacing:.04em;color:#fff}.tpl-card__badge--typo{background:#f97316}.tpl-card__preview{width:100%;aspect-ratio:4/3;background:#f8fafc;border-radius:6px;overflow:hidden;border:1px solid #e4e4e7;padding:8px;box-sizing:border-box}.tpl-card__body{display:flex;align-items:baseline;justify-content:space-between}.tpl-card__name{font-size:13px;font-weight:700;color:#18181b}.tpl-card__area{font-size:11px;color:#71717a}.tpl-card__desc{margin:0;font-size:11px;color:#52525b;line-height:1.4}.tpl-card__rooms{margin:0;padding-left:14px;list-style:disc;& li{font-size:10px;color:#71717a;line-height:1.5}}.tpl-card__btn{margin-top:auto;padding:7px 0;background:#f97316;color:#fff;border:none;border-radius:7px;cursor:pointer;font-size:12px;font-weight:600;width:100%;transition:background .12s;&:hover{background:#ea580c}}@keyframes tpl-fade{0%{opacity:0}to{opacity:1}}@keyframes tpl-slide{0%{transform:translateY(16px);opacity:0}to{transform:translateY(0);opacity:1}}\n"] }]
        }] });

/** Hauteur d'un niveau en mètres */
const FLOOR_HEIGHT_M = 2.7;
/** Épaisseur visuelle des murs porteurs (m) */
const MUR_THICKNESS_M = 0.2;
/** Épaisseur visuelle des cloisons (m) */
const CLOISON_THICKNESS_M = 0.1;
/** Hauteur d'une porte (m) */
const DOOR_HEIGHT_M = 2.1;
/** Hauteur de l'appui de fenêtre (m) */
const SILL_HEIGHT_M = 0.9;
/** Hauteur d'une fenêtre (m) */
const WINDOW_HEIGHT_M = 1.2;
/** Couleurs 3D des canalisations par type (alignées sur l'éditeur 2D) */
const PIPE_COLORS_3D = {
    PipeAEP: 0x2563eb, PipeEU: 0x7c3aed, PipeEM: 0xa16207, PipeEV: 0x78350f,
    PipeVent: 0x6b7280, PipeEP: 0x22d3ee, PipeGaz: 0xf59e0b,
    PipeElec: 0xeab308, PipeFibre: 0x06b6d4,
};
/** Couleurs 3D des regards AC selon le type d'eau */
const REGARD_COLORS_3D = {
    'ac-regard-eu': 0x7c3aed, 'ac-regard-em': 0xa16207,
    'ac-regard-ev': 0x78350f, 'ac-regard-ep': 0x22d3ee,
};
/** Vitesse de la rotation auto (OrbitControls). 2.0 ≈ 1 tour en 30s à 60fps. */
const AUTO_ROTATE_SPEED = 2.0;
/** Élévation du réseau de canalisations au-dessus du sol (m) */
const PIPE_ELEVATION_M = 0.22;
/** Rayon d'une canalisation en 3D (m) */
const PIPE_RADIUS_M = 0.09;
class Viewer3DComponent {
    project = input(null);
    canvasRef = viewChild.required('canvas3d');
    /** Vrai s'il y a quelque chose d'affiché : murs, réseau ou pictogrammes SPANC/AC.
     *  Signal (et non getter) : le rebuild de la scène est déclenché hors cycle de
     *  détection Angular — un signal garantit que l'overlay « rien à afficher »
     *  se met bien à jour après le rendu. */
    hasContent = signal(false);
    selectedFloorId = signal(null);
    /** Tous les niveaux triés bas → haut */
    allFloors = computed(() => {
        const p = this.project();
        if (!p)
            return [];
        const floors = p.floors?.length ? p.floors : [{ id: 'rdc', name: 'RDC', order: 0 }];
        return [...floors].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    });
    /** Vrai si au moins une pièce (DetectedRoom) existe dans le projet. Le
     *  watermark de niveau (« RDC »…) n'a de sens qu'avec des pièces ou plusieurs
     *  niveaux — un plan réseau SPANC/AC sans pièce n'en a pas besoin. */
    hasAnyRoom = computed(() => {
        const p = this.project();
        if (!p)
            return false;
        const inObjects = (objs) => (objs ?? []).some(o => o?.myType === 'DetectedRoom');
        if (inObjects(p.objects))
            return true;
        return (p.floors ?? []).some(f => inObjects(f.objects));
    });
    /** Niveaux affichés dans le watermark (filtrés selon la sélection). Vide si
     *  aucune pièce et un seul niveau (plan réseau pur) → pas de watermark. */
    watermarkFloors = computed(() => {
        const floors = this.allFloors();
        if (!this.hasAnyRoom() && floors.length <= 1)
            return [];
        const id = this.selectedFloorId();
        return id ? floors.filter(f => f.id === id) : floors;
    });
    selectFloor(id) {
        this.selectedFloorId.set(id);
    }
    showSlabs = signal(true);
    toggleSlabs() {
        this.showSlabs.update(v => !v);
    }
    /** Rotation auto « démo » : la caméra orbite en continu autour du plan. */
    autoRotate = signal(false);
    toggleAutoRotate() {
        const next = !this.autoRotate();
        this.autoRotate.set(next);
        if (this.controls)
            this.controls.autoRotate = next;
    }
    scene;
    camera;
    renderer;
    controls;
    animId = 0;
    wallCount = 0;
    pipeCount = 0;
    pictoCount = 0;
    resizeObserver;
    /** Textures chargées à disposer lors du prochain rebuild */
    loadedTextures = [];
    zone = inject(NgZone);
    constructor() {
        effect(() => {
            const proj = this.project();
            const selectedId = this.selectedFloorId();
            if (this.scene)
                this.rebuildScene(proj, selectedId);
        });
        effect(() => {
            const visible = this.showSlabs();
            if (!this.scene)
                return;
            this.scene.children
                .filter(c => c.isSlab)
                .forEach(c => { c.visible = visible; });
        });
    }
    ngAfterViewInit() {
        this.zone.runOutsideAngular(() => {
            this.initThree();
            this.rebuildScene(this.project(), this.selectedFloorId());
            this.animate();
        });
        const canvas = this.canvasRef().nativeElement;
        this.resizeObserver = new ResizeObserver(() => this.zone.runOutsideAngular(() => this.onResize()));
        this.resizeObserver.observe(canvas.parentElement);
        // Re-mesure après que le navigateur a fini le layout : dans certaines
        // intégrations (overlay créé via @if, conteneur dont la hauteur se stabilise
        // après l'init), clientHeight peut être incorrect au moment de initThree().
        // Deux rAF garantissent qu'on lit la taille définitive.
        this.zone.runOutsideAngular(() => {
            requestAnimationFrame(() => requestAnimationFrame(() => this.onResize()));
        });
    }
    ngOnDestroy() {
        cancelAnimationFrame(this.animId);
        this.resizeObserver?.disconnect();
        this.loadedTextures.forEach(t => t.dispose());
        this.renderer?.dispose();
    }
    // ── Three.js init ─────────────────────────────────────────────────────────
    initThree() {
        const canvas = this.canvasRef().nativeElement;
        const w = Math.max(canvas.parentElement.clientWidth, 1);
        const h = Math.max(canvas.parentElement.clientHeight, 1);
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0xf1f5f9);
        this.scene.fog = new THREE.Fog(0xf1f5f9, 40, 120);
        this.camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 200);
        this.camera.position.set(0, 18, 22);
        this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
        this.renderer.setSize(w, h);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        // Lumières
        const ambient = new THREE.AmbientLight(0xffffff, 0.6);
        this.scene.add(ambient);
        const sun = new THREE.DirectionalLight(0xfff8e7, 1.4);
        sun.position.set(10, 20, 15);
        sun.castShadow = true;
        sun.shadow.camera.near = 0.5;
        sun.shadow.camera.far = 100;
        sun.shadow.camera.left = -30;
        sun.shadow.camera.right = 30;
        sun.shadow.camera.top = 30;
        sun.shadow.camera.bottom = -30;
        sun.shadow.mapSize.set(2048, 2048);
        this.scene.add(sun);
        const fill = new THREE.DirectionalLight(0xdce8ff, 0.4);
        fill.position.set(-8, 10, -10);
        this.scene.add(fill);
        // Sol de référence neutre (toujours présent en arrière-plan)
        const groundGeo = new THREE.PlaneGeometry(100, 100);
        const groundMat = new THREE.MeshLambertMaterial({ color: 0xe2e8f0 });
        const ground = new THREE.Mesh(groundGeo, groundMat);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        this.scene.add(ground);
        // Grille légère
        const grid = new THREE.GridHelper(100, 100, 0xb0bec5, 0xcfd8dc);
        grid.position.y = 0.001;
        this.scene.add(grid);
        // Contrôles orbite
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.08;
        this.controls.minDistance = 2;
        this.controls.maxDistance = 80;
        this.controls.maxPolarAngle = Math.PI / 2 - 0.02;
        // Rotation auto « démo » : sens horaire (vu de dessus → vitesse négative),
        // ~1 tour en 30s à 60fps (vitesse 2.0). Désactivée par défaut (toggle).
        this.controls.autoRotate = false;
        this.controls.autoRotateSpeed = -AUTO_ROTATE_SPEED;
        // Stoppe la rotation auto dès que l'utilisateur interagit (drag/zoom).
        this.controls.addEventListener('start', () => {
            if (this.controls.autoRotate) {
                this.controls.autoRotate = false;
                this.zone.run(() => this.autoRotate.set(false));
            }
        });
    }
    // ── Construction de la scène ──────────────────────────────────────────────
    rebuildScene(project, selectedFloorId = null) {
        if (!this.scene)
            return;
        // Nettoyage des meshes précédents + textures
        const toRemove = this.scene.children.filter(c => c.isWallMesh);
        toRemove.forEach(c => {
            this.scene.remove(c);
            if (c instanceof THREE.Mesh)
                c.geometry?.dispose();
            if (c instanceof THREE.Group) {
                c.children.forEach(child => {
                    if (child instanceof THREE.Mesh)
                        child.geometry?.dispose();
                });
            }
        });
        this.loadedTextures.forEach(t => t.dispose());
        this.loadedTextures = [];
        this.wallCount = 0;
        this.pipeCount = 0;
        this.pictoCount = 0;
        this.hasContent.set(false);
        if (!project)
            return;
        const ppm = project.pixelsPerMeter;
        if (!ppm)
            return;
        const allFloors = project.floors?.length
            ? project.floors
            : [{ id: 'rdc', name: 'RDC', order: 0, objects: project.objects }];
        const floors = selectedFloorId
            ? allFloors.filter(f => f.id === selectedFloorId)
            : allFloors;
        // Cadrage global : murs + réseau + pictogrammes + fond de carte. La scène
        // se construit dès qu'au moins un de ces éléments existe (plus besoin de murs).
        const bounds = this.computeSceneBounds(floors, ppm);
        if (!bounds)
            return; // strictement rien à afficher
        const cx = ((bounds.minX + bounds.maxX) / 2) / ppm;
        const cy = ((bounds.minY + bounds.maxY) / 2) / ppm;
        // Fond de plan (Backdrop) — sert de plan de base, notamment pour SPANC/AC
        this.addBackdrop(floors, ppm, cx, cy);
        // Matériaux murs
        const murMat = new THREE.MeshLambertMaterial({ color: 0x94a3b8 });
        const cloisonMat = new THREE.MeshLambertMaterial({ color: 0xcbd5e1 });
        const dalMat = new THREE.MeshLambertMaterial({ color: 0xe2e8f0, transparent: true, opacity: 0.55 });
        let totalWalls = 0;
        let totalPipes = 0;
        let totalPictos = 0;
        for (const floor of floors) {
            const order = floor.order ?? 0;
            const baseY = order * FLOOR_HEIGHT_M;
            const segs = this.extractWalls(floor.objects);
            const openings = this.extractOpenings(floor.objects, ppm, cx, cy);
            totalWalls += segs.length;
            // Dalle — tous les niveaux (RDC au sol, autres entre les étages)
            const bb = this.boundingBox(segs, ppm, cx, cy);
            if (bb) {
                const slabGeo = new THREE.BoxGeometry(bb.w + 1, 0.15, bb.d + 1);
                const slab = new THREE.Mesh(slabGeo, dalMat);
                slab.isWallMesh = true;
                slab.isSlab = true;
                slab.visible = this.showSlabs();
                slab.position.set(bb.mx, order === 0 ? 0.002 : baseY - 0.075, bb.mz);
                slab.receiveShadow = true;
                this.scene.add(slab);
                // Sol extérieur texturé — uniquement au RDC
                if (order === 0) {
                    const margin = 6; // 6 m de marge autour de l'enveloppe
                    const groundTex = this.createGroundTexture();
                    this.loadedTextures.push(groundTex);
                    const groundGeo = new THREE.PlaneGeometry(bb.w + margin * 2, bb.d + margin * 2);
                    const groundMat = new THREE.MeshLambertMaterial({ map: groundTex });
                    const ground = new THREE.Mesh(groundGeo, groundMat);
                    ground.isWallMesh = true;
                    ground.rotation.x = -Math.PI / 2;
                    ground.position.set(bb.mx, 0.003, bb.mz);
                    ground.receiveShadow = true;
                    this.scene.add(ground);
                }
            }
            // Murs avec découpe aux portes/fenêtres
            for (const seg of segs) {
                const mat = seg.type === 'Mur' ? murMat : cloisonMat;
                this.renderWall(seg, baseY, ppm, cx, cy, mat, openings);
            }
            // Sol des pièces détectées
            this.renderRoomFloors(floor.objects, ppm, cx, cy, baseY);
            // Zones à risque (amiante, plomb/crep, humidité)
            const hazardZones = this.extractHazardZones(floor.objects, ppm, cx, cy);
            this.renderHazardZones(hazardZones, baseY);
            // Prélèvements amiante (P1, P2…)
            const samples = this.extractHazardSamples(floor.objects, ppm, cx, cy);
            this.renderHazardSamples(samples, baseY);
            // Réseau de canalisations — cylindres colorés au-dessus du sol
            const pipes = this.extractPipes(floor.objects);
            this.renderPipes(pipes, ppm, cx, cy, baseY);
            totalPipes += pipes.length;
            // Pictogrammes SPANC / AC — regards colorés + marqueurs étiquetés
            const pictos = this.extractPictograms(floor.objects);
            this.renderPictograms(pictos, ppm, cx, cy, baseY);
            totalPictos += pictos.length;
        }
        this.wallCount = totalWalls;
        this.pipeCount = totalPipes;
        this.pictoCount = totalPictos;
        this.hasContent.set(totalWalls > 0 || totalPipes > 0 || totalPictos > 0);
        this.lastBuildingSpan = Math.max((bounds.maxX - bounds.minX) / ppm, (bounds.maxY - bounds.minY) / ppm);
        this.lastFloorCount = floors.length;
        this.resetCamera();
    }
    /** Recadre la caméra autour du bâtiment courant. Exposée pour le bouton
     *  "Recadrer" et pour le rebuild initial. */
    resetCamera() {
        if (!this.controls || !this.camera)
            return;
        const span = this.lastBuildingSpan || 8;
        const dist = span * 1.5 + 6;
        this.camera.position.set(0, dist * 0.6, dist);
        // Plan de réseau à plat (SPANC/AC, sans mur) : viser près du sol.
        const targetY = this.wallCount > 0 ? this.lastFloorCount * FLOOR_HEIGHT_M / 2 : 0.4;
        this.controls.target.set(0, targetY, 0);
        this.controls.update();
    }
    lastBuildingSpan = 0;
    lastFloorCount = 1;
    // ── Fond de plan (Backdrop) ───────────────────────────────────────────────
    addBackdrop(floors, ppm, cx, cy) {
        // Cherche le Backdrop dans le niveau le plus bas (RDC ou SS)
        const sorted = [...floors].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
        let bd = null;
        for (const floor of sorted) {
            bd = floor.objects.find(o => o.myType === 'Backdrop');
            if (bd)
                break;
        }
        if (!bd?.src)
            return;
        const scaleX = bd.scaleX ?? 1;
        const scaleY = bd.scaleY ?? 1;
        const wPx = (bd.width ?? 0) * scaleX;
        const hPx = (bd.height ?? 0) * scaleY;
        if (wPx < 1 || hPx < 1)
            return;
        const wM = wPx / ppm;
        const hM = hPx / ppm;
        // left/top = centre si originX/Y: 'center' (tous les Backdrop du projet)
        // sinon coin supérieur-gauche → on ajoute la demi-dimension
        const originXCenter = (bd.originX ?? 'left') === 'center';
        const originYCenter = (bd.originY ?? 'top') === 'center';
        const centerXm = (bd.left ?? 0) / ppm + (originXCenter ? 0 : wM / 2) - cx;
        const centerZm = (bd.top ?? 0) / ppm + (originYCenter ? 0 : hM / 2) - cy;
        const angleRad = -(bd.angle ?? 0) * Math.PI / 180;
        const loader = new THREE.TextureLoader();
        loader.load(bd.src, (texture) => {
            this.loadedTextures.push(texture);
            const geo = new THREE.PlaneGeometry(wM, hM);
            const mat = new THREE.MeshBasicMaterial({
                map: texture,
                transparent: true,
                opacity: 0.85,
                depthWrite: false,
            });
            const mesh = new THREE.Mesh(geo, mat);
            mesh.rotation.x = -Math.PI / 2;
            // Groupe pour la rotation autour de l'axe Y (angle du backdrop)
            const group = new THREE.Group();
            group.isWallMesh = true;
            group.add(mesh);
            group.position.set(centerXm, 0.003, centerZm);
            group.rotation.y = angleRad;
            this.scene.add(group);
        });
    }
    // ── Helpers ───────────────────────────────────────────────────────────────
    extractWalls(objects) {
        return objects
            .filter(o => o.myType === 'Mur' || o.myType === 'Cloison')
            .map(o => ({
            x1: o.x1 ?? 0, y1: o.y1 ?? 0,
            x2: o.x2 ?? 0, y2: o.y2 ?? 0,
            type: o.myType,
            left: o.left ?? 0, top: o.top ?? 0,
            wallId: o.data?.wallId,
        }));
    }
    extractOpenings(objects, ppm, cx, cy) {
        return objects
            .filter(o => o.myType === 'Door' || o.myType === 'Window')
            .map(o => ({
            x: (o.left ?? 0) / ppm - cx,
            z: (o.top ?? 0) / ppm - cy,
            widthM: (o.width ?? 80) * (o.scaleX ?? 1) / ppm,
            angleRad: (o.angle ?? 0) * Math.PI / 180,
            type: o.myType,
            parentWallId: o.data?.parentWallId,
            glazingType: o.data?.glazingType ?? 'simple',
            doorType: o.data?.doorType ?? 'simple',
        }));
    }
    extractHazardZones(objects, ppm, cx, cy) {
        return objects
            .filter(o => o.myType === 'HazardZone')
            .map(o => {
            const scaleX = o.scaleX ?? 1;
            const scaleY = o.scaleY ?? 1;
            const wPx = (o.width ?? 100) * scaleX;
            const hPx = (o.height ?? 100) * scaleY;
            // left/top = coin sup-gauche (originX/Y: 'left'/'top' par défaut pour Rect)
            return {
                centerXm: ((o.left ?? 0) + wPx / 2) / ppm - cx,
                centerZm: ((o.top ?? 0) + hPx / 2) / ppm - cy,
                widthM: wPx / ppm,
                depthM: hPx / ppm,
                hazardType: (o.data?.hazardType ?? 'amiante'),
                hazardSurface: (o.data?.hazardSurface ?? 'sol'),
            };
        });
    }
    /** Ajoute une boîte de mur (segment) orientée selon le mur. */
    addWallSegment(x1m, z1m, ux, uz, tStart, tEnd, baseY, yOffset, height, thickness, mat, wallAngle) {
        const segLen = tEnd - tStart;
        if (segLen < 0.01 || height < 0.01)
            return;
        const cx = x1m + (tStart + segLen / 2) * ux;
        const cz = z1m + (tStart + segLen / 2) * uz;
        const geo = new THREE.BoxGeometry(segLen, height, thickness);
        const mesh = new THREE.Mesh(geo, mat);
        mesh.isWallMesh = true;
        mesh.position.set(cx, baseY + yOffset + height / 2, cz);
        mesh.rotation.y = wallAngle;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        this.scene.add(mesh);
    }
    /** Rend un mur en découpant les ouvertures (portes/fenêtres). */
    renderWall(seg, baseY, ppm, cx, cy, mat, openings) {
        const ends = this.getAbsoluteEnds(seg);
        const x1m = ends.p1.x / ppm - cx;
        const z1m = ends.p1.y / ppm - cy;
        const x2m = ends.p2.x / ppm - cx;
        const z2m = ends.p2.y / ppm - cy;
        const len = Math.hypot(x2m - x1m, z2m - z1m);
        if (len < 0.05)
            return;
        const thickness = seg.type === 'Mur' ? MUR_THICKNESS_M : CLOISON_THICKNESS_M;
        const ux = (x2m - x1m) / len;
        const uz = (z2m - z1m) / len;
        const wallAngle = -Math.atan2(z2m - z1m, x2m - x1m);
        // Sélectionner les ouvertures de ce mur
        const cuts = openings
            .filter(op => {
            if (seg.wallId && op.parentWallId)
                return op.parentWallId === seg.wallId;
            // Fallback par proximité
            const t = (op.x - x1m) * ux + (op.z - z1m) * uz;
            const px = x1m + t * ux, pz = z1m + t * uz;
            return Math.hypot(op.x - px, op.z - pz) < 0.4 && t > 0 && t < len;
        })
            .map(op => {
            const t = (op.x - x1m) * ux + (op.z - z1m) * uz;
            const hw = op.widthM / 2;
            return {
                type: op.type, from: Math.max(0, t - hw), to: Math.min(len, t + hw),
                glazingType: op.glazingType, doorType: op.doorType,
            };
        })
            .sort((a, b) => a.from - b.from);
        if (!cuts.length) {
            // Mur simple sans ouverture
            this.addWallSegment(x1m, z1m, ux, uz, 0, len, baseY, 0, FLOOR_HEIGHT_M, thickness, mat, wallAngle);
            return;
        }
        let cursor = 0;
        for (const cut of cuts) {
            // Segment plein avant l'ouverture
            if (cut.from > cursor + 0.01) {
                this.addWallSegment(x1m, z1m, ux, uz, cursor, cut.from, baseY, 0, FLOOR_HEIGHT_M, thickness, mat, wallAngle);
            }
            if (cut.type === 'Door') {
                // Linteau au-dessus de la porte
                const lintelH = FLOOR_HEIGHT_M - DOOR_HEIGHT_M;
                if (lintelH > 0.05) {
                    this.addWallSegment(x1m, z1m, ux, uz, cut.from, cut.to, baseY, DOOR_HEIGHT_M, lintelH, thickness, mat, wallAngle);
                }
                // Vantail(s) de porte
                this.addDoorLeaves(x1m, z1m, ux, uz, cut.from, cut.to, baseY, wallAngle, cut.doorType ?? 'simple');
            }
            else {
                // Appui de fenêtre (bas) + linteau (haut)
                this.addWallSegment(x1m, z1m, ux, uz, cut.from, cut.to, baseY, 0, SILL_HEIGHT_M, thickness, mat, wallAngle);
                const lintelH = FLOOR_HEIGHT_M - SILL_HEIGHT_M - WINDOW_HEIGHT_M;
                if (lintelH > 0.05) {
                    this.addWallSegment(x1m, z1m, ux, uz, cut.from, cut.to, baseY, SILL_HEIGHT_M + WINDOW_HEIGHT_M, lintelH, thickness, mat, wallAngle);
                }
                // Ouvrants côte à côte (simple = 1, double = 2, triple = 3, quadruple = 4)
                const segLen = cut.to - cut.from;
                const paneCount = cut.glazingType === 'quadruple' ? 4 : cut.glazingType === 'triple' ? 3 : cut.glazingType === 'double' ? 2 : 1;
                const MULLION_W = 0.04; // largeur d'un montant intermédiaire
                const totalMullions = paneCount - 1;
                const paneW = (segLen - totalMullions * MULLION_W) / paneCount;
                const vitreMat = new THREE.MeshBasicMaterial({ color: 0x7dd3fc, transparent: true, opacity: 0.35, depthWrite: false });
                const mullionMat = new THREE.MeshLambertMaterial({ color: 0xe2e8f0 });
                for (let pi = 0; pi < paneCount; pi++) {
                    const pStart = cut.from + pi * (paneW + MULLION_W);
                    const paneCx = x1m + (pStart + paneW / 2) * ux;
                    const paneCz = z1m + (pStart + paneW / 2) * uz;
                    const vitreGeo = new THREE.BoxGeometry(paneW, WINDOW_HEIGHT_M, 0.008);
                    const vitreMesh = new THREE.Mesh(vitreGeo, vitreMat);
                    vitreMesh.isWallMesh = true;
                    vitreMesh.position.set(paneCx, baseY + SILL_HEIGHT_M + WINDOW_HEIGHT_M / 2, paneCz);
                    vitreMesh.rotation.y = wallAngle;
                    this.scene.add(vitreMesh);
                    // Montant entre ouvrants
                    if (pi < paneCount - 1) {
                        const mStart = pStart + paneW;
                        const mCx = x1m + (mStart + MULLION_W / 2) * ux;
                        const mCz = z1m + (mStart + MULLION_W / 2) * uz;
                        const mullGeo = new THREE.BoxGeometry(MULLION_W, WINDOW_HEIGHT_M, thickness);
                        const mullMesh = new THREE.Mesh(mullGeo, mullionMat);
                        mullMesh.isWallMesh = true;
                        mullMesh.position.set(mCx, baseY + SILL_HEIGHT_M + WINDOW_HEIGHT_M / 2, mCz);
                        mullMesh.rotation.y = wallAngle;
                        this.scene.add(mullMesh);
                    }
                }
            }
            cursor = cut.to;
        }
        // Segment plein après la dernière ouverture
        if (cursor < len - 0.01) {
            this.addWallSegment(x1m, z1m, ux, uz, cursor, len, baseY, 0, FLOOR_HEIGHT_M, thickness, mat, wallAngle);
        }
    }
    /** Rendu des vantaux de porte (simples ou doubles), ouverts à ~70°. */
    addDoorLeaves(x1m, z1m, ux, uz, from, to, baseY, wallAngle, doorType) {
        const leafMat = new THREE.MeshLambertMaterial({ color: 0xd97706, transparent: true, opacity: 0.85 });
        const OPEN_ANGLE = Math.PI * 0.38; // ~70° ouverture
        const doorW = to - from;
        const leafW = doorType === 'double' ? doorW / 2 - 0.02 : doorW - 0.02;
        const leafH = DOOR_HEIGHT_M - 0.02;
        const leafThick = 0.04;
        const addLeaf = (pivotT, sign) => {
            const geo = new THREE.BoxGeometry(leafW, leafH, leafThick);
            // Décaler la géométrie pour que le pivot soit à l'extrémité
            geo.translate(sign * leafW / 2, 0, 0);
            const mesh = new THREE.Mesh(geo, leafMat);
            mesh.isWallMesh = true;
            mesh.position.set(x1m + pivotT * ux, baseY + leafH / 2 + 0.01, z1m + pivotT * uz);
            // Rotation : angle du mur + ouverture
            mesh.rotation.y = wallAngle + sign * OPEN_ANGLE;
            mesh.castShadow = true;
            this.scene.add(mesh);
        };
        if (doorType === 'double') {
            // Deux vantaux s'ouvrant vers l'extérieur depuis le centre
            const mid = (from + to) / 2;
            addLeaf(mid, -1); // vantail gauche
            addLeaf(mid, 1); // vantail droit
        }
        else {
            addLeaf(from, 1); // vantail unique depuis le montant gauche
        }
    }
    /** Rendu des zones à risque (amiante, plomb/crep, humidité) en 3D. */
    renderHazardZones(zones, baseY) {
        const COLORS = {
            amiante: 0xf59e0b, // ambre
            plomb: 0xef4444, // rouge
            humidite: 0x3b82f6, // bleu
        };
        for (const zone of zones) {
            const color = COLORS[zone.hazardType] ?? 0xf59e0b;
            const mat = new THREE.MeshBasicMaterial({
                color, transparent: true, opacity: 0.45,
                side: THREE.DoubleSide, depthWrite: false,
            });
            if (zone.hazardSurface === 'sol') {
                // Volume depuis le sol jusqu'à 0.3 m de hauteur
                const h = 0.30;
                const geo = new THREE.BoxGeometry(zone.widthM, h, zone.depthM);
                const mesh = new THREE.Mesh(geo, mat);
                mesh.isWallMesh = true;
                mesh.position.set(zone.centerXm, baseY + h / 2, zone.centerZm);
                this.scene.add(mesh);
                this.addHazardOutline(zone.widthM, zone.depthM, color, zone.centerXm, baseY + 0.001, zone.centerZm, 'sol');
            }
            else if (zone.hazardSurface === 'plafond') {
                // Volume depuis le plafond vers le bas sur 0.3 m
                const h = 0.30;
                const geo = new THREE.BoxGeometry(zone.widthM, h, zone.depthM);
                const mesh = new THREE.Mesh(geo, mat);
                mesh.isWallMesh = true;
                mesh.position.set(zone.centerXm, baseY + FLOOR_HEIGHT_M - h / 2, zone.centerZm);
                this.scene.add(mesh);
                this.addHazardOutline(zone.widthM, zone.depthM, color, zone.centerXm, baseY + FLOOR_HEIGHT_M - 0.001, zone.centerZm, 'plafond');
            }
            else {
                // Mur : cadre rectangulaire creux = 4 panneaux sur toute la hauteur du niveau
                const h = FLOOR_HEIGHT_M;
                const t = 0.06; // épaisseur de chaque panneau (6 cm)
                const cx = zone.centerXm;
                const cz = zone.centerZm;
                const y = baseY + h / 2;
                const hw = zone.widthM / 2;
                const hd = zone.depthM / 2;
                const panels = [
                    { w: zone.widthM, d: t, px: cx, pz: cz - hd }, // face avant
                    { w: zone.widthM, d: t, px: cx, pz: cz + hd }, // face arrière
                    { w: t, d: zone.depthM, px: cx - hw, pz: cz }, // face gauche
                    { w: t, d: zone.depthM, px: cx + hw, pz: cz }, // face droite
                ];
                for (const p of panels) {
                    const geo = new THREE.BoxGeometry(p.w, h, p.d);
                    const mesh = new THREE.Mesh(geo, mat);
                    mesh.isWallMesh = true;
                    mesh.position.set(p.px, y, p.pz);
                    this.scene.add(mesh);
                }
            }
        }
    }
    extractHazardSamples(objects, ppm, cx, cy) {
        return objects
            .filter(o => o.myType === 'HazardSample')
            .map(o => ({
            x: (o.left ?? 0) / ppm - cx,
            z: (o.top ?? 0) / ppm - cy,
            sampleId: o.data?.sampleId ?? 'P?',
            hazardSurface: (o.data?.hazardSurface ?? 'sol'),
            amianteResult: (o.data?.amianteResult ?? 'unknown'),
        }));
    }
    /** Rendu des prélèvements amiante en 3D : sphère positionnée selon la surface. Rouge si positif amiante, ambre sinon. */
    renderHazardSamples(samples, baseY) {
        const ringMat = new THREE.MeshBasicMaterial({ color: 0x92400e, wireframe: true });
        const R = 0.12; // rayon en mètres
        for (const s of samples) {
            let y;
            if (s.hazardSurface === 'plafond') {
                y = baseY + FLOOR_HEIGHT_M - R - 0.02;
            }
            else if (s.hazardSurface === 'mur') {
                y = baseY + FLOOR_HEIGHT_M * 0.5;
            }
            else {
                y = baseY + R + 0.01; // sol
            }
            // Sphère : rouge si positif, vert si négatif, ambre si non renseigné
            const sphereColor = s.amianteResult === 'positive' ? 0xef4444
                : s.amianteResult === 'negative' ? 0x22c55e
                    : 0xf59e0b;
            const sphereMat = new THREE.MeshLambertMaterial({ color: sphereColor });
            const sphere = new THREE.Mesh(new THREE.SphereGeometry(R, 12, 8), sphereMat);
            sphere.isWallMesh = true;
            sphere.position.set(s.x, y, s.z);
            sphere.castShadow = true;
            this.scene.add(sphere);
            // Anneau de contour
            const ring = new THREE.Mesh(new THREE.TorusGeometry(R, 0.015, 6, 16), ringMat);
            ring.isWallMesh = true;
            ring.position.set(s.x, y, s.z);
            // Orienter l'anneau selon la surface
            if (s.hazardSurface === 'sol' || s.hazardSurface === 'plafond') {
                ring.rotation.x = Math.PI / 2;
            }
            this.scene.add(ring);
            // Tige verticale pour repérage (sol uniquement)
            if (s.hazardSurface === 'sol') {
                const stemH = 0.25;
                const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, stemH, 6), new THREE.MeshLambertMaterial({ color: 0x92400e }));
                stem.isWallMesh = true;
                stem.position.set(s.x, baseY + stemH / 2, s.z);
                this.scene.add(stem);
            }
        }
    }
    addHazardOutline(w, d, color, cx, y, cz, surface) {
        const points = [
            new THREE.Vector3(-w / 2, 0, -d / 2), new THREE.Vector3(w / 2, 0, -d / 2),
            new THREE.Vector3(w / 2, 0, d / 2), new THREE.Vector3(-w / 2, 0, d / 2),
            new THREE.Vector3(-w / 2, 0, -d / 2),
        ].map(p => surface === 'plafond' ? new THREE.Vector3(p.x, -p.z, p.y) : p);
        const geo = new THREE.BufferGeometry().setFromPoints(points);
        const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color, linewidth: 2 }));
        line.isWallMesh = true;
        line.position.set(cx, y, cz);
        this.scene.add(line);
    }
    getAbsoluteEnds(seg) {
        const dx = (seg.left ?? 0) - Math.min(seg.x1 ?? 0, seg.x2 ?? 0);
        const dy = (seg.top ?? 0) - Math.min(seg.y1 ?? 0, seg.y2 ?? 0);
        return {
            p1: { x: (seg.x1 ?? 0) + dx, y: (seg.y1 ?? 0) + dy },
            p2: { x: (seg.x2 ?? 0) + dx, y: (seg.y2 ?? 0) + dy },
        };
    }
    /** Bornes (en pixels canvas) de toute la géométrie : murs, canalisations,
     *  pictogrammes et fond de carte. `null` si la scène est strictement vide. */
    computeSceneBounds(floors, ppm) {
        let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
        let any = false;
        const add = (x, y) => {
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            any = true;
        };
        for (const floor of floors) {
            for (const o of (floor.objects ?? [])) {
                if (o.myType === 'Mur' || o.myType === 'Cloison' || PIPE_COLORS_3D[o.myType] !== undefined) {
                    const e = this.getAbsoluteEnds(o);
                    add(e.p1.x, e.p1.y);
                    add(e.p2.x, e.p2.y);
                }
                else if (o.myType === 'AcPictogram' || o.myType === 'SpancPictogram' || o.myType === 'HazardSample') {
                    add(o.left ?? 0, o.top ?? 0);
                }
                else if (o.myType === 'Backdrop') {
                    const w = (o.width ?? 0) * (o.scaleX ?? 1);
                    const h = (o.height ?? 0) * (o.scaleY ?? 1);
                    const l = (o.left ?? 0) - ((o.originX ?? 'left') === 'center' ? w / 2 : 0);
                    const t = (o.top ?? 0) - ((o.originY ?? 'top') === 'center' ? h / 2 : 0);
                    add(l, t);
                    add(l + w, t + h);
                }
            }
        }
        return any ? { minX, maxX, minY, maxY } : null;
    }
    // ── Réseau de canalisations ───────────────────────────────────────────────
    extractPipes(objects) {
        return objects
            .filter(o => PIPE_COLORS_3D[o.myType] !== undefined)
            .map(o => ({
            x1: o.x1 ?? 0, y1: o.y1 ?? 0,
            x2: o.x2 ?? 0, y2: o.y2 ?? 0,
            left: o.left ?? 0, top: o.top ?? 0,
            myType: o.myType,
        }));
    }
    /** Rend chaque canalisation en cylindre coloré, légèrement surélevé au-dessus
     *  du fond de plan, avec une sphère de jonction à chaque extrémité. */
    renderPipes(pipes, ppm, cx, cy, baseY) {
        const up = new THREE.Vector3(0, 1, 0);
        for (const p of pipes) {
            const ends = this.getAbsoluteEnds(p);
            const x1 = ends.p1.x / ppm - cx, z1 = ends.p1.y / ppm - cy;
            const x2 = ends.p2.x / ppm - cx, z2 = ends.p2.y / ppm - cy;
            const dir = new THREE.Vector3(x2 - x1, 0, z2 - z1);
            const len = dir.length();
            if (len < 0.02)
                continue;
            const color = PIPE_COLORS_3D[p.myType] ?? 0x64748b;
            const mat = new THREE.MeshLambertMaterial({ color });
            const y = baseY + PIPE_ELEVATION_M;
            const tube = new THREE.Mesh(new THREE.CylinderGeometry(PIPE_RADIUS_M, PIPE_RADIUS_M, len, 12), mat);
            tube.isWallMesh = true;
            tube.position.set((x1 + x2) / 2, y, (z1 + z2) / 2);
            tube.quaternion.setFromUnitVectors(up, dir.clone().normalize());
            tube.castShadow = true;
            this.scene.add(tube);
            // Sphères de jonction aux extrémités → le réseau se lit comme un graphe
            for (const [jx, jz] of [[x1, z1], [x2, z2]]) {
                const joint = new THREE.Mesh(new THREE.SphereGeometry(PIPE_RADIUS_M * 1.35, 10, 8), mat);
                joint.isWallMesh = true;
                joint.position.set(jx, y, jz);
                this.scene.add(joint);
            }
        }
    }
    // ── Pictogrammes SPANC / AC ───────────────────────────────────────────────
    extractPictograms(objects) {
        return objects
            .filter(o => o.myType === 'AcPictogram' || o.myType === 'SpancPictogram')
            .map(o => ({
            px: o.left ?? 0, py: o.top ?? 0,
            kind: (o.data?.acKind ?? o.data?.spancKind ?? ''),
            label: (o.data?.label ?? ''),
            isAc: o.myType === 'AcPictogram',
        }));
    }
    /** Rend les pictogrammes : regards en cuves cylindriques colorées selon le
     *  type d'eau, autres pictogrammes en marqueurs cubiques. Tous étiquetés. */
    renderPictograms(pictos, ppm, cx, cy, baseY) {
        for (const pic of pictos) {
            const x = pic.px / ppm - cx;
            const z = pic.py / ppm - cy;
            const regardColor = REGARD_COLORS_3D[pic.kind];
            const isRegard = regardColor !== undefined || pic.kind === 'spanc-regard';
            if (isRegard) {
                // Regard : cuve cylindrique colorée + tampon (anneau) en surface
                const color = regardColor ?? 0x475569; // spanc-regard → gris ardoise
                const h = 0.5, r = 0.38;
                const cuve = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 20), new THREE.MeshLambertMaterial({ color }));
                cuve.isWallMesh = true;
                cuve.position.set(x, baseY + h / 2, z);
                cuve.castShadow = true;
                cuve.receiveShadow = true;
                this.scene.add(cuve);
                const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.05, 8, 24), new THREE.MeshLambertMaterial({ color: 0x1f2937 }));
                ring.isWallMesh = true;
                ring.rotation.x = Math.PI / 2;
                ring.position.set(x, baseY + h, z);
                this.scene.add(ring);
            }
            else {
                // Autre pictogramme : marqueur cubique (cyan pour AC, brun pour SPANC)
                const s = 0.6;
                const box = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), new THREE.MeshLambertMaterial({ color: pic.isAc ? 0x0891b2 : 0xa16207 }));
                box.isWallMesh = true;
                box.position.set(x, baseY + s / 2, z);
                box.castShadow = true;
                this.scene.add(box);
            }
            // Étiquette texte flottante, toujours face caméra
            if (pic.label) {
                const sprite = this.makeLabelSprite(pic.label);
                sprite.position.set(x, baseY + 1.15, z);
                this.scene.add(sprite);
            }
        }
    }
    /** Crée une étiquette texte flottante (sprite face-caméra) via un canvas. */
    makeLabelSprite(text) {
        const pad = 14, fontPx = 30;
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        ctx.font = `bold ${fontPx}px sans-serif`;
        const textW = ctx.measureText(text).width;
        canvas.width = Math.ceil(textW + pad * 2);
        canvas.height = fontPx + pad * 2;
        // Le redimensionnement du canvas réinitialise le contexte → re-déclarer la police
        ctx.font = `bold ${fontPx}px sans-serif`;
        ctx.fillStyle = 'rgba(15,23,42,0.82)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, canvas.width / 2, canvas.height / 2);
        const tex = new THREE.CanvasTexture(canvas);
        this.loadedTextures.push(tex);
        const sprite = new THREE.Sprite(new THREE.SpriteMaterial({
            map: tex, transparent: true, depthTest: false,
        }));
        sprite.isWallMesh = true;
        const hM = 0.42; // hauteur ~0.42 m, largeur proportionnelle au texte
        sprite.scale.set(hM * canvas.width / canvas.height, hM, 1);
        return sprite;
    }
    /** Rendu du sol de chaque pièce DetectedRoom (polygone Fabric.js) */
    renderRoomFloors(objects, ppm, cx, cy, baseY) {
        const rooms = objects.filter(o => o.myType === 'DetectedRoom' && o.data?.isNested === false);
        if (!rooms.length)
            return;
        const parquetTex = this.createParquetTexture();
        this.loadedTextures.push(parquetTex);
        for (const room of rooms) {
            const pts = room.points ?? [];
            if (pts.length < 3)
                continue;
            // Points Fabric.js stockés relatifs au coin sup-gauche du bbox.
            // abs = left + p.x  /  top + p.y
            // Après rotateX(-π/2) : shape Y → -Z → on négative zM.
            const bLeft = room.left ?? 0;
            const bTop = room.top ?? 0;
            const shape = new THREE.Shape();
            pts.forEach((p, i) => {
                const xM = (bLeft + p.x) / ppm - cx;
                const zM = -((bTop + p.y) / ppm - cy);
                if (i === 0)
                    shape.moveTo(xM, zM);
                else
                    shape.lineTo(xM, zM);
            });
            shape.closePath();
            const geo = new THREE.ShapeGeometry(shape);
            // ShapeGeometry est dans le plan XY → rotation pour le poser à plat
            geo.rotateX(-Math.PI / 2);
            const mat = new THREE.MeshLambertMaterial({ map: parquetTex, side: THREE.DoubleSide });
            const mesh = new THREE.Mesh(geo, mat);
            mesh.isWallMesh = true;
            mesh.position.set(0, baseY + 0.005, 0);
            mesh.receiveShadow = true;
            this.scene.add(mesh);
        }
    }
    /** Génère une texture procédurale parquet bois pour le sol intérieur */
    createParquetTexture() {
        const size = 512;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        const lameW = 64; // largeur d'une lame (px)
        const lameH = 16; // épaisseur d'une lame (px)
        for (let row = 0; row < size / lameH; row++) {
            const offset = (row % 2 === 0) ? 0 : lameW / 2;
            for (let col = -1; col <= size / lameW + 1; col++) {
                const x = col * lameW + offset;
                const y = row * lameH;
                // Fond bois (légère variation)
                const lightness = 0.82 + (Math.sin(row * 7.3 + col * 13.1) * 0.5 + 0.5) * 0.12;
                const r = Math.round(180 * lightness);
                const g = Math.round(120 * lightness);
                const b = Math.round(60 * lightness);
                ctx.fillStyle = `rgb(${r},${g},${b})`;
                ctx.fillRect(x, y, lameW - 1, lameH - 1);
                // Grain bois (lignes horizontales légères)
                ctx.strokeStyle = `rgba(0,0,0,0.06)`;
                ctx.lineWidth = 1;
                for (let g2 = 1; g2 < lameH - 1; g2 += 3) {
                    ctx.beginPath();
                    ctx.moveTo(x, y + g2);
                    ctx.lineTo(x + lameW - 1, y + g2);
                    ctx.stroke();
                }
                // Joint
                ctx.fillStyle = 'rgba(80,50,20,0.25)';
                ctx.fillRect(x, y + lameH - 1, lameW, 1);
                ctx.fillRect(x + lameW - 1, y, 1, lameH);
            }
        }
        const tex = new THREE.CanvasTexture(canvas);
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.repeat.set(4, 4);
        return tex;
    }
    /** Génère une texture procédurale type pelouse/terrain pour le sol RDC */
    createGroundTexture() {
        const size = 512;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        // Base herbe verte
        ctx.fillStyle = '#5a8a3c';
        ctx.fillRect(0, 0, size, size);
        // Variation de teinte aléatoire pour simuler l'herbe
        const rng = (n) => Math.sin(n * 127.1 + 311.7) * 0.5 + 0.5;
        for (let i = 0; i < 4000; i++) {
            const x = rng(i) * size;
            const y = rng(i + 1000) * size;
            const r = 2 + rng(i + 2000) * 5;
            const light = rng(i + 3000);
            const g = Math.round(120 + light * 60);
            const gr = Math.round(70 + light * 30);
            ctx.beginPath();
            ctx.arc(x, y, r, 0, Math.PI * 2);
            ctx.fillStyle = `rgb(${gr},${g},${Math.round(30 + light * 20)})`;
            ctx.fill();
        }
        // Quelques brins d'herbe
        ctx.strokeStyle = '#3d6b28';
        ctx.lineWidth = 1;
        for (let i = 0; i < 800; i++) {
            const x = rng(i + 500) * size;
            const y = rng(i + 600) * size;
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + (rng(i + 700) - 0.5) * 6, y - 4 - rng(i + 800) * 6);
            ctx.stroke();
        }
        const tex = new THREE.CanvasTexture(canvas);
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.repeat.set(8, 8);
        return tex;
    }
    boundingBox(segs, ppm, cx, cy) {
        if (!segs.length)
            return null;
        let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
        for (const s of segs) {
            const e = this.getAbsoluteEnds(s);
            const x1 = e.p1.x / ppm - cx, z1 = e.p1.y / ppm - cy;
            const x2 = e.p2.x / ppm - cx, z2 = e.p2.y / ppm - cy;
            minX = Math.min(minX, x1, x2);
            maxX = Math.max(maxX, x1, x2);
            minZ = Math.min(minZ, z1, z2);
            maxZ = Math.max(maxZ, z1, z2);
        }
        return { mx: (minX + maxX) / 2, mz: (minZ + maxZ) / 2, w: maxX - minX, d: maxZ - minZ };
    }
    // ── Boucle de rendu ───────────────────────────────────────────────────────
    animate() {
        this.animId = requestAnimationFrame(() => this.animate());
        this.controls.update();
        this.renderer.render(this.scene, this.camera);
    }
    onResize() {
        if (!this.renderer)
            return;
        const canvas = this.canvasRef().nativeElement;
        const w = canvas.parentElement.clientWidth;
        const h = canvas.parentElement.clientHeight;
        if (w === 0 || h === 0)
            return;
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: Viewer3DComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: Viewer3DComponent, isStandalone: true, selector: "ng-gplan-viewer-3d", inputs: { project: { classPropertyName: "project", publicName: "project", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "canvasRef", first: true, predicate: ["canvas3d"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="ngf-viewer3d">
      <canvas #canvas3d class="ngf-viewer3d__canvas"></canvas>

      @if (watermarkFloors().length) {
        <div class="ngf-viewer3d__watermark">
          @for (floor of watermarkFloors(); track floor.name) {
            <span>{{ floor.name }}</span>
          }
        </div>
      }

      <div class="ngf-viewer3d__floor-select">
        @if (allFloors().length > 1) {
          <button class="ngf-viewer3d__floor-btn"
            [class.ngf-viewer3d__floor-btn--active]="selectedFloorId() === null"
            (click)="selectFloor(null)">Tous</button>
          @for (floor of allFloors().slice().reverse(); track floor.id) {
            <button class="ngf-viewer3d__floor-btn"
              [class.ngf-viewer3d__floor-btn--active]="selectedFloorId() === floor.id"
              (click)="selectFloor(floor.id)">{{ floor.name }}</button>
          }
          <div class="ngf-viewer3d__floor-sep"></div>
        }
        <button class="ngf-viewer3d__floor-btn"
          [class.ngf-viewer3d__floor-btn--active]="showSlabs()"
          (click)="toggleSlabs()" title="Afficher / masquer les dalles">⬜ Dalles</button>
        <button class="ngf-viewer3d__floor-btn"
          [class.ngf-viewer3d__floor-btn--active]="autoRotate()"
          (click)="toggleAutoRotate()"
          [title]="autoRotate() ? 'Arrêter la rotation automatique' : 'Faire tourner le plan automatiquement'">
          {{ autoRotate() ? '⏸ Rotation' : '▶ Rotation' }}
        </button>
      </div>

      <button class="ngf-viewer3d__recenter" type="button"
        (click)="resetCamera()"
        title="Recadrer la caméra"
        aria-label="Recadrer la caméra">
        ⟲
      </button>

      <div class="ngf-viewer3d__hint">
        Clic gauche : rotation · Clic droit : déplacement · Molette : zoom
      </div>
      @if (!hasContent()) {
        <div class="ngf-viewer3d__empty">
          Rien à afficher — dessinez un plan, un réseau ou ajoutez un fond de carte dans l'éditeur.
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:flex;flex:1;overflow:hidden}.ngf-viewer3d{position:relative;flex:1;display:flex;overflow:hidden}.ngf-viewer3d__canvas{display:block;width:100%;height:100%;touch-action:none}.ngf-viewer3d__recenter{position:absolute;top:12px;left:12px;width:36px;height:36px;background:#0f172a8c;color:#ffffffd9;border:1px solid rgba(255,255,255,.12);border-radius:50%;cursor:pointer;font-size:18px;line-height:1;backdrop-filter:blur(6px);transition:background .15s,color .15s,transform .15s;z-index:10}.ngf-viewer3d__recenter:hover{background:#0f172ac7;color:#fff;transform:rotate(-30deg)}@media(pointer:coarse){.ngf-viewer3d__floor-btn,.ngf-viewer3d__recenter{min-height:44px;min-width:44px}}@media(max-width:768px){.ngf-viewer3d__floor-select{inset:auto 12px 12px auto;flex-direction:row;max-width:calc(100vw - 24px);overflow-x:auto;scrollbar-width:none}.ngf-viewer3d__floor-select::-webkit-scrollbar{display:none}.ngf-viewer3d__hint{display:none}.ngf-viewer3d__recenter{top:8px;left:8px}}.ngf-viewer3d__floor-select{position:absolute;top:12px;right:12px;display:flex;flex-direction:column;gap:4px;z-index:10}.ngf-viewer3d__floor-sep{height:1px;background:#fff3;margin:2px 0}.ngf-viewer3d__floor-btn{padding:5px 14px;background:#0f172a8c;color:#fffc;border:1px solid rgba(255,255,255,.12);border-radius:100px;cursor:pointer;font-size:11px;font-weight:600;font-family:ui-sans-serif,system-ui,sans-serif;white-space:nowrap;text-align:center;backdrop-filter:blur(6px);transition:background .15s,color .15s}.ngf-viewer3d__floor-btn:hover{background:#0f172abf;color:#fff}.ngf-viewer3d__floor-btn--active{background:#f97316e6;color:#fff;border-color:transparent}.ngf-viewer3d__hint{position:absolute;bottom:12px;left:50%;transform:translate(-50%);background:#0f172aa6;color:#ffffffd9;font-size:11px;font-family:ui-sans-serif,system-ui,sans-serif;padding:5px 14px;border-radius:100px;pointer-events:none;white-space:nowrap}.ngf-viewer3d__watermark{position:absolute;inset:0;display:flex;flex-direction:column-reverse;justify-content:space-evenly;align-items:center;pointer-events:none;-webkit-user-select:none;user-select:none;overflow:hidden}.ngf-viewer3d__watermark span{font-size:clamp(28px,5vw,72px);font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:#0000000d;white-space:nowrap;font-family:ui-sans-serif,system-ui,sans-serif;line-height:1}.ngf-viewer3d__empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:13px;color:#94a3b8;font-family:ui-sans-serif,system-ui,sans-serif;pointer-events:none}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: Viewer3DComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-gplan-viewer-3d', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="ngf-viewer3d">
      <canvas #canvas3d class="ngf-viewer3d__canvas"></canvas>

      @if (watermarkFloors().length) {
        <div class="ngf-viewer3d__watermark">
          @for (floor of watermarkFloors(); track floor.name) {
            <span>{{ floor.name }}</span>
          }
        </div>
      }

      <div class="ngf-viewer3d__floor-select">
        @if (allFloors().length > 1) {
          <button class="ngf-viewer3d__floor-btn"
            [class.ngf-viewer3d__floor-btn--active]="selectedFloorId() === null"
            (click)="selectFloor(null)">Tous</button>
          @for (floor of allFloors().slice().reverse(); track floor.id) {
            <button class="ngf-viewer3d__floor-btn"
              [class.ngf-viewer3d__floor-btn--active]="selectedFloorId() === floor.id"
              (click)="selectFloor(floor.id)">{{ floor.name }}</button>
          }
          <div class="ngf-viewer3d__floor-sep"></div>
        }
        <button class="ngf-viewer3d__floor-btn"
          [class.ngf-viewer3d__floor-btn--active]="showSlabs()"
          (click)="toggleSlabs()" title="Afficher / masquer les dalles">⬜ Dalles</button>
        <button class="ngf-viewer3d__floor-btn"
          [class.ngf-viewer3d__floor-btn--active]="autoRotate()"
          (click)="toggleAutoRotate()"
          [title]="autoRotate() ? 'Arrêter la rotation automatique' : 'Faire tourner le plan automatiquement'">
          {{ autoRotate() ? '⏸ Rotation' : '▶ Rotation' }}
        </button>
      </div>

      <button class="ngf-viewer3d__recenter" type="button"
        (click)="resetCamera()"
        title="Recadrer la caméra"
        aria-label="Recadrer la caméra">
        ⟲
      </button>

      <div class="ngf-viewer3d__hint">
        Clic gauche : rotation · Clic droit : déplacement · Molette : zoom
      </div>
      @if (!hasContent()) {
        <div class="ngf-viewer3d__empty">
          Rien à afficher — dessinez un plan, un réseau ou ajoutez un fond de carte dans l'éditeur.
        </div>
      }
    </div>
  `, styles: [":host{display:flex;flex:1;overflow:hidden}.ngf-viewer3d{position:relative;flex:1;display:flex;overflow:hidden}.ngf-viewer3d__canvas{display:block;width:100%;height:100%;touch-action:none}.ngf-viewer3d__recenter{position:absolute;top:12px;left:12px;width:36px;height:36px;background:#0f172a8c;color:#ffffffd9;border:1px solid rgba(255,255,255,.12);border-radius:50%;cursor:pointer;font-size:18px;line-height:1;backdrop-filter:blur(6px);transition:background .15s,color .15s,transform .15s;z-index:10}.ngf-viewer3d__recenter:hover{background:#0f172ac7;color:#fff;transform:rotate(-30deg)}@media(pointer:coarse){.ngf-viewer3d__floor-btn,.ngf-viewer3d__recenter{min-height:44px;min-width:44px}}@media(max-width:768px){.ngf-viewer3d__floor-select{inset:auto 12px 12px auto;flex-direction:row;max-width:calc(100vw - 24px);overflow-x:auto;scrollbar-width:none}.ngf-viewer3d__floor-select::-webkit-scrollbar{display:none}.ngf-viewer3d__hint{display:none}.ngf-viewer3d__recenter{top:8px;left:8px}}.ngf-viewer3d__floor-select{position:absolute;top:12px;right:12px;display:flex;flex-direction:column;gap:4px;z-index:10}.ngf-viewer3d__floor-sep{height:1px;background:#fff3;margin:2px 0}.ngf-viewer3d__floor-btn{padding:5px 14px;background:#0f172a8c;color:#fffc;border:1px solid rgba(255,255,255,.12);border-radius:100px;cursor:pointer;font-size:11px;font-weight:600;font-family:ui-sans-serif,system-ui,sans-serif;white-space:nowrap;text-align:center;backdrop-filter:blur(6px);transition:background .15s,color .15s}.ngf-viewer3d__floor-btn:hover{background:#0f172abf;color:#fff}.ngf-viewer3d__floor-btn--active{background:#f97316e6;color:#fff;border-color:transparent}.ngf-viewer3d__hint{position:absolute;bottom:12px;left:50%;transform:translate(-50%);background:#0f172aa6;color:#ffffffd9;font-size:11px;font-family:ui-sans-serif,system-ui,sans-serif;padding:5px 14px;border-radius:100px;pointer-events:none;white-space:nowrap}.ngf-viewer3d__watermark{position:absolute;inset:0;display:flex;flex-direction:column-reverse;justify-content:space-evenly;align-items:center;pointer-events:none;-webkit-user-select:none;user-select:none;overflow:hidden}.ngf-viewer3d__watermark span{font-size:clamp(28px,5vw,72px);font-weight:900;letter-spacing:.14em;text-transform:uppercase;color:#0000000d;white-space:nowrap;font-family:ui-sans-serif,system-ui,sans-serif;line-height:1}.ngf-viewer3d__empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:13px;color:#94a3b8;font-family:ui-sans-serif,system-ui,sans-serif;pointer-events:none}\n"] }]
        }], ctorParameters: () => [] });

/** Liste des noms de pièces proposés par défaut dans l'éditeur */
const ROOM_NAMES = [
    // Pièces de vie
    'Séjour', 'Salle à manger', 'Cuisine', 'Cuisine ouverte', 'Séjour / Cuisine',
    // Chambres
    'Chambre 1', 'Chambre 2', 'Chambre 3', 'Chambre 4', 'Chambre 5',
    // Sanitaires
    'Salle de bain', "Salle d'eau", 'WC', 'WC + Salle d\'eau',
    // Circulations et dégagements
    'Entrée', 'Couloir', 'Dégagement', 'Palier', "Cage d'escalier",
    // Rangements et dépendances intérieures
    'Bureau', 'Dressing', 'Placard', 'Débarras', 'Buanderie',
    // Locaux techniques
    'Garage', 'Chaufferie', 'Local technique', 'Cave à gaz',
    // Extérieurs
    'Terrasse', 'Balcon', 'Loggia', 'Véranda', 'Jardin',
    // Niveaux spéciaux (hors loi Carrez si HSP < 1,80 m)
    'Cave', 'Sous-sol', 'Combles', 'Grenier', 'Mezzanine',
    // Locaux professionnels / divers
    'Atelier', 'Remise', 'Local commun', 'Piscine',
];
/**
 * Pièces exclues de la surface habitable loi Carrez (décret 97-532).
 * À utiliser pour informer l'utilisateur lors de l'export.
 */
const ROOM_NAMES_CARREZ_EXCLUDED = [
    'Cave', 'Sous-sol', 'Combles', 'Grenier', 'Garage',
    'Terrasse', 'Balcon', 'Jardin', 'Piscine', 'Local commun',
];

/**
 * Modes métier — cumulables.
 * Le mapping outil ↔ mode vit dans `fabric-types.const.ts` (champ `modes` de chaque
 * ToolDefinition / ToolGroup). Un outil est visible si l'intersection entre ses
 * modes et les modes actifs est non vide.
 */
const WORK_MODES = [
    { id: 'diag', label: 'Diagnostic immobilier', shortLabel: 'Diag', color: '#6366f1', icon: '🏠' },
    { id: 'aep', label: 'Adduction Eau Potable', shortLabel: 'AEP', color: '#3b82f6', icon: '💧' },
    { id: 'eu', label: 'Eaux usées', shortLabel: 'EU', color: '#8b5cf6', icon: '🔵' },
    { id: 'spanc', label: 'SPANC', shortLabel: 'SPANC', color: '#a16207', icon: '🛢' },
    { id: 'ac', label: 'Assainissement collectif', shortLabel: 'AC', color: '#0891b2', icon: '🚰' },
    { id: 'vrd', label: 'Voirie Réseaux Divers', shortLabel: 'VRD', color: '#16a34a', icon: '🛣' },
];
const ALL_WORK_MODES = WORK_MODES.map(m => m.id);
const DEFAULT_WORK_MODES = ['diag'];
const WORK_MODES_STORAGE_KEY = 'gplan-work-modes';

// AUTO-GÉNÉRÉ depuis package.json par `make sync-version` — ne pas éditer à la main.
const GPLAN_VERSION = '1.8.0';

const POLYLINE_MODES = [
    'wall', 'cloison',
    'pipe-aep', 'pipe-eu', 'pipe-em', 'pipe-ev', 'pipe-vent',
    'pipe-ep', 'pipe-gaz', 'pipe-elec', 'pipe-fibre',
];
const AUTOSAVE_KEY = 'gplan-autosave';
const AUTOSAVE_INTERVAL_MS = 60_000;
class PlanEditorComponent {
    // ── INPUTS ──────────────────────────────────────────────
    initialWalls = input(null);
    project = input(null);
    showSidebar = input(true);
    showHeader = input(true);
    canvasHeight = input(1200);
    canvasWidth = input(1600);
    /** Charge automatiquement un fond de carte depuis project.geo au démarrage */
    autoGeoLayer = input(null);
    /** Coordonnées GPS fournies par l'app hôte (mobile / administration) pour
     *  charger automatiquement un fond de carte au démarrage, sans passer par la
     *  modale OSM. `zoom` absent → zoom max (19). `layer` absent → valeur de
     *  `autoGeoLayer` sinon 'satellite'. Prioritaire sur `project.geo`. */
    geoPoint = input(null);
    /** Force le mode compact (drawer mobile) même sur grand viewport — utile pour
     *  les conteneurs étroits comme une iframe ou une modal Gordon-PWA. */
    compactMode = input(false);
    /** Mode lecture seule : sélection/zoom/pan possibles, mais aucune création
     *  ni édition d'objet. Utile pour la consultation d'un CRI archivé. */
    readOnly = input(false);
    /** Liste des pièces du CRI à proposer dans l'inspecteur pour lier une pièce
     *  dessinée à une pièce CRI (« cette pièce = Chambre 1 »). */
    criRooms = input([]);
    /** Prélèvements amiante du CRI à positionner. Quand l'outil « Prélèvement » est
     *  actif, chaque clic pose le prochain de la file avec son id/label CRI.
     *  Passer une NOUVELLE référence de tableau pour réinitialiser la file. */
    pendingSamples = input([]);
    // ── OUTPUTS ─────────────────────────────────────────────
    projectSaved = output();
    projectChange = output();
    statsChanged = output();
    roomsChanged = output();
    jpgExported = output();
    pngExported = output();
    svgExported = output();
    /** Émis une fois le canvas Fabric initialisé — passe l'élément `<canvas>` natif
     *  pour que le parent puisse capturer une vignette à la demande. */
    canvasReady = output();
    /** Émis à chaque transition de l'état de chargement interne. */
    loadingState = output();
    /** Synthèse structurée du plan, émise (debounce ~500ms) à chaque modification.
     *  Voir aussi la méthode impérative `getPlanSummary()`. */
    summaryChange = output();
    /** Émis quand l'utilisateur lie une pièce dessinée à une pièce CRI. */
    roomLinked = output();
    /** Émis quand un prélèvement CRI de la file est posé sur le plan. */
    samplePlaced = output();
    // ── CANVAS REF ──────────────────────────────────────────
    canvasRef = viewChild.required('fabricCanvas');
    /** Conteneur scrollable du canvas — sert à recentrer la vue sur le fond de carte. */
    canvasAreaRef = viewChild('canvasArea');
    // ── ÉTAT ────────────────────────────────────────────────
    currentMode = signal('select');
    stats = signal({ roomCount: 0, totalArea: 0, wallCount: 0, wallLength: 0 });
    inspectorData = signal(null);
    showInspector = signal(false);
    isLoading = signal(false);
    pixelsPerMeter = signal(50);
    showMeasurements = signal(false);
    isOsmModalOpen = signal(false);
    isTemplateModalOpen = signal(false);
    calibrationLength = signal('');
    roomBoxWidthM = signal('');
    roomBoxHeightM = signal('');
    backgroundLocked = signal(false);
    bgRotation = signal(0);
    scaleLocked = signal(false);
    hasBackdrop = signal(false);
    /** Affiche la vue 3D par-dessus le canvas 2D (toggle non destructif). */
    show3D = signal(false);
    /** Projet sérialisé passé au viewer 3D — recalculé à chaque entrée en 3D. */
    project3D = signal(null);
    /** File des prélèvements CRI restant à poser (pose guidée). Initialisée depuis
     *  l'input `pendingSamples`, consommée tête en premier à chaque pose. */
    pendingQueue = signal([]);
    /** Libellés restant à placer — pour le bandeau d'aide. */
    remainingSampleLabels = computed(() => this.pendingQueue().map(s => s.label));
    // ── AUTOSAVE ─────────────────────────────────────────────
    hasAutosave = signal(false);
    autosaveTime = signal(null);
    autosaveInterval = null;
    projectChangeTimer = null;
    // ── MULTI-NIVEAUX ─────────────────────────────────────────
    floors = signal([
        { id: 'rdc', name: 'RDC', order: 0 }
    ]);
    currentFloorId = signal('rdc');
    floorObjects = new Map();
    /** ID du niveau source dont on propose de copier les murs extérieurs. */
    copyWallsSourceId = signal(null);
    showCopyWallsOffer = computed(() => this.copyWallsSourceId() !== null);
    /** Modal d'ajout d'un niveau */
    showAddFloorModal = signal(false);
    newFloorDirection = signal('above');
    newFloorName = signal('');
    /** Dropdown "copier depuis" (rétroactif) */
    showCopyFromMenu = signal(false);
    /** Dropdowns header */
    showFondMenu = signal(false);
    showFichierMenu = signal(false);
    /** Étages triés du plus bas (SS) au plus haut (Combles) */
    sortedFloors = computed(() => [...this.floors()].sort((a, b) => a.order - b.order));
    // ── LISTE DES PIÈCES ──────────────────────────────────────────────────────
    roomsByFloor = signal([]);
    showRoomList = signal(true);
    /** Surface totale cumulée sur tous les niveaux. */
    globalAreaM2 = computed(() => this.roomsByFloor().reduce((sum, f) => sum + f.totalArea, 0));
    /** Entrées de linéaire triées par type pour l'affichage. */
    pipeEntries = computed(() => {
        const pl = this.stats().pipeLengths;
        if (!pl || Object.keys(pl).length === 0)
            return [];
        return PIPE_ORDER
            .filter(k => pl[k] !== undefined)
            .map(k => ({ label: PIPE_LABELS[k] ?? k, lengthM: pl[k] }));
    });
    toggleRoomList() { this.showRoomList.update(v => !v); }
    /** Sélectionne une pièce depuis la liste (les DetectedRoom étant non-sélectionnables
     *  par clic canvas, on ouvre l'inspecteur directement sans passer par setActiveObject). */
    selectRoomFromList(floorId, label, areaM2) {
        if (floorId !== this.currentFloorId()) {
            this.switchFloor(floorId);
            return;
        }
        const obj = this.canvas?.getObjects().find((o) => o.myType === 'DetectedRoom' &&
            (o.data?.label || '') === label &&
            Math.abs((o.data?.areaM2 ?? 0) - areaM2) < 0.05);
        if (!obj)
            return;
        // Activer temporairement la sélectabilité pour que l'inspecteur se lie à cet objet
        obj.selectable = true;
        this.canvas.setActiveObject(obj);
        obj.selectable = false;
        this.canvas.renderAll();
        this.zone.run(() => {
            this.updateInspector(obj);
            this.showInspector.set(true);
        });
    }
    updateRoomList() {
        if (!this.canvas)
            return;
        const result = [...this.floors()].sort((a, b) => a.order - b.order).map(floor => {
            const objects = floor.id === this.currentFloorId()
                ? this.canvas.getObjects()
                : (this.floorObjects.get(floor.id) ?? []);
            const rooms = objects
                .filter((o) => o.myType === 'DetectedRoom')
                .map((o) => ({
                label: o.data?.label || '',
                areaM2: o.data?.areaM2 ?? 0,
                sol: o.data?.roomDescription?.sol,
                solEtat: o.data?.roomDescription?.solEtat,
                mur: o.data?.roomDescription?.mur,
                murEtat: o.data?.roomDescription?.murEtat,
                plafond: o.data?.roomDescription?.plafond,
                plafondEtat: o.data?.roomDescription?.plafondEtat,
                notes: o.data?.notes,
            }));
            return {
                floorId: floor.id,
                floorName: floor.name,
                order: floor.order,
                rooms,
                totalArea: rooms.reduce((s, r) => s + r.areaM2, 0),
            };
        });
        this.roomsByFloor.set(result);
        this.roomsChanged.emit(result);
    }
    currentFloorName = computed(() => this.floors().find(f => f.id === this.currentFloorId())?.name ?? 'RDC');
    /** Ordre calculé selon la direction choisie dans la modal */
    newFloorOrder = computed(() => {
        const dir = this.newFloorDirection();
        const orders = this.floors().map(f => f.order);
        return dir === 'above' ? Math.max(...orders) + 1 : Math.min(...orders) - 1;
    });
    toolGroups = TOOL_GROUPS;
    ROOM_NAMES = ROOM_NAMES;
    /** Version de la librairie (synchronisée depuis package.json au build). */
    version = GPLAN_VERSION;
    // ── DRAWER MOBILE ────────────────────────────────────────
    /** État du drawer latéral sur mobile (slide-in). Géré par les media queries CSS,
     *  ce signal pilote uniquement l'overlay/transform sous le breakpoint. */
    mobileSidebarOpen = signal(false);
    toggleMobileSidebar() { this.mobileSidebarOpen.update(v => !v); }
    closeMobileSidebar() { this.mobileSidebarOpen.set(false); }
    constructor() {
        // Relais du chargement interne vers l'output public
        effect(() => this.loadingState.emit(this.isLoading()));
        // Mode visualisation : force la sélection et verrouille tous les objets dès
        // que readOnly() bascule. Idempotent — peut être appelé plusieurs fois.
        effect(() => {
            const ro = this.readOnly();
            if (!this.canvas)
                return; // canvas pas encore initialisé — sera appliqué dans ngAfterViewInit
            if (ro) {
                this.currentMode.set('select');
                this.fabricSvc.setMode('select');
            }
            // Le service Fabric porte le flag pour que applyModeSelectability — qui
            // ré-active selectable=true à chaque entrée en mode select — n'écrase pas
            // notre verrouillage. Sans ce flag, le cadre de sélection avec poignées
            // s'affichait en cliquant sur un objet et laissait croire à une édition.
            this.fabricSvc.setReadOnly(ro);
            this.applyReadOnlyToObjects(ro);
        });
        // Chargement du fond de carte quand l'app hôte (re)fournit des coordonnées
        // après l'init du canvas. Le garde hasBackdrop évite tout double chargement.
        effect(() => {
            this.geoPoint(); // dépendance
            if (this.canvas)
                this.loadGeoBackdropIfNeeded();
        });
        // Pose guidée : (ré)initialise la file dès que l'app hôte fournit une nouvelle
        // liste de prélèvements (nouvelle référence de tableau requise).
        effect(() => this.pendingQueue.set([...this.pendingSamples()]));
        // Arme le prochain prélèvement côté service uniquement quand l'outil
        // « Prélèvement » est actif et hors lecture seule.
        effect(() => {
            const head = this.pendingQueue()[0] ?? null;
            const armed = this.currentMode() === 'prelevement' && !this.readOnly() ? head : null;
            this.fabricSvc.setNextSample(armed);
        });
    }
    // ── MODES MÉTIER (cumulables) ────────────────────────────────────────────
    workModeDefs = WORK_MODES;
    activeWorkModes = signal(this.loadInitialWorkModes());
    /** Filtre les groupes/outils selon les modes actifs (union d'outils, sans doublon). */
    visibleToolGroups = computed(() => {
        const active = this.activeWorkModes();
        if (active.size === 0)
            return [];
        const isToolVisible = (toolModes, groupModes) => {
            const modes = toolModes ?? groupModes;
            if (!modes || modes.length === 0)
                return true; // outil sans contrainte → toujours visible
            return modes.some(m => active.has(m));
        };
        return TOOL_GROUPS
            .map(g => ({
            ...g,
            tools: g.tools.filter(t => isToolVisible(t.modes, g.modes)),
        }))
            .filter(g => g.tools.length > 0);
    });
    isWorkModeActive(id) {
        return this.activeWorkModes().has(id);
    }
    toggleWorkMode(id) {
        this.activeWorkModes.update(set => {
            const next = new Set(set);
            if (next.has(id)) {
                // Empêche de tout désactiver — au moins un mode reste ON
                if (next.size > 1)
                    next.delete(id);
            }
            else {
                next.add(id);
            }
            return next;
        });
        this.persistWorkModes();
        this.resetToolIfHidden();
    }
    loadInitialWorkModes() {
        try {
            const raw = localStorage.getItem(WORK_MODES_STORAGE_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed) && parsed.length > 0)
                    return new Set(parsed);
            }
        }
        catch { /* ignore */ }
        return new Set(DEFAULT_WORK_MODES);
    }
    persistWorkModes() {
        try {
            localStorage.setItem(WORK_MODES_STORAGE_KEY, JSON.stringify([...this.activeWorkModes()]));
        }
        catch { /* ignore */ }
    }
    /** Si l'outil courant n'est plus dans les modes actifs, retombe en sélection. */
    resetToolIfHidden() {
        const visible = new Set(this.visibleToolGroups().flatMap(g => g.tools.map(t => t.mode)));
        if (!visible.has(this.currentMode()))
            this.setMode('select');
    }
    // ── SERVICES ────────────────────────────────────────────
    fabricSvc = inject(FabricCanvasService);
    historySvc = inject(HistoryService);
    exportSvc = inject(ExportService);
    osmSvc = inject(OsmService);
    geometrySvc = inject(GeometryService);
    analysisSvc = inject(PlanAnalysisService);
    config = inject(FLOORPLAN_CONFIG);
    destroyRef = inject(DestroyRef);
    zone = inject(NgZone);
    canvas;
    /** Mur actuellement mis en surbrillance (sélection) — pour restaurer sa couleur. */
    highlightedWall = null;
    /** Dernier mur/cloison sélectionné — conservé même après deselection (pour applyCalibration). */
    calibrationTarget = null;
    /** Dernier projet émis par CE composant — utilisé pour éviter les rechargements inutiles. */
    _lastEmittedProject = null;
    // ── COMPUTED ────────────────────────────────────────────
    /** Libellé lisible de l'outil actif (résolu depuis TOOL_GROUPS) — utilisé
     *  par le badge contextuel du header pour éviter l'affichage du mode brut
     *  type "ac-regard-eu". */
    currentToolLabel = computed(() => {
        const mode = this.currentMode();
        for (const g of TOOL_GROUPS) {
            const t = g.tools.find(t => t.mode === mode);
            if (t)
                return t.label;
        }
        return mode;
    });
    /** Vrai dès qu'un outil de tracé polyligne est actif (mur/cloison/pipe).
     *  Volontairement indépendant de l'état "tracé en cours" : ce dernier bascule
     *  dans un handler Fabric hors zone Angular et ne déclencherait pas de
     *  détection de changements fiable — le bouton "Terminer le tracé" ne
     *  s'afficherait jamais pour les pipes. `currentMode` est mis à jour par un
     *  clic in-zone, donc le binding réagit toujours. */
    isPolylineMode = computed(() => POLYLINE_MODES.includes(this.currentMode()));
    /** Vrai s'il y a des pièces détectées (≥ 1). Les compteurs pcs/m² et le badge
     *  de surface n'ont de sens que dans ce cas (un plan SPANC/AC à base de
     *  réseaux n'a aucune pièce → "0 pcs / 0,0 m²" est du bruit). */
    hasRooms = computed(() => this.stats().roomCount > 0);
    /** Vrai si le panneau latéral droit a quelque chose à afficher : au moins une
     *  pièce détectée OU au moins un linéaire de réseau. Sinon il ne montrerait
     *  que « Aucune pièce détectée » — inutile, on le masque (cf. plan en cours de
     *  tracé sans pièce). */
    hasRoomListContent = computed(() => this.roomsByFloor().some(f => f.rooms.length > 0) || this.pipeEntries().length > 0);
    /** Le badge de stats du header est masqué quand il n'y a ni pièce ni mur. */
    showStatsBadge = computed(() => this.stats().roomCount > 0 || this.stats().wallCount > 0);
    /** Le badge de niveau (RDC…) n'a de sens que s'il y a des pièces ou plusieurs
     *  niveaux à distinguer. Pour un plan réseau SPANC/AC (1 niveau, 0 pièce) il
     *  n'est que du bruit → masqué. (En 3D le badge est de toute façon recouvert
     *  par l'overlay ; c'est le watermark interne du viewer 3D qui prend le relais,
     *  gating identique côté viewer-3d.) */
    showFloorBadge = computed(() => this.stats().roomCount > 0 || this.floors().length > 1);
    // ── GETTERS pour template ────────────────────────────────
    get canUndo() { return this.historySvc.canUndo; }
    get canRedo() { return this.historySvc.canRedo; }
    ngAfterViewInit() {
        // Vérifier la présence d'un autosave avant d'initialiser le canvas
        this.zone.run(() => this.checkAutosave());
        this.zone.runOutsideAngular(() => {
            const fabric = window['fabric'];
            if (!fabric) {
                console.warn('Fabric.js non chargé. Assurez-vous que fabric est importé.');
                return;
            }
            this.canvas = new fabric.Canvas(this.canvasRef().nativeElement, {
                backgroundColor: '#ffffff',
                selection: true,
                preserveObjectStacking: true
            });
            this.fabricSvc.init(this.canvas);
            this.fabricSvc.onWallsChanged = () => this.zone.run(() => this.recalculateRooms());
            // Pose guidée : un prélèvement de la file vient d'être posé → remonter la
            // position à l'app et consommer la tête de file.
            this.fabricSvc.onSamplePlaced = (e) => this.zone.run(() => {
                this.samplePlaced.emit({ ...e, floorId: this.currentFloorId() });
                this.pendingQueue.update(q => q.slice(1));
            });
            this.historySvc.init(this.canvas);
            this.setupKeyboardShortcuts();
            // Si readOnly est déjà à true à l'init (cas SSR/hydration), appliquer
            // immédiatement les verrous — l'effect du constructor a pu rater le
            // moment où this.canvas n'existait pas encore.
            if (this.readOnly()) {
                this.zone.run(() => this.currentMode.set('select'));
                this.fabricSvc.setMode('select');
                this.fabricSvc.setReadOnly(true);
                this.applyReadOnlyToObjects(true);
            }
            // Notifier le parent que le canvas est prêt (pour vignette à la demande).
            this.zone.run(() => this.canvasReady.emit(this.canvasRef().nativeElement));
            const proj = this.project();
            if (proj) {
                this.zone.run(() => this.isLoading.set(true));
                this.fabricSvc.loadFromProject(proj).then(() => {
                    this.zone.run(() => {
                        this.pixelsPerMeter.set(proj.pixelsPerMeter);
                        if (proj.floors?.length) {
                            this.zone.run(() => this.floors.set(proj.floors.map(f => ({ id: f.id, name: f.name, order: f.order ?? 0 }))));
                            proj.floors.forEach(f => this.floorObjects.set(f.id, f.objects));
                        }
                        this.applyProjectWorkModes(proj);
                        this.recalculateRooms();
                        this.syncBackdropState();
                        // loadFromProject() ne ré-applique pas la sélectabilité — pousser
                        // explicitement le flag pour que les objets fraîchement chargés
                        // héritent immédiatement du verrouillage de sélection.
                        this.fabricSvc.setReadOnly(this.readOnly());
                        this.applyReadOnlyToObjects(this.readOnly());
                        this.isLoading.set(false);
                        this._lastEmittedProject = proj;
                        // Auto-chargement fond de carte. Priorité à l'input geoPoint
                        // (coordonnées fournies par l'app hôte) ; sinon fallback project.geo.
                        const loadedFromGeoPoint = this.loadGeoBackdropIfNeeded();
                        const layer = this.autoGeoLayer();
                        const geo = proj.geo;
                        const hasBackdrop = this.canvas.getObjects().some((o) => o.myType === 'Backdrop');
                        if (!loadedFromGeoPoint && layer && geo?.valid && !hasBackdrop) {
                            this.osmSvc.captureAt(geo, layer, this.config).then(({ dataUrl, scaleVal }) => {
                                this.zone.run(() => this.applyBackdrop(dataUrl, scaleVal));
                            });
                        }
                    });
                });
            }
            else {
                // Pas de projet à charger : charger tout de même le fond de carte si
                // l'app hôte a fourni des coordonnées via geoPoint.
                this.zone.run(() => this.loadGeoBackdropIfNeeded());
            }
            const walls = this.initialWalls();
            if (walls) {
                this.importWallsFromScanner(walls);
            }
            // Recalcul des pièces après déplacement d'un mur
            this.canvas.on('object:modified', (e) => {
                if (['Mur', 'Cloison', 'PipeAEP', 'PipeEU'].includes(e.target?.myType)) {
                    this.zone.run(() => this.recalculateRooms());
                }
                // Renumérotation si une porte ou fenêtre est déplacée
                if (e.target?.myType === 'Door' || e.target?.myType === 'Window') {
                    this.zone.run(() => this.refreshWallLetters());
                }
                // Repositionnement du label si une zone à risque est déplacée
                if (e.target?.myType === 'HazardZone') {
                    this.zone.run(() => this.refreshHazardLabels());
                }
                this.scheduleProjectChange();
            });
            this.canvas.on('object:added', (e) => {
                const t = e.target;
                if (t?.myType === 'Door' || t?.myType === 'Window') {
                    t.set({ lockScalingX: true, lockScalingY: true });
                    this.zone.run(() => this.refreshWallLetters());
                }
                this.scheduleProjectChange();
            });
            this.canvas.on('object:removed', (e) => {
                if (e.target?.myType === 'Door' || e.target?.myType === 'Window') {
                    this.zone.run(() => this.refreshWallLetters());
                }
                this.scheduleProjectChange();
            });
            // Sélections Fabric → inspecteur
            this.canvas.on('selection:created', (e) => {
                this.zone.run(() => {
                    this.highlightSelectedWall(e.selected?.[0]);
                    this.updateInspector(e.selected?.[0]);
                });
            });
            this.canvas.on('selection:updated', (e) => {
                this.zone.run(() => {
                    this.highlightSelectedWall(e.selected?.[0]);
                    this.updateInspector(e.selected?.[0]);
                });
            });
            this.canvas.on('selection:cleared', () => {
                this.zone.run(() => {
                    this.restoreHighlightedWall();
                    this.inspectorData.set(null);
                    this.showInspector.set(false);
                });
            });
            // Autosave toutes les 60 secondes (hors zone Angular pour éviter le CD)
            this.autosaveInterval = setInterval(() => this.performAutosave(), AUTOSAVE_INTERVAL_MS);
        });
        this.destroyRef.onDestroy(() => {
            if (this.projectChangeTimer)
                clearTimeout(this.projectChangeTimer);
            this.canvas?.dispose();
            this.fabricSvc.destroy();
            if (this.autosaveInterval)
                clearInterval(this.autosaveInterval);
        });
    }
    // ── AUTOSAVE ──────────────────────────────────────────────────────────────────
    checkAutosave() {
        try {
            const saved = localStorage.getItem(AUTOSAVE_KEY);
            if (!saved)
                return;
            const proj = JSON.parse(saved);
            if (proj?.meta?.updatedAt) {
                this.hasAutosave.set(true);
                this.autosaveTime.set(proj.meta.updatedAt);
            }
        }
        catch { /* ignore */ }
    }
    scheduleProjectChange(delay = 500) {
        if (this.projectChangeTimer)
            clearTimeout(this.projectChangeTimer);
        this.projectChangeTimer = setTimeout(() => {
            this.zone.run(() => {
                const proj = this.buildProjectWithFloors();
                this._lastEmittedProject = proj;
                this.projectChange.emit(proj);
                this.summaryChange.emit(this.analysisSvc.analyze(proj, { criRooms: this.criRooms() }));
            });
        }, delay);
    }
    /** Synthèse structurée du plan, à la demande (ex : au clic « Valider le plan »).
     *  Synchrone et à jour : `buildProjectWithFloors()` snapshote le niveau courant
     *  et renvoie tous les niveaux. */
    getPlanSummary() {
        return this.analysisSvc.analyze(this.buildProjectWithFloors(), { criRooms: this.criRooms() });
    }
    /** Recharge le canvas depuis un projet externe (autre onglet éditeur). */
    performAutosave() {
        if (!this.canvas)
            return;
        try {
            // Sauvegarde le niveau courant dans floorObjects avant de sérialiser
            const currentObjects = this.exportSvc.toProject(this.canvas, this.pixelsPerMeter()).objects;
            this.floorObjects.set(this.currentFloorId(), currentObjects);
            const project = this.buildProjectWithFloors();
            localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(project));
        }
        catch { /* quota exceeded ou contexte SSR */ }
    }
    restoreAutosave() {
        const saved = localStorage.getItem(AUTOSAVE_KEY);
        if (!saved)
            return;
        try {
            const project = JSON.parse(saved);
            this.isLoading.set(true);
            this.fabricSvc.loadFromProject(project).then(() => {
                this.pixelsPerMeter.set(project.pixelsPerMeter ?? 50);
                this.recalculateRooms();
                this.isLoading.set(false);
                this.hasAutosave.set(false);
            });
        }
        catch {
            this.hasAutosave.set(false);
        }
    }
    dismissAutosave() {
        this.hasAutosave.set(false);
        localStorage.removeItem(AUTOSAVE_KEY);
    }
    // ── MULTI-NIVEAUX ─────────────────────────────────────────────────────────────
    openAddFloorModal() {
        this.newFloorDirection.set('above');
        this.newFloorName.set(this.nameForOrder(this.newFloorOrder()));
        this.showAddFloorModal.set(true);
    }
    setAddFloorDirection(dir) {
        this.newFloorDirection.set(dir);
        this.newFloorName.set(this.nameForOrder(this.newFloorOrder()));
    }
    confirmAddFloor() {
        const order = this.newFloorOrder();
        const name = this.newFloorName().trim() || this.nameForOrder(order);
        const id = crypto.randomUUID();
        const sourceFloorId = this.currentFloorId();
        this.floors.update(f => [...f, { id, name, order }]);
        this.floorObjects.set(id, []);
        this.showAddFloorModal.set(false);
        this.switchFloor(id);
        this.copyWallsSourceId.set(sourceFloorId);
    }
    cancelAddFloor() {
        this.showAddFloorModal.set(false);
    }
    /** Nom par défaut selon l'ordre relatif du niveau */
    nameForOrder(order) {
        if (order === 0)
            return 'RDC';
        if (order > 0)
            return `Étage ${order}`;
        return `Sous-sol ${Math.abs(order)}`;
    }
    /** Nom d'un niveau par son id */
    getFloorName(id) {
        if (!id)
            return '';
        return this.floors().find(f => f.id === id)?.name ?? '';
    }
    /** Ouvre/ferme le menu rétroactif "copier depuis" */
    openCopyFromMenu() {
        this.showCopyFromMenu.update(v => !v);
    }
    toggleFondMenu() {
        this.showFondMenu.update(v => !v);
        this.showFichierMenu.set(false);
    }
    toggleFichierMenu() {
        this.showFichierMenu.update(v => !v);
        this.showFondMenu.set(false);
    }
    /** Déclenche la proposition de copie depuis un étage donné (rétroactif) */
    copyWallsFromFloor(sourceId) {
        this.showCopyFromMenu.set(false);
        this.copyWallsSourceId.set(sourceId);
    }
    switchFloor(floorId) {
        if (!this.canvas || floorId === this.currentFloorId())
            return;
        // Sauvegarde les objets du niveau courant
        const currentProject = this.exportSvc.toProject(this.canvas, this.pixelsPerMeter());
        const previousObjects = currentProject.objects;
        this.floorObjects.set(this.currentFloorId(), previousObjects);
        // Charge le nouveau niveau
        this.currentFloorId.set(floorId);
        const objects = this.floorObjects.get(floorId) ?? [];
        this.isLoading.set(true);
        this.fabricSvc.loadFromProject({ ...currentProject, objects }).then(() => {
            // Affiche l'étage précédent en très atténué comme référence visuelle
            this.fabricSvc.showGhostFloor(previousObjects);
            this.recalculateRooms();
            this.isLoading.set(false);
        });
    }
    copyExteriorWalls() {
        const sourceId = this.copyWallsSourceId();
        if (!sourceId)
            return;
        const sourceObjects = this.floorObjects.get(sourceId) ?? [];
        this.fabricSvc.copyObjectsFromFloor(sourceObjects);
        this.copyWallsSourceId.set(null);
    }
    dismissCopyWallsOffer() {
        this.copyWallsSourceId.set(null);
    }
    // ── INSPECTEUR ─────────────────────────────────────────────────────────────────
    updateInspector(obj) {
        if (!obj?.myType) {
            this.showInspector.set(false);
            return;
        }
        const data = {
            objectType: obj.myType,
            label: obj.data?.label || obj.text || '',
            material: obj.data?.material || 'Agglo',
            isPrimary: obj.data?.isPrimary ?? false,
            equipSubtype: obj.data?.subtype,
            hazardType: obj.data?.hazardType,
            hazardLabel: obj.data?.label,
            hazardSurface: obj.data?.hazardSurface ?? 'sol',
            amianteResult: obj.data?.amianteResult ?? 'unknown',
            ...(obj.myType === 'HazardSample' ? { label: obj.data?.sampleId ?? obj.data?.label } : {}),
            ...(obj.myType === 'HazardZone' ? {
                linkedSampleId: obj.data?.linkedSampleId ?? null,
                availableSamples: this.canvas.getObjects()
                    .filter(o => o.myType === 'HazardSample')
                    .map(o => ({ sampleId: o.data?.sampleId ?? o.data?.label })),
            } : {}),
            notes: obj.data?.notes,
            wallRef: obj.data?.wallRef ?? obj.data?.wallLabel,
            glazingType: obj.data?.glazingType ?? 'simple',
            doorType: obj.data?.doorType ?? 'simple',
        };
        if (obj.myType === 'Mur' || obj.myType === 'Cloison') {
            // Utilise calcLinePoints() pour la longueur réelle du segment (pas la bounding box)
            const pts = obj.calcLinePoints ? obj.calcLinePoints()
                : { x1: obj.x1, y1: obj.y1, x2: obj.x2, y2: obj.y2 };
            data.length = Math.hypot(pts.x2 - pts.x1, pts.y2 - pts.y1) / this.pixelsPerMeter();
        }
        if (obj.myType === 'DetectedRoom') {
            data.area = obj.data?.areaM2 || obj.area || 0;
            data.roomDescription = obj.data?.roomDescription ?? {};
            data.criRoomId = obj.data?.criRoomId ?? null;
            data.availableCriRooms = this.criRooms();
        }
        if (obj.myType === 'RoomBox') {
            const ppm = this.pixelsPerMeter();
            const pxW = (obj.width ?? 0) * (obj.scaleX ?? 1);
            const pxH = (obj.height ?? 0) * (obj.scaleY ?? 1);
            this.roomBoxWidthM.set(obj.data?.realWidthM != null
                ? String(obj.data.realWidthM)
                : String(Math.round(pxW / ppm * 100) / 100));
            this.roomBoxHeightM.set(obj.data?.realHeightM != null
                ? String(obj.data.realHeightM)
                : String(Math.round(pxH / ppm * 100) / 100));
        }
        this.inspectorData.set(data);
        this.showInspector.set(true);
    }
    // ── CLAVIER ────────────────────────────────────────────────────────────────────
    setupKeyboardShortcuts() {
        const handler = (e) => {
            const tag = e.target.tagName;
            if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT')
                return;
            const key = e.key.toLowerCase();
            this.zone.run(() => {
                const ro = this.readOnly();
                // Mode visualisation : seuls Escape / v (select) / h (pan) sont actifs.
                if (ro) {
                    if (key === 'escape') {
                        this.setMode('select');
                        return;
                    }
                    if (!e.ctrlKey && (key === 'v' || key === 'h')) {
                        this.setMode(key === 'v' ? 'select' : 'pan');
                    }
                    return;
                }
                if (e.ctrlKey && key === 'z') {
                    e.preventDefault();
                    this.undo();
                    return;
                }
                if (e.ctrlKey && key === 'y') {
                    e.preventDefault();
                    this.redo();
                    return;
                }
                if (key === 'delete' || key === 'backspace') {
                    this.deleteActive();
                    return;
                }
                if (key === 'escape') {
                    this.setMode('select');
                    return;
                }
                const shortcuts = {
                    v: 'select', h: 'pan', n: 'node-edit', w: 'wall', c: 'cloison',
                    r: 'room', k: 'room-sketch', d: 'door', f: 'window'
                };
                if (!e.ctrlKey && shortcuts[key])
                    this.setMode(shortcuts[key]);
            });
        };
        document.addEventListener('keydown', handler);
        this.destroyRef.onDestroy(() => document.removeEventListener('keydown', handler));
    }
    // ── MODES ──────────────────────────────────────────────────────────────────────
    setMode(mode) {
        // Mode visualisation : seuls 'select' et 'pan' (navigation) sont autorisés.
        // node-edit modifie la géométrie des murs → bloqué.
        if (this.readOnly() && mode !== 'select' && mode !== 'pan') {
            mode = 'select';
        }
        this.currentMode.set(mode);
        if (!POLYLINE_MODES.includes(mode)) {
            this.fabricSvc.finishPolyline();
        }
        this.fabricSvc.setMode(mode);
        // Sur mobile, refermer le drawer après sélection d'un outil
        if (this.mobileSidebarOpen())
            this.mobileSidebarOpen.set(false);
    }
    /** Bascule entre la vue 2D (canvas Fabric) et la vue 3D (Three.js). À chaque
     *  entrée en 3D, on resérialise le projet courant pour refléter les dernières
     *  modifications. Non destructif : le canvas 2D est simplement masqué. */
    toggle3D() {
        const next = !this.show3D();
        if (next) {
            this.project3D.set(this.buildProjectWithFloors());
        }
        this.show3D.set(next);
    }
    undo() {
        this.historySvc.pauseSaving();
        this.historySvc.undo().then(() => {
            this.recalculateRooms();
            this.fabricSvc.refreshNodeHandles();
            this.historySvc.resumeSaving();
        });
    }
    redo() {
        this.historySvc.pauseSaving();
        this.historySvc.redo().then(() => {
            this.recalculateRooms();
            this.fabricSvc.refreshNodeHandles();
            this.historySvc.resumeSaving();
        });
    }
    /** Termine le tracé en cours et repasse en mode Sélection (l'outil de
     *  dessin est désélectionné — pratique sur tactile pour clôturer nettement). */
    finishPolyline() {
        this.fabricSvc.finishPolyline();
        this.setMode('select');
    }
    /** Convertit les RoomBox du croquis en murs porteurs et cloisons. */
    generateEnvelope() {
        // Suspend onWallsChanged pour éviter un double recalcul pendant la génération
        const saved = this.fabricSvc.onWallsChanged;
        this.fabricSvc.onWallsChanged = undefined;
        this.historySvc.pauseSaving();
        this.fabricSvc.generateEnvelope();
        this.historySvc.resumeSaving();
        this.fabricSvc.onWallsChanged = saved;
        // Normalise les coordonnées Fabric.js de tous les murs générés :
        // garantit que left=min(x1,x2), top=min(y1,y2), width/height corrects,
        // condition nécessaire pour que getAbsoluteLineEnds() fonctionne.
        this.normalizeWallCoordinates();
        this.historySvc.save();
        this.recalculateRooms();
        this.setMode('select');
    }
    /**
     * Snape les extrémités de tous les murs sur une grille dédupliquée à ±SNAP px.
     * Garantit que deux coordonnées quasi-identiques (ex: 199.7 et 200.0) convergent
     * vers la même valeur — condition nécessaire pour la détection des T-jonctions.
     */
    normalizeWallCoordinates() {
        if (!this.canvas)
            return;
        const SNAP = 8;
        const walls = this.canvas.getObjects()
            .filter((o) => ['Mur', 'Cloison'].includes(o.myType));
        if (walls.length === 0)
            return;
        // Construire les grilles X et Y en dédupliquant à ±SNAP px
        const rawCols = [];
        const rawRows = [];
        for (const wall of walls) {
            const { ax1, ay1, ax2, ay2 } = this.getAbsWallEndpoints(wall);
            for (const x of [ax1, ax2]) {
                if (!rawCols.some(c => Math.abs(c - x) <= SNAP))
                    rawCols.push(x);
            }
            for (const y of [ay1, ay2]) {
                if (!rawRows.some(r => Math.abs(r - y) <= SNAP))
                    rawRows.push(y);
            }
        }
        rawCols.sort((a, b) => a - b);
        rawRows.sort((a, b) => a - b);
        // Repositionner chaque mur avec des coordonnées snappées sur la grille
        for (const wall of walls) {
            const { ax1, ay1, ax2, ay2 } = this.getAbsWallEndpoints(wall);
            const nx1 = this.snapRemap(ax1, rawCols, rawCols, SNAP);
            const ny1 = this.snapRemap(ay1, rawRows, rawRows, SNAP);
            const nx2 = this.snapRemap(ax2, rawCols, rawCols, SNAP);
            const ny2 = this.snapRemap(ay2, rawRows, rawRows, SNAP);
            wall.set({
                x1: nx1, y1: ny1, x2: nx2, y2: ny2,
                left: Math.min(nx1, nx2), top: Math.min(ny1, ny2),
                width: Math.abs(nx2 - nx1), height: Math.abs(ny2 - ny1),
            });
            wall.ownMatrixCache = null;
            wall.dirty = true;
            wall.setCoords?.();
        }
    }
    /** Bascule le mur/cloison sélectionné entre porteur et cloison. */
    toggleSelectedWallType() {
        const active = this.canvas?.getActiveObject() ?? this.calibrationTarget;
        if (!active)
            return;
        this.fabricSvc.toggleWallType(active);
        this.updateInspector(active);
        this.recalculateRooms();
    }
    /**
     * 1ère calibration → ajuste le PPM pour que ce mur = realLengthM.
     * Calibrations suivantes → redimensionne CE mur en pixels (PPM inchangé).
     * Dans les deux cas, verrouille la longueur et affiche un indicateur visuel.
     */
    applyCalibration() {
        // getActiveObject() peut être null si cliquer le bouton a déclenché selection:cleared
        const active = this.canvas?.getActiveObject() ?? this.calibrationTarget;
        if (!active || !['Mur', 'Cloison'].includes(active.myType))
            return;
        const realLengthM = parseFloat(this.calibrationLength());
        if (isNaN(realLengthM) || realLengthM <= 0)
            return;
        const { ax1, ay1, ax2, ay2 } = this.getAbsWallEndpoints(active);
        const pixelLen = Math.hypot(ax2 - ax1, ay2 - ay1);
        if (pixelLen <= 0)
            return;
        // Première calibration : définit l'échelle globale (PPM)
        const hasOtherLocked = this.canvas.getObjects()
            .some((o) => ['Mur', 'Cloison'].includes(o.myType) && o.data?.lockedLengthM != null && o !== active);
        if (!hasOtherLocked) {
            const newPpm = Math.round((pixelLen / realLengthM) * 10) / 10;
            this.pixelsPerMeter.set(Math.max(1, Math.min(500, newPpm)));
        }
        // Verrouille la longueur de ce mur
        active.data = { ...(active.data || {}), lockedLengthM: realLengthM };
        this.calibrationLength.set('');
        this.restoreHighlightedWall(); // retire l'orange avant le recalcul visuel
        // Solveur de contraintes global : repositionne tous les murs
        this.applyLayoutConstraints();
        this.fabricSvc.refreshNodeHandles();
        this.refreshLockedLabels();
        this.recalculateRooms();
    }
    /** Définit les dimensions réelles (m) d'une pièce RoomBox et redimensionne en pixels. */
    applyRoomBoxDimensions() {
        const active = this.canvas?.getActiveObject();
        if (!active || active.myType !== 'RoomBox')
            return;
        const wM = parseFloat(this.roomBoxWidthM());
        const hM = parseFloat(this.roomBoxHeightM());
        const ppm = this.pixelsPerMeter();
        let changed = false;
        if (!isNaN(wM) && wM > 0) {
            active.set({ width: Math.round(wM * ppm), scaleX: 1 });
            active.data = { ...(active.data || {}), realWidthM: wM };
            changed = true;
        }
        if (!isNaN(hM) && hM > 0) {
            active.set({ height: Math.round(hM * ppm), scaleY: 1 });
            active.data = { ...(active.data || {}), realHeightM: hM };
            changed = true;
        }
        if (changed) {
            active.setCoords?.();
            this.canvas.renderAll();
            this.historySvc.save();
        }
    }
    /** Retourne les coordonnées absolues canvas des deux extrémités d'un mur (fabric.Line). */
    getAbsWallEndpoints(wall) {
        const dxOff = (wall.left ?? 0) - Math.min(wall.x1 ?? 0, wall.x2 ?? 0);
        const dyOff = (wall.top ?? 0) - Math.min(wall.y1 ?? 0, wall.y2 ?? 0);
        return {
            ax1: (wall.x1 ?? 0) + dxOff, ay1: (wall.y1 ?? 0) + dyOff,
            ax2: (wall.x2 ?? 0) + dxOff, ay2: (wall.y2 ?? 0) + dyOff,
        };
    }
    /**
     * Solveur de contraintes de layout orthogonal global.
     *
     * Principe :
     *  1. Construire un modèle colonnes (X uniques) / lignes (Y uniques) depuis tous les murs.
     *  2. Chaque mur verrouillé impose une distance fixe entre deux colonnes ou deux lignes.
     *  3. Résoudre les positions 1D en respectant ces contraintes, les spans libres
     *     se compressant/dilatant proportionnellement.
     *  4. Repositionner tous les murs selon les nouvelles positions colonnes/lignes.
     *
     * Avantage vs BFS impératif : toutes les contraintes sont résolues simultanément,
     * sans accumulation d'erreurs entre calibrations successives.
     */
    applyLayoutConstraints() {
        if (!this.canvas)
            return;
        const ppm = this.pixelsPerMeter();
        const SNAP = 8; // px — coordonnées à moins de 8px = même ligne de grille
        const walls = this.canvas.getObjects()
            .filter((o) => ['Mur', 'Cloison'].includes(o.myType));
        if (walls.length === 0)
            return;
        // ── 1. Construire les colonnes (X) et lignes (Y) ──────────────────────────
        const rawCols = [];
        const rawRows = [];
        for (const wall of walls) {
            const { ax1, ay1, ax2, ay2 } = this.getAbsWallEndpoints(wall);
            for (const x of [ax1, ax2]) {
                if (!rawCols.some(c => Math.abs(c - x) <= SNAP))
                    rawCols.push(x);
            }
            for (const y of [ay1, ay2]) {
                if (!rawRows.some(r => Math.abs(r - y) <= SNAP))
                    rawRows.push(y);
            }
        }
        rawCols.sort((a, b) => a - b);
        rawRows.sort((a, b) => a - b);
        if (rawCols.length === 0 || rawRows.length === 0)
            return;
        // ── 2. Collecter les contraintes depuis les murs verrouillés ─────────────
        const hConstraints = [];
        const vConstraints = [];
        for (const wall of walls) {
            if (!wall.data?.lockedLengthM)
                continue;
            const { ax1, ay1, ax2, ay2 } = this.getAbsWallEndpoints(wall);
            const d = wall.data.lockedLengthM * ppm;
            if (Math.abs(ay1 - ay2) <= SNAP) {
                // Mur horizontal → contrainte sur colonnes
                const lx = Math.min(ax1, ax2), rx = Math.max(ax1, ax2);
                const ci = rawCols.findIndex(c => Math.abs(c - lx) <= SNAP);
                const cj = rawCols.findIndex(c => Math.abs(c - rx) <= SNAP);
                if (ci >= 0 && cj > ci)
                    hConstraints.push({ ci, cj, d });
            }
            else {
                // Mur vertical → contrainte sur lignes
                const ty = Math.min(ay1, ay2), by = Math.max(ay1, ay2);
                const ri = rawRows.findIndex(r => Math.abs(r - ty) <= SNAP);
                const rj = rawRows.findIndex(r => Math.abs(r - by) <= SNAP);
                if (ri >= 0 && rj > ri)
                    vConstraints.push({ ci: ri, cj: rj, d });
            }
        }
        if (hConstraints.length === 0 && vConstraints.length === 0)
            return;
        // ── 3. Résoudre les positions 1D ─────────────────────────────────────────
        const newCols = this.solve1D(rawCols, hConstraints);
        const newRows = this.solve1D(rawRows, vConstraints);
        // ── 4. Repositionner tous les murs ───────────────────────────────────────
        for (const wall of walls) {
            const { ax1, ay1, ax2, ay2 } = this.getAbsWallEndpoints(wall);
            const nx1 = this.snapRemap(ax1, rawCols, newCols, SNAP);
            const ny1 = this.snapRemap(ay1, rawRows, newRows, SNAP);
            const nx2 = this.snapRemap(ax2, rawCols, newCols, SNAP);
            const ny2 = this.snapRemap(ay2, rawRows, newRows, SNAP);
            if (Math.abs(nx1 - ax1) < 0.5 && Math.abs(ny1 - ay1) < 0.5 &&
                Math.abs(nx2 - ax2) < 0.5 && Math.abs(ny2 - ay2) < 0.5)
                continue;
            wall.set({
                x1: nx1, y1: ny1, x2: nx2, y2: ny2,
                left: Math.min(nx1, nx2), top: Math.min(ny1, ny2),
                width: Math.abs(nx2 - nx1), height: Math.abs(ny2 - ny1),
            });
            wall.ownMatrixCache = null;
            wall.dirty = true;
            wall.setCoords?.();
        }
        this.canvas.renderAll();
    }
    /**
     * Solveur 1D : repositionne N positions ordonnées selon des contraintes de distance.
     *
     * L'ancre est la première position (index 0), fixe.
     * Les contraintes (ci, cj, d) imposent : positions[cj] - positions[ci] = d px.
     * Traitées de gauche à droite : chaque contrainte décale les positions ≥ cj,
     * puis redistribue les positions intermédiaires proportionnellement.
     * Les spans libres s'ajustent naturellement.
     */
    solve1D(positions, constraints) {
        const n = positions.length;
        const result = [...positions];
        if (n === 0 || constraints.length === 0)
            return result;
        // Aucune position n'est pré-ancrée : le solveur peut étendre dans les deux
        // directions (vers le bas/droite OU vers le haut/gauche).
        const pinned = new Set();
        // Trier par span croissant : les contraintes locales (petits spans) d'abord
        const sorted = [...constraints].sort((a, b) => (a.cj - a.ci) - (b.cj - b.ci) || a.ci - b.ci);
        for (const { ci, cj, d } of sorted) {
            const currentDist = result[cj] - result[ci];
            if (Math.abs(currentDist - d) < 0.5) {
                pinned.add(ci);
                pinned.add(cj);
                continue;
            }
            const delta = d - currentDist;
            const cjFree = !pinned.has(cj);
            const ciFree = !pinned.has(ci);
            if (cjFree) {
                // Cas standard : étendre vers le bas/droite (shift le bloc cj..n-1)
                for (let k = cj; k < n; k++)
                    result[k] += delta;
            }
            else if (ciFree && ci > 0) {
                // cj est bloqué, ci est libre ET n'est pas l'ancre absolue (ci > 0) :
                // on tire vers le haut/gauche sans déplacer tout le plan.
                for (let k = 0; k <= ci; k++)
                    result[k] -= delta;
            }
            // else : conflit réel (même span, cibles incompatibles ou ci=0 bloqué) → violet
            // Redistribuer UNIQUEMENT les positions libres (non pinnées) entre ci et cj
            if (cj - ci > 1) {
                const oldSpan = positions[cj] - positions[ci];
                const newSpan = result[cj] - result[ci];
                if (Math.abs(newSpan) > 0.5) {
                    for (let k = ci + 1; k < cj; k++) {
                        if (pinned.has(k))
                            continue;
                        const ratio = oldSpan > 0
                            ? (positions[k] - positions[ci]) / oldSpan
                            : (k - ci) / (cj - ci);
                        result[k] = result[ci] + ratio * newSpan;
                    }
                }
            }
            pinned.add(ci);
            pinned.add(cj);
        }
        return result;
    }
    /**
     * Mappe une coordonnée de l'ancien espace grille vers le nouveau.
     * Snap exact sur les lignes de grille, interpolation linéaire entre.
     */
    snapRemap(coord, oldPos, newPos, snap = 8) {
        const n = oldPos.length;
        for (let i = 0; i < n; i++) {
            if (Math.abs(coord - oldPos[i]) <= snap)
                return newPos[i];
        }
        for (let i = 0; i < n - 1; i++) {
            if (coord >= oldPos[i] - snap && coord <= oldPos[i + 1] + snap) {
                const t = (coord - oldPos[i]) / (oldPos[i + 1] - oldPos[i]);
                return newPos[i] + t * (newPos[i + 1] - newPos[i]);
            }
        }
        if (coord < oldPos[0])
            return newPos[0] + (coord - oldPos[0]);
        return newPos[n - 1] + (coord - oldPos[n - 1]);
    }
    /**
     * Redimensionne les RoomBoxes avec cotes réelles verrouillées selon le PPM courant.
     * Les murs verrouillés sont gérés par applyLayoutConstraints().
     */
    updateLockedObjects() {
        if (!this.canvas)
            return;
        const ppm = this.pixelsPerMeter();
        let changed = false;
        this.canvas.getObjects()
            .filter((o) => o.myType === 'RoomBox')
            .forEach((box) => {
            const rW = box.data?.realWidthM;
            const rH = box.data?.realHeightM;
            if (rW != null && rW > 0) {
                box.set({ width: Math.round(rW * ppm), scaleX: 1 });
                changed = true;
            }
            if (rH != null && rH > 0) {
                box.set({ height: Math.round(rH * ppm), scaleY: 1 });
                changed = true;
            }
            if (rW != null || rH != null)
                box.setCoords?.();
        });
        if (changed)
            this.canvas.renderAll();
    }
    /**
     * Crée les labels visuels "⊛ X.XX m" sur les murs avec longueur verrouillée.
     * Non persistés (recréés à chaque recalculateRooms).
     */
    refreshLockedLabels() {
        if (!this.canvas)
            return;
        const fabric = window['fabric'];
        if (!fabric)
            return;
        this.canvas.getObjects()
            .filter((o) => o.myType === 'LockedLabel')
            .forEach((o) => this.canvas.remove(o));
        const ppm = this.pixelsPerMeter();
        this.canvas.getObjects()
            .filter((o) => ['Mur', 'Cloison'].includes(o.myType) && o.data?.lockedLengthM != null)
            .forEach((wall) => {
            const dxOff = (wall.left ?? 0) - Math.min(wall.x1 ?? 0, wall.x2 ?? 0);
            const dyOff = (wall.top ?? 0) - Math.min(wall.y1 ?? 0, wall.y2 ?? 0);
            const ax1 = (wall.x1 ?? 0) + dxOff, ay1 = (wall.y1 ?? 0) + dyOff;
            const ax2 = (wall.x2 ?? 0) + dxOff, ay2 = (wall.y2 ?? 0) + dyOff;
            const mx = (ax1 + ax2) / 2, my = (ay1 + ay2) / 2;
            // Décalage perpendiculaire (14px) pour placer le label à côté du mur
            const wLen = Math.hypot(ax2 - ax1, ay2 - ay1);
            const normX = wLen > 0 ? -(ay2 - ay1) / wLen * 14 : 0;
            const normY = wLen > 0 ? (ax2 - ax1) / wLen * 14 : -14;
            // Contrainte impossible si la longueur réelle ≠ cible (angle non-droit ou conflit)
            const targetPx = wall.data.lockedLengthM * ppm;
            const isImpossible = Math.abs(wLen - targetPx) > 2;
            const fill = isImpossible ? '#7c3aed' : '#f97316';
            const backgroundColor = isImpossible ? 'rgba(245,243,255,0.9)' : 'rgba(255,247,237,0.9)';
            const label = new fabric.Text(`⊛ ${wall.data.lockedLengthM.toFixed(2)} m`, {
                left: mx + normX, top: my + normY,
                originX: 'center', originY: 'center',
                fontSize: 10, fontFamily: 'Arial', fontWeight: 'bold',
                fill, backgroundColor,
                padding: 2,
                selectable: false, evented: false,
                myType: 'LockedLabel',
            });
            this.canvas.add(label);
        });
    }
    /** Met le mur sélectionné en orange vif et sauvegarde sa couleur d'origine. */
    highlightSelectedWall(obj) {
        this.restoreHighlightedWall();
        if (!obj || !['Mur', 'Cloison'].includes(obj.myType))
            return;
        this.calibrationTarget = obj; // mémorisé même après déselection
        this.highlightedWall = { obj, stroke: obj.stroke, strokeWidth: obj.strokeWidth };
        obj.set({ stroke: '#f97316', strokeWidth: Math.max(obj.strokeWidth, 4) });
        this.canvas?.renderAll();
    }
    /** Restaure la couleur d'origine du mur précédemment mis en surbrillance. */
    restoreHighlightedWall() {
        if (!this.highlightedWall)
            return;
        const { obj, stroke, strokeWidth } = this.highlightedWall;
        obj.set({ stroke, strokeWidth });
        this.highlightedWall = null;
        this.canvas?.renderAll();
    }
    deleteActive() {
        const active = this.canvas?.getActiveObjects() ?? [];
        const deletedWallIds = active
            .filter((o) => ['Mur', 'Cloison'].includes(o.myType) && o.data?.wallId)
            .map((o) => o.data.wallId);
        active.forEach((obj) => this.canvas.remove(obj));
        this.fabricSvc.cascadeDeleteOpenings(deletedWallIds);
        this.canvas?.discardActiveObject();
        // Reconstruire les nœuds pour supprimer les cercles orphelins
        this.fabricSvc.refreshNodeHandles();
        this.canvas?.renderAll();
        this.recalculateRooms();
        // Plus rien de sélectionné : refermer le panneau inspecteur.
        this.inspectorData.set(null);
        this.showInspector.set(false);
    }
    // ── IMPORT SCANNER ─────────────────────────────────────────────────────────────
    importWallsFromScanner(payload) {
        if (!this.canvas)
            return;
        const fabric = window['fabric'];
        if (!fabric)
            return;
        this.canvas.clear();
        this.canvas.setBackgroundColor('#ffffff', () => { });
        if (payload.backgroundImageDataUrl) {
            fabric.Image.fromURL(payload.backgroundImageDataUrl, (img) => {
                img.set({
                    left: this.canvasWidth() / 2, top: this.canvasHeight() / 2,
                    originX: 'center', originY: 'center',
                    opacity: 0.5, myType: 'Backdrop',
                    selectable: false, evented: false,
                    lockMovementX: true, lockMovementY: true,
                    lockRotation: true,
                    lockScalingX: true, lockScalingY: true,
                });
                img.data = { ...(img.data || {}), locked: true };
                this.canvas.insertAt(img, 0, false);
                this.backgroundLocked.set(true);
                this.hasBackdrop.set(true);
            });
        }
        payload.walls.forEach(l => {
            const dx = l.x2 - l.x1, dy = l.y2 - l.y1;
            const cx = (l.x1 + l.x2) / 2, cy = (l.y1 + l.y2) / 2;
            const centerX = this.canvasWidth() / 2 + (cx - (payload.bounds.x + payload.bounds.w / 2));
            const centerY = this.canvasHeight() / 2 + (cy - (payload.bounds.y + payload.bounds.h / 2));
            const line = new fabric.Line([-dx / 2, -dy / 2, dx / 2, dy / 2], {
                left: centerX, top: centerY,
                stroke: 'black', strokeWidth: 5,
                originX: 'center', originY: 'center',
                selectable: true, myType: 'Mur', data: { material: 'Agglo' }
            });
            this.canvas.add(line);
        });
        this.canvas.renderAll();
        this.historySvc.save();
        this.recalculateRooms();
    }
    /** Identifiant unique (UUID si dispo, sinon fallback). Utilisé pour les ids
     *  stables de pièces (data.roomId). */
    genId() {
        const c = globalThis.crypto;
        if (c?.randomUUID)
            return c.randomUUID();
        return 'r-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    }
    // ── RECALCUL SURFACES ──────────────────────────────────────────────────────────
    recalculateRooms() {
        if (!this.canvas)
            return;
        // Snapshot des métadonnées utilisateur sur les pièces existantes (label, description, notes)
        // indexées par centroïde (_cx/_cy stocké dans data par le GeometryService).
        const snapshot = new Map();
        this.canvas.getObjects()
            .filter((o) => o.myType === 'DetectedRoom' && o.data)
            .forEach((o) => {
            const { _cx, _cy, roomId, label, roomDescription, notes, criRoomId } = o.data;
            if (_cx != null && _cy != null && (roomId || label || roomDescription || notes || criRoomId)) {
                snapshot.set(`${_cx}_${_cy}`, { roomId, label, roomDescription, notes, criRoomId });
            }
        });
        const result = this.geometrySvc.recalculateRooms(this.canvas, this.pixelsPerMeter(), this.showMeasurements());
        this.stats.set(result.stats);
        this.statsChanged.emit(result.stats);
        // Restaure les métadonnées sur les nouvelles pièces par proximité de centroïde (tolérance 25px)
        if (snapshot.size > 0) {
            this.canvas.getObjects()
                .filter((o) => o.myType === 'DetectedRoom' && o.data?._cx != null)
                .forEach((o) => {
                const cx = o.data._cx;
                const cy = o.data._cy;
                for (const [key, meta] of snapshot) {
                    const [kx, ky] = key.split('_').map(Number);
                    if (Math.abs(cx - kx) <= 25 && Math.abs(cy - ky) <= 25) {
                        o.data = { ...o.data, ...meta };
                        break;
                    }
                }
            });
        }
        // Affecte un id stable aux pièces qui n'en ont pas (1re détection). Préservé
        // ensuite via le snapshot/restore par centroïde ci-dessus. Sert de handle
        // fiable pour la liaison pièce↔CRI et le résumé (RoomSummary.id).
        this.canvas.getObjects()
            .filter((o) => o.myType === 'DetectedRoom' && o.data && !o.data.roomId)
            .forEach((o) => { o.data.roomId = this.genId(); });
        this.refreshRoomLabels();
        this.refreshLockedLabels();
        this.refreshWallLetters();
        this.refreshHazardLabels();
        this.hasBackdrop.set(this.canvas.getObjects().some((o) => o.myType === 'Backdrop'));
        this.updateRoomList();
        this.canvas.renderAll();
    }
    /** Affiche les identifiants (P1, P2…) des zones à risque sur le plan 2D. */
    refreshHazardLabels() {
        if (!this.canvas)
            return;
        const fabric = window['fabric'];
        if (!fabric)
            return;
        // Supprimer les anciens labels
        this.canvas.getObjects()
            .filter((o) => o.myType === 'HazardLabel')
            .forEach((o) => this.canvas.remove(o));
        const COLORS = { amiante: '#b45309', plomb: '#b91c1c', humidite: '#1d4ed8' };
        this.canvas.getObjects()
            .filter(o => o.myType === 'HazardZone' && o.data?.linkedSampleId)
            .forEach(zone => {
            const cx = zone.left + (zone.width * (zone.scaleX ?? 1)) / 2;
            const cy = zone.top + (zone.height * (zone.scaleY ?? 1)) / 2;
            const color = COLORS[zone.data.hazardType] ?? '#78350f';
            const label = new fabric.Text(zone.data.linkedSampleId, {
                left: cx, top: cy,
                originX: 'center', originY: 'center',
                fontSize: 13, fontFamily: 'Arial', fontWeight: 'bold',
                fill: color,
                selectable: false, evented: false,
                myType: 'HazardLabel',
            });
            this.canvas.add(label);
        });
    }
    /** Supprime et recrée les labels de pièces nommées sur le canvas (non sélectionnables). */
    refreshRoomLabels() {
        if (!this.canvas)
            return;
        const fabric = window['fabric'];
        if (!fabric)
            return;
        this.canvas.getObjects()
            .filter((o) => o.myType === 'RoomLabel')
            .forEach((o) => this.canvas.remove(o));
        this.canvas.getObjects()
            .filter((o) => o.myType === 'DetectedRoom' && o.data?.label && o.data?._cx != null)
            .forEach((o) => {
            const areaLine = `${o.data.areaM2.toFixed(1)} m²`;
            const text = new fabric.Text(`${o.data.label}\n${areaLine}`, {
                left: o.data._cx, top: o.data._cy,
                originX: 'center', originY: 'center',
                fontSize: 13, fontFamily: 'Arial', fill: '#1e293b',
                fontWeight: 'bold', lineHeight: 1.3, textAlign: 'center',
                backgroundColor: 'rgba(255,255,255,0.72)',
                selectable: false, evented: false,
                myType: 'RoomLabel',
            });
            this.canvas.add(text);
        });
    }
    // ── SAVE / LOAD ────────────────────────────────────────────────────────────────
    saveProject() {
        if (!this.canvas)
            return;
        const project = this.buildProjectWithFloors();
        this.projectSaved.emit(project);
        this.exportSvc.downloadJson(project);
    }
    buildProjectWithFloors() {
        const currentObjects = this.exportSvc.toProject(this.canvas, this.pixelsPerMeter()).objects;
        this.floorObjects.set(this.currentFloorId(), currentObjects);
        const floorsArr = this.floors().map(f => ({
            id: f.id,
            name: f.name,
            order: f.order,
            objects: this.floorObjects.get(f.id) ?? [],
        }));
        return {
            version: '5.3.0',
            pixelsPerMeter: this.pixelsPerMeter(),
            objects: currentObjects,
            floors: floorsArr,
            meta: {
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                workModes: [...this.activeWorkModes()],
            }
        };
    }
    loadProject(event) {
        const file = event.target.files?.[0];
        if (!file)
            return;
        this.isLoading.set(true);
        this.exportSvc.fromFile(file).then(project => {
            this.fabricSvc.loadFromProject(project).then(() => {
                this.pixelsPerMeter.set(project.pixelsPerMeter);
                if (project.floors?.length) {
                    this.floors.set(project.floors.map(f => ({ id: f.id, name: f.name, order: f.order ?? 0 })));
                    project.floors.forEach(f => this.floorObjects.set(f.id, f.objects));
                    this.currentFloorId.set(project.floors[0].id);
                }
                this.applyProjectWorkModes(project);
                this.recalculateRooms();
                this.syncBackdropState();
                this.isLoading.set(false);
                const built = this.buildProjectWithFloors();
                this.projectChange.emit(built);
            });
        });
    }
    /** Applique les modes métier portés par un projet chargé (override localStorage si présents). */
    applyProjectWorkModes(project) {
        const modes = project.meta?.workModes;
        if (modes && modes.length > 0) {
            this.activeWorkModes.set(new Set(modes));
            this.persistWorkModes();
            this.resetToolIfHidden();
        }
    }
    // ── EXPORTS ────────────────────────────────────────────────────────────────────
    exportJPG() {
        if (!this.canvas)
            return;
        // Export avec légende automatique des éléments dessinés (placée à droite si
        // paysage, en bas si portrait). Asynchrone : le blob émis sert aussi à l'app hôte.
        this.exportSvc.downloadJpgWithLegend(this.canvas)
            .then(blob => this.jpgExported.emit(blob))
            .catch(err => console.error('[G-Plan] Export JPEG avec légende échoué', err));
    }
    exportPNG() {
        if (!this.canvas)
            return;
        this.exportSvc.downloadPngWithLegend(this.canvas)
            .then(blob => this.pngExported.emit(blob))
            .catch(err => console.error('[G-Plan] Export PNG avec légende échoué', err));
    }
    exportSVG() {
        if (!this.canvas)
            return;
        const svg = this.exportSvc.toSvg(this.canvas);
        this.svgExported.emit(svg);
        this.exportSvc.downloadSvg(this.canvas);
    }
    /** Recharge le canvas depuis un projet externe (appelable par le parent au changement d'onglet). */
    reloadFromProject(proj) {
        if (!this.canvas || !proj)
            return;
        const targetFloor = proj.floors?.find(f => f.id === this.currentFloorId());
        const objects = targetFloor?.objects ?? proj.objects ?? [];
        this.isLoading.set(true);
        this.fabricSvc.loadFromProject({ ...proj, objects }).then(() => {
            this.zone.run(() => {
                this.pixelsPerMeter.set(proj.pixelsPerMeter);
                if (proj.floors?.length) {
                    this.floors.set(proj.floors.map(f => ({ id: f.id, name: f.name, order: f.order ?? 0 })));
                    proj.floors.forEach(f => this.floorObjects.set(f.id, f.objects));
                }
                this.applyProjectWorkModes(proj);
                this._lastEmittedProject = proj;
                this.recalculateRooms();
                this.syncBackdropState();
                this.centerViewOnBackdrop();
                // loadFromProject() recharge les objets avec leur selectable d'origine —
                // ré-appliquer le verrouillage de visualisation côté service et locks.
                this.fabricSvc.setReadOnly(this.readOnly());
                this.applyReadOnlyToObjects(this.readOnly());
                this.isLoading.set(false);
            });
        });
    }
    // ── ÉCHELLE ────────────────────────────────────────────────────────────────────
    onScaleInput(event) {
        const val = parseFloat(event.target.value);
        this.pixelsPerMeter.set(val);
        this.scaleLocked.set(false);
    }
    commitScaleChange(event) {
        const val = parseFloat(event.target.value);
        this.pixelsPerMeter.set(val);
        this.scaleLocked.set(false);
        this.updateLockedObjects(); // RoomBoxes
        this.applyLayoutConstraints(); // Murs verrouillés
        this.fabricSvc.refreshNodeHandles();
        this.recalculateRooms();
    }
    toggleMeasurements() {
        this.showMeasurements.update(v => !v);
        this.recalculateRooms();
    }
    // ── FOND DE CARTE ──────────────────────────────────────────────────────────────
    openOsmModal() { this.isOsmModalOpen.set(true); }
    closeOsmModal() { this.isOsmModalOpen.set(false); }
    openTemplateModal() { this.isTemplateModalOpen.set(true); }
    closeTemplateModal() { this.isTemplateModalOpen.set(false); }
    loadTemplate(tpl) {
        this.isLoading.set(true);
        this.fabricSvc.loadFromProject(tpl.project).then(() => {
            this.zone.run(() => {
                this.pixelsPerMeter.set(tpl.project.pixelsPerMeter);
                this.recalculateRooms();
                this.isLoading.set(false);
                this.projectChange.emit(this.buildProjectWithFloors());
            });
        });
    }
    onOsmImport(data) {
        this.applyBackdrop(data.dataUrl, data.scaleVal);
        this.closeOsmModal();
    }
    /** Charge un fond de carte depuis l'input `geoPoint` (coordonnées fournies par
     *  l'app hôte) si présent et qu'aucun fond n'existe déjà. Zoom max par défaut.
     *  Idempotent — le garde `hasBackdrop` évite le double chargement. */
    loadGeoBackdropIfNeeded() {
        const gp = this.geoPoint();
        if (!gp || gp.lat == null || gp.lng == null || !this.canvas)
            return false;
        const hasBackdrop = this.canvas.getObjects().some((o) => o.myType === 'Backdrop');
        if (hasBackdrop)
            return false;
        const geo = {
            lat: gp.lat,
            lng: gp.lng,
            zoom: gp.zoom ?? 19, // zoom max par défaut
            valid: true,
        };
        const layer = gp.layer ?? this.autoGeoLayer() ?? 'satellite';
        this.isLoading.set(true);
        // width/height omis → captureAt retombe sur la config (backdropCaptureWidth/Height).
        this.osmSvc.captureAt(geo, layer, this.config, gp.width, gp.height)
            .then(({ dataUrl, scaleVal }) => {
            this.zone.run(() => {
                this.applyBackdrop(dataUrl, scaleVal);
                this.isLoading.set(false);
            });
        })
            .catch(() => this.zone.run(() => this.isLoading.set(false)));
        return true;
    }
    applyBackdrop(dataUrl, scaleVal) {
        if (!this.canvas)
            return;
        const fabric = window['fabric'];
        // Arrondi à 1 décimale, borné entre 1 et 500
        const scale = Math.max(1, Math.min(500, Math.round(scaleVal * 10) / 10));
        fabric.Image.fromURL(dataUrl, (img) => {
            img.set({
                left: this.canvasWidth() / 2, top: this.canvasHeight() / 2,
                originX: 'center', originY: 'center',
                opacity: 0.5, myType: 'Backdrop',
                selectable: false, evented: false,
                // Locks de motion Fabric — défense en profondeur : ils empêchent tout
                // déplacement/redimensionnement même si selectable/evented sont remis
                // à true par un autre code path (ex : applyModeSelectability).
                lockMovementX: true, lockMovementY: true,
                lockRotation: true,
                lockScalingX: true, lockScalingY: true,
            });
            img.data = { ...(img.data || {}), locked: true };
            this.canvas.add(img);
            this.canvas.sendToBack(img);
            this.pixelsPerMeter.set(scale);
            this.backgroundLocked.set(true);
            this.scaleLocked.set(true);
            this.hasBackdrop.set(true);
            this.recalculateRooms();
            this.canvas.renderAll();
            this.centerViewOnBackdrop();
        });
    }
    /** Recentre la vue sur le fond de carte / backdrop dès son ajout : viewport
     *  remis à l'identité et zone de canvas scrollée sur le centre (le backdrop
     *  est placé au centre du canvas). */
    centerViewOnBackdrop() {
        const area = this.canvasAreaRef()?.nativeElement;
        if (!area || !this.canvas)
            return;
        this.canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
        this.canvas.renderAll();
        requestAnimationFrame(() => {
            area.scrollLeft = Math.max(0, (area.scrollWidth - area.clientWidth) / 2);
            area.scrollTop = Math.max(0, (area.scrollHeight - area.clientHeight) / 2);
        });
    }
    /** Mode visualisation : verrouille la motion de tous les objets non-backdrop.
     *  Les objets restent sélectionnables (inspection panneau latéral) mais
     *  immobiles. Backdrop conserve ses propres verrous (syncBackdropState).
     *  Porte/fenêtre conservent leur lock de scaling en sortie de readOnly. */
    applyReadOnlyToObjects(readOnly) {
        if (!this.canvas)
            return;
        this.canvas.getObjects().forEach((obj) => {
            if (obj.myType === 'Backdrop')
                return;
            const isDoorOrWindow = obj.myType === 'Door' || obj.myType === 'Window';
            obj.lockMovementX = readOnly;
            obj.lockMovementY = readOnly;
            obj.lockRotation = readOnly;
            obj.lockScalingX = readOnly || isDoorOrWindow;
            obj.lockScalingY = readOnly || isDoorOrWindow;
        });
        this.canvas.requestRenderAll?.();
    }
    /** Synchronise l'état du fond de carte après chargement d'un projet : le
     *  backdrop est verrouillé (non sélectionnable) par défaut — sinon il se
     *  déplace par mégarde au doigt. */
    syncBackdropState() {
        const backdrop = this.canvas?.getObjects().find((o) => o.myType === 'Backdrop');
        if (backdrop) {
            backdrop.set({
                selectable: false, evented: false,
                lockMovementX: true, lockMovementY: true,
                lockRotation: true,
                lockScalingX: true, lockScalingY: true,
            });
            backdrop.data = { ...(backdrop.data || {}), locked: true };
            this.hasBackdrop.set(true);
            this.backgroundLocked.set(true);
            this.canvas?.renderAll();
        }
        else {
            this.hasBackdrop.set(false);
            this.backgroundLocked.set(false);
        }
    }
    removeBackdrop() {
        if (!this.canvas)
            return;
        const backdrops = this.canvas.getObjects().filter((o) => o.myType === 'Backdrop');
        backdrops.forEach((o) => this.canvas.remove(o));
        this.canvas.renderAll();
        this.backgroundLocked.set(false);
        this.scaleLocked.set(false);
        this.hasBackdrop.set(false);
    }
    loadBackgroundImage(event) {
        const file = event.target.files?.[0];
        if (!file)
            return;
        const reader = new FileReader();
        reader.onload = (e) => {
            const fabric = window['fabric'];
            fabric.Image.fromURL(e.target.result, (img) => {
                img.set({
                    left: this.canvasWidth() / 2, top: this.canvasHeight() / 2,
                    originX: 'center', originY: 'center',
                    opacity: 0.5, myType: 'Backdrop',
                    selectable: false, evented: false,
                    lockMovementX: true, lockMovementY: true,
                    lockRotation: true,
                    lockScalingX: true, lockScalingY: true,
                });
                img.data = { ...(img.data || {}), locked: true };
                this.canvas.add(img);
                this.canvas.sendToBack(img);
                this.backgroundLocked.set(true);
                this.hasBackdrop.set(true);
                this.canvas.renderAll();
                this.centerViewOnBackdrop();
            });
        };
        reader.readAsDataURL(file);
    }
    toggleBackgroundLock() {
        this.backgroundLocked.update(v => !v);
        const locked = this.backgroundLocked();
        const backdrop = this.canvas?.getObjects().find((o) => o.myType === 'Backdrop');
        if (backdrop) {
            backdrop.set({
                selectable: !locked, evented: !locked,
                lockMovementX: locked, lockMovementY: locked,
                lockRotation: locked,
                lockScalingX: locked, lockScalingY: locked,
            });
            backdrop.data = { ...(backdrop.data || {}), locked };
            this.canvas.renderAll();
        }
    }
    updateBackgroundRotation(event) {
        const val = parseFloat(event.target.value);
        this.bgRotation.set(val);
        const backdrop = this.canvas?.getObjects().find((o) => o.myType === 'Backdrop');
        if (backdrop) {
            backdrop.set({ angle: val });
            this.canvas.renderAll();
        }
    }
    showGridOverlay() {
        const grid = document.querySelector('.ngf-alignment-grid');
        if (grid)
            grid.classList.add('ngf-alignment-grid--visible');
    }
    hideGridOverlay() {
        const grid = document.querySelector('.ngf-alignment-grid');
        if (grid)
            grid.classList.remove('ngf-alignment-grid--visible');
    }
    onInspectorChange(data) {
        this.inspectorData.set(data);
        const active = this.canvas?.getActiveObject();
        if (!active)
            return;
        if (data.label !== undefined) {
            active.data = { ...active.data, label: data.label };
            this.refreshRoomLabels();
            this.updateRoomList();
        }
        if (data.material) {
            active.data = { ...active.data, material: data.material };
        }
        if (data.isPrimary !== undefined && active.myType === 'Door') {
            active.data = { ...active.data, isPrimary: data.isPrimary };
            // Si la porte devient principale, retirer le statut principal des autres portes de la même pièce
            if (data.isPrimary) {
                const allDoors = this.canvas.getObjects().filter((o) => o.myType === 'Door');
                const activePts = this.canvas.getObjects()
                    .filter((o) => o.myType === 'DetectedRoom' && o.data?.isNested === false)
                    .find((room) => {
                    const pts = room.points ?? [];
                    return pts.length > 0 && this.rwlNearEdge({ x: active.left, y: active.top }, pts, 30);
                })
                    ?.points ?? [];
                allDoors.forEach((d) => {
                    if (d !== active && this.rwlNearEdge({ x: d.left, y: d.top }, activePts, 30)) {
                        d.data = { ...(d.data ?? {}), isPrimary: false };
                    }
                });
            }
            this.refreshWallLetters();
        }
        if (data.hazardLabel !== undefined) {
            active.data = { ...active.data, label: data.hazardLabel };
        }
        if (data.hazardSurface !== undefined &&
            ['HazardZone', 'HazardSample'].includes(active.myType)) {
            active.data = { ...active.data, hazardSurface: data.hazardSurface };
        }
        if ('linkedSampleId' in data && active.myType === 'HazardZone') {
            active.data = { ...active.data, linkedSampleId: data.linkedSampleId };
            this.refreshHazardLabels();
        }
        if (data.amianteResult !== undefined && active.myType === 'HazardSample') {
            active.data = { ...active.data, amianteResult: data.amianteResult };
            // Mettre à jour la couleur du cercle selon le résultat
            const circle = active.getObjects?.()?.find((o) => o.type === 'circle');
            if (circle) {
                const fill = data.amianteResult === 'positive' ? '#ef4444'
                    : data.amianteResult === 'negative' ? '#22c55e'
                        : '#f59e0b';
                circle.set({ fill });
                circle.dirty = true;
            }
        }
        if (data.glazingType !== undefined && active.myType === 'Window') {
            active.data = { ...active.data, glazingType: data.glazingType };
            const panes = data.glazingType === 'quadruple' ? 4 : data.glazingType === 'triple' ? 3 : data.glazingType === 'double' ? 2 : 1;
            active.set({ width: 60 * panes });
        }
        if (data.doorType !== undefined && active.myType === 'Door') {
            active.data = { ...active.data, doorType: data.doorType };
            active.set({ width: data.doorType === 'double' ? 160 : 80 });
        }
        if (data.notes !== undefined) {
            active.data = { ...active.data, notes: data.notes };
        }
        if (data.roomDescription !== undefined) {
            active.data = { ...active.data, roomDescription: data.roomDescription };
        }
        if ('criRoomId' in data && active.myType === 'DetectedRoom') {
            const criId = data.criRoomId ?? null;
            const cri = this.criRooms().find(c => c.id === criId);
            active.data = { ...active.data, criRoomId: criId };
            // Lier = nommer la pièce dessinée d'après la pièce CRI choisie.
            if (cri) {
                active.data.label = cri.name;
                this.refreshRoomLabels();
                this.updateRoomList();
            }
            const roomId = active.data?.roomId;
            if (criId && roomId) {
                this.roomLinked.emit({ roomId, criRoomId: criId, name: cri?.name ?? '' });
            }
        }
        this.canvas.renderAll();
        this.scheduleProjectChange(0); // émission immédiate pour les changements discrets d'attributs
    }
    // ── NUMÉROTATION DES MURS PAR PIÈCE ────────────────────────────────────────────
    /**
     * Assigne les lettres A, B, C… à chaque mur d'une pièce, dans le sens horaire
     * en partant de la porte principale (la porte avec isPrimary=true, ou la première).
     * Crée des labels 'RoomWallLabel' sur le canvas et annote les fenêtres (ex : B-F1).
     * Seules les pièces avec au moins une porte sont numérotées.
     */
    refreshWallLetters() {
        const fabric = window['fabric'];
        if (!this.canvas || !fabric)
            return;
        // Supprime les anciens labels de lettres de murs
        this.canvas.getObjects()
            .filter((o) => o.myType === 'RoomWallLabel')
            .forEach((o) => this.canvas.remove(o));
        const allObjs = this.canvas.getObjects();
        // Uniquement les pièces intérieures (isNested=false = non-enveloppe)
        const rooms = allObjs.filter(o => o.myType === 'DetectedRoom' && o.data?.isNested === false);
        const walls = allObjs.filter(o => o.myType === 'Mur' || o.myType === 'Cloison');
        const doors = allObjs.filter(o => o.myType === 'Door');
        const windows = allObjs.filter(o => o.myType === 'Window');
        // Réinitialise les références de mur sur toutes les portes/fenêtres avant de recalculer
        doors.forEach((d) => { if (d.data)
            d.data.wallRef = undefined; });
        windows.forEach((w) => { if (w.data)
            w.data.wallLabel = undefined; });
        if (rooms.length === 0)
            return;
        for (const room of rooms) {
            const pts = room.points ?? [];
            if (pts.length < 3)
                continue;
            // Portes situées sur la frontière de cette pièce (tolérance 30px)
            const roomDoors = doors.filter((d) => this.rwlNearEdge({ x: d.left ?? 0, y: d.top ?? 0 }, pts, 30));
            if (roomDoors.length === 0)
                continue;
            // Auto-marquage de la première porte comme principale si aucune ne l'est
            if (!roomDoors.some((d) => d.data?.isPrimary)) {
                roomDoors[0].data = { ...(roomDoors[0].data ?? {}), isPrimary: true };
            }
            const primary = roomDoors.find((d) => d.data?.isPrimary) ?? roomDoors[0];
            const startEdge = this.rwlNearestEdge({ x: primary.left ?? 0, y: primary.top ?? 0 }, pts);
            if (startEdge < 0)
                continue;
            const n = pts.length;
            let code = 0;
            const wallLetterMap = new Map(); // wallId → lettre
            // Polygones CW (screen Y-down, signedArea > 0) → parcours forward = sens horaire à l'écran
            for (let i = 0; i < n && code < 26; i++) {
                const ei = (startEdge + i) % n;
                const p1 = pts[ei], p2 = pts[(ei + 1) % n];
                const wall = this.rwlFindWall(p1, p2, walls);
                if (!wall)
                    continue;
                const letter = String.fromCharCode(65 + code++);
                const wallId = wall.data?.wallId;
                if (wallId)
                    wallLetterMap.set(wallId, letter);
                this.rwlAddLabel(fabric, p1, p2, pts, letter);
            }
            // Stocke la carte des lettres sur la pièce pour d'éventuelles consultations
            if (room.data)
                room.data.wallLetters = Object.fromEntries(wallLetterMap);
            // Annote chaque porte avec sa référence de mur dans cette pièce
            const roomName = room.data?.label ?? '';
            for (const door of roomDoors) {
                const wallId = door.data?.parentWallId;
                const letter = wallId ? wallLetterMap.get(wallId) : undefined;
                if (letter !== undefined) {
                    const ref = roomName ? `${letter} — ${roomName}` : letter;
                    // Agrège si la porte donne sur deux pièces numérotées
                    const existing = door.data?.wallRef ?? '';
                    door.data = {
                        ...(door.data ?? {}),
                        wallRef: existing && existing !== ref ? `${existing} / ${ref}` : ref,
                    };
                }
            }
            this.rwlLabelWindows(windows, walls, wallLetterMap);
        }
        this.canvas.requestRenderAll();
    }
    /** Vérifie si un point est à moins de `tol` pixels d'une arête du polygone. */
    rwlNearEdge(pt, poly, tol) {
        for (let i = 0; i < poly.length; i++) {
            if (this.rwlDist(pt, poly[i], poly[(i + 1) % poly.length]) < tol)
                return true;
        }
        return false;
    }
    /** Renvoie l'index de l'arête du polygone la plus proche du point (tolérance 60px). */
    rwlNearestEdge(pt, poly) {
        let best = -1, bestD = Infinity;
        for (let i = 0; i < poly.length; i++) {
            const d = this.rwlDist(pt, poly[i], poly[(i + 1) % poly.length]);
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        return bestD < 60 ? best : -1;
    }
    /** Renvoie les extrémités absolues d'un mur Fabric (même formule que geometry.service). */
    rwlLineEnds(w) {
        const dx = (w.left ?? 0) - Math.min(w.x1 ?? 0, w.x2 ?? 0);
        const dy = (w.top ?? 0) - Math.min(w.y1 ?? 0, w.y2 ?? 0);
        return {
            ax: (w.x1 ?? 0) + dx, ay: (w.y1 ?? 0) + dy,
            bx: (w.x2 ?? 0) + dx, by: (w.y2 ?? 0) + dy,
        };
    }
    /** Trouve le mur Fabric dont le segment est colinéaire à l'arête (p1, p2). */
    rwlFindWall(p1, p2, walls) {
        const mx = (p1.x + p2.x) / 2, my = (p1.y + p2.y) / 2;
        const eLen = Math.hypot(p2.x - p1.x, p2.y - p1.y);
        if (eLen < 2)
            return null;
        const eDx = (p2.x - p1.x) / eLen, eDy = (p2.y - p1.y) / eLen;
        let best = null, bestD = 40; // seuil 40px
        for (const w of walls) {
            const { ax, ay, bx, by } = this.rwlLineEnds(w);
            const d = this.rwlDist({ x: mx, y: my }, { x: ax, y: ay }, { x: bx, y: by });
            if (d >= bestD)
                continue;
            const wLen = Math.hypot(bx - ax, by - ay);
            if (wLen < 2)
                continue;
            const dot = Math.abs(eDx * (bx - ax) / wLen + eDy * (by - ay) / wLen);
            if (dot > 0.80) {
                best = w;
                bestD = d;
            }
        }
        return best;
    }
    /** Distance d'un point à un segment. */
    rwlDist(p, a, b) {
        const dx = b.x - a.x, dy = b.y - a.y;
        const l2 = dx * dx + dy * dy;
        if (l2 === 0)
            return Math.hypot(p.x - a.x, p.y - a.y);
        const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2));
        return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy);
    }
    /** Crée un label de lettre sur le canvas, décalé vers l'intérieur de la pièce. */
    rwlAddLabel(fabric, p1, p2, poly, letter) {
        const mx = (p1.x + p2.x) / 2, my = (p1.y + p2.y) / 2;
        const cx = poly.reduce((s, p) => s + p.x, 0) / poly.length;
        const cy = poly.reduce((s, p) => s + p.y, 0) / poly.length;
        const dx = cx - mx, dy = cy - my;
        const d = Math.hypot(dx, dy) || 1;
        const off = 15;
        const lbl = new fabric.Text(letter, {
            left: mx + dx / d * off, top: my + dy / d * off,
            originX: 'center', originY: 'center',
            fontSize: 11, fontFamily: 'monospace', fontWeight: 'bold',
            fill: '#6366f1', backgroundColor: 'rgba(255,255,255,0.82)',
            padding: 2, selectable: false, evented: false, objectCaching: false,
            myType: 'RoomWallLabel', data: { letter },
        });
        this.canvas.add(lbl);
    }
    /**
     * Trie les fenêtres d'un mur le long de son axe et leur attribue un label
     * de type "B-F1", "B-F2", etc. stocké dans `window.data.wallLabel`.
     */
    rwlLabelWindows(windows, walls, letterMap) {
        for (const [wallId, letter] of letterMap) {
            const wins = windows.filter((w) => w.data?.parentWallId === wallId);
            if (!wins.length)
                continue;
            const wall = walls.find((w) => w.data?.wallId === wallId);
            if (!wall)
                continue;
            const { ax, ay, bx, by } = this.rwlLineEnds(wall);
            const dx = bx - ax, dy = by - ay;
            wins.sort((a, b) => ((a.left - ax) * dx + (a.top - ay) * dy) - ((b.left - ax) * dx + (b.top - ay) * dy));
            wins.forEach((w, i) => {
                w.data = { ...(w.data ?? {}), wallLabel: `${letter}-F${i + 1}` };
            });
        }
    }
    ngOnDestroy() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: PlanEditorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: PlanEditorComponent, isStandalone: true, selector: "ng-gplan-plan-editor", inputs: { initialWalls: { classPropertyName: "initialWalls", publicName: "initialWalls", isSignal: true, isRequired: false, transformFunction: null }, project: { classPropertyName: "project", publicName: "project", isSignal: true, isRequired: false, transformFunction: null }, showSidebar: { classPropertyName: "showSidebar", publicName: "showSidebar", isSignal: true, isRequired: false, transformFunction: null }, showHeader: { classPropertyName: "showHeader", publicName: "showHeader", isSignal: true, isRequired: false, transformFunction: null }, canvasHeight: { classPropertyName: "canvasHeight", publicName: "canvasHeight", isSignal: true, isRequired: false, transformFunction: null }, canvasWidth: { classPropertyName: "canvasWidth", publicName: "canvasWidth", isSignal: true, isRequired: false, transformFunction: null }, autoGeoLayer: { classPropertyName: "autoGeoLayer", publicName: "autoGeoLayer", isSignal: true, isRequired: false, transformFunction: null }, geoPoint: { classPropertyName: "geoPoint", publicName: "geoPoint", isSignal: true, isRequired: false, transformFunction: null }, compactMode: { classPropertyName: "compactMode", publicName: "compactMode", isSignal: true, isRequired: false, transformFunction: null }, readOnly: { classPropertyName: "readOnly", publicName: "readOnly", isSignal: true, isRequired: false, transformFunction: null }, criRooms: { classPropertyName: "criRooms", publicName: "criRooms", isSignal: true, isRequired: false, transformFunction: null }, pendingSamples: { classPropertyName: "pendingSamples", publicName: "pendingSamples", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { projectSaved: "projectSaved", projectChange: "projectChange", statsChanged: "statsChanged", roomsChanged: "roomsChanged", jpgExported: "jpgExported", pngExported: "pngExported", svgExported: "svgExported", canvasReady: "canvasReady", loadingState: "loadingState", summaryChange: "summaryChange", roomLinked: "roomLinked", samplePlaced: "samplePlaced" }, viewQueries: [{ propertyName: "canvasRef", first: true, predicate: ["fabricCanvas"], descendants: true, isSignal: true }, { propertyName: "canvasAreaRef", first: true, predicate: ["canvasArea"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"ngf-editor\"\n  [class.ngf-editor--compact]=\"compactMode()\"\n  [class.ngf-editor--readonly]=\"readOnly()\">\n\n  <!-- Banni\u00E8re de r\u00E9cup\u00E9ration autosave (masqu\u00E9e en visualisation) -->\n  @if (hasAutosave() && !readOnly()) {\n    <div class=\"ngf-autosave-banner\">\n      <span>Un brouillon a \u00E9t\u00E9 trouv\u00E9 ({{ autosaveTime() | date:'dd/MM/yyyy HH:mm' }})</span>\n      <button class=\"ngf-autosave-banner__restore\" (click)=\"restoreAutosave()\">Restaurer</button>\n      <button class=\"ngf-autosave-banner__dismiss\" (click)=\"dismissAutosave()\">Ignorer</button>\n    </div>\n  }\n\n  <!-- Banni\u00E8re copie des murs ext\u00E9rieurs (masqu\u00E9e en visualisation) -->\n  @if (showCopyWallsOffer() && !readOnly()) {\n    <div class=\"ngf-copy-walls-banner\">\n      <span>Copier les murs de <strong>{{ getFloorName(copyWallsSourceId()) }}</strong> sur ce niveau comme base ?</span>\n      <button class=\"ngf-copy-walls-banner__confirm\" (click)=\"copyExteriorWalls()\">Copier les murs</button>\n      <button class=\"ngf-copy-walls-banner__dismiss\" (click)=\"dismissCopyWallsOffer()\">Non merci</button>\n    </div>\n  }\n\n  @if (showHeader()) {\n    <header class=\"ngf-editor__header\">\n      <div class=\"ngf-editor__header-left\">\n        @if (showSidebar() && !readOnly()) {\n          <button class=\"ngf-mobile-menu-btn\" type=\"button\"\n            (click)=\"toggleMobileSidebar()\"\n            [attr.aria-expanded]=\"mobileSidebarOpen()\"\n            aria-label=\"Outils\">\n            \u2630\n          </button>\n        }\n        <span class=\"ngf-editor__title\">G-Plan</span>\n        <span class=\"ngf-version-badge\" [title]=\"'Version de la librairie g-plan : ' + version\">v{{ version }}</span>\n\n        <!-- Badge stats contextuel : masqu\u00E9 s'il n'y a ni pi\u00E8ce ni mur (plan\n             SPANC/AC \u00E0 base de r\u00E9seaux). Les segments pcs/m\u00B2/\u26A0 ne s'affichent\n             que si des pi\u00E8ces existent ; \"murs\" que s'il y a des murs. -->\n        @if (showStatsBadge()) {\n          <div class=\"ngf-stats-badge\" title=\"Surface brute (axe des murs) \u2014 pas une surface Carrez/Boutin\">\n            @if (hasRooms()) {\n              <span>{{ stats().roomCount }} pcs</span>\n              <span class=\"ngf-stat-sep\">\u00B7</span>\n              <span>{{ stats().totalArea | number:'1.1-1' }} m\u00B2</span>\n              @if (stats().wallCount > 0) {\n                <span class=\"ngf-stat-sep\">\u00B7</span>\n              }\n            }\n            @if (stats().wallCount > 0) {\n              <span>{{ stats().wallCount }} murs</span>\n            }\n            @if (floors().length > 1 && hasRooms()) {\n              <span class=\"ngf-stat-sep\">|</span>\n              <span class=\"ngf-stat-global\" title=\"Surface totale cumul\u00E9e tous niveaux confondus\">\n                \u03A3 {{ globalAreaM2() | number:'1.1-1' }} m\u00B2\n              </span>\n            }\n            @if (hasRooms()) {\n              <span class=\"ngf-surface-disclaimer\" title=\"Surface brute sur axe des murs. Ne constitue pas une mesure Carrez ou Boutin.\">\u26A0 brut</span>\n            }\n          </div>\n        }\n\n        @if (readOnly()) {\n          <div class=\"ngf-h-divider\"></div>\n          <div class=\"ngf-readonly-badge\" role=\"status\" title=\"Le plan est ouvert en mode consultation : aucune modification possible.\">\n            \uD83D\uDC41 Mode visualisation\n          </div>\n        }\n\n        @if (!readOnly()) {\n          <div class=\"ngf-h-divider\"></div>\n\n          <button class=\"ngf-icon-btn\" (click)=\"undo()\" title=\"Annuler (Ctrl+Z)\" [disabled]=\"!canUndo()\">\n            \u21A9 Annuler\n          </button>\n          <button class=\"ngf-icon-btn\" (click)=\"redo()\" title=\"R\u00E9tablir (Ctrl+Y)\" [disabled]=\"!canRedo()\">\n            R\u00E9tablir \u21AA\n          </button>\n        }\n\n        <!-- Bouton contextuel : visible d\u00E8s qu'un outil de trac\u00E9 (mur/cloison/\n             pipe) est actif. Plac\u00E9 dans le header \u2014 seul conteneur garanti\n             toujours visible quelle que soit l'int\u00E9gration (modale, iframe\u2026). -->\n        @if (isPolylineMode() && !show3D()) {\n          <button class=\"ngf-finish-trace-btn\" type=\"button\"\n            (click)=\"finishPolyline()\"\n            title=\"Terminer le trac\u00E9 en cours (clic droit ou \u00C9chap au clavier)\">\n            \u2713 Terminer le trac\u00E9\n          </button>\n        }\n\n        <!-- Badge d'aide \u00E0 la pose : visible pour les outils \"click-to-place\"\n             (pictogrammes, \u00E9quipements, portes/fen\u00EAtres, etc.). Plac\u00E9 dans le\n             header pour rester visible et bien centr\u00E9 quel que soit le scroll. -->\n        @if (currentMode() !== 'select' && currentMode() !== 'pan' && currentMode() !== 'node-edit' && !isPolylineMode() && !show3D()) {\n          <div class=\"ngf-mode-info\" role=\"status\" aria-live=\"polite\">\n            \uD83D\uDC46 Cliquez sur le canvas pour placer :\n            <strong>{{ currentToolLabel() }}</strong>\n          </div>\n        }\n\n        <!-- Pose guid\u00E9e des pr\u00E9l\u00E8vements CRI : file restant \u00E0 positionner. -->\n        @if (currentMode() === 'prelevement' && !readOnly() && remainingSampleLabels().length) {\n          <div class=\"ngf-sample-queue\" role=\"status\" aria-live=\"polite\">\n            \uD83D\uDCCD \u00C0 placer : <strong>{{ remainingSampleLabels().join(', ') }}</strong>\n          </div>\n        }\n      </div>\n\n      <div class=\"ngf-editor__header-right\">\n\n        @if (!readOnly()) {\n          <!-- Modes m\u00E9tier (cumulables) -->\n          <div class=\"ngf-workmodes\" title=\"Modes m\u00E9tier \u2014 cumulables. Filtrent les outils visibles dans la barre lat\u00E9rale.\">\n            @for (m of workModeDefs; track m.id) {\n              <button type=\"button\"\n                class=\"ngf-workmode\"\n                [class.ngf-workmode--active]=\"isWorkModeActive(m.id)\"\n                [style.--wm-color]=\"m.color\"\n                (click)=\"toggleWorkMode(m.id)\"\n                [title]=\"m.label\">\n                <span class=\"ngf-workmode__icon\">{{ m.icon }}</span>\n                {{ m.shortLabel }}\n              </button>\n            }\n          </div>\n\n          <div class=\"ngf-h-divider\"></div>\n        }\n\n        <!-- Niveaux : visibles aussi en lecture seule pour naviguer entre \u00E9tages,\n             mais le \"+\" et la copie de murs (\u00E9dition) sont masqu\u00E9s. -->\n        <div class=\"ngf-floor-tabs\">\n          @for (floor of sortedFloors(); track floor.id) {\n            <button class=\"ngf-floor-tab\"\n              [class.ngf-floor-tab--active]=\"currentFloorId() === floor.id\"\n              (click)=\"switchFloor(floor.id)\">\n              {{ floor.name }}\n            </button>\n          }\n          @if (!readOnly()) {\n            <button class=\"ngf-floor-tab ngf-floor-tab--add\" (click)=\"openAddFloorModal()\" title=\"Ajouter un niveau\">+</button>\n\n            @if (floors().length > 1) {\n              <div class=\"ngf-copy-from-wrap\">\n                <button class=\"ngf-floor-tab ngf-floor-tab--copy\" (click)=\"openCopyFromMenu()\" title=\"Copier les murs depuis un autre niveau\">\u29C9</button>\n                @if (showCopyFromMenu()) {\n                  <div class=\"ngf-copy-from-menu\">\n                    <div class=\"ngf-copy-from-menu__title\">Copier les murs de\u2026</div>\n                    @for (floor of sortedFloors(); track floor.id) {\n                      @if (floor.id !== currentFloorId()) {\n                        <button class=\"ngf-copy-from-menu__item\" (click)=\"copyWallsFromFloor(floor.id)\">\n                          {{ floor.name }}\n                        </button>\n                      }\n                    }\n                  </div>\n                }\n              </div>\n            }\n          }\n        </div>\n\n        <div class=\"ngf-h-divider\"></div>\n\n        @if (!readOnly()) {\n          <!-- \u00C9chelle : modifier le ratio px/m change la g\u00E9om\u00E9trie du projet \u2192 \u00E9dition -->\n          <div class=\"ngf-scale-ctrl\" [class.ngf-scale-ctrl--locked]=\"scaleLocked()\">\n            <span>\u00C9chelle</span>\n            <strong>{{ pixelsPerMeter() | number:'1.0-1' }} px/m</strong>\n            @if (scaleLocked()) {\n              <span class=\"ngf-scale-lock\" title=\"\u00C9chelle calcul\u00E9e depuis la carte \u2014 modifiez le slider pour d\u00E9verrouiller\">\uD83D\uDD12</span>\n            }\n            <input type=\"range\" min=\"1\" max=\"500\" step=\"0.5\"\n              [value]=\"pixelsPerMeter()\"\n              (input)=\"onScaleInput($event)\"\n              (change)=\"commitScaleChange($event)\" />\n          </div>\n\n          <div class=\"ngf-h-divider\"></div>\n        }\n\n        <!-- Cotes : pur affichage, conserv\u00E9 en lecture seule -->\n        <label class=\"ngf-toggle\" title=\"Afficher / masquer les cotes\">\n          <input type=\"checkbox\" [checked]=\"showMeasurements()\" (change)=\"toggleMeasurements()\" />\n          Cotes\n        </label>\n\n        <div class=\"ngf-h-divider\"></div>\n\n        <!-- Bascule 2D / 3D : non destructive, disponible en \u00E9dition comme en visualisation -->\n        <button class=\"ngf-btn-action ngf-btn-action--3d\"\n          [class.ngf-btn-action--active]=\"show3D()\"\n          (click)=\"toggle3D()\"\n          [title]=\"show3D() ? 'Revenir \u00E0 la vue 2D' : 'Afficher la vue 3D'\">\n          {{ show3D() ? '\uD83D\uDDFA Vue 2D' : '\uD83E\uDDCA Vue 3D' }}\n        </button>\n\n        <!-- Pi\u00E8ces : panneau de consultation. Masqu\u00E9 en lecture seule et tant\n             qu'il n'y a rien \u00E0 lister (pas de pi\u00E8ce ni de lin\u00E9aire r\u00E9seau). -->\n        @if (!readOnly()) {\n          @if (hasRoomListContent()) {\n            <button class=\"ngf-btn-action ngf-btn-action--osm\"\n              [class.ngf-btn-action--active]=\"showRoomList()\"\n              (click)=\"toggleRoomList()\" title=\"Liste des pi\u00E8ces\">\uD83D\uDCCB Pi\u00E8ces</button>\n          }\n\n          <button class=\"ngf-btn-action ngf-btn-action--tpl\" (click)=\"openTemplateModal()\" title=\"Partir d'un mod\u00E8le d'appartement\">\u22A1 Mod\u00E8les</button>\n        }\n\n        <div class=\"ngf-h-divider\"></div>\n\n        @if (!readOnly()) {\n        <!-- \u2500\u2500 Dropdown Fond \u2500\u2500 -->\n        <div class=\"ngf-dropdown-wrap\">\n          <button class=\"ngf-btn-action ngf-btn-action--osm\"\n            [class.ngf-btn-action--active]=\"showFondMenu()\"\n            (click)=\"toggleFondMenu()\"\n            title=\"Image de fond & carte\">\n            \uD83D\uDDBC Fond \u25BE\n          </button>\n          @if (showFondMenu()) {\n            <div class=\"ngf-dropdown-panel ngf-dropdown-panel--fond\">\n              <div class=\"ngf-dropdown-panel__title\">Fond de plan</div>\n\n              <button class=\"ngf-dropdown-panel__item\" (click)=\"openOsmModal(); showFondMenu.set(false)\">\n                \uD83D\uDDFA Importer depuis la carte\n              </button>\n\n              <label class=\"ngf-dropdown-panel__item\">\n                \uD83D\uDCF7 Charger une image\u2026\n                <input type=\"file\" accept=\"image/png,image/jpeg\" (change)=\"loadBackgroundImage($event); showFondMenu.set(false)\" hidden />\n              </label>\n\n              @if (hasBackdrop()) {\n                <div class=\"ngf-dropdown-panel__sep\"></div>\n                <div class=\"ngf-dropdown-panel__row\">\n                  <label class=\"ngf-dropdown-panel__toggle\">\n                    <input type=\"checkbox\" [checked]=\"backgroundLocked()\" (change)=\"toggleBackgroundLock()\" />\n                    \uD83D\uDD12 Verrouiller\n                  </label>\n                </div>\n                <div class=\"ngf-dropdown-panel__row\">\n                  <span class=\"ngf-dropdown-panel__label\">Rotation</span>\n                  <input type=\"range\" min=\"-90\" max=\"90\" step=\"0.5\"\n                    [value]=\"bgRotation()\"\n                    (input)=\"updateBackgroundRotation($event)\"\n                    (mousedown)=\"showGridOverlay()\"\n                    (mouseup)=\"hideGridOverlay()\"\n                    style=\"flex:1; accent-color: var(--primary)\" />\n                  <span class=\"ngf-dropdown-panel__val\">{{ bgRotation() }}\u00B0</span>\n                </div>\n                <div class=\"ngf-dropdown-panel__sep\"></div>\n                <button class=\"ngf-dropdown-panel__item ngf-dropdown-panel__item--danger\"\n                  (click)=\"removeBackdrop(); showFondMenu.set(false)\">\n                  \u2715 Supprimer le fond\n                </button>\n              }\n            </div>\n          }\n        </div>\n        } <!-- /@if (!readOnly()) \u2014 fin dropdown Fond -->\n\n        <!-- \u2500\u2500 Dropdown Fichier \u2500\u2500 (Exports conserv\u00E9s en lecture seule) -->\n        <div class=\"ngf-dropdown-wrap\">\n          <button class=\"ngf-btn-action ngf-btn-action--save\"\n            [class.ngf-btn-action--active]=\"showFichierMenu()\"\n            (click)=\"toggleFichierMenu()\"\n            [title]=\"readOnly() ? 'Exporter le plan' : 'Sauvegarder, ouvrir et exporter'\">\n            \uD83D\uDCC1 {{ readOnly() ? 'Exporter' : 'Fichier' }} \u25BE\n          </button>\n          @if (showFichierMenu()) {\n            <div class=\"ngf-dropdown-panel ngf-dropdown-panel--right\">\n              @if (!readOnly()) {\n                <div class=\"ngf-dropdown-panel__title\">Projet</div>\n                <button class=\"ngf-dropdown-panel__item\" (click)=\"saveProject(); showFichierMenu.set(false)\">\n                  \u2193 Enregistrer (JSON)\n                </button>\n                <label class=\"ngf-dropdown-panel__item\">\n                  \u2191 Ouvrir un projet\u2026\n                  <input type=\"file\" accept=\".json\" (change)=\"loadProject($event); showFichierMenu.set(false)\" hidden />\n                </label>\n                <div class=\"ngf-dropdown-panel__sep\"></div>\n              }\n              <div class=\"ngf-dropdown-panel__title\">Exporter</div>\n              <button class=\"ngf-dropdown-panel__item\" (click)=\"exportJPG(); showFichierMenu.set(false)\">\n                \u2193 JPEG\n              </button>\n              <button class=\"ngf-dropdown-panel__item\" (click)=\"exportPNG(); showFichierMenu.set(false)\">\n                \u2193 PNG haute r\u00E9solution\n              </button>\n              <button class=\"ngf-dropdown-panel__item\" (click)=\"exportSVG(); showFichierMenu.set(false)\">\n                \u2193 SVG vectoriel\n              </button>\n            </div>\n          }\n        </div>\n\n      </div>\n    </header>\n  }\n\n  <div class=\"ngf-editor__workspace\">\n\n    @if (showSidebar() && mobileSidebarOpen() && !readOnly()) {\n      <div class=\"ngf-mobile-backdrop\" (click)=\"closeMobileSidebar()\"></div>\n    }\n\n    @if (showSidebar() && !readOnly()) {\n      <aside class=\"ngf-editor__sidebar\"\n        [class.ngf-editor__sidebar--mobile-open]=\"mobileSidebarOpen()\">\n        <!-- \u2500\u2500 Actions contextuelles (en haut, toujours visibles) \u2500\u2500 -->\n        @if (currentMode() === 'room-sketch') {\n          <div class=\"ngf-ctx-actions ngf-ctx-actions--top\">\n            <div class=\"ngf-sidebar__group-title\">Croquis</div>\n            <button class=\"ngf-tool-item ngf-tool-item--action\" (click)=\"generateEnvelope()\"\n              title=\"Convertir les pi\u00E8ces en murs et cloisons\">\n              \u2B07 G\u00E9n\u00E9rer l'enveloppe\n            </button>\n          </div>\n        }\n\n        @if (inspectorData()?.objectType === 'RoomBox') {\n          <div class=\"ngf-ctx-actions ngf-ctx-actions--top\">\n            <div class=\"ngf-sidebar__group-title\">Dimensions pi\u00E8ce</div>\n            <div class=\"ngf-calibrate\">\n              <div class=\"ngf-calibrate__row\">\n                <span class=\"ngf-calibrate__label\" style=\"min-width:20px;font-weight:700\">L</span>\n                <input class=\"ngf-calibrate__input\" type=\"number\" min=\"0.01\" step=\"0.1\"\n                  [value]=\"roomBoxWidthM()\"\n                  (input)=\"roomBoxWidthM.set($any($event.target).value)\"\n                  placeholder=\"larg. (m)\" />\n              </div>\n              <div class=\"ngf-calibrate__row\">\n                <span class=\"ngf-calibrate__label\" style=\"min-width:20px;font-weight:700\">H</span>\n                <input class=\"ngf-calibrate__input\" type=\"number\" min=\"0.01\" step=\"0.1\"\n                  [value]=\"roomBoxHeightM()\"\n                  (input)=\"roomBoxHeightM.set($any($event.target).value)\"\n                  placeholder=\"haut. (m)\" />\n              </div>\n              <button class=\"ngf-tool-item ngf-tool-item--action\" (click)=\"applyRoomBoxDimensions()\"\n                title=\"Redimensionner selon les cotes \u00D7 PPM courant\">\n                \u2713 Appliquer\n              </button>\n            </div>\n          </div>\n        }\n\n        @if (inspectorData()?.objectType === 'Mur' || inspectorData()?.objectType === 'Cloison') {\n          <div class=\"ngf-ctx-actions ngf-ctx-actions--top\">\n            <div class=\"ngf-sidebar__group-title\">\n              @if (inspectorData()?.objectType === 'Cloison') { Cloison s\u00E9lectionn\u00E9e } @else { Mur s\u00E9lectionn\u00E9 }\n            </div>\n            <button class=\"ngf-tool-item ngf-tool-item--action\" (click)=\"toggleSelectedWallType()\"\n              title=\"Basculer entre mur porteur et cloison\">\n              \u21CC @if (inspectorData()?.objectType === 'Mur') { En cloison } @else { En mur porteur }\n            </button>\n            <div class=\"ngf-calibrate\">\n              <span class=\"ngf-calibrate__label\">\uD83D\uDCCF Calibrer</span>\n              <div class=\"ngf-calibrate__row\">\n                <input class=\"ngf-calibrate__input\" type=\"number\" min=\"0.01\" step=\"0.01\"\n                  [value]=\"calibrationLength()\"\n                  (input)=\"calibrationLength.set($any($event.target).value)\"\n                  placeholder=\"longueur r\u00E9elle (m)\" />\n                <button class=\"ngf-calibrate__btn\" (click)=\"applyCalibration()\" title=\"Appliquer la calibration\">\u2194</button>\n              </div>\n            </div>\n          </div>\n        }\n\n        <!-- \u2500\u2500 Outils (filtr\u00E9s par les modes m\u00E9tier actifs) \u2500\u2500 -->\n        @for (group of visibleToolGroups(); track group.label) {\n          <h3 class=\"ngf-sidebar__group-title\">{{ group.label }}</h3>\n          @for (tool of group.tools; track tool.mode) {\n            <button class=\"ngf-tool-item\"\n              [class.ngf-tool-item--active]=\"currentMode() === tool.mode\"\n              [attr.data-mode]=\"tool.mode\"\n              (click)=\"setMode(tool.mode)\"\n              [title]=\"tool.label + (tool.shortcut ? ' (' + tool.shortcut + ')' : '')\">\n              <span class=\"tool-icon-wrap\">{{ tool.icon }}</span>\n              {{ tool.label }}\n              @if (tool.shortcut) {\n                <span class=\"tool-shortcut\">{{ tool.shortcut }}</span>\n              }\n            </button>\n          }\n        }\n\n        <div style=\"flex: 1\"></div>\n      </aside>\n    }\n\n    <div class=\"ngf-editor__canvas-area\" #canvasArea>\n      <canvas #fabricCanvas [width]=\"canvasWidth()\" [height]=\"canvasHeight()\"></canvas>\n      <div class=\"ngf-alignment-grid\"></div>\n\n      @if (isLoading()) {\n        <div class=\"ngf-loading-overlay\">Chargement du projet\u2026</div>\n      }\n\n      @if (showFloorBadge()) {\n        <div class=\"ngf-floor-badge\">{{ currentFloorName() }}</div>\n      }\n    </div>\n\n    @if (showRoomList() && !readOnly() && hasRoomListContent()) {\n      <aside class=\"ngf-room-list\">\n        <div class=\"ngf-room-list__header\">Pi\u00E8ces</div>\n\n        @for (floor of roomsByFloor(); track floor.floorId) {\n          <div class=\"ngf-room-list__floor\">\n            <div class=\"ngf-room-list__floor-name\">{{ floor.floorName }}</div>\n            @if (floor.rooms.length === 0) {\n              <div class=\"ngf-room-list__empty\">Aucune pi\u00E8ce d\u00E9tect\u00E9e</div>\n            }\n            @for (room of floor.rooms; track $index) {\n              <div class=\"ngf-room-list__room\"\n                (click)=\"selectRoomFromList(floor.floorId, room.label, room.areaM2)\"\n                title=\"S\u00E9lectionner cette pi\u00E8ce\">\n                <span class=\"ngf-room-list__room-name\">{{ room.label || '(sans nom)' }}</span>\n                <span class=\"ngf-room-list__room-area\">{{ room.areaM2 | number:'1.1-1' }} m\u00B2</span>\n              </div>\n            }\n            @if (floor.rooms.length > 0) {\n              <div class=\"ngf-room-list__total\">\n                <span>Total</span>\n                <span>{{ floor.totalArea | number:'1.1-1' }} m\u00B2</span>\n              </div>\n            }\n          </div>\n        }\n        @if (pipeEntries().length > 0) {\n          <div class=\"ngf-room-list__header ngf-room-list__header--pipes\">Lin\u00E9aires r\u00E9seaux</div>\n          @for (entry of pipeEntries(); track entry.label) {\n            <div class=\"ngf-room-list__room ngf-room-list__room--pipe\">\n              <span class=\"ngf-room-list__room-name\">{{ entry.label }}</span>\n              <span class=\"ngf-room-list__room-area\">{{ entry.lengthM | number:'1.1-1' }} m</span>\n            </div>\n          }\n        }\n      </aside>\n    }\n\n    <aside class=\"ngf-inspector\" [class.ngf-inspector--active]=\"showInspector()\">\n      <ng-gplan-inspector-panel\n        [data]=\"inspectorData()\"\n        [readOnly]=\"readOnly()\"\n        (dataChange)=\"onInspectorChange($event)\"\n      />\n      <!-- Suppression de l'\u00E9l\u00E9ment s\u00E9lectionn\u00E9 \u2014 indispensable sur tactile\n           (pas de touche Suppr comme sur PC). Masqu\u00E9e en mode visualisation. -->\n      @if (!readOnly()) {\n        <button class=\"ngf-inspector-delete-btn\" type=\"button\"\n          (click)=\"deleteActive()\"\n          title=\"Supprimer l'\u00E9l\u00E9ment s\u00E9lectionn\u00E9 (touche Suppr au clavier)\">\n          \uD83D\uDDD1 Supprimer l'\u00E9l\u00E9ment\n        </button>\n      }\n    </aside>\n\n    <!-- Vue 3D : superpos\u00E9e \u00E0 TOUT le workspace (sidebar + canvas + inspecteur)\n         pour qu'aucune zone 2D ne reste visible autour. Toggle non destructif. -->\n    @if (show3D()) {\n      <div class=\"ngf-viewer3d-overlay\">\n        <ng-gplan-viewer-3d [project]=\"project3D()\" />\n      </div>\n    }\n\n  </div>\n\n  @if (isOsmModalOpen()) {\n    <ng-gplan-osm-modal\n      [config]=\"config\"\n      (import)=\"onOsmImport($event)\"\n      (close)=\"closeOsmModal()\"\n    />\n  }\n\n  @if (isTemplateModalOpen()) {\n    <ng-gplan-template-modal\n      (close)=\"closeTemplateModal()\"\n      (templateSelected)=\"loadTemplate($event)\"\n    />\n  }\n\n  <!-- Modal ajout d'un niveau -->\n  @if (showAddFloorModal()) {\n    <div class=\"ngf-modal-overlay\" (click)=\"cancelAddFloor()\">\n      <div class=\"ngf-add-floor-modal\" (click)=\"$event.stopPropagation()\">\n        <h3 class=\"ngf-add-floor-modal__title\">Ajouter un niveau</h3>\n\n        <div class=\"ngf-add-floor-modal__direction\">\n          <button class=\"ngf-add-floor-modal__dir-btn\"\n            [class.ngf-add-floor-modal__dir-btn--active]=\"newFloorDirection() === 'above'\"\n            (click)=\"setAddFloorDirection('above')\">\n            \u2191 En hauteur\n          </button>\n          <button class=\"ngf-add-floor-modal__dir-btn\"\n            [class.ngf-add-floor-modal__dir-btn--active]=\"newFloorDirection() === 'below'\"\n            (click)=\"setAddFloorDirection('below')\">\n            \u2193 En sous-sol\n          </button>\n        </div>\n\n        <label class=\"ngf-add-floor-modal__label\">Nom du niveau</label>\n        <input class=\"ngf-add-floor-modal__input\" type=\"text\"\n          [value]=\"newFloorName()\"\n          (input)=\"newFloorName.set($any($event.target).value)\"\n          placeholder=\"ex : \u00C9tage 1\" />\n\n        <div class=\"ngf-add-floor-modal__actions\">\n          <button class=\"ngf-add-floor-modal__cancel\" (click)=\"cancelAddFloor()\">Annuler</button>\n          <button class=\"ngf-add-floor-modal__confirm\" (click)=\"confirmAddFloor()\">Cr\u00E9er le niveau</button>\n        </div>\n      </div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{--z-50: #fafafa;--z-100: #f5f5f5;--z-200: #e5e5e5;--z-300: #d4d4d4;--z-400: #a3a3a3;--z-500: #737373;--z-600: #525252;--z-700: #404040;--z-800: #262626;--z-900: #171717;--primary: #f97316;--primary-hover: #ea580c;--primary-dark: #c2410c;--primary-light: #fff7ed;--primary-border: #fed7aa;--primary-text: #9a3412;--success: #16a34a;--danger: #dc2626;--warn: #d97706;--info: #0284c7;--purple: #7c3aed;--teal: #0d9488;--radius-sm: 4px;--radius: 8px;--radius-lg: 12px;--radius-xl: 16px;--shadow-sm: 0 1px 3px rgba(0,0,0,.08);--shadow: 0 2px 8px rgba(0,0,0,.08), 0 0 0 1px rgba(0,0,0,.04);--shadow-lg: 0 8px 24px rgba(0,0,0,.1);--font: \"Poppins\", ui-sans-serif, system-ui, sans-serif;--font-mono: \"DM Mono\", ui-monospace, monospace;display:flex;flex-direction:column;height:100%;font-family:var(--font)}.ngf-editor{display:flex;flex-direction:column;height:100%;min-height:0;background:#f5f4f2}.ngf-editor__header{min-height:52px;padding:5px 14px;background:#fff;border-bottom:1px solid var(--z-200);display:flex;align-items:center;flex-wrap:wrap;gap:6px;flex-shrink:0;z-index:20;overflow:visible;box-shadow:0 1px 4px #0000000f}.ngf-editor__header-left,.ngf-editor__header-right{display:flex;align-items:center;flex-wrap:wrap;gap:5px}.ngf-editor__header-left{flex:1}.ngf-editor__header-right{flex-shrink:0}.ngf-editor__title{font-size:13px;font-weight:800;letter-spacing:.01em;color:#fff;background:var(--primary);padding:4px 10px;border-radius:var(--radius);white-space:nowrap;margin-right:8px;line-height:1}.ngf-editor__workspace{display:flex;flex:1;min-height:0;overflow:hidden;position:relative}.ngf-editor__sidebar{width:200px;background:#fff;border-right:1px solid var(--z-200);padding:8px 6px;display:flex;flex-direction:column;gap:1px;overflow-y:auto;flex-shrink:0;box-shadow:2px 0 8px #0000000a}.ngf-editor__sidebar::-webkit-scrollbar{width:3px}.ngf-editor__sidebar::-webkit-scrollbar-thumb{background:var(--z-200);border-radius:2px}.ngf-editor__canvas-area{flex:1;overflow:auto;position:relative;display:flex;justify-content:safe center;align-items:safe center;background:#f0ede8;background-image:radial-gradient(circle,#d6d2cc 1px,transparent 1px);background-size:24px 24px;background-position:12px 12px}.ngf-viewer3d-overlay{position:absolute;inset:0;z-index:50;display:flex;background:#f0ede8}.ngf-viewer3d-overlay ng-gplan-viewer-3d{flex:1;min-width:0;min-height:0}.ngf-h-divider{width:1px;height:22px;background:var(--z-200);flex-shrink:0;margin:0 3px}.ngf-workmodes{display:inline-flex;align-items:center;gap:4px;padding:2px;border-radius:100px;background:var(--z-100, #f1f5f9);border:1px solid var(--z-200, #e2e8f0)}.ngf-workmode{--wm-color: #6366f1;height:24px;padding:0 10px;border:none;background:transparent;border-radius:100px;cursor:pointer;font-size:11px;font-family:var(--font);font-weight:600;color:var(--z-500);display:inline-flex;align-items:center;gap:4px;white-space:nowrap;transition:background .12s,color .12s;-webkit-user-select:none;user-select:none}.ngf-workmode__icon{font-size:13px;line-height:1}.ngf-workmode:hover{background:#6366f10f;color:var(--wm-color)}.ngf-workmode--active{background:var(--wm-color);color:#fff;font-weight:700;box-shadow:0 1px 2px #00000014}.ngf-stats-badge{display:flex;align-items:center;gap:8px;padding:4px 12px;background:var(--primary-light);border:1px solid var(--primary-border);color:var(--primary-text);border-radius:100px;font-size:11px;font-weight:600;font-family:var(--font-mono);white-space:nowrap}.ngf-stat-sep{color:var(--primary-border);font-weight:400}.ngf-stat-global{font-weight:600;color:var(--primary);opacity:.85}.ngf-icon-btn{height:32px;padding:0 11px;border:1px solid var(--z-200);background:transparent;border-radius:var(--radius);cursor:pointer;font-size:12px;font-family:var(--font);color:var(--z-600);white-space:nowrap;transition:background .12s,border-color .12s,color .12s;display:inline-flex;align-items:center;gap:4px}.ngf-icon-btn:hover:not(:disabled){background:var(--primary-light);border-color:var(--primary-border);color:var(--primary)}.ngf-icon-btn:disabled{opacity:.35;cursor:not-allowed}.ngf-scale-ctrl{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--z-500);white-space:nowrap}.ngf-scale-ctrl strong{color:var(--primary);font-family:var(--font-mono);font-weight:700}.ngf-scale-ctrl input[type=range]{width:72px;accent-color:var(--primary);cursor:pointer}.ngf-scale-ctrl--locked{background:var(--primary-light);border:1px solid var(--primary-border);border-radius:var(--radius);padding:3px 8px}.ngf-scale-ctrl--locked strong{color:var(--primary-hover)}.ngf-scale-lock{font-size:11px;cursor:help}.ngf-toggle{display:inline-flex;align-items:center;gap:5px;font-size:11px;color:var(--z-500);cursor:pointer;white-space:nowrap;-webkit-user-select:none;user-select:none}.ngf-toggle input[type=checkbox]{accent-color:var(--primary);cursor:pointer;width:14px;height:14px}.ngf-toggle:hover{color:var(--primary)}.ngf-floor-tabs{display:flex;align-items:center;gap:3px}.ngf-floor-tab{height:28px;padding:0 12px;border:1px solid var(--z-200);background:transparent;border-radius:100px;cursor:pointer;font-size:11px;font-family:var(--font);font-weight:600;color:var(--z-500);white-space:nowrap;transition:background .12s,color .12s,border-color .12s}.ngf-floor-tab:hover{background:var(--primary-light);border-color:var(--primary-border);color:var(--primary)}.ngf-floor-tab--active{background:var(--primary);color:#fff;border-color:var(--primary);font-weight:700}.ngf-floor-tab--add{padding:0 10px;font-size:18px;font-weight:300;color:var(--z-300);border-style:dashed}.ngf-floor-tab--add:hover{color:var(--primary);border-color:var(--primary-border);background:var(--primary-light)}.ngf-btn-action{height:32px;padding:0 12px;border:none;border-radius:var(--radius);cursor:pointer;font-size:11px;font-family:var(--font);font-weight:700;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;transition:filter .1s,opacity .1s;color:#fff;letter-spacing:.01em}.ngf-btn-action:hover{filter:brightness(.9)}.ngf-btn-action--save{background:var(--primary)}.ngf-btn-action--load{background:var(--z-600)}.ngf-btn-action--jpg{background:var(--success)}.ngf-btn-action--png{background:var(--info)}.ngf-btn-action--svg{background:var(--purple)}.ngf-btn-action--bg{background:var(--z-500)}.ngf-btn-action--remove-bg{background:var(--danger, #ef4444)}.ngf-btn-action--tpl{background:#6366f1}.ngf-btn-action--3d{background:#0ea5e9}.ngf-btn-action--active,.ngf-btn-action--osm.ngf-btn-action--active{background:var(--primary);color:#fff;border-color:transparent;filter:none}.ngf-btn-action--osm{background:transparent;color:var(--z-600);border:1px solid var(--z-200)}.ngf-btn-action--osm:hover{background:var(--primary-light);border-color:var(--primary-border);color:var(--primary);filter:none}.ngf-sidebar__group-title{margin:12px 0 4px 8px;font-size:9px;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:var(--z-400)}.ngf-sidebar__group-title:first-child{margin-top:6px}.ngf-tool-item{position:relative;padding:7px 10px 7px 8px;cursor:pointer;border:none;background:transparent;border-radius:var(--radius);text-align:left;width:100%;transition:background .1s,color .1s;font-size:12px;font-family:var(--font);font-weight:500;color:var(--z-700);display:flex;align-items:center;gap:9px;line-height:1}.ngf-tool-item:hover:not(.ngf-tool-item--active):not(.ngf-tool-item--danger){background:var(--primary-light);color:var(--primary)}.ngf-tool-item:hover:not(.ngf-tool-item--active):not(.ngf-tool-item--danger) .tool-icon-wrap{background:var(--primary-border)}.ngf-tool-item--active{background:var(--primary)!important;color:#fff!important;font-weight:700}.ngf-tool-item--active .tool-icon-wrap{background:#fff3!important}.ngf-tool-item--active .tool-shortcut{background:#ffffff2e;color:#ffffffd9}.ngf-tool-item--danger{margin-top:8px;border-top:1px solid var(--z-100);padding-top:10px;color:var(--danger);justify-content:center;font-size:11px;font-weight:700;border-radius:0;background:none}.ngf-tool-item--danger:hover{background:#fef2f2;color:#b91c1c;border-radius:var(--radius)}.ngf-tool-item .tool-icon{display:none}.ngf-tool-item .tool-icon-wrap{width:26px;height:26px;border-radius:7px;background:var(--primary-light);display:flex;align-items:center;justify-content:center;font-size:13px;flex-shrink:0;transition:background .1s}.ngf-tool-item .tool-shortcut{margin-left:auto;font-size:9px;color:var(--z-400);font-family:var(--font-mono);font-weight:600;background:var(--z-100);padding:1px 5px;border-radius:3px}.ngf-ctx-actions{display:flex;flex-direction:column;gap:4px}.ngf-ctx-actions--top{border-bottom:1px solid var(--z-100);padding-bottom:8px;margin-bottom:4px}.ngf-tool-item--action{background:var(--primary-light);color:var(--primary-text);font-weight:600;border-radius:var(--radius)}.ngf-tool-item--action:hover{background:var(--primary);color:#fff}.ngf-calibrate{display:flex;flex-direction:column;gap:4px;padding:6px 8px}.ngf-calibrate__label{font-size:10px;font-weight:700;color:var(--z-500);text-transform:uppercase;letter-spacing:.04em}.ngf-calibrate__row{display:flex;gap:4px;align-items:center}.ngf-calibrate__input{flex:1;min-width:0;padding:4px 6px;border:1.5px solid var(--z-200);border-radius:var(--radius-sm);font-size:11px;font-family:var(--font-mono);color:var(--z-800);background:#fff}.ngf-calibrate__input:focus{outline:none;border-color:var(--info)}.ngf-calibrate__btn{padding:4px 8px;background:var(--info);color:#fff;border:none;border-radius:var(--radius-sm);cursor:pointer;font-size:13px;font-weight:700;flex-shrink:0}.ngf-calibrate__btn:hover{background:#0369a1}.ngf-inspector{width:224px;background:#fff;border-left:1px solid var(--z-200);padding:16px 12px;display:none;flex-direction:column;gap:12px;overflow-y:auto;flex-shrink:0;box-shadow:-2px 0 8px #0000000a}.ngf-inspector--active{display:flex;animation:slideIn .15s ease-out}.ngf-inspector-delete-btn{display:flex;align-items:center;justify-content:center;gap:6px;flex-shrink:0;width:100%;min-height:40px;padding:8px 14px;background:var(--danger);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;font-size:12px;font-weight:700;font-family:var(--font);white-space:nowrap;touch-action:manipulation;transition:filter .1s,transform .08s}.ngf-inspector-delete-btn:hover{filter:brightness(1.1)}.ngf-inspector-delete-btn:active{transform:scale(.97)}@media(pointer:coarse){.ngf-inspector-delete-btn{min-height:44px;font-size:13px}}@keyframes slideIn{0%{opacity:0;transform:translate(8px)}to{opacity:1;transform:translate(0)}}.ngf-room-list{width:200px;flex-shrink:0;background:#fff;border-left:1px solid var(--z-200);display:flex;flex-direction:column;overflow-y:auto;box-shadow:-2px 0 8px #0000000a;animation:slideIn .15s ease-out}.ngf-room-list__header{padding:10px 12px 8px;font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--z-400);border-bottom:1px solid var(--z-100)}.ngf-room-list__floor{padding:8px 12px;border-bottom:1px solid var(--z-100)}.ngf-room-list__floor:last-child{border-bottom:none}.ngf-room-list__floor-name{font-size:11px;font-weight:700;color:var(--primary-text);background:var(--primary-light);border:1px solid var(--primary-border);border-radius:var(--radius-sm);padding:2px 7px;margin-bottom:6px;display:inline-block}.ngf-room-list__empty{font-size:11px;color:var(--z-400);font-style:italic;padding:2px 0}.ngf-room-list__room{display:flex;justify-content:space-between;align-items:baseline;gap:4px;padding:3px 4px;font-size:12px;border-bottom:1px solid var(--z-100);border-radius:var(--radius-sm);cursor:pointer;transition:background .1s}.ngf-room-list__room:last-of-type{border-bottom:none}.ngf-room-list__room:hover{background:var(--primary-light)}.ngf-room-list__room:hover .ngf-room-list__room-name{color:var(--primary-text)}.ngf-room-list__room-name{color:var(--z-700);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:110px}.ngf-room-list__room-area{color:var(--z-500);font-size:11px;white-space:nowrap;flex-shrink:0}.ngf-room-list__total{display:flex;justify-content:space-between;padding:4px 0 0;margin-top:2px;font-size:11px;font-weight:700;color:var(--z-600);border-top:1px solid var(--z-200)}.ngf-room-list__header--pipes{margin-top:4px;border-top:2px solid var(--z-200);color:#0369a1}.ngf-room-list__room--pipe{cursor:default}.ngf-room-list__room--pipe:hover{background:#f0f9ff}.ngf-room-list__room--pipe .ngf-room-list__room-name{color:#0369a1;font-weight:600}.ngf-room-list__room--pipe .ngf-room-list__room-area{color:#0284c7;font-weight:600}.ngf-alignment-grid{position:absolute;inset:0;pointer-events:none;z-index:100;display:none;background-image:linear-gradient(rgba(220,38,38,.18) 1px,transparent 1px),linear-gradient(90deg,rgba(220,38,38,.18) 1px,transparent 1px);background-size:48px 48px}.ngf-alignment-grid--visible{display:block}.ngf-floor-badge{position:absolute;top:50%;left:0;right:0;transform:translateY(-50%);text-align:center;font-size:clamp(40px,8vw,96px);font-weight:900;letter-spacing:.12em;text-transform:uppercase;color:#0000000a;pointer-events:none;-webkit-user-select:none;user-select:none;line-height:1;z-index:1;white-space:nowrap;overflow:hidden}.ngf-mode-info{display:inline-flex;align-items:center;gap:6px;background:var(--primary);color:#fff;padding:6px 14px;border-radius:100px;font-size:12px;font-weight:600;white-space:nowrap;box-shadow:0 2px 8px #f973164d}.ngf-mode-info strong{font-weight:800}@media(pointer:coarse){.ngf-mode-info{min-height:36px;font-size:13px}}.ngf-sample-queue{display:inline-flex;align-items:center;gap:6px;background:#b45309;color:#fff;padding:6px 14px;border-radius:100px;font-size:12px;font-weight:600;white-space:nowrap;box-shadow:0 2px 8px #b453094d}.ngf-sample-queue strong{font-weight:800}@media(pointer:coarse){.ngf-sample-queue{min-height:36px;font-size:13px}}.ngf-version-badge{display:inline-flex;align-items:center;padding:1px 6px;border-radius:100px;background:var(--z-100);border:1px solid var(--z-200);color:var(--z-500);font-family:var(--font-mono, monospace);font-size:10px;font-weight:600;line-height:1.4;letter-spacing:.01em;white-space:nowrap;-webkit-user-select:text;user-select:text;flex-shrink:0}.ngf-readonly-badge{display:inline-flex;align-items:center;gap:6px;background:#475569;color:#fff;padding:5px 12px;border-radius:100px;font-size:12px;font-weight:700;letter-spacing:.02em;white-space:nowrap;box-shadow:0 1px 3px #0f172a33;-webkit-user-select:none;user-select:none}@media(pointer:coarse){.ngf-readonly-badge{min-height:32px;font-size:13px}}.ngf-finish-trace-btn{background:var(--primary);color:#fff;border:none;min-height:36px;padding:6px 16px;border-radius:100px;cursor:pointer;font-size:12px;font-weight:800;font-family:var(--font);letter-spacing:.02em;white-space:nowrap;touch-action:manipulation;box-shadow:0 2px 8px #f9731659;transition:filter .1s,transform .08s}.ngf-finish-trace-btn:hover{filter:brightness(1.08)}.ngf-finish-trace-btn:active{transform:scale(.96)}@media(pointer:coarse){.ngf-finish-trace-btn{min-height:44px;font-size:13px;padding:8px 20px}}.ngf-loading-overlay{position:absolute;inset:0;background:#ffffffd9;backdrop-filter:blur(4px);display:flex;flex-direction:column;justify-content:center;align-items:center;z-index:5000;gap:12px;font-size:13px;font-weight:600;color:var(--z-500)}.ngf-loading-overlay:before{content:\"\";width:28px;height:28px;border:3px solid var(--primary-border);border-top-color:var(--primary);border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}.ngf-surface-disclaimer{font-size:9px;font-weight:600;opacity:.7;letter-spacing:.02em;color:var(--primary);cursor:help}.ngf-sep{color:#ffffff40}.ngf-autosave-banner{display:flex;align-items:center;gap:10px;padding:9px 16px;background:#fffbeb;border-bottom:1px solid #fde68a;font-size:12px;color:#92400e;flex-shrink:0}.ngf-autosave-banner span{flex:1}.ngf-autosave-banner__restore{padding:5px 14px;background:var(--primary);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;font-size:11px;font-weight:700;font-family:var(--font)}.ngf-autosave-banner__restore:hover{background:var(--primary-hover)}.ngf-autosave-banner__dismiss{padding:5px 12px;background:transparent;color:#92400e;border:1px solid #fcd34d;border-radius:var(--radius);cursor:pointer;font-size:11px;font-family:var(--font)}.ngf-autosave-banner__dismiss:hover{background:#fef3c7}.ngf-copy-walls-banner{display:flex;align-items:center;gap:10px;padding:9px 16px;background:var(--primary-light);border-bottom:1px solid var(--primary-border);font-size:12px;color:var(--primary-text);flex-shrink:0}.ngf-copy-walls-banner span{flex:1}.ngf-copy-walls-banner__confirm{padding:5px 14px;background:var(--primary);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;font-size:11px;font-weight:700;font-family:var(--font)}.ngf-copy-walls-banner__confirm:hover{background:var(--primary-hover)}.ngf-copy-walls-banner__dismiss{padding:5px 12px;background:transparent;color:var(--primary-text);border:1px solid var(--primary-border);border-radius:var(--radius);cursor:pointer;font-size:11px;font-family:var(--font)}.ngf-copy-walls-banner__dismiss:hover{background:#fed7aa}.ngf-dropdown-wrap{position:relative}.ngf-dropdown-panel{position:absolute;top:calc(100% + 8px);left:0;min-width:220px;background:#fff;border:1px solid var(--z-200);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);z-index:300;overflow:hidden;animation:dropDown .12s ease-out}.ngf-dropdown-panel--right{left:auto;right:0}.ngf-dropdown-panel--fond{min-width:240px}.ngf-dropdown-panel__title{padding:8px 14px 5px;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:var(--z-400)}.ngf-dropdown-panel__item{display:flex;align-items:center;gap:8px;width:100%;padding:9px 14px;border:none;background:transparent;text-align:left;font-size:12px;font-family:var(--font);font-weight:500;color:var(--z-700);cursor:pointer;transition:background .1s,color .1s}.ngf-dropdown-panel__item:hover{background:var(--primary-light);color:var(--primary-text)}.ngf-dropdown-panel__item--danger{color:var(--danger)}.ngf-dropdown-panel__item--danger:hover{background:#fef2f2;color:#b91c1c}.ngf-dropdown-panel__sep{height:1px;background:var(--z-100);margin:4px 0}.ngf-dropdown-panel__row{display:flex;align-items:center;gap:8px;padding:6px 14px;font-size:11px;color:var(--z-600)}.ngf-dropdown-panel__label{white-space:nowrap;flex-shrink:0;font-size:11px}.ngf-dropdown-panel__val{white-space:nowrap;flex-shrink:0;font-size:10px;font-family:var(--font-mono);color:var(--primary);font-weight:700;min-width:28px;text-align:right}.ngf-dropdown-panel__toggle{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--z-600);cursor:pointer;-webkit-user-select:none;user-select:none}.ngf-dropdown-panel__toggle input[type=checkbox]{accent-color:var(--primary);width:14px;height:14px;cursor:pointer}@keyframes dropDown{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.ngf-floor-tab--copy{padding:0 9px;font-size:14px;color:var(--z-400);border-style:dashed}.ngf-floor-tab--copy:hover{color:var(--primary);border-color:var(--primary-border);background:var(--primary-light)}.ngf-copy-from-wrap{position:relative}.ngf-copy-from-menu{position:absolute;top:calc(100% + 6px);right:0;min-width:160px;background:#fff;border:1px solid var(--z-200);border-radius:var(--radius);box-shadow:0 4px 16px #0000001f;z-index:200;overflow:hidden}.ngf-copy-from-menu__title{padding:7px 12px 5px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--z-400);border-bottom:1px solid var(--z-100)}.ngf-copy-from-menu__item{display:block;width:100%;padding:8px 12px;background:transparent;border:none;text-align:left;font-size:12px;font-family:var(--font);font-weight:600;color:var(--z-700);cursor:pointer}.ngf-copy-from-menu__item:hover{background:var(--primary-light);color:var(--primary)}.ngf-modal-overlay{position:absolute;inset:0;background:#00000059;display:flex;align-items:center;justify-content:center;z-index:500}.ngf-add-floor-modal{background:#fff;border-radius:12px;padding:24px;width:320px;box-shadow:0 8px 32px #0000002e;display:flex;flex-direction:column;gap:14px}.ngf-add-floor-modal__title{margin:0;font-size:15px;font-weight:700;color:var(--z-900)}.ngf-add-floor-modal__direction{display:flex;gap:8px}.ngf-add-floor-modal__dir-btn{flex:1;padding:9px 0;border:1px solid var(--z-200);border-radius:var(--radius);background:transparent;font-size:12px;font-family:var(--font);font-weight:600;color:var(--z-500);cursor:pointer;transition:all .12s}.ngf-add-floor-modal__dir-btn:hover{border-color:var(--primary-border);color:var(--primary);background:var(--primary-light)}.ngf-add-floor-modal__dir-btn--active{background:var(--primary);border-color:var(--primary);color:#fff}.ngf-add-floor-modal__label{font-size:11px;font-weight:700;color:var(--z-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:-8px}.ngf-add-floor-modal__input{width:100%;padding:9px 12px;border:1px solid var(--z-200);border-radius:var(--radius);font-size:13px;font-family:var(--font);color:var(--z-800);box-sizing:border-box;outline:none}.ngf-add-floor-modal__input:focus{border-color:var(--primary);box-shadow:0 0 0 2px var(--primary-light)}.ngf-add-floor-modal__actions{display:flex;gap:8px;justify-content:flex-end;margin-top:4px}.ngf-add-floor-modal__cancel{padding:8px 16px;background:transparent;border:1px solid var(--z-200);border-radius:var(--radius);font-size:12px;font-family:var(--font);font-weight:600;color:var(--z-500);cursor:pointer}.ngf-add-floor-modal__cancel:hover{background:var(--z-50)}.ngf-add-floor-modal__confirm{padding:8px 16px;background:var(--primary);border:none;border-radius:var(--radius);font-size:12px;font-family:var(--font);font-weight:700;color:#fff;cursor:pointer}.ngf-add-floor-modal__confirm:hover{background:var(--primary-hover)}:host{--gplan-touch-target-min: 44px;--gplan-mobile-bp: 768px}.ngf-mobile-menu-btn{display:none;width:36px;height:36px;background:transparent;border:1px solid var(--z-200);border-radius:var(--radius);font-size:18px;line-height:1;color:var(--z-700);cursor:pointer;flex-shrink:0}.ngf-mobile-menu-btn:hover{background:var(--z-100);color:var(--primary)}.ngf-mobile-backdrop{display:none;position:fixed;inset:0;background:#0f172a66;z-index:50;animation:fadeIn .18s ease-out}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.ngf-editor__canvas-area canvas,.ngf-editor__canvas-area .canvas-container{touch-action:none;-webkit-touch-callout:none;user-select:none;-webkit-user-select:none}@media(max-width:768px){.ngf-editor .ngf-editor__header{height:auto;padding:6px 8px;flex-wrap:wrap;gap:4px;overflow:visible}.ngf-editor .ngf-editor__header-left,.ngf-editor .ngf-editor__header-right{flex:1 1 100%;flex-wrap:wrap;overflow:visible;padding-bottom:2px}.ngf-editor .ngf-stats-badge,.ngf-editor .ngf-scale-ctrl,.ngf-editor .ngf-toggle,.ngf-editor .ngf-h-divider{display:none}.ngf-editor .ngf-editor__title{padding:3px 7px;font-size:11px;margin-right:4px}.ngf-editor .ngf-mobile-menu-btn{display:inline-flex;align-items:center;justify-content:center}.ngf-editor .ngf-workmodes{flex:1 1 100%;overflow-x:auto;overflow-y:visible;scrollbar-width:none;padding:2px 0}.ngf-editor .ngf-workmodes::-webkit-scrollbar{display:none}.ngf-editor .ngf-workmode{padding:0 9px;font-size:11px;height:26px;flex-shrink:0}.ngf-editor .ngf-floor-tabs{position:fixed;bottom:0;left:0;right:0;background:#fff;border-top:1px solid var(--z-200);box-shadow:0 -1px 4px #0000000f;padding:4px 8px;z-index:40;overflow-x:auto;justify-content:flex-start;gap:4px}.ngf-editor .ngf-floor-tab{height:var(--gplan-touch-target-min);min-width:56px;padding:0 14px;font-size:12px}.ngf-editor .ngf-editor__canvas-area{padding-bottom:calc(var(--gplan-touch-target-min) + 12px + env(safe-area-inset-bottom,0))}.ngf-editor .ngf-editor__sidebar{position:fixed;top:0;bottom:0;left:0;width:min(78vw,280px);z-index:60;transform:translate(-100%);transition:transform .22s ease-out;box-shadow:4px 0 16px #0000002e;padding-top:14px}.ngf-editor .ngf-editor__sidebar--mobile-open{transform:translate(0)}.ngf-editor .ngf-mobile-backdrop{display:block}.ngf-editor .ngf-tool-item{min-height:var(--gplan-touch-target-min);padding:9px 12px;font-size:13px}.ngf-editor .ngf-tool-item .tool-icon-wrap{width:30px;height:30px;font-size:15px}.ngf-editor .ngf-tool-item .tool-shortcut{display:none}.ngf-editor .ngf-sidebar__group-title{font-size:10px;margin-top:16px}.ngf-editor .ngf-inspector{position:fixed;left:0;right:0;bottom:calc(var(--gplan-touch-target-min) + 8px + env(safe-area-inset-bottom,0));width:100%;max-height:50vh;border-left:none;border-top:1px solid var(--z-200);border-radius:var(--radius-lg) var(--radius-lg) 0 0;box-shadow:0 -4px 18px #0000001a;padding:14px 14px 18px;z-index:35}.ngf-editor .ngf-inspector--active:before{content:\"\";display:block;width:36px;height:4px;background:var(--z-300);border-radius:2px;margin:-6px auto 10px}.ngf-editor .ngf-room-list{position:fixed;left:0;right:0;bottom:calc(var(--gplan-touch-target-min) + 8px + env(safe-area-inset-bottom,0));width:100%;max-height:40vh;border-left:none;border-top:1px solid var(--z-200);border-radius:var(--radius-lg) var(--radius-lg) 0 0;box-shadow:0 -4px 18px #0000001a;z-index:34}.ngf-editor .ngf-modal-overlay{padding:0}.ngf-editor .ngf-add-floor-modal{width:100vw;height:100vh;max-height:100dvh;border-radius:0;overflow-y:auto}.ngf-editor .ngf-icon-btn,.ngf-editor .ngf-btn-action{min-height:36px;padding:0 10px;font-size:11px}.ngf-editor .ngf-dropdown-panel{max-width:calc(100vw - 16px);max-height:60vh;overflow-y:auto;z-index:70}}.ngf-editor--compact .ngf-editor__header{height:auto;padding:6px 8px;flex-wrap:wrap;gap:4px;overflow:visible}.ngf-editor--compact .ngf-editor__header-left,.ngf-editor--compact .ngf-editor__header-right{flex:1 1 100%;flex-wrap:wrap;overflow:visible;padding-bottom:2px}.ngf-editor--compact .ngf-stats-badge,.ngf-editor--compact .ngf-scale-ctrl,.ngf-editor--compact .ngf-toggle,.ngf-editor--compact .ngf-h-divider{display:none}.ngf-editor--compact .ngf-editor__title{padding:3px 7px;font-size:11px;margin-right:4px}.ngf-editor--compact .ngf-mobile-menu-btn{display:inline-flex;align-items:center;justify-content:center}.ngf-editor--compact .ngf-workmodes{flex:1 1 100%;overflow-x:auto;overflow-y:visible;scrollbar-width:none;padding:2px 0}.ngf-editor--compact .ngf-workmodes::-webkit-scrollbar{display:none}.ngf-editor--compact .ngf-workmode{padding:0 9px;font-size:11px;height:26px;flex-shrink:0}.ngf-editor--compact .ngf-floor-tabs{position:fixed;bottom:0;left:0;right:0;background:#fff;border-top:1px solid var(--z-200);box-shadow:0 -1px 4px #0000000f;padding:4px 8px;z-index:40;overflow-x:auto;justify-content:flex-start;gap:4px}.ngf-editor--compact .ngf-floor-tab{height:var(--gplan-touch-target-min);min-width:56px;padding:0 14px;font-size:12px}.ngf-editor--compact .ngf-editor__canvas-area{padding-bottom:calc(var(--gplan-touch-target-min) + 12px + env(safe-area-inset-bottom,0))}.ngf-editor--compact .ngf-editor__sidebar{position:fixed;top:0;bottom:0;left:0;width:min(78vw,280px);z-index:60;transform:translate(-100%);transition:transform .22s ease-out;box-shadow:4px 0 16px #0000002e;padding-top:14px}.ngf-editor--compact .ngf-editor__sidebar--mobile-open{transform:translate(0)}.ngf-editor--compact .ngf-mobile-backdrop{display:block}.ngf-editor--compact .ngf-tool-item{min-height:var(--gplan-touch-target-min);padding:9px 12px;font-size:13px}.ngf-editor--compact .ngf-tool-item .tool-icon-wrap{width:30px;height:30px;font-size:15px}.ngf-editor--compact .ngf-tool-item .tool-shortcut{display:none}.ngf-editor--compact .ngf-sidebar__group-title{font-size:10px;margin-top:16px}.ngf-editor--compact .ngf-inspector{position:fixed;left:0;right:0;bottom:calc(var(--gplan-touch-target-min) + 8px + env(safe-area-inset-bottom,0));width:100%;max-height:50vh;border-left:none;border-top:1px solid var(--z-200);border-radius:var(--radius-lg) var(--radius-lg) 0 0;box-shadow:0 -4px 18px #0000001a;padding:14px 14px 18px;z-index:35}.ngf-editor--compact .ngf-inspector--active:before{content:\"\";display:block;width:36px;height:4px;background:var(--z-300);border-radius:2px;margin:-6px auto 10px}.ngf-editor--compact .ngf-room-list{position:fixed;left:0;right:0;bottom:calc(var(--gplan-touch-target-min) + 8px + env(safe-area-inset-bottom,0));width:100%;max-height:40vh;border-left:none;border-top:1px solid var(--z-200);border-radius:var(--radius-lg) var(--radius-lg) 0 0;box-shadow:0 -4px 18px #0000001a;z-index:34}.ngf-editor--compact .ngf-modal-overlay{padding:0}.ngf-editor--compact .ngf-add-floor-modal{width:100vw;height:100vh;max-height:100dvh;border-radius:0;overflow-y:auto}.ngf-editor--compact .ngf-icon-btn,.ngf-editor--compact .ngf-btn-action{min-height:36px;padding:0 10px;font-size:11px}.ngf-editor--compact .ngf-dropdown-panel{max-width:calc(100vw - 16px);max-height:60vh;overflow-y:auto;z-index:70}@media(max-height:500px)and (max-width:932px){.ngf-editor__header{padding:4px 6px;height:38px;flex-wrap:nowrap}.ngf-editor__header-left,.ngf-editor__header-right{flex:0 1 auto}.ngf-editor .ngf-floor-tabs{position:static;box-shadow:none;border-top:none;padding:0}.ngf-editor .ngf-floor-tab{height:28px;min-width:0;padding:0 10px}.ngf-editor .ngf-editor__canvas-area{padding-bottom:0}.ngf-editor .ngf-inspector,.ngf-editor .ngf-room-list{bottom:0;max-height:100%}}@media(pointer:coarse){.ngf-tool-item,.ngf-floor-tab,.ngf-icon-btn,.ngf-btn-action,.ngf-workmode,.ngf-mobile-menu-btn{min-height:var(--gplan-touch-target-min, 44px)}}.ngf-editor--readonly .ngf-editor__sidebar{opacity:.55;pointer-events:none}.ngf-editor--readonly .ngf-editor__sidebar .ngf-tool-item[data-mode=select],.ngf-editor--readonly .ngf-editor__sidebar .ngf-tool-item[data-mode=node-edit]{opacity:1;pointer-events:auto}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "component", type: InspectorPanelComponent, selector: "ng-gplan-inspector-panel", inputs: ["data", "readOnly"], outputs: ["dataChange"] }, { kind: "component", type: OsmModalComponent, selector: "ng-gplan-osm-modal", inputs: ["config"], outputs: ["import", "close"] }, { kind: "component", type: TemplateModalComponent, selector: "ng-gplan-template-modal", outputs: ["close", "templateSelected"] }, { kind: "component", type: Viewer3DComponent, selector: "ng-gplan-viewer-3d", inputs: ["project"] }, { kind: "pipe", type: DecimalPipe, name: "number" }, { kind: "pipe", type: DatePipe, name: "date" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: PlanEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-gplan-plan-editor', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [FormsModule, MetersPipe, InspectorPanelComponent, OsmModalComponent, TemplateModalComponent, Viewer3DComponent, DecimalPipe, DatePipe], template: "<div class=\"ngf-editor\"\n  [class.ngf-editor--compact]=\"compactMode()\"\n  [class.ngf-editor--readonly]=\"readOnly()\">\n\n  <!-- Banni\u00E8re de r\u00E9cup\u00E9ration autosave (masqu\u00E9e en visualisation) -->\n  @if (hasAutosave() && !readOnly()) {\n    <div class=\"ngf-autosave-banner\">\n      <span>Un brouillon a \u00E9t\u00E9 trouv\u00E9 ({{ autosaveTime() | date:'dd/MM/yyyy HH:mm' }})</span>\n      <button class=\"ngf-autosave-banner__restore\" (click)=\"restoreAutosave()\">Restaurer</button>\n      <button class=\"ngf-autosave-banner__dismiss\" (click)=\"dismissAutosave()\">Ignorer</button>\n    </div>\n  }\n\n  <!-- Banni\u00E8re copie des murs ext\u00E9rieurs (masqu\u00E9e en visualisation) -->\n  @if (showCopyWallsOffer() && !readOnly()) {\n    <div class=\"ngf-copy-walls-banner\">\n      <span>Copier les murs de <strong>{{ getFloorName(copyWallsSourceId()) }}</strong> sur ce niveau comme base ?</span>\n      <button class=\"ngf-copy-walls-banner__confirm\" (click)=\"copyExteriorWalls()\">Copier les murs</button>\n      <button class=\"ngf-copy-walls-banner__dismiss\" (click)=\"dismissCopyWallsOffer()\">Non merci</button>\n    </div>\n  }\n\n  @if (showHeader()) {\n    <header class=\"ngf-editor__header\">\n      <div class=\"ngf-editor__header-left\">\n        @if (showSidebar() && !readOnly()) {\n          <button class=\"ngf-mobile-menu-btn\" type=\"button\"\n            (click)=\"toggleMobileSidebar()\"\n            [attr.aria-expanded]=\"mobileSidebarOpen()\"\n            aria-label=\"Outils\">\n            \u2630\n          </button>\n        }\n        <span class=\"ngf-editor__title\">G-Plan</span>\n        <span class=\"ngf-version-badge\" [title]=\"'Version de la librairie g-plan : ' + version\">v{{ version }}</span>\n\n        <!-- Badge stats contextuel : masqu\u00E9 s'il n'y a ni pi\u00E8ce ni mur (plan\n             SPANC/AC \u00E0 base de r\u00E9seaux). Les segments pcs/m\u00B2/\u26A0 ne s'affichent\n             que si des pi\u00E8ces existent ; \"murs\" que s'il y a des murs. -->\n        @if (showStatsBadge()) {\n          <div class=\"ngf-stats-badge\" title=\"Surface brute (axe des murs) \u2014 pas une surface Carrez/Boutin\">\n            @if (hasRooms()) {\n              <span>{{ stats().roomCount }} pcs</span>\n              <span class=\"ngf-stat-sep\">\u00B7</span>\n              <span>{{ stats().totalArea | number:'1.1-1' }} m\u00B2</span>\n              @if (stats().wallCount > 0) {\n                <span class=\"ngf-stat-sep\">\u00B7</span>\n              }\n            }\n            @if (stats().wallCount > 0) {\n              <span>{{ stats().wallCount }} murs</span>\n            }\n            @if (floors().length > 1 && hasRooms()) {\n              <span class=\"ngf-stat-sep\">|</span>\n              <span class=\"ngf-stat-global\" title=\"Surface totale cumul\u00E9e tous niveaux confondus\">\n                \u03A3 {{ globalAreaM2() | number:'1.1-1' }} m\u00B2\n              </span>\n            }\n            @if (hasRooms()) {\n              <span class=\"ngf-surface-disclaimer\" title=\"Surface brute sur axe des murs. Ne constitue pas une mesure Carrez ou Boutin.\">\u26A0 brut</span>\n            }\n          </div>\n        }\n\n        @if (readOnly()) {\n          <div class=\"ngf-h-divider\"></div>\n          <div class=\"ngf-readonly-badge\" role=\"status\" title=\"Le plan est ouvert en mode consultation : aucune modification possible.\">\n            \uD83D\uDC41 Mode visualisation\n          </div>\n        }\n\n        @if (!readOnly()) {\n          <div class=\"ngf-h-divider\"></div>\n\n          <button class=\"ngf-icon-btn\" (click)=\"undo()\" title=\"Annuler (Ctrl+Z)\" [disabled]=\"!canUndo()\">\n            \u21A9 Annuler\n          </button>\n          <button class=\"ngf-icon-btn\" (click)=\"redo()\" title=\"R\u00E9tablir (Ctrl+Y)\" [disabled]=\"!canRedo()\">\n            R\u00E9tablir \u21AA\n          </button>\n        }\n\n        <!-- Bouton contextuel : visible d\u00E8s qu'un outil de trac\u00E9 (mur/cloison/\n             pipe) est actif. Plac\u00E9 dans le header \u2014 seul conteneur garanti\n             toujours visible quelle que soit l'int\u00E9gration (modale, iframe\u2026). -->\n        @if (isPolylineMode() && !show3D()) {\n          <button class=\"ngf-finish-trace-btn\" type=\"button\"\n            (click)=\"finishPolyline()\"\n            title=\"Terminer le trac\u00E9 en cours (clic droit ou \u00C9chap au clavier)\">\n            \u2713 Terminer le trac\u00E9\n          </button>\n        }\n\n        <!-- Badge d'aide \u00E0 la pose : visible pour les outils \"click-to-place\"\n             (pictogrammes, \u00E9quipements, portes/fen\u00EAtres, etc.). Plac\u00E9 dans le\n             header pour rester visible et bien centr\u00E9 quel que soit le scroll. -->\n        @if (currentMode() !== 'select' && currentMode() !== 'pan' && currentMode() !== 'node-edit' && !isPolylineMode() && !show3D()) {\n          <div class=\"ngf-mode-info\" role=\"status\" aria-live=\"polite\">\n            \uD83D\uDC46 Cliquez sur le canvas pour placer :\n            <strong>{{ currentToolLabel() }}</strong>\n          </div>\n        }\n\n        <!-- Pose guid\u00E9e des pr\u00E9l\u00E8vements CRI : file restant \u00E0 positionner. -->\n        @if (currentMode() === 'prelevement' && !readOnly() && remainingSampleLabels().length) {\n          <div class=\"ngf-sample-queue\" role=\"status\" aria-live=\"polite\">\n            \uD83D\uDCCD \u00C0 placer : <strong>{{ remainingSampleLabels().join(', ') }}</strong>\n          </div>\n        }\n      </div>\n\n      <div class=\"ngf-editor__header-right\">\n\n        @if (!readOnly()) {\n          <!-- Modes m\u00E9tier (cumulables) -->\n          <div class=\"ngf-workmodes\" title=\"Modes m\u00E9tier \u2014 cumulables. Filtrent les outils visibles dans la barre lat\u00E9rale.\">\n            @for (m of workModeDefs; track m.id) {\n              <button type=\"button\"\n                class=\"ngf-workmode\"\n                [class.ngf-workmode--active]=\"isWorkModeActive(m.id)\"\n                [style.--wm-color]=\"m.color\"\n                (click)=\"toggleWorkMode(m.id)\"\n                [title]=\"m.label\">\n                <span class=\"ngf-workmode__icon\">{{ m.icon }}</span>\n                {{ m.shortLabel }}\n              </button>\n            }\n          </div>\n\n          <div class=\"ngf-h-divider\"></div>\n        }\n\n        <!-- Niveaux : visibles aussi en lecture seule pour naviguer entre \u00E9tages,\n             mais le \"+\" et la copie de murs (\u00E9dition) sont masqu\u00E9s. -->\n        <div class=\"ngf-floor-tabs\">\n          @for (floor of sortedFloors(); track floor.id) {\n            <button class=\"ngf-floor-tab\"\n              [class.ngf-floor-tab--active]=\"currentFloorId() === floor.id\"\n              (click)=\"switchFloor(floor.id)\">\n              {{ floor.name }}\n            </button>\n          }\n          @if (!readOnly()) {\n            <button class=\"ngf-floor-tab ngf-floor-tab--add\" (click)=\"openAddFloorModal()\" title=\"Ajouter un niveau\">+</button>\n\n            @if (floors().length > 1) {\n              <div class=\"ngf-copy-from-wrap\">\n                <button class=\"ngf-floor-tab ngf-floor-tab--copy\" (click)=\"openCopyFromMenu()\" title=\"Copier les murs depuis un autre niveau\">\u29C9</button>\n                @if (showCopyFromMenu()) {\n                  <div class=\"ngf-copy-from-menu\">\n                    <div class=\"ngf-copy-from-menu__title\">Copier les murs de\u2026</div>\n                    @for (floor of sortedFloors(); track floor.id) {\n                      @if (floor.id !== currentFloorId()) {\n                        <button class=\"ngf-copy-from-menu__item\" (click)=\"copyWallsFromFloor(floor.id)\">\n                          {{ floor.name }}\n                        </button>\n                      }\n                    }\n                  </div>\n                }\n              </div>\n            }\n          }\n        </div>\n\n        <div class=\"ngf-h-divider\"></div>\n\n        @if (!readOnly()) {\n          <!-- \u00C9chelle : modifier le ratio px/m change la g\u00E9om\u00E9trie du projet \u2192 \u00E9dition -->\n          <div class=\"ngf-scale-ctrl\" [class.ngf-scale-ctrl--locked]=\"scaleLocked()\">\n            <span>\u00C9chelle</span>\n            <strong>{{ pixelsPerMeter() | number:'1.0-1' }} px/m</strong>\n            @if (scaleLocked()) {\n              <span class=\"ngf-scale-lock\" title=\"\u00C9chelle calcul\u00E9e depuis la carte \u2014 modifiez le slider pour d\u00E9verrouiller\">\uD83D\uDD12</span>\n            }\n            <input type=\"range\" min=\"1\" max=\"500\" step=\"0.5\"\n              [value]=\"pixelsPerMeter()\"\n              (input)=\"onScaleInput($event)\"\n              (change)=\"commitScaleChange($event)\" />\n          </div>\n\n          <div class=\"ngf-h-divider\"></div>\n        }\n\n        <!-- Cotes : pur affichage, conserv\u00E9 en lecture seule -->\n        <label class=\"ngf-toggle\" title=\"Afficher / masquer les cotes\">\n          <input type=\"checkbox\" [checked]=\"showMeasurements()\" (change)=\"toggleMeasurements()\" />\n          Cotes\n        </label>\n\n        <div class=\"ngf-h-divider\"></div>\n\n        <!-- Bascule 2D / 3D : non destructive, disponible en \u00E9dition comme en visualisation -->\n        <button class=\"ngf-btn-action ngf-btn-action--3d\"\n          [class.ngf-btn-action--active]=\"show3D()\"\n          (click)=\"toggle3D()\"\n          [title]=\"show3D() ? 'Revenir \u00E0 la vue 2D' : 'Afficher la vue 3D'\">\n          {{ show3D() ? '\uD83D\uDDFA Vue 2D' : '\uD83E\uDDCA Vue 3D' }}\n        </button>\n\n        <!-- Pi\u00E8ces : panneau de consultation. Masqu\u00E9 en lecture seule et tant\n             qu'il n'y a rien \u00E0 lister (pas de pi\u00E8ce ni de lin\u00E9aire r\u00E9seau). -->\n        @if (!readOnly()) {\n          @if (hasRoomListContent()) {\n            <button class=\"ngf-btn-action ngf-btn-action--osm\"\n              [class.ngf-btn-action--active]=\"showRoomList()\"\n              (click)=\"toggleRoomList()\" title=\"Liste des pi\u00E8ces\">\uD83D\uDCCB Pi\u00E8ces</button>\n          }\n\n          <button class=\"ngf-btn-action ngf-btn-action--tpl\" (click)=\"openTemplateModal()\" title=\"Partir d'un mod\u00E8le d'appartement\">\u22A1 Mod\u00E8les</button>\n        }\n\n        <div class=\"ngf-h-divider\"></div>\n\n        @if (!readOnly()) {\n        <!-- \u2500\u2500 Dropdown Fond \u2500\u2500 -->\n        <div class=\"ngf-dropdown-wrap\">\n          <button class=\"ngf-btn-action ngf-btn-action--osm\"\n            [class.ngf-btn-action--active]=\"showFondMenu()\"\n            (click)=\"toggleFondMenu()\"\n            title=\"Image de fond & carte\">\n            \uD83D\uDDBC Fond \u25BE\n          </button>\n          @if (showFondMenu()) {\n            <div class=\"ngf-dropdown-panel ngf-dropdown-panel--fond\">\n              <div class=\"ngf-dropdown-panel__title\">Fond de plan</div>\n\n              <button class=\"ngf-dropdown-panel__item\" (click)=\"openOsmModal(); showFondMenu.set(false)\">\n                \uD83D\uDDFA Importer depuis la carte\n              </button>\n\n              <label class=\"ngf-dropdown-panel__item\">\n                \uD83D\uDCF7 Charger une image\u2026\n                <input type=\"file\" accept=\"image/png,image/jpeg\" (change)=\"loadBackgroundImage($event); showFondMenu.set(false)\" hidden />\n              </label>\n\n              @if (hasBackdrop()) {\n                <div class=\"ngf-dropdown-panel__sep\"></div>\n                <div class=\"ngf-dropdown-panel__row\">\n                  <label class=\"ngf-dropdown-panel__toggle\">\n                    <input type=\"checkbox\" [checked]=\"backgroundLocked()\" (change)=\"toggleBackgroundLock()\" />\n                    \uD83D\uDD12 Verrouiller\n                  </label>\n                </div>\n                <div class=\"ngf-dropdown-panel__row\">\n                  <span class=\"ngf-dropdown-panel__label\">Rotation</span>\n                  <input type=\"range\" min=\"-90\" max=\"90\" step=\"0.5\"\n                    [value]=\"bgRotation()\"\n                    (input)=\"updateBackgroundRotation($event)\"\n                    (mousedown)=\"showGridOverlay()\"\n                    (mouseup)=\"hideGridOverlay()\"\n                    style=\"flex:1; accent-color: var(--primary)\" />\n                  <span class=\"ngf-dropdown-panel__val\">{{ bgRotation() }}\u00B0</span>\n                </div>\n                <div class=\"ngf-dropdown-panel__sep\"></div>\n                <button class=\"ngf-dropdown-panel__item ngf-dropdown-panel__item--danger\"\n                  (click)=\"removeBackdrop(); showFondMenu.set(false)\">\n                  \u2715 Supprimer le fond\n                </button>\n              }\n            </div>\n          }\n        </div>\n        } <!-- /@if (!readOnly()) \u2014 fin dropdown Fond -->\n\n        <!-- \u2500\u2500 Dropdown Fichier \u2500\u2500 (Exports conserv\u00E9s en lecture seule) -->\n        <div class=\"ngf-dropdown-wrap\">\n          <button class=\"ngf-btn-action ngf-btn-action--save\"\n            [class.ngf-btn-action--active]=\"showFichierMenu()\"\n            (click)=\"toggleFichierMenu()\"\n            [title]=\"readOnly() ? 'Exporter le plan' : 'Sauvegarder, ouvrir et exporter'\">\n            \uD83D\uDCC1 {{ readOnly() ? 'Exporter' : 'Fichier' }} \u25BE\n          </button>\n          @if (showFichierMenu()) {\n            <div class=\"ngf-dropdown-panel ngf-dropdown-panel--right\">\n              @if (!readOnly()) {\n                <div class=\"ngf-dropdown-panel__title\">Projet</div>\n                <button class=\"ngf-dropdown-panel__item\" (click)=\"saveProject(); showFichierMenu.set(false)\">\n                  \u2193 Enregistrer (JSON)\n                </button>\n                <label class=\"ngf-dropdown-panel__item\">\n                  \u2191 Ouvrir un projet\u2026\n                  <input type=\"file\" accept=\".json\" (change)=\"loadProject($event); showFichierMenu.set(false)\" hidden />\n                </label>\n                <div class=\"ngf-dropdown-panel__sep\"></div>\n              }\n              <div class=\"ngf-dropdown-panel__title\">Exporter</div>\n              <button class=\"ngf-dropdown-panel__item\" (click)=\"exportJPG(); showFichierMenu.set(false)\">\n                \u2193 JPEG\n              </button>\n              <button class=\"ngf-dropdown-panel__item\" (click)=\"exportPNG(); showFichierMenu.set(false)\">\n                \u2193 PNG haute r\u00E9solution\n              </button>\n              <button class=\"ngf-dropdown-panel__item\" (click)=\"exportSVG(); showFichierMenu.set(false)\">\n                \u2193 SVG vectoriel\n              </button>\n            </div>\n          }\n        </div>\n\n      </div>\n    </header>\n  }\n\n  <div class=\"ngf-editor__workspace\">\n\n    @if (showSidebar() && mobileSidebarOpen() && !readOnly()) {\n      <div class=\"ngf-mobile-backdrop\" (click)=\"closeMobileSidebar()\"></div>\n    }\n\n    @if (showSidebar() && !readOnly()) {\n      <aside class=\"ngf-editor__sidebar\"\n        [class.ngf-editor__sidebar--mobile-open]=\"mobileSidebarOpen()\">\n        <!-- \u2500\u2500 Actions contextuelles (en haut, toujours visibles) \u2500\u2500 -->\n        @if (currentMode() === 'room-sketch') {\n          <div class=\"ngf-ctx-actions ngf-ctx-actions--top\">\n            <div class=\"ngf-sidebar__group-title\">Croquis</div>\n            <button class=\"ngf-tool-item ngf-tool-item--action\" (click)=\"generateEnvelope()\"\n              title=\"Convertir les pi\u00E8ces en murs et cloisons\">\n              \u2B07 G\u00E9n\u00E9rer l'enveloppe\n            </button>\n          </div>\n        }\n\n        @if (inspectorData()?.objectType === 'RoomBox') {\n          <div class=\"ngf-ctx-actions ngf-ctx-actions--top\">\n            <div class=\"ngf-sidebar__group-title\">Dimensions pi\u00E8ce</div>\n            <div class=\"ngf-calibrate\">\n              <div class=\"ngf-calibrate__row\">\n                <span class=\"ngf-calibrate__label\" style=\"min-width:20px;font-weight:700\">L</span>\n                <input class=\"ngf-calibrate__input\" type=\"number\" min=\"0.01\" step=\"0.1\"\n                  [value]=\"roomBoxWidthM()\"\n                  (input)=\"roomBoxWidthM.set($any($event.target).value)\"\n                  placeholder=\"larg. (m)\" />\n              </div>\n              <div class=\"ngf-calibrate__row\">\n                <span class=\"ngf-calibrate__label\" style=\"min-width:20px;font-weight:700\">H</span>\n                <input class=\"ngf-calibrate__input\" type=\"number\" min=\"0.01\" step=\"0.1\"\n                  [value]=\"roomBoxHeightM()\"\n                  (input)=\"roomBoxHeightM.set($any($event.target).value)\"\n                  placeholder=\"haut. (m)\" />\n              </div>\n              <button class=\"ngf-tool-item ngf-tool-item--action\" (click)=\"applyRoomBoxDimensions()\"\n                title=\"Redimensionner selon les cotes \u00D7 PPM courant\">\n                \u2713 Appliquer\n              </button>\n            </div>\n          </div>\n        }\n\n        @if (inspectorData()?.objectType === 'Mur' || inspectorData()?.objectType === 'Cloison') {\n          <div class=\"ngf-ctx-actions ngf-ctx-actions--top\">\n            <div class=\"ngf-sidebar__group-title\">\n              @if (inspectorData()?.objectType === 'Cloison') { Cloison s\u00E9lectionn\u00E9e } @else { Mur s\u00E9lectionn\u00E9 }\n            </div>\n            <button class=\"ngf-tool-item ngf-tool-item--action\" (click)=\"toggleSelectedWallType()\"\n              title=\"Basculer entre mur porteur et cloison\">\n              \u21CC @if (inspectorData()?.objectType === 'Mur') { En cloison } @else { En mur porteur }\n            </button>\n            <div class=\"ngf-calibrate\">\n              <span class=\"ngf-calibrate__label\">\uD83D\uDCCF Calibrer</span>\n              <div class=\"ngf-calibrate__row\">\n                <input class=\"ngf-calibrate__input\" type=\"number\" min=\"0.01\" step=\"0.01\"\n                  [value]=\"calibrationLength()\"\n                  (input)=\"calibrationLength.set($any($event.target).value)\"\n                  placeholder=\"longueur r\u00E9elle (m)\" />\n                <button class=\"ngf-calibrate__btn\" (click)=\"applyCalibration()\" title=\"Appliquer la calibration\">\u2194</button>\n              </div>\n            </div>\n          </div>\n        }\n\n        <!-- \u2500\u2500 Outils (filtr\u00E9s par les modes m\u00E9tier actifs) \u2500\u2500 -->\n        @for (group of visibleToolGroups(); track group.label) {\n          <h3 class=\"ngf-sidebar__group-title\">{{ group.label }}</h3>\n          @for (tool of group.tools; track tool.mode) {\n            <button class=\"ngf-tool-item\"\n              [class.ngf-tool-item--active]=\"currentMode() === tool.mode\"\n              [attr.data-mode]=\"tool.mode\"\n              (click)=\"setMode(tool.mode)\"\n              [title]=\"tool.label + (tool.shortcut ? ' (' + tool.shortcut + ')' : '')\">\n              <span class=\"tool-icon-wrap\">{{ tool.icon }}</span>\n              {{ tool.label }}\n              @if (tool.shortcut) {\n                <span class=\"tool-shortcut\">{{ tool.shortcut }}</span>\n              }\n            </button>\n          }\n        }\n\n        <div style=\"flex: 1\"></div>\n      </aside>\n    }\n\n    <div class=\"ngf-editor__canvas-area\" #canvasArea>\n      <canvas #fabricCanvas [width]=\"canvasWidth()\" [height]=\"canvasHeight()\"></canvas>\n      <div class=\"ngf-alignment-grid\"></div>\n\n      @if (isLoading()) {\n        <div class=\"ngf-loading-overlay\">Chargement du projet\u2026</div>\n      }\n\n      @if (showFloorBadge()) {\n        <div class=\"ngf-floor-badge\">{{ currentFloorName() }}</div>\n      }\n    </div>\n\n    @if (showRoomList() && !readOnly() && hasRoomListContent()) {\n      <aside class=\"ngf-room-list\">\n        <div class=\"ngf-room-list__header\">Pi\u00E8ces</div>\n\n        @for (floor of roomsByFloor(); track floor.floorId) {\n          <div class=\"ngf-room-list__floor\">\n            <div class=\"ngf-room-list__floor-name\">{{ floor.floorName }}</div>\n            @if (floor.rooms.length === 0) {\n              <div class=\"ngf-room-list__empty\">Aucune pi\u00E8ce d\u00E9tect\u00E9e</div>\n            }\n            @for (room of floor.rooms; track $index) {\n              <div class=\"ngf-room-list__room\"\n                (click)=\"selectRoomFromList(floor.floorId, room.label, room.areaM2)\"\n                title=\"S\u00E9lectionner cette pi\u00E8ce\">\n                <span class=\"ngf-room-list__room-name\">{{ room.label || '(sans nom)' }}</span>\n                <span class=\"ngf-room-list__room-area\">{{ room.areaM2 | number:'1.1-1' }} m\u00B2</span>\n              </div>\n            }\n            @if (floor.rooms.length > 0) {\n              <div class=\"ngf-room-list__total\">\n                <span>Total</span>\n                <span>{{ floor.totalArea | number:'1.1-1' }} m\u00B2</span>\n              </div>\n            }\n          </div>\n        }\n        @if (pipeEntries().length > 0) {\n          <div class=\"ngf-room-list__header ngf-room-list__header--pipes\">Lin\u00E9aires r\u00E9seaux</div>\n          @for (entry of pipeEntries(); track entry.label) {\n            <div class=\"ngf-room-list__room ngf-room-list__room--pipe\">\n              <span class=\"ngf-room-list__room-name\">{{ entry.label }}</span>\n              <span class=\"ngf-room-list__room-area\">{{ entry.lengthM | number:'1.1-1' }} m</span>\n            </div>\n          }\n        }\n      </aside>\n    }\n\n    <aside class=\"ngf-inspector\" [class.ngf-inspector--active]=\"showInspector()\">\n      <ng-gplan-inspector-panel\n        [data]=\"inspectorData()\"\n        [readOnly]=\"readOnly()\"\n        (dataChange)=\"onInspectorChange($event)\"\n      />\n      <!-- Suppression de l'\u00E9l\u00E9ment s\u00E9lectionn\u00E9 \u2014 indispensable sur tactile\n           (pas de touche Suppr comme sur PC). Masqu\u00E9e en mode visualisation. -->\n      @if (!readOnly()) {\n        <button class=\"ngf-inspector-delete-btn\" type=\"button\"\n          (click)=\"deleteActive()\"\n          title=\"Supprimer l'\u00E9l\u00E9ment s\u00E9lectionn\u00E9 (touche Suppr au clavier)\">\n          \uD83D\uDDD1 Supprimer l'\u00E9l\u00E9ment\n        </button>\n      }\n    </aside>\n\n    <!-- Vue 3D : superpos\u00E9e \u00E0 TOUT le workspace (sidebar + canvas + inspecteur)\n         pour qu'aucune zone 2D ne reste visible autour. Toggle non destructif. -->\n    @if (show3D()) {\n      <div class=\"ngf-viewer3d-overlay\">\n        <ng-gplan-viewer-3d [project]=\"project3D()\" />\n      </div>\n    }\n\n  </div>\n\n  @if (isOsmModalOpen()) {\n    <ng-gplan-osm-modal\n      [config]=\"config\"\n      (import)=\"onOsmImport($event)\"\n      (close)=\"closeOsmModal()\"\n    />\n  }\n\n  @if (isTemplateModalOpen()) {\n    <ng-gplan-template-modal\n      (close)=\"closeTemplateModal()\"\n      (templateSelected)=\"loadTemplate($event)\"\n    />\n  }\n\n  <!-- Modal ajout d'un niveau -->\n  @if (showAddFloorModal()) {\n    <div class=\"ngf-modal-overlay\" (click)=\"cancelAddFloor()\">\n      <div class=\"ngf-add-floor-modal\" (click)=\"$event.stopPropagation()\">\n        <h3 class=\"ngf-add-floor-modal__title\">Ajouter un niveau</h3>\n\n        <div class=\"ngf-add-floor-modal__direction\">\n          <button class=\"ngf-add-floor-modal__dir-btn\"\n            [class.ngf-add-floor-modal__dir-btn--active]=\"newFloorDirection() === 'above'\"\n            (click)=\"setAddFloorDirection('above')\">\n            \u2191 En hauteur\n          </button>\n          <button class=\"ngf-add-floor-modal__dir-btn\"\n            [class.ngf-add-floor-modal__dir-btn--active]=\"newFloorDirection() === 'below'\"\n            (click)=\"setAddFloorDirection('below')\">\n            \u2193 En sous-sol\n          </button>\n        </div>\n\n        <label class=\"ngf-add-floor-modal__label\">Nom du niveau</label>\n        <input class=\"ngf-add-floor-modal__input\" type=\"text\"\n          [value]=\"newFloorName()\"\n          (input)=\"newFloorName.set($any($event.target).value)\"\n          placeholder=\"ex : \u00C9tage 1\" />\n\n        <div class=\"ngf-add-floor-modal__actions\">\n          <button class=\"ngf-add-floor-modal__cancel\" (click)=\"cancelAddFloor()\">Annuler</button>\n          <button class=\"ngf-add-floor-modal__confirm\" (click)=\"confirmAddFloor()\">Cr\u00E9er le niveau</button>\n        </div>\n      </div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{--z-50: #fafafa;--z-100: #f5f5f5;--z-200: #e5e5e5;--z-300: #d4d4d4;--z-400: #a3a3a3;--z-500: #737373;--z-600: #525252;--z-700: #404040;--z-800: #262626;--z-900: #171717;--primary: #f97316;--primary-hover: #ea580c;--primary-dark: #c2410c;--primary-light: #fff7ed;--primary-border: #fed7aa;--primary-text: #9a3412;--success: #16a34a;--danger: #dc2626;--warn: #d97706;--info: #0284c7;--purple: #7c3aed;--teal: #0d9488;--radius-sm: 4px;--radius: 8px;--radius-lg: 12px;--radius-xl: 16px;--shadow-sm: 0 1px 3px rgba(0,0,0,.08);--shadow: 0 2px 8px rgba(0,0,0,.08), 0 0 0 1px rgba(0,0,0,.04);--shadow-lg: 0 8px 24px rgba(0,0,0,.1);--font: \"Poppins\", ui-sans-serif, system-ui, sans-serif;--font-mono: \"DM Mono\", ui-monospace, monospace;display:flex;flex-direction:column;height:100%;font-family:var(--font)}.ngf-editor{display:flex;flex-direction:column;height:100%;min-height:0;background:#f5f4f2}.ngf-editor__header{min-height:52px;padding:5px 14px;background:#fff;border-bottom:1px solid var(--z-200);display:flex;align-items:center;flex-wrap:wrap;gap:6px;flex-shrink:0;z-index:20;overflow:visible;box-shadow:0 1px 4px #0000000f}.ngf-editor__header-left,.ngf-editor__header-right{display:flex;align-items:center;flex-wrap:wrap;gap:5px}.ngf-editor__header-left{flex:1}.ngf-editor__header-right{flex-shrink:0}.ngf-editor__title{font-size:13px;font-weight:800;letter-spacing:.01em;color:#fff;background:var(--primary);padding:4px 10px;border-radius:var(--radius);white-space:nowrap;margin-right:8px;line-height:1}.ngf-editor__workspace{display:flex;flex:1;min-height:0;overflow:hidden;position:relative}.ngf-editor__sidebar{width:200px;background:#fff;border-right:1px solid var(--z-200);padding:8px 6px;display:flex;flex-direction:column;gap:1px;overflow-y:auto;flex-shrink:0;box-shadow:2px 0 8px #0000000a}.ngf-editor__sidebar::-webkit-scrollbar{width:3px}.ngf-editor__sidebar::-webkit-scrollbar-thumb{background:var(--z-200);border-radius:2px}.ngf-editor__canvas-area{flex:1;overflow:auto;position:relative;display:flex;justify-content:safe center;align-items:safe center;background:#f0ede8;background-image:radial-gradient(circle,#d6d2cc 1px,transparent 1px);background-size:24px 24px;background-position:12px 12px}.ngf-viewer3d-overlay{position:absolute;inset:0;z-index:50;display:flex;background:#f0ede8}.ngf-viewer3d-overlay ng-gplan-viewer-3d{flex:1;min-width:0;min-height:0}.ngf-h-divider{width:1px;height:22px;background:var(--z-200);flex-shrink:0;margin:0 3px}.ngf-workmodes{display:inline-flex;align-items:center;gap:4px;padding:2px;border-radius:100px;background:var(--z-100, #f1f5f9);border:1px solid var(--z-200, #e2e8f0)}.ngf-workmode{--wm-color: #6366f1;height:24px;padding:0 10px;border:none;background:transparent;border-radius:100px;cursor:pointer;font-size:11px;font-family:var(--font);font-weight:600;color:var(--z-500);display:inline-flex;align-items:center;gap:4px;white-space:nowrap;transition:background .12s,color .12s;-webkit-user-select:none;user-select:none}.ngf-workmode__icon{font-size:13px;line-height:1}.ngf-workmode:hover{background:#6366f10f;color:var(--wm-color)}.ngf-workmode--active{background:var(--wm-color);color:#fff;font-weight:700;box-shadow:0 1px 2px #00000014}.ngf-stats-badge{display:flex;align-items:center;gap:8px;padding:4px 12px;background:var(--primary-light);border:1px solid var(--primary-border);color:var(--primary-text);border-radius:100px;font-size:11px;font-weight:600;font-family:var(--font-mono);white-space:nowrap}.ngf-stat-sep{color:var(--primary-border);font-weight:400}.ngf-stat-global{font-weight:600;color:var(--primary);opacity:.85}.ngf-icon-btn{height:32px;padding:0 11px;border:1px solid var(--z-200);background:transparent;border-radius:var(--radius);cursor:pointer;font-size:12px;font-family:var(--font);color:var(--z-600);white-space:nowrap;transition:background .12s,border-color .12s,color .12s;display:inline-flex;align-items:center;gap:4px}.ngf-icon-btn:hover:not(:disabled){background:var(--primary-light);border-color:var(--primary-border);color:var(--primary)}.ngf-icon-btn:disabled{opacity:.35;cursor:not-allowed}.ngf-scale-ctrl{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--z-500);white-space:nowrap}.ngf-scale-ctrl strong{color:var(--primary);font-family:var(--font-mono);font-weight:700}.ngf-scale-ctrl input[type=range]{width:72px;accent-color:var(--primary);cursor:pointer}.ngf-scale-ctrl--locked{background:var(--primary-light);border:1px solid var(--primary-border);border-radius:var(--radius);padding:3px 8px}.ngf-scale-ctrl--locked strong{color:var(--primary-hover)}.ngf-scale-lock{font-size:11px;cursor:help}.ngf-toggle{display:inline-flex;align-items:center;gap:5px;font-size:11px;color:var(--z-500);cursor:pointer;white-space:nowrap;-webkit-user-select:none;user-select:none}.ngf-toggle input[type=checkbox]{accent-color:var(--primary);cursor:pointer;width:14px;height:14px}.ngf-toggle:hover{color:var(--primary)}.ngf-floor-tabs{display:flex;align-items:center;gap:3px}.ngf-floor-tab{height:28px;padding:0 12px;border:1px solid var(--z-200);background:transparent;border-radius:100px;cursor:pointer;font-size:11px;font-family:var(--font);font-weight:600;color:var(--z-500);white-space:nowrap;transition:background .12s,color .12s,border-color .12s}.ngf-floor-tab:hover{background:var(--primary-light);border-color:var(--primary-border);color:var(--primary)}.ngf-floor-tab--active{background:var(--primary);color:#fff;border-color:var(--primary);font-weight:700}.ngf-floor-tab--add{padding:0 10px;font-size:18px;font-weight:300;color:var(--z-300);border-style:dashed}.ngf-floor-tab--add:hover{color:var(--primary);border-color:var(--primary-border);background:var(--primary-light)}.ngf-btn-action{height:32px;padding:0 12px;border:none;border-radius:var(--radius);cursor:pointer;font-size:11px;font-family:var(--font);font-weight:700;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;transition:filter .1s,opacity .1s;color:#fff;letter-spacing:.01em}.ngf-btn-action:hover{filter:brightness(.9)}.ngf-btn-action--save{background:var(--primary)}.ngf-btn-action--load{background:var(--z-600)}.ngf-btn-action--jpg{background:var(--success)}.ngf-btn-action--png{background:var(--info)}.ngf-btn-action--svg{background:var(--purple)}.ngf-btn-action--bg{background:var(--z-500)}.ngf-btn-action--remove-bg{background:var(--danger, #ef4444)}.ngf-btn-action--tpl{background:#6366f1}.ngf-btn-action--3d{background:#0ea5e9}.ngf-btn-action--active,.ngf-btn-action--osm.ngf-btn-action--active{background:var(--primary);color:#fff;border-color:transparent;filter:none}.ngf-btn-action--osm{background:transparent;color:var(--z-600);border:1px solid var(--z-200)}.ngf-btn-action--osm:hover{background:var(--primary-light);border-color:var(--primary-border);color:var(--primary);filter:none}.ngf-sidebar__group-title{margin:12px 0 4px 8px;font-size:9px;text-transform:uppercase;letter-spacing:.12em;font-weight:800;color:var(--z-400)}.ngf-sidebar__group-title:first-child{margin-top:6px}.ngf-tool-item{position:relative;padding:7px 10px 7px 8px;cursor:pointer;border:none;background:transparent;border-radius:var(--radius);text-align:left;width:100%;transition:background .1s,color .1s;font-size:12px;font-family:var(--font);font-weight:500;color:var(--z-700);display:flex;align-items:center;gap:9px;line-height:1}.ngf-tool-item:hover:not(.ngf-tool-item--active):not(.ngf-tool-item--danger){background:var(--primary-light);color:var(--primary)}.ngf-tool-item:hover:not(.ngf-tool-item--active):not(.ngf-tool-item--danger) .tool-icon-wrap{background:var(--primary-border)}.ngf-tool-item--active{background:var(--primary)!important;color:#fff!important;font-weight:700}.ngf-tool-item--active .tool-icon-wrap{background:#fff3!important}.ngf-tool-item--active .tool-shortcut{background:#ffffff2e;color:#ffffffd9}.ngf-tool-item--danger{margin-top:8px;border-top:1px solid var(--z-100);padding-top:10px;color:var(--danger);justify-content:center;font-size:11px;font-weight:700;border-radius:0;background:none}.ngf-tool-item--danger:hover{background:#fef2f2;color:#b91c1c;border-radius:var(--radius)}.ngf-tool-item .tool-icon{display:none}.ngf-tool-item .tool-icon-wrap{width:26px;height:26px;border-radius:7px;background:var(--primary-light);display:flex;align-items:center;justify-content:center;font-size:13px;flex-shrink:0;transition:background .1s}.ngf-tool-item .tool-shortcut{margin-left:auto;font-size:9px;color:var(--z-400);font-family:var(--font-mono);font-weight:600;background:var(--z-100);padding:1px 5px;border-radius:3px}.ngf-ctx-actions{display:flex;flex-direction:column;gap:4px}.ngf-ctx-actions--top{border-bottom:1px solid var(--z-100);padding-bottom:8px;margin-bottom:4px}.ngf-tool-item--action{background:var(--primary-light);color:var(--primary-text);font-weight:600;border-radius:var(--radius)}.ngf-tool-item--action:hover{background:var(--primary);color:#fff}.ngf-calibrate{display:flex;flex-direction:column;gap:4px;padding:6px 8px}.ngf-calibrate__label{font-size:10px;font-weight:700;color:var(--z-500);text-transform:uppercase;letter-spacing:.04em}.ngf-calibrate__row{display:flex;gap:4px;align-items:center}.ngf-calibrate__input{flex:1;min-width:0;padding:4px 6px;border:1.5px solid var(--z-200);border-radius:var(--radius-sm);font-size:11px;font-family:var(--font-mono);color:var(--z-800);background:#fff}.ngf-calibrate__input:focus{outline:none;border-color:var(--info)}.ngf-calibrate__btn{padding:4px 8px;background:var(--info);color:#fff;border:none;border-radius:var(--radius-sm);cursor:pointer;font-size:13px;font-weight:700;flex-shrink:0}.ngf-calibrate__btn:hover{background:#0369a1}.ngf-inspector{width:224px;background:#fff;border-left:1px solid var(--z-200);padding:16px 12px;display:none;flex-direction:column;gap:12px;overflow-y:auto;flex-shrink:0;box-shadow:-2px 0 8px #0000000a}.ngf-inspector--active{display:flex;animation:slideIn .15s ease-out}.ngf-inspector-delete-btn{display:flex;align-items:center;justify-content:center;gap:6px;flex-shrink:0;width:100%;min-height:40px;padding:8px 14px;background:var(--danger);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;font-size:12px;font-weight:700;font-family:var(--font);white-space:nowrap;touch-action:manipulation;transition:filter .1s,transform .08s}.ngf-inspector-delete-btn:hover{filter:brightness(1.1)}.ngf-inspector-delete-btn:active{transform:scale(.97)}@media(pointer:coarse){.ngf-inspector-delete-btn{min-height:44px;font-size:13px}}@keyframes slideIn{0%{opacity:0;transform:translate(8px)}to{opacity:1;transform:translate(0)}}.ngf-room-list{width:200px;flex-shrink:0;background:#fff;border-left:1px solid var(--z-200);display:flex;flex-direction:column;overflow-y:auto;box-shadow:-2px 0 8px #0000000a;animation:slideIn .15s ease-out}.ngf-room-list__header{padding:10px 12px 8px;font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--z-400);border-bottom:1px solid var(--z-100)}.ngf-room-list__floor{padding:8px 12px;border-bottom:1px solid var(--z-100)}.ngf-room-list__floor:last-child{border-bottom:none}.ngf-room-list__floor-name{font-size:11px;font-weight:700;color:var(--primary-text);background:var(--primary-light);border:1px solid var(--primary-border);border-radius:var(--radius-sm);padding:2px 7px;margin-bottom:6px;display:inline-block}.ngf-room-list__empty{font-size:11px;color:var(--z-400);font-style:italic;padding:2px 0}.ngf-room-list__room{display:flex;justify-content:space-between;align-items:baseline;gap:4px;padding:3px 4px;font-size:12px;border-bottom:1px solid var(--z-100);border-radius:var(--radius-sm);cursor:pointer;transition:background .1s}.ngf-room-list__room:last-of-type{border-bottom:none}.ngf-room-list__room:hover{background:var(--primary-light)}.ngf-room-list__room:hover .ngf-room-list__room-name{color:var(--primary-text)}.ngf-room-list__room-name{color:var(--z-700);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:110px}.ngf-room-list__room-area{color:var(--z-500);font-size:11px;white-space:nowrap;flex-shrink:0}.ngf-room-list__total{display:flex;justify-content:space-between;padding:4px 0 0;margin-top:2px;font-size:11px;font-weight:700;color:var(--z-600);border-top:1px solid var(--z-200)}.ngf-room-list__header--pipes{margin-top:4px;border-top:2px solid var(--z-200);color:#0369a1}.ngf-room-list__room--pipe{cursor:default}.ngf-room-list__room--pipe:hover{background:#f0f9ff}.ngf-room-list__room--pipe .ngf-room-list__room-name{color:#0369a1;font-weight:600}.ngf-room-list__room--pipe .ngf-room-list__room-area{color:#0284c7;font-weight:600}.ngf-alignment-grid{position:absolute;inset:0;pointer-events:none;z-index:100;display:none;background-image:linear-gradient(rgba(220,38,38,.18) 1px,transparent 1px),linear-gradient(90deg,rgba(220,38,38,.18) 1px,transparent 1px);background-size:48px 48px}.ngf-alignment-grid--visible{display:block}.ngf-floor-badge{position:absolute;top:50%;left:0;right:0;transform:translateY(-50%);text-align:center;font-size:clamp(40px,8vw,96px);font-weight:900;letter-spacing:.12em;text-transform:uppercase;color:#0000000a;pointer-events:none;-webkit-user-select:none;user-select:none;line-height:1;z-index:1;white-space:nowrap;overflow:hidden}.ngf-mode-info{display:inline-flex;align-items:center;gap:6px;background:var(--primary);color:#fff;padding:6px 14px;border-radius:100px;font-size:12px;font-weight:600;white-space:nowrap;box-shadow:0 2px 8px #f973164d}.ngf-mode-info strong{font-weight:800}@media(pointer:coarse){.ngf-mode-info{min-height:36px;font-size:13px}}.ngf-sample-queue{display:inline-flex;align-items:center;gap:6px;background:#b45309;color:#fff;padding:6px 14px;border-radius:100px;font-size:12px;font-weight:600;white-space:nowrap;box-shadow:0 2px 8px #b453094d}.ngf-sample-queue strong{font-weight:800}@media(pointer:coarse){.ngf-sample-queue{min-height:36px;font-size:13px}}.ngf-version-badge{display:inline-flex;align-items:center;padding:1px 6px;border-radius:100px;background:var(--z-100);border:1px solid var(--z-200);color:var(--z-500);font-family:var(--font-mono, monospace);font-size:10px;font-weight:600;line-height:1.4;letter-spacing:.01em;white-space:nowrap;-webkit-user-select:text;user-select:text;flex-shrink:0}.ngf-readonly-badge{display:inline-flex;align-items:center;gap:6px;background:#475569;color:#fff;padding:5px 12px;border-radius:100px;font-size:12px;font-weight:700;letter-spacing:.02em;white-space:nowrap;box-shadow:0 1px 3px #0f172a33;-webkit-user-select:none;user-select:none}@media(pointer:coarse){.ngf-readonly-badge{min-height:32px;font-size:13px}}.ngf-finish-trace-btn{background:var(--primary);color:#fff;border:none;min-height:36px;padding:6px 16px;border-radius:100px;cursor:pointer;font-size:12px;font-weight:800;font-family:var(--font);letter-spacing:.02em;white-space:nowrap;touch-action:manipulation;box-shadow:0 2px 8px #f9731659;transition:filter .1s,transform .08s}.ngf-finish-trace-btn:hover{filter:brightness(1.08)}.ngf-finish-trace-btn:active{transform:scale(.96)}@media(pointer:coarse){.ngf-finish-trace-btn{min-height:44px;font-size:13px;padding:8px 20px}}.ngf-loading-overlay{position:absolute;inset:0;background:#ffffffd9;backdrop-filter:blur(4px);display:flex;flex-direction:column;justify-content:center;align-items:center;z-index:5000;gap:12px;font-size:13px;font-weight:600;color:var(--z-500)}.ngf-loading-overlay:before{content:\"\";width:28px;height:28px;border:3px solid var(--primary-border);border-top-color:var(--primary);border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}.ngf-surface-disclaimer{font-size:9px;font-weight:600;opacity:.7;letter-spacing:.02em;color:var(--primary);cursor:help}.ngf-sep{color:#ffffff40}.ngf-autosave-banner{display:flex;align-items:center;gap:10px;padding:9px 16px;background:#fffbeb;border-bottom:1px solid #fde68a;font-size:12px;color:#92400e;flex-shrink:0}.ngf-autosave-banner span{flex:1}.ngf-autosave-banner__restore{padding:5px 14px;background:var(--primary);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;font-size:11px;font-weight:700;font-family:var(--font)}.ngf-autosave-banner__restore:hover{background:var(--primary-hover)}.ngf-autosave-banner__dismiss{padding:5px 12px;background:transparent;color:#92400e;border:1px solid #fcd34d;border-radius:var(--radius);cursor:pointer;font-size:11px;font-family:var(--font)}.ngf-autosave-banner__dismiss:hover{background:#fef3c7}.ngf-copy-walls-banner{display:flex;align-items:center;gap:10px;padding:9px 16px;background:var(--primary-light);border-bottom:1px solid var(--primary-border);font-size:12px;color:var(--primary-text);flex-shrink:0}.ngf-copy-walls-banner span{flex:1}.ngf-copy-walls-banner__confirm{padding:5px 14px;background:var(--primary);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;font-size:11px;font-weight:700;font-family:var(--font)}.ngf-copy-walls-banner__confirm:hover{background:var(--primary-hover)}.ngf-copy-walls-banner__dismiss{padding:5px 12px;background:transparent;color:var(--primary-text);border:1px solid var(--primary-border);border-radius:var(--radius);cursor:pointer;font-size:11px;font-family:var(--font)}.ngf-copy-walls-banner__dismiss:hover{background:#fed7aa}.ngf-dropdown-wrap{position:relative}.ngf-dropdown-panel{position:absolute;top:calc(100% + 8px);left:0;min-width:220px;background:#fff;border:1px solid var(--z-200);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);z-index:300;overflow:hidden;animation:dropDown .12s ease-out}.ngf-dropdown-panel--right{left:auto;right:0}.ngf-dropdown-panel--fond{min-width:240px}.ngf-dropdown-panel__title{padding:8px 14px 5px;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:var(--z-400)}.ngf-dropdown-panel__item{display:flex;align-items:center;gap:8px;width:100%;padding:9px 14px;border:none;background:transparent;text-align:left;font-size:12px;font-family:var(--font);font-weight:500;color:var(--z-700);cursor:pointer;transition:background .1s,color .1s}.ngf-dropdown-panel__item:hover{background:var(--primary-light);color:var(--primary-text)}.ngf-dropdown-panel__item--danger{color:var(--danger)}.ngf-dropdown-panel__item--danger:hover{background:#fef2f2;color:#b91c1c}.ngf-dropdown-panel__sep{height:1px;background:var(--z-100);margin:4px 0}.ngf-dropdown-panel__row{display:flex;align-items:center;gap:8px;padding:6px 14px;font-size:11px;color:var(--z-600)}.ngf-dropdown-panel__label{white-space:nowrap;flex-shrink:0;font-size:11px}.ngf-dropdown-panel__val{white-space:nowrap;flex-shrink:0;font-size:10px;font-family:var(--font-mono);color:var(--primary);font-weight:700;min-width:28px;text-align:right}.ngf-dropdown-panel__toggle{display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--z-600);cursor:pointer;-webkit-user-select:none;user-select:none}.ngf-dropdown-panel__toggle input[type=checkbox]{accent-color:var(--primary);width:14px;height:14px;cursor:pointer}@keyframes dropDown{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.ngf-floor-tab--copy{padding:0 9px;font-size:14px;color:var(--z-400);border-style:dashed}.ngf-floor-tab--copy:hover{color:var(--primary);border-color:var(--primary-border);background:var(--primary-light)}.ngf-copy-from-wrap{position:relative}.ngf-copy-from-menu{position:absolute;top:calc(100% + 6px);right:0;min-width:160px;background:#fff;border:1px solid var(--z-200);border-radius:var(--radius);box-shadow:0 4px 16px #0000001f;z-index:200;overflow:hidden}.ngf-copy-from-menu__title{padding:7px 12px 5px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--z-400);border-bottom:1px solid var(--z-100)}.ngf-copy-from-menu__item{display:block;width:100%;padding:8px 12px;background:transparent;border:none;text-align:left;font-size:12px;font-family:var(--font);font-weight:600;color:var(--z-700);cursor:pointer}.ngf-copy-from-menu__item:hover{background:var(--primary-light);color:var(--primary)}.ngf-modal-overlay{position:absolute;inset:0;background:#00000059;display:flex;align-items:center;justify-content:center;z-index:500}.ngf-add-floor-modal{background:#fff;border-radius:12px;padding:24px;width:320px;box-shadow:0 8px 32px #0000002e;display:flex;flex-direction:column;gap:14px}.ngf-add-floor-modal__title{margin:0;font-size:15px;font-weight:700;color:var(--z-900)}.ngf-add-floor-modal__direction{display:flex;gap:8px}.ngf-add-floor-modal__dir-btn{flex:1;padding:9px 0;border:1px solid var(--z-200);border-radius:var(--radius);background:transparent;font-size:12px;font-family:var(--font);font-weight:600;color:var(--z-500);cursor:pointer;transition:all .12s}.ngf-add-floor-modal__dir-btn:hover{border-color:var(--primary-border);color:var(--primary);background:var(--primary-light)}.ngf-add-floor-modal__dir-btn--active{background:var(--primary);border-color:var(--primary);color:#fff}.ngf-add-floor-modal__label{font-size:11px;font-weight:700;color:var(--z-500);text-transform:uppercase;letter-spacing:.05em;margin-bottom:-8px}.ngf-add-floor-modal__input{width:100%;padding:9px 12px;border:1px solid var(--z-200);border-radius:var(--radius);font-size:13px;font-family:var(--font);color:var(--z-800);box-sizing:border-box;outline:none}.ngf-add-floor-modal__input:focus{border-color:var(--primary);box-shadow:0 0 0 2px var(--primary-light)}.ngf-add-floor-modal__actions{display:flex;gap:8px;justify-content:flex-end;margin-top:4px}.ngf-add-floor-modal__cancel{padding:8px 16px;background:transparent;border:1px solid var(--z-200);border-radius:var(--radius);font-size:12px;font-family:var(--font);font-weight:600;color:var(--z-500);cursor:pointer}.ngf-add-floor-modal__cancel:hover{background:var(--z-50)}.ngf-add-floor-modal__confirm{padding:8px 16px;background:var(--primary);border:none;border-radius:var(--radius);font-size:12px;font-family:var(--font);font-weight:700;color:#fff;cursor:pointer}.ngf-add-floor-modal__confirm:hover{background:var(--primary-hover)}:host{--gplan-touch-target-min: 44px;--gplan-mobile-bp: 768px}.ngf-mobile-menu-btn{display:none;width:36px;height:36px;background:transparent;border:1px solid var(--z-200);border-radius:var(--radius);font-size:18px;line-height:1;color:var(--z-700);cursor:pointer;flex-shrink:0}.ngf-mobile-menu-btn:hover{background:var(--z-100);color:var(--primary)}.ngf-mobile-backdrop{display:none;position:fixed;inset:0;background:#0f172a66;z-index:50;animation:fadeIn .18s ease-out}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.ngf-editor__canvas-area canvas,.ngf-editor__canvas-area .canvas-container{touch-action:none;-webkit-touch-callout:none;user-select:none;-webkit-user-select:none}@media(max-width:768px){.ngf-editor .ngf-editor__header{height:auto;padding:6px 8px;flex-wrap:wrap;gap:4px;overflow:visible}.ngf-editor .ngf-editor__header-left,.ngf-editor .ngf-editor__header-right{flex:1 1 100%;flex-wrap:wrap;overflow:visible;padding-bottom:2px}.ngf-editor .ngf-stats-badge,.ngf-editor .ngf-scale-ctrl,.ngf-editor .ngf-toggle,.ngf-editor .ngf-h-divider{display:none}.ngf-editor .ngf-editor__title{padding:3px 7px;font-size:11px;margin-right:4px}.ngf-editor .ngf-mobile-menu-btn{display:inline-flex;align-items:center;justify-content:center}.ngf-editor .ngf-workmodes{flex:1 1 100%;overflow-x:auto;overflow-y:visible;scrollbar-width:none;padding:2px 0}.ngf-editor .ngf-workmodes::-webkit-scrollbar{display:none}.ngf-editor .ngf-workmode{padding:0 9px;font-size:11px;height:26px;flex-shrink:0}.ngf-editor .ngf-floor-tabs{position:fixed;bottom:0;left:0;right:0;background:#fff;border-top:1px solid var(--z-200);box-shadow:0 -1px 4px #0000000f;padding:4px 8px;z-index:40;overflow-x:auto;justify-content:flex-start;gap:4px}.ngf-editor .ngf-floor-tab{height:var(--gplan-touch-target-min);min-width:56px;padding:0 14px;font-size:12px}.ngf-editor .ngf-editor__canvas-area{padding-bottom:calc(var(--gplan-touch-target-min) + 12px + env(safe-area-inset-bottom,0))}.ngf-editor .ngf-editor__sidebar{position:fixed;top:0;bottom:0;left:0;width:min(78vw,280px);z-index:60;transform:translate(-100%);transition:transform .22s ease-out;box-shadow:4px 0 16px #0000002e;padding-top:14px}.ngf-editor .ngf-editor__sidebar--mobile-open{transform:translate(0)}.ngf-editor .ngf-mobile-backdrop{display:block}.ngf-editor .ngf-tool-item{min-height:var(--gplan-touch-target-min);padding:9px 12px;font-size:13px}.ngf-editor .ngf-tool-item .tool-icon-wrap{width:30px;height:30px;font-size:15px}.ngf-editor .ngf-tool-item .tool-shortcut{display:none}.ngf-editor .ngf-sidebar__group-title{font-size:10px;margin-top:16px}.ngf-editor .ngf-inspector{position:fixed;left:0;right:0;bottom:calc(var(--gplan-touch-target-min) + 8px + env(safe-area-inset-bottom,0));width:100%;max-height:50vh;border-left:none;border-top:1px solid var(--z-200);border-radius:var(--radius-lg) var(--radius-lg) 0 0;box-shadow:0 -4px 18px #0000001a;padding:14px 14px 18px;z-index:35}.ngf-editor .ngf-inspector--active:before{content:\"\";display:block;width:36px;height:4px;background:var(--z-300);border-radius:2px;margin:-6px auto 10px}.ngf-editor .ngf-room-list{position:fixed;left:0;right:0;bottom:calc(var(--gplan-touch-target-min) + 8px + env(safe-area-inset-bottom,0));width:100%;max-height:40vh;border-left:none;border-top:1px solid var(--z-200);border-radius:var(--radius-lg) var(--radius-lg) 0 0;box-shadow:0 -4px 18px #0000001a;z-index:34}.ngf-editor .ngf-modal-overlay{padding:0}.ngf-editor .ngf-add-floor-modal{width:100vw;height:100vh;max-height:100dvh;border-radius:0;overflow-y:auto}.ngf-editor .ngf-icon-btn,.ngf-editor .ngf-btn-action{min-height:36px;padding:0 10px;font-size:11px}.ngf-editor .ngf-dropdown-panel{max-width:calc(100vw - 16px);max-height:60vh;overflow-y:auto;z-index:70}}.ngf-editor--compact .ngf-editor__header{height:auto;padding:6px 8px;flex-wrap:wrap;gap:4px;overflow:visible}.ngf-editor--compact .ngf-editor__header-left,.ngf-editor--compact .ngf-editor__header-right{flex:1 1 100%;flex-wrap:wrap;overflow:visible;padding-bottom:2px}.ngf-editor--compact .ngf-stats-badge,.ngf-editor--compact .ngf-scale-ctrl,.ngf-editor--compact .ngf-toggle,.ngf-editor--compact .ngf-h-divider{display:none}.ngf-editor--compact .ngf-editor__title{padding:3px 7px;font-size:11px;margin-right:4px}.ngf-editor--compact .ngf-mobile-menu-btn{display:inline-flex;align-items:center;justify-content:center}.ngf-editor--compact .ngf-workmodes{flex:1 1 100%;overflow-x:auto;overflow-y:visible;scrollbar-width:none;padding:2px 0}.ngf-editor--compact .ngf-workmodes::-webkit-scrollbar{display:none}.ngf-editor--compact .ngf-workmode{padding:0 9px;font-size:11px;height:26px;flex-shrink:0}.ngf-editor--compact .ngf-floor-tabs{position:fixed;bottom:0;left:0;right:0;background:#fff;border-top:1px solid var(--z-200);box-shadow:0 -1px 4px #0000000f;padding:4px 8px;z-index:40;overflow-x:auto;justify-content:flex-start;gap:4px}.ngf-editor--compact .ngf-floor-tab{height:var(--gplan-touch-target-min);min-width:56px;padding:0 14px;font-size:12px}.ngf-editor--compact .ngf-editor__canvas-area{padding-bottom:calc(var(--gplan-touch-target-min) + 12px + env(safe-area-inset-bottom,0))}.ngf-editor--compact .ngf-editor__sidebar{position:fixed;top:0;bottom:0;left:0;width:min(78vw,280px);z-index:60;transform:translate(-100%);transition:transform .22s ease-out;box-shadow:4px 0 16px #0000002e;padding-top:14px}.ngf-editor--compact .ngf-editor__sidebar--mobile-open{transform:translate(0)}.ngf-editor--compact .ngf-mobile-backdrop{display:block}.ngf-editor--compact .ngf-tool-item{min-height:var(--gplan-touch-target-min);padding:9px 12px;font-size:13px}.ngf-editor--compact .ngf-tool-item .tool-icon-wrap{width:30px;height:30px;font-size:15px}.ngf-editor--compact .ngf-tool-item .tool-shortcut{display:none}.ngf-editor--compact .ngf-sidebar__group-title{font-size:10px;margin-top:16px}.ngf-editor--compact .ngf-inspector{position:fixed;left:0;right:0;bottom:calc(var(--gplan-touch-target-min) + 8px + env(safe-area-inset-bottom,0));width:100%;max-height:50vh;border-left:none;border-top:1px solid var(--z-200);border-radius:var(--radius-lg) var(--radius-lg) 0 0;box-shadow:0 -4px 18px #0000001a;padding:14px 14px 18px;z-index:35}.ngf-editor--compact .ngf-inspector--active:before{content:\"\";display:block;width:36px;height:4px;background:var(--z-300);border-radius:2px;margin:-6px auto 10px}.ngf-editor--compact .ngf-room-list{position:fixed;left:0;right:0;bottom:calc(var(--gplan-touch-target-min) + 8px + env(safe-area-inset-bottom,0));width:100%;max-height:40vh;border-left:none;border-top:1px solid var(--z-200);border-radius:var(--radius-lg) var(--radius-lg) 0 0;box-shadow:0 -4px 18px #0000001a;z-index:34}.ngf-editor--compact .ngf-modal-overlay{padding:0}.ngf-editor--compact .ngf-add-floor-modal{width:100vw;height:100vh;max-height:100dvh;border-radius:0;overflow-y:auto}.ngf-editor--compact .ngf-icon-btn,.ngf-editor--compact .ngf-btn-action{min-height:36px;padding:0 10px;font-size:11px}.ngf-editor--compact .ngf-dropdown-panel{max-width:calc(100vw - 16px);max-height:60vh;overflow-y:auto;z-index:70}@media(max-height:500px)and (max-width:932px){.ngf-editor__header{padding:4px 6px;height:38px;flex-wrap:nowrap}.ngf-editor__header-left,.ngf-editor__header-right{flex:0 1 auto}.ngf-editor .ngf-floor-tabs{position:static;box-shadow:none;border-top:none;padding:0}.ngf-editor .ngf-floor-tab{height:28px;min-width:0;padding:0 10px}.ngf-editor .ngf-editor__canvas-area{padding-bottom:0}.ngf-editor .ngf-inspector,.ngf-editor .ngf-room-list{bottom:0;max-height:100%}}@media(pointer:coarse){.ngf-tool-item,.ngf-floor-tab,.ngf-icon-btn,.ngf-btn-action,.ngf-workmode,.ngf-mobile-menu-btn{min-height:var(--gplan-touch-target-min, 44px)}}.ngf-editor--readonly .ngf-editor__sidebar{opacity:.55;pointer-events:none}.ngf-editor--readonly .ngf-editor__sidebar .ngf-tool-item[data-mode=select],.ngf-editor--readonly .ngf-editor__sidebar .ngf-tool-item[data-mode=node-edit]{opacity:1;pointer-events:auto}\n"] }]
        }], ctorParameters: () => [] });

class FloorplanComponent {
    // ── INPUTS ──────────────────────────────────────────────
    project = model(null);
    layout = input('tabs');
    scannerParams = input({});
    /** Charge automatiquement un fond de carte depuis project.geo : 'osm' | 'satellite' | null */
    autoGeoLayer = input(null);
    /** Coordonnées GPS (lat/lng, zoom max par défaut) pour charger un fond de carte
     *  au démarrage sans passer par la modale. Propagé à l'éditeur. */
    geoPoint = input(null);
    /** Force le layout compact (drawer/sheet) sur grand viewport — utile pour iframe/modal étroites. */
    compactMode = input(false);
    /** Mode visualisation : seuls select & pan, tous les objets verrouillés, sidebar/menus d'édition masqués. */
    readOnly = input(false);
    /** Pièces du CRI proposées pour lier une pièce dessinée. Propagé à l'éditeur. */
    criRooms = input([]);
    /** Prélèvements CRI à positionner (pose guidée). Propagé à l'éditeur. */
    pendingSamples = input([]);
    // ── OUTPUTS ─────────────────────────────────────────────
    projectChange = output();
    statsChanged = output();
    roomsChanged = output();
    jpgExported = output();
    pngExported = output();
    svgExported = output();
    summaryChange = output();
    roomLinked = output();
    samplePlaced = output();
    // ── ÉTAT ────────────────────────────────────────────────
    activeTab = signal('scanner');
    detectedWalls = signal(null);
    setTab(tab) {
        this.activeTab.set(tab);
    }
    onWallsDetected(payload) {
        this.detectedWalls.set(payload);
        this.activeTab.set('editor');
    }
    onProjectSaved(project) {
        this.project.set(project);
        this.projectChange.emit(project);
    }
    onStatsChanged(stats) {
        this.statsChanged.emit(stats);
    }
    onRoomsChanged(rooms) {
        this.roomsChanged.emit(rooms);
    }
    onJpgExported(blob) { this.jpgExported.emit(blob); }
    onPngExported(blob) { this.pngExported.emit(blob); }
    onSvgExported(svg) { this.svgExported.emit(svg); }
    onSummaryChange(s) { this.summaryChange.emit(s); }
    onRoomLinked(e) { this.roomLinked.emit(e); }
    onSamplePlaced(e) { this.samplePlaced.emit(e); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: FloorplanComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: FloorplanComponent, isStandalone: true, selector: "ng-gplan", inputs: { project: { classPropertyName: "project", publicName: "project", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, scannerParams: { classPropertyName: "scannerParams", publicName: "scannerParams", isSignal: true, isRequired: false, transformFunction: null }, autoGeoLayer: { classPropertyName: "autoGeoLayer", publicName: "autoGeoLayer", isSignal: true, isRequired: false, transformFunction: null }, geoPoint: { classPropertyName: "geoPoint", publicName: "geoPoint", isSignal: true, isRequired: false, transformFunction: null }, compactMode: { classPropertyName: "compactMode", publicName: "compactMode", isSignal: true, isRequired: false, transformFunction: null }, readOnly: { classPropertyName: "readOnly", publicName: "readOnly", isSignal: true, isRequired: false, transformFunction: null }, criRooms: { classPropertyName: "criRooms", publicName: "criRooms", isSignal: true, isRequired: false, transformFunction: null }, pendingSamples: { classPropertyName: "pendingSamples", publicName: "pendingSamples", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { project: "projectChange", projectChange: "projectChange", statsChanged: "statsChanged", roomsChanged: "roomsChanged", jpgExported: "jpgExported", pngExported: "pngExported", svgExported: "svgExported", summaryChange: "summaryChange", roomLinked: "roomLinked", samplePlaced: "samplePlaced" }, ngImport: i0, template: "<div class=\"ngf-floorplan\" [class.ngf-floorplan--split]=\"layout() === 'split'\">\n\n  @if (layout() === 'tabs') {\n    <div class=\"ngf-floorplan__tabs\">\n      <button class=\"ngf-floorplan__tab\"\n        [class.ngf-floorplan__tab--active]=\"activeTab() === 'scanner'\"\n        (click)=\"setTab('scanner')\">\n        Scanner\n      </button>\n      <button class=\"ngf-floorplan__tab\"\n        [class.ngf-floorplan__tab--active]=\"activeTab() === 'editor'\"\n        (click)=\"setTab('editor')\">\n        Editeur\n      </button>\n    </div>\n\n    <div class=\"ngf-floorplan__content\">\n      @if (activeTab() === 'scanner') {\n        <ng-gplan-scanner\n          [initialParams]=\"scannerParams()\"\n          (wallsDetected)=\"onWallsDetected($event)\"\n        />\n      }\n      @if (activeTab() === 'editor') {\n        <ng-gplan-plan-editor\n          [initialWalls]=\"detectedWalls()\"\n          [project]=\"project()\"\n          [autoGeoLayer]=\"autoGeoLayer()\"\n          [geoPoint]=\"geoPoint()\"\n          [compactMode]=\"compactMode()\"\n          [readOnly]=\"readOnly()\"\n          [criRooms]=\"criRooms()\"\n          [pendingSamples]=\"pendingSamples()\"\n          (projectSaved)=\"onProjectSaved($event)\"\n          (projectChange)=\"onProjectSaved($event)\"\n          (statsChanged)=\"onStatsChanged($event)\"\n          (roomsChanged)=\"onRoomsChanged($event)\"\n          (jpgExported)=\"onJpgExported($event)\"\n          (pngExported)=\"onPngExported($event)\"\n          (svgExported)=\"onSvgExported($event)\"\n          (summaryChange)=\"onSummaryChange($event)\"\n          (roomLinked)=\"onRoomLinked($event)\"\n          (samplePlaced)=\"onSamplePlaced($event)\"\n        />\n      }\n    </div>\n  }\n\n  @if (layout() === 'split') {\n    <div class=\"ngf-floorplan__split-pane\">\n      <div class=\"ngf-floorplan__pane\">\n        <ng-gplan-scanner\n          [initialParams]=\"scannerParams()\"\n          (wallsDetected)=\"onWallsDetected($event)\"\n        />\n      </div>\n      <div class=\"ngf-floorplan__pane\">\n        <ng-gplan-plan-editor\n          [initialWalls]=\"detectedWalls()\"\n          [project]=\"project()\"\n          [autoGeoLayer]=\"autoGeoLayer()\"\n          [geoPoint]=\"geoPoint()\"\n          [compactMode]=\"compactMode()\"\n          [readOnly]=\"readOnly()\"\n          [criRooms]=\"criRooms()\"\n          [pendingSamples]=\"pendingSamples()\"\n          (projectSaved)=\"onProjectSaved($event)\"\n          (statsChanged)=\"onStatsChanged($event)\"\n          (roomsChanged)=\"onRoomsChanged($event)\"\n          (jpgExported)=\"onJpgExported($event)\"\n          (pngExported)=\"onPngExported($event)\"\n          (svgExported)=\"onSvgExported($event)\"\n          (summaryChange)=\"onSummaryChange($event)\"\n          (roomLinked)=\"onRoomLinked($event)\"\n          (samplePlaced)=\"onSamplePlaced($event)\"\n        />\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{--z-200: #e5e5e5;--z-400: #a3a3a3;--primary: #f97316;--primary-hover: #ea580c;--primary-light: #fff7ed;--primary-border: #fed7aa;--font: \"Poppins\", ui-sans-serif, system-ui, sans-serif;display:flex;flex-direction:column;height:100%;font-family:var(--font)}.ngf-floorplan{display:flex;flex-direction:column;height:100%}.ngf-floorplan__tabs{display:flex;align-items:stretch;background:#fff;border-bottom:1px solid var(--z-200);flex-shrink:0;padding:0 8px;gap:2px;height:46px;box-shadow:0 1px 4px #0000000f}.ngf-floorplan__tab{padding:0 20px;color:var(--z-400);font-size:12px;font-weight:600;font-family:var(--font);cursor:pointer;border:none;background:none;letter-spacing:.01em;transition:color .12s;position:relative}.ngf-floorplan__tab:after{content:\"\";position:absolute;bottom:0;left:8px;right:8px;height:3px;background:var(--primary);border-radius:3px 3px 0 0;transform:scaleX(0);transition:transform .15s cubic-bezier(.34,1.56,.64,1)}.ngf-floorplan__tab:hover{color:var(--primary)}.ngf-floorplan__tab--active{color:var(--primary);font-weight:700}.ngf-floorplan__tab--active:after{transform:scaleX(1)}.ngf-floorplan__content{flex:1;min-height:0;display:flex;flex-direction:column}.ngf-floorplan__split-pane{display:flex;flex:1;min-height:0}.ngf-floorplan__pane{flex:1;min-width:0;overflow:hidden;border-right:1px solid var(--z-200)}.ngf-floorplan__pane:last-child{border-right:none}\n"], dependencies: [{ kind: "component", type: ScannerComponent, selector: "ng-gplan-scanner", inputs: ["initialParams", "showControls", "showTabs"], outputs: ["wallsDetected", "paramsChanged", "opencvReady"] }, { kind: "component", type: PlanEditorComponent, selector: "ng-gplan-plan-editor", inputs: ["initialWalls", "project", "showSidebar", "showHeader", "canvasHeight", "canvasWidth", "autoGeoLayer", "geoPoint", "compactMode", "readOnly", "criRooms", "pendingSamples"], outputs: ["projectSaved", "projectChange", "statsChanged", "roomsChanged", "jpgExported", "pngExported", "svgExported", "canvasReady", "loadingState", "summaryChange", "roomLinked", "samplePlaced"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: FloorplanComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-gplan', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [ScannerComponent, PlanEditorComponent], template: "<div class=\"ngf-floorplan\" [class.ngf-floorplan--split]=\"layout() === 'split'\">\n\n  @if (layout() === 'tabs') {\n    <div class=\"ngf-floorplan__tabs\">\n      <button class=\"ngf-floorplan__tab\"\n        [class.ngf-floorplan__tab--active]=\"activeTab() === 'scanner'\"\n        (click)=\"setTab('scanner')\">\n        Scanner\n      </button>\n      <button class=\"ngf-floorplan__tab\"\n        [class.ngf-floorplan__tab--active]=\"activeTab() === 'editor'\"\n        (click)=\"setTab('editor')\">\n        Editeur\n      </button>\n    </div>\n\n    <div class=\"ngf-floorplan__content\">\n      @if (activeTab() === 'scanner') {\n        <ng-gplan-scanner\n          [initialParams]=\"scannerParams()\"\n          (wallsDetected)=\"onWallsDetected($event)\"\n        />\n      }\n      @if (activeTab() === 'editor') {\n        <ng-gplan-plan-editor\n          [initialWalls]=\"detectedWalls()\"\n          [project]=\"project()\"\n          [autoGeoLayer]=\"autoGeoLayer()\"\n          [geoPoint]=\"geoPoint()\"\n          [compactMode]=\"compactMode()\"\n          [readOnly]=\"readOnly()\"\n          [criRooms]=\"criRooms()\"\n          [pendingSamples]=\"pendingSamples()\"\n          (projectSaved)=\"onProjectSaved($event)\"\n          (projectChange)=\"onProjectSaved($event)\"\n          (statsChanged)=\"onStatsChanged($event)\"\n          (roomsChanged)=\"onRoomsChanged($event)\"\n          (jpgExported)=\"onJpgExported($event)\"\n          (pngExported)=\"onPngExported($event)\"\n          (svgExported)=\"onSvgExported($event)\"\n          (summaryChange)=\"onSummaryChange($event)\"\n          (roomLinked)=\"onRoomLinked($event)\"\n          (samplePlaced)=\"onSamplePlaced($event)\"\n        />\n      }\n    </div>\n  }\n\n  @if (layout() === 'split') {\n    <div class=\"ngf-floorplan__split-pane\">\n      <div class=\"ngf-floorplan__pane\">\n        <ng-gplan-scanner\n          [initialParams]=\"scannerParams()\"\n          (wallsDetected)=\"onWallsDetected($event)\"\n        />\n      </div>\n      <div class=\"ngf-floorplan__pane\">\n        <ng-gplan-plan-editor\n          [initialWalls]=\"detectedWalls()\"\n          [project]=\"project()\"\n          [autoGeoLayer]=\"autoGeoLayer()\"\n          [geoPoint]=\"geoPoint()\"\n          [compactMode]=\"compactMode()\"\n          [readOnly]=\"readOnly()\"\n          [criRooms]=\"criRooms()\"\n          [pendingSamples]=\"pendingSamples()\"\n          (projectSaved)=\"onProjectSaved($event)\"\n          (statsChanged)=\"onStatsChanged($event)\"\n          (roomsChanged)=\"onRoomsChanged($event)\"\n          (jpgExported)=\"onJpgExported($event)\"\n          (pngExported)=\"onPngExported($event)\"\n          (svgExported)=\"onSvgExported($event)\"\n          (summaryChange)=\"onSummaryChange($event)\"\n          (roomLinked)=\"onRoomLinked($event)\"\n          (samplePlaced)=\"onSamplePlaced($event)\"\n        />\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{--z-200: #e5e5e5;--z-400: #a3a3a3;--primary: #f97316;--primary-hover: #ea580c;--primary-light: #fff7ed;--primary-border: #fed7aa;--font: \"Poppins\", ui-sans-serif, system-ui, sans-serif;display:flex;flex-direction:column;height:100%;font-family:var(--font)}.ngf-floorplan{display:flex;flex-direction:column;height:100%}.ngf-floorplan__tabs{display:flex;align-items:stretch;background:#fff;border-bottom:1px solid var(--z-200);flex-shrink:0;padding:0 8px;gap:2px;height:46px;box-shadow:0 1px 4px #0000000f}.ngf-floorplan__tab{padding:0 20px;color:var(--z-400);font-size:12px;font-weight:600;font-family:var(--font);cursor:pointer;border:none;background:none;letter-spacing:.01em;transition:color .12s;position:relative}.ngf-floorplan__tab:after{content:\"\";position:absolute;bottom:0;left:8px;right:8px;height:3px;background:var(--primary);border-radius:3px 3px 0 0;transform:scaleX(0);transition:transform .15s cubic-bezier(.34,1.56,.64,1)}.ngf-floorplan__tab:hover{color:var(--primary)}.ngf-floorplan__tab--active{color:var(--primary);font-weight:700}.ngf-floorplan__tab--active:after{transform:scaleX(1)}.ngf-floorplan__content{flex:1;min-height:0;display:flex;flex-direction:column}.ngf-floorplan__split-pane{display:flex;flex:1;min-height:0}.ngf-floorplan__pane{flex:1;min-width:0;overflow:hidden;border-right:1px solid var(--z-200)}.ngf-floorplan__pane:last-child{border-right:none}\n"] }]
        }] });

/*
 * Public API Surface of g-plan
 */
// Models

/**
 * Generated bundle index. Do not edit.
 */

export { AC_PICTOGRAMS, AC_PICTOGRAM_TYPE, ALL_WORK_MODES, APARTMENT_TEMPLATES, CanvasDropDirective, DEFAULT_DETECTION_PARAMS, DEFAULT_WORK_MODES, ExportService, FABRIC_SAVED_TYPES, FLOORPLAN_CONFIG, FabricCanvasService, FloorplanComponent, GPLAN_VERSION, GeometryService, HistoryService, InspectorPanelComponent, MetersPipe, OpenCvService, OsmModalComponent, OsmService, PIPE_LABELS, PIPE_ORDER, PlanAnalysisService, PlanEditorComponent, ROOM_NAMES, ROOM_NAMES_CARREZ_EXCLUDED, SPANC_PICTOGRAMS, SPANC_PICTOGRAM_TYPE, SURFACE_DISCLAIMER, ScannerComponent, TOOL_GROUPS, Viewer3DComponent, WORK_MODES, WORK_MODES_STORAGE_KEY, WallDetectionService, collectLegendItems, isAcPictogramMode, isSpancPictogramMode, provideGPlan };
//# sourceMappingURL=g-plan.mjs.map
